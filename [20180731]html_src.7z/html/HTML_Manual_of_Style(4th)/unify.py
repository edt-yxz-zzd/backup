

if __name__ == '__main__':
    import sys
    s = frozenset(line[:-1] if line[-1:] == '\n' else line
                  for line in sys.stdin)
    #pprint(sorted(s))
    ls = sorted(s)
    print('\n'.join(ls))
    
