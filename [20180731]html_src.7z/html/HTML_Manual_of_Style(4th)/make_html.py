
import sand
import argparse


'''
let temp.txt:
<fname>
<html_content>
<eof>

to <fname>.html:
<html_content>
'''

txt_fname = 'temp.txt'

def to_html(txt_fname):
    with open(txt_fname, 'rb') as fin:
        firstline = fin.readline()
        fname = firstline[:-1].decode('utf-8')
        
        if not fname:
            raise ValueError('file name is empty')
        fname += '.html'
        content = fin.read()


    with open(fname, 'xb') as fout:
        fout.write(content)

def main(args = None):
    parser = argparse.ArgumentParser(description='Make html from txt')
    parser.add_argument('src', type=str,
                       help='text file name')

    args = parser.parse_args(args)
    to_html(args.src)


if sand.is_main(__name__):
    main()






        
