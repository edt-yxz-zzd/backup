
import io
from sand import colors_in_matplotlib, colors_in_tkinter

color_steps = tuple(range(0, 256, 51))

color_table = [[(R, G, B) for B in color_steps] for R in color_steps for G in color_steps]
str_colors_in_css2_1 = r'''
Color Name  RGB Decimal  RGB Percentage  Hexadecimal
black  rgb(0,0,0)  rgb(0%,0%,0%)  #000000
white  rgb(255,255,255)  rgb(100%,100%,100%)  #ffffff
red  rgb(255,0,0)  rgb(100%,0%,0%)  #ff0000
yellow  rgb(255,255,0)  rgb(100%,100%,0%)  #ffff00
green  rgb(0,128,0)  rgb(0%,50%,0%)  #008000
aqua  rgb(0,255,255)  rgb(0%,100%,100%)  #00ffff
blue  rgb(0,0,255)  rgb(0%,0%,100%)  #0000ff
fuchsia  rgb(255,0,255)  rgb(100%,0%,100%)  #ff00ff
gray  rgb(128,128,128)  rgb(50%,50%,50%)  #808080
silver  rgb(192,192,192)  rgb(75%,75%,75%)  #c0c0c0
orange  rgb(255,170,0)  rgb(100%,67%,0%)  #ffaa00
olive  rgb(128,128,0)  rgb(50%,50%,0%)  #808000
lime  rgb(0,255,0)  rgb(0%,100%,0%)  #00ff00
teal  rgb(0,128,128)  rgb(0%,50%,50%)  #008080
purple  rgb(128,0,128)  rgb(50%,0%,50%)  #800080
navy  rgb(0,0,128)  rgb(0%,0%,50%)  #000080
maroon  rgb(128,0,0)  rgb(50%,0%,0%)  #800000
'''

with io.StringIO(str_colors_in_css2_1) as fin:
    lines = list(fin)[2:]
    color17_name_rgb = [(parts[0], parts[-1]) for line in lines
                        for parts in [line.split()]]
    assert len(color17_name_rgb) == 17

    


html_tpl = r'''
<!DOCTYPE html>
<html>
<head>
    <title>colors</title>
    <style type="text/css">
        body { padding-top: 36px; }
        th, td { padding: 3px 6px; }
        thead th { text-align: right; }
        th { text-align: left; }
        td { text-align: right; }
        caption { font-style: italic; }
    </style>
</head>

<body>
    <table cellspacing="0" border="1" align="center" width="80%">
    <caption>colors</caption>
    <tbody>
    <<tbody>>
    </tbody>
    </table>

    <ul>
    <<color_name_rgb_ul>>
    </ul>
</body>
</html>
'''


def reverse_color(rgb):
    return tuple(255 - x for x in rgb)

def far_color(color):
    return 255 if color < 128 else 0

def far_rgb(rgb):
    return tuple(far_color(x) for x in rgb)


def to_tbody(color_table):
    color_tpl = r'rgb({},{},{})'
    hcolor_tpl = '#' + '{:02x}' * 3
    td_tpl = r'<td style="color:{fgcolor}; background-color:{bgcolor};">{content!s}</td>'
    tr_tpl = r'<tr>{row}</tr>'
    ls = []
    for row in color_table:
        tmp = [td_tpl.format(fgcolor=hcolor_tpl.format(*far_rgb(rgb)),
                             bgcolor=color, content=color)
               for rgb in row
               for color in [hcolor_tpl.format(*rgb)]]
        ls.append(tr_tpl.format(row = ''.join(tmp)))
    tbody = ''.join(ls)
    return tbody

def to_color_name_rgb_ul(color_name_rgb_ls):
    li_tpl = r'<li>{name}{rgb}<span style="white-space:pre-wrap; background-color:{bgcolor};">    </span></li>'
    ul = ''.join(li_tpl.format(name=name, rgb=rgb, bgcolor=rgb) for name, rgb in color_name_rgb_ls)
    return ul


def to_html(color_table, html_tpl, color_name_rgb_ls):
    tbody = to_tbody(color_table)
    ul = to_color_name_rgb_ul(color_name_rgb_ls)

    html = html_tpl.replace('<<tbody>>', tbody)
    html = html.replace('<<color_name_rgb_ul>>', ul)
    return html


##import pprint
##pprint.PrettyPrinter(4).pprint(dict(color17_name_rgb))
##raise

def main():
    #html = to_html(color_table, html_tpl, color17_name_rgb)

    ls1 = list(colors_in_matplotlib.items())
    ls1.sort()
    ls2 = list(colors_in_tkinter.items())
    ls2.sort()
    ls = color17_name_rgb + ls1 + ls2
    html = to_html(color_table, html_tpl, ls)
    with open('colors.html', 'x') as fout:
        fout.write(html)

main()


                  
