var indexApiURL = "http://sext.ie.sogou.com/app/video/home_new.html";             // 首页
var xsxpApiURL = "http://sext.ie.sogou.com/app/video/essay.html"; //相声
var hotApiURL = "http://sext.ie.sogou.com/app/video/hot.html"; //热门
var mtvApiURL = "http://sext.ie.sogou.com/app/video/mv.html"; //mtv
var tvApiURL = "http://sext.ie.sogou.com/app/video/tv.html";  //电视剧场
var cartoonApiURL = "http://sext.ie.sogou.com/app/video/comic.html"; //卡通
var varietyApiURL = "http://sext.ie.sogou.com/app/video/variety.html"; //综艺
var movieApiURL = "http://sext.ie.sogou.com/app/video/movie.html"; //热播电影