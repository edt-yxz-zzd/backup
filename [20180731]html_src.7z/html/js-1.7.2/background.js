/*初次安装不弹出向导页，再次打开浏览器弹出*/
var flag = false, timer = 0, sW = 471, sH = 318, aW = 0, aH = 0, getCalc = 0, hid, newestEqList = {}, curEqName, curEqUUID, calcCBFn = '',dlCB,dlDes,curDlTabs = {};

var downloadTips = function(){
    sogouExplorer.tabs.getSelected(function(tab){
        if(localStorage.getItem('downLoadTips') == '0'){
            return
        }
        closCurWin('dlballoon');

        var reg = /^(http|https):\/\/(\S)*\.(apk|ipa|epub|pdf|txt|torrent|mp3|wav|doc|docx|xls|xlsx|ppt|pptx|mp4|flv|wma|avi|mkv|rm|3gp)$/ig;
        if(!!tab.url.match(reg)){
            var dlUrlArr = tab.url.split('.'),extNameIdx = dlUrlArr.length- 1,dlExtName = dlUrlArr[extNameIdx].toLowerCase(),dlFileType;

            switch(dlExtName){
                case 'apk':
                case 'ipa':
                    dlFileType = '应用';
                    break;
                case 'epub':
                    dlFileType = '电子书';
                    break;
                case 'pdf':
                    dlFileType = 'PDF';
                    break;
                case 'txt':
                    dlFileType = 'TXT';
                    break;
                case 'torrent':
                    dlFileType = 'BT种子';
                    break;
                case 'mp3':
                case 'wav':
                    dlFileType = '歌曲';
                    break;
                case 'doc':
                case 'docx':
                case 'xls':
                case 'xlsx':
                case 'ppt':
                case 'pptx':
                    dlFileType = '文档';
                    break;
                case 'mp4':
                case 'flv':
                case 'wma':
                case 'avi':
                case 'mkv':
                case 'rm':
                case '3gp':
                    dlFileType = '视频';
                    break;
            }

            getEqList(function(){

                if(!newestEqList.length){
                    dlDes = '你还可以将这个'+ dlFileType +'直接下载到你的手机上 ，无需数据线，无需账号。';
                    localStorage.setItem('autoSend',1);
                    dlCB = function(){
                        getEqList(clickPageIcon,[1,null],1);
                    };
                }
                else{
                    dlDes = '你还可以把这个'+ dlFileType +'直接下载到你的 ' + JSON.parse(localStorage.getItem("lastSentEq")).eqname;
                    dlCB = function(){
                        getEqList(clickPageIcon,[1,null]);
                    };
                }
                if(!!Object.keys(curDlTabs).length){
                    for(var key in curDlTabs){
                        if(tab.id == ~~key){
                            return
                        }
                    }
                    sogouExplorer.browserAction.showHTMLBalloon({'path':'dlballoon.html','width':292,'height':142,'timeout':60000});

                }
                else{
                    sogouExplorer.browserAction.showHTMLBalloon({'path':'dlballoon.html','width':292,'height':142,'timeout':60000});
                }

            })
        }
    })
};

sogouExplorer.tabs.onUpdated.addListener(function(tabId,changeInfo,tab){
    if(!!changeInfo.url){
        downloadTips();
    }
});

sogouExplorer.tabs.onRemoved.addListener(function(tabId, removeInfo){
    for(var key in curDlTabs){
        if(tabId === ~~key){
            delete curDlTabs[key];
        }
    }
});

sogouExplorer.tabs.onSelectionChanged.addListener(downloadTips);



if(localStorage.getItem("isInstalled") == null){
    localStorage.setItem("isInstalled",0);
}
else{
    var installedFlag = parseInt(localStorage.getItem("isInstalled"));
    ++installedFlag;
    localStorage.setItem("isInstalled",installedFlag);
    if(installedFlag == 1){
        sogouExplorer.tabs.create({"url":"http://mse.sogou.com/app/features/feichuan.html","selected":true});
        sogouExplorer.browserAction.showHTMLBalloon({'path':'balloon.html','width':259,'height':96,'timeout':60000});
    }
}

function onGetCurrentUser(m,apid){
    hid = m;
}
sogouExplorer.command.userInfo.getUserID(onGetCurrentUser);

/*设置工具栏按钮browserAction*/
sogouExplorer.browserAction.setTitle({title:"发送到手机"});
sogouExplorer.browserAction.setDescription({description:'将当前网页一键发送到手机'});
sogouExplorer.browserAction.onClicked.addListener(function(tab){
    closCurWin('dlballoon','tips');
    tipForTimeout();
//    getEqList(clickPageIcon,[1,null]);
    getEqList(clickMenuOption);

    /*点击工具栏按钮的pingback*/
    ping({"hid":hid,"btn":"browseraction"});

});
updateEqTips();

/*自定义右键*/
var menuItems = [
    {
        type: "normal",
        title: "设备列表",
        contexts: ["mainframe"],
        onclick: function(){
            tipForTimeout();
            getEqList(clickMenuOption);
        }
    },
    {
        type: "normal",
        title: "发送链接到手机",
        contexts: ["link"],
        icon: {"path":'images/default.png'},
        onclick: function(info,documentUrlPatterns,targetUrlPatterns){
            tipForTimeout();
            /*点击右键菜单的pingback*/
            ping({"hid":hid,"btn":"contextmenu"});

            var curUrl = info.linkUrl;
            if($.trim(info.linkUrl).indexOf('sbwk') === 0){
                curUrl = 'se';
            }
            getEqList(clickPageIcon,[0,curUrl]);
        }
    },
    {
        type: "normal",
        title: "发送当前网址到手机",
        contexts: ["page"],
        icon: {"path":'images/default.png'},
        onclick: function(info,documentUrlPatterns,targetUrlPatterns){
            tipForTimeout();
            /*点击右键菜单的pingback*/
            ping({"hid":hid,"btn":"contextmenu"});

            var curUrl = info.pageUrl;
            if($.trim(info.pageUrl).indexOf('sbwk') === 0){
                curUrl = 'se';
            }
            getEqList(clickPageIcon,[0,curUrl]);
        }
    },
    {
        type: "normal",
        title: "发送文本到手机",
        contexts: ["selection"],
        icon: {"path":'images/default.png'},
        onclick: function(info,documentUrlPatterns,targetUrlPatterns){
            tipForTimeout();
            //点击右键菜单的pingback
            ping({"hid":hid,"btn":"contextmenu"});

            var curselected = info.selectionText;
            getEqList(clickPageIcon,[2,{"curUrl":info.pageUrl,"curselected":curselected}]);
        }
    }
];
for(var i in menuItems){
    sogouExplorer.contextMenus.create(menuItems[i]);
}



/*选中文字内容发送*/
function sendSelection(param){
    var sendCon = param.curselected ? param.curselected : param;
    sogouExplorer.tabs.getSelected(function(tab){
        var port2cs = sogouExplorer.tabs.connect(tab.id),
            odata = '{"hid":"'+hid+'","uuid":"'+curEqUUID+'","data":"'+sendCon+'","title":"'+sendCon.substr(0,30)+'"}';
        $.ajax({
            type:'POST',
            url:'http://sync.mse.sogou.com/sendtext',
            data:odata,
            success:function(succinfo){
                tipMsg = '正在发送到'+ curEqName;
                rCmd = 'succ_regular';
                calcWinOffset();

                ping({"hid":hid,"uuid":curEqUUID,"url":tab.curUrl,"title":tab.title,"selectedText":param.curselected,"send_t":new Date()});
            },
            error:function(errorinfo){
                tipMsg = '发送失败，请稍后再试！';
                rCmd = 'err';
                calcWinOffset();
            }
        })
    })
}

/*设置pageAction*/
setPageIcon();
sogouExplorer.tabs.onSelectionChanged.addListener(function(tabId){
    setPageIcon();
})
sogouExplorer.tabs.onCreated.addListener(function(tabId){
    setPageIcon();
})

sogouExplorer.pageAction.onClicked.addListener(function(tab){
    /*点击pageaction的pingback*/
    ping({"hid":hid,"btn":"pageaction"});

    sogouExplorer.tabs.getSelected(function(tab){
        sogouExplorer.pageAction.setIcon({tabId:tab.id, path:'images/default-active.png'});
        setTimeout(function(){
            sogouExplorer.pageAction.setIcon({tabId:tab.id, path:'images/default.png'});
        },200)
    });

    getEqList(clickPageIcon,[1,null]);

    /*address getText*/
    /*sogouExplorer.command.address.getText(function(addtext){
        var isUrl = (/(http|https|ftp):\/\//ig).test(addtext);  //true - url
        console.log('isUrl: ',isUrl );
        if(!isUrl){//非标准url，走sendSelection
            getEqList(clickPageIcon,[2,addtext]);
        }
        else{
            getEqList(clickPageIcon,[1,null]);
        }
    });*/
});


/*接收列表页的指令*/
sogouExplorer.extension.onConnect.addListener(function(port){
    port.onMessage.addListener(function(data) {
        switch (data.cmd){
            case "showQR":
//                        localStorage.setItem("qrclose","dowait");
                calcOffset(showQRWin);
                break;
            case "uploadFile":
                break;
            case "updateEqTips":
                updateEqTips(data);
                break;
        }
    });
    port.onDisconnect.addListener(function(data){
    })
});


function longPoll(){
    var XPromise;
    function doPoll(){
        XPromise = $.ajax({
            type:"GET",
            url:"http://sync.mse.sogou.com/checkbind?hid="+hid
        });
        XPromise.done(function(succinfo, msg, xhr){
            if(xhr.status == 200 && succinfo.toLowerCase().indexOf('ok') !== -1){
                localStorage.setItem("qrclose","doclose");
                getEqList(null,null,1);
            }
            else{
                XPromise = null;
                longPoll()();
            }
        }).fail(function(errinfo){
            });

        return XPromise;
    }

    return function(){
        if(XPromise){
            return XPromise;
        }
        return XPromise = doPoll();
    };
}

/*为低版本se计算窗体宽高差值*/
/*接收QR页指令，轮询设备最新状态*/
/*点击pageActionIcon*/
var tipMsg = '正在发送到'+ curEqName,
    rCmd = 'succ_regular',
    posLeft = 0,
    posTop = 0; //succ_regular/succ_se/err
sogouExplorer.extension.onRequest.addListener(function (response, msg, sendResponse) {
    switch (response.cmd){
        case "calced":
            aW = sW + response.param.deltaW;
            aH = sH + response.param.deltaH;
            localStorage.setItem('aW',aW);
            localStorage.setItem('aH',aH);
            sendResponse({"cmd":"calcclos"});
            calcCBFn();
            break;
        case "poll":
            /*避免轮询*/
            longPoll()();
            break;
        case "stoppolling":
            var curXPromise = longPoll()();
            curXPromise.abort();
            clearInterval(timer);
            break;
        case "changeisOpen":
            break;
        case 'calcwinoffset':
            var offsetData = response.offset;
            posLeft = offsetData.win_width - 325 - 20 + offsetData.win_SL;
            posTop = offsetData.win_ST + 20;
            showTipMsg(rCmd,tipMsg);
            break;
        case 'tipsdone':
            sendResponse({"rCmd":rCmd,"eqName" : curEqName,"tipMsg" : tipMsg});
            break;
        case 'downLoad':
            setTimeout(function(){
                dlCB();
            },0);
            break;
        case 'dlBalloonDone':
            sendResponse({"cmd":"setDlTips","text" : dlDes});
            break;
        case 'downLoadTipsClose':
            var dlCloseTabId = response.tabId;
            curDlTabs[dlCloseTabId] = false;
    }
});

function calcOffset(cb){
    //todo 判断本地是否存过版本号、以及升级后版本号比对，来决定是否再计算一次
    var lastVer = !localStorage.getItem("curVer") ? '' : localStorage.getItem("curVer");
    if(sogouExplorer.command.userInfo && sogouExplorer.command.userInfo.getSEVersion){
        sogouExplorer.command.userInfo.getSEVersion(function(arg) {//这里是异步得到version，故subCalc()要分别写在两个分支
            localStorage.setItem("curVer",arg);
            if(versionCompare(arg, "5.0.8") >= 0) {
                localStorage.setItem('aW',sW);
                localStorage.setItem('aH',sH);
                if(cb) {
                    cb();
                }
            }
            else {
                subCalc();
            }
        })
    }
    else{
        localStorage.setItem("curVer",'4.0.2.0000');
        subCalc();
    }
    function subCalc(){
        if(lastVer !== localStorage.getItem("curVer")){
            sogouExplorer.windows.create({
                url:"calcoffset.html",
                width:200,
                height:200,
                left:-2000,
                top:-2000,
                type:"popup",
                uniqueId:"com.sogou.calc",
                reNavigate:true,
                resizable:false
            });
            if(cb){
                calcCBFn = cb;
            }
        }
        else{
            if(cb){
                cb();
            }
        }
    }
}

/*set pageAction*/
function setPageIcon(){
    sogouExplorer.tabs.getSelected(function(tab){

        sogouExplorer.command.userInfo && sogouExplorer.command.userInfo.getSEVersion && sogouExplorer.command.userInfo.getSEVersion(function(arg) {
//                    if (arg >= "4.1.3.8157"){
            if (versionCompare(arg,"4.1.3.8157") >= 0){
                sogouExplorer.pageAction.setIcon({tabId:tab.id, path:'images/default.png'});
//                sogouExplorer.pageAction.setTitle({tabId:tab.id, title: "一键发送到手机"});
                sogouExplorer.pageAction.show(tab.id);
            }
        })
    });
}

/*显示二维码弹窗*/
function showQRWin(){
    sogouExplorer.windows.create({
        url:"popup.html",
        width:!localStorage.getItem('aW') ? sW : parseInt(localStorage.getItem('aW')),
        height:!localStorage.getItem('aH') ? sH : parseInt(localStorage.getItem('aH')),
        left:Math.floor((window.screen.width-470)/2),
        top:Math.floor((window.screen.height-318)/2),
        type:"popup",
        uniqueId:"com.sogou.pc2mt",
        reNavigate:true,
        resizable:false,
        topMost:true
    });
}

/*显示设备列表弹窗*/
function showEqWin(){
    sogouExplorer.windows.create({
        url:"eqlists.html",
        width:!localStorage.getItem('aW') ? sW : parseInt(localStorage.getItem('aW')),
        height:!localStorage.getItem('aH') ? sH : parseInt(localStorage.getItem('aH')),
        left:Math.floor((window.screen.width-470)/2),
        top:Math.floor((window.screen.height-318)/2),
        type:"popup",
        uniqueId:"com.sogou.pc2mt",
        reNavigate:true,
        resizable:false,
        topMost:true
    });
}

/*获取最新设备信息*/
function getEqList(cb,param,isLongPoll){
    $.getJSON("http://sync.mse.sogou.com/checkpair",{"hid":hid}, function(data){
        /*按绑定时间由近到远排序*/
        var len = data.length,newdata = data,lastSentEqIdx = 0;
        if(!!len){
            for(var i=0; i<len; i++){
                for(var j=len-1; j>0; j--){
                    if(data[j].tm > data[j-1].tm){
                        var temp = data[j-1];
                        newdata[j-1] = data[j];
                        newdata[j] = temp;
                    }
                }
            }
            if((localStorage.getItem("equip") !== null && newdata.length > JSON.parse(localStorage.getItem("equip")).length) || (localStorage.getItem("equip") == null && newdata.length > 0) || !!isLongPoll){

                if(!!isLongPoll){
                    calcOffset(showEqWin);

                    if(localStorage.getItem('autoSend') == '1'){
                        localStorage.setItem('autoSend',0);
                        sogouExplorer.tabs.getSelected(function(tab){
                            setTimeout(function(){
                                /*var port2eq = sogouExplorer.tabs.connect(tab.id);
                                port2eq.postMessage({cmd:"autoSend"})*/
                            sogouExplorer.extension.sendRequest({"cmd":"autoSend"},function(){})
                            },600)
                        })

                    }
                }
            }
            else{
                for(var z= 0;z<len;z++){
                    if(newdata[z].name === JSON.parse(localStorage.getItem("lastSentEq")).eqname){
                        lastSentEqIdx = z;
//                        return
                    }
                }
                localStorage.setItem("qrclose","dowait");
            }
            var lastSentEq = '{"idx":"'+ lastSentEqIdx +'","eqid":"'+ newdata[lastSentEqIdx].uuid +'","eqname":"'+ newdata[lastSentEqIdx].name +'"}';
            localStorage.setItem("lastSentEq",lastSentEq);
            localStorage.setItem("equip",JSON.stringify(newdata));
            newestEqList = newdata;
            if(cb){
                cb(param);
            }
        }
        else{
            newestEqList = {};
            localStorage.removeItem('equip');
            setTimeout(function(){
                if(cb){
                    cb(param);
                }
            },0)
        }
    })
}

function calcWinOffset(){//通过executescript计算tips位置
    sogouExplorer.tabs.getSelected(function(tab) {
        sogouExplorer.tabs.executeScript(tab.id, {"file": "js/calcwinoffset.js", "allFrames": false},function(response){
        });
    })
}

function showTipMsg(rcmd,tipmsg){
    sogouExplorer.windows.getCurrent(function(win){
        sogouExplorer.tabs.getSelected(function(tab) {
            tipMsg = tipmsg;
            rCmd = rcmd;

            closCurWin('tips');
            if(localStorage.getItem("markConfirm") == "1"){
                sogouExplorer.extension.sendRequest({"cmd":"confirmHide"},function(){})
            }
            closCurWin('dlballoon');

            if(sogouExplorer.command.userInfo && sogouExplorer.command.userInfo.getSEVersion){
                sogouExplorer.command.userInfo.getSEVersion(function(arg) {
                    if(versionCompare(arg,'5.0.0') >= 0){
                        //TODO 新的layer调用
                        sogouExplorer.windows.advanced.createLayered({
                            "url": "tips.html",
                            "x": 0, "y": 0,
                            "width": 320, "height": 260,
                            "windowId": win.id,
                            "autoSnap": true
                        }, function(layeredId) {
                            sogouExplorer.windows.advanced.setSnapType({
                                "layeredId": layeredId,
                                "windowId": win.id,
                                "top": {"target": "tabMargin", "position": "top", distance: 15},
                                "right": {"target": "tabMargin", "position": "right", distance: 20},
                                "bottom": {"target": "tabMargin", "position": "top", distance: 275},
                                "left": {"target": "tabMargin", "position": "right", distance: 340}
                            });
                        });
                    }
                    else{
                        sogouExplorer.windows.advanced.createLayered('tips.html',posLeft, posTop, 400, 260, -1, function(winId){});
                    }
                })
            }
        })
    })
}

function clickPageIcon(params){

    if(!newestEqList.length){
        /*if(!!sogouExplorer.extension.getViews({"type": "popup"}).length){
            return
        }
        else{*/
            calcOffset(showQRWin);
//        }
    }
    else{
        if(localStorage.getItem("lastSentEq") == null || localStorage.getItem("lastSentEq") == "undefined"){
            curEqName = newestEqList[0].name;
            curEqUUID = newestEqList[0].uuid;
        }
        else{
            curEqName = JSON.parse(localStorage.getItem("lastSentEq")).eqname;
            curEqUUID = JSON.parse(localStorage.getItem("lastSentEq")).eqid;
        }
        if(params[0] > 1){
            if(params[0] == 2){
                sendSelection(params[1]);
            }
        }
        else{
            sendUrls(params);
        }
    }
}


/*右键菜单发送url*/
function sendUrls(params){
    sogouExplorer.tabs.getSelected(function(tab){
        var port2cs = sogouExplorer.tabs.connect(tab.id),
            sdata = params[0] ? tab.url : params[1],
            title = params[0] ? tab.title : sdata,
            odata,taburl,tabtitle;
        title = title.replace(/\"/g,"\\\"");
        if(!(/^se/ig).test(sdata)){
            if( (/^(http|https|ftp)/ig).test(sdata) ){
                taburl = sdata;
                tabtitle = title;
            }
            else{
                taburl = tab.url;
                tabtitle = tab.title;
            }
            odata = '{"hid":"'+hid+'","uuid":"'+curEqUUID+'","data":"'+taburl+'","title":"'+ tabtitle +'"}';
            $.ajax({
                type:"POST",
                url:"http://sync.mse.sogou.com/sendurl",
                processData:false,
                data:odata,
                success:function(){
                    tipMsg = '正在发送到'+ curEqName;
                    rCmd = 'succ_regular';
                    calcWinOffset();

                    /*var newimg = new Image();
                    newimg.src = 'http://ping.ie.sogou.com/feichuan.gif?hid='+ hid +'&uuid='+ curEqUUID +'&url='+ taburl +'&title='+ tabtitle +'&send_t='+ new Date();*/
                    ping({"hid":hid,"uuid":curEqUUID,"url":taburl,"title":tabtitle,"send_t":new Date()});

                },
                error:function(){
                    tipMsg = '发送失败，请稍后再试！';
                    rCmd = 'err';
                    calcWinOffset();
                }
            })
        }
        else if((/^se/ig).test(sdata)){
            $.ajax({
                type:"POST",
                url:"http://sync.mse.sogou.com/sendurl",
                processData:false,
                data:'{"hid":"'+hid+'","uuid":"'+curEqUUID+'","data":"http://123.sogou.com/","title":"搜狗网址导航"}',
                success:function(){
                    tipMsg = '正在发送"网址大全"到'+ curEqName;
                    rCmd = 'succ_regular';
                    calcWinOffset();

                    ping({"hid":hid,"uuid":curEqUUID,"url":"http://123.sogou.com/","title":"搜狗网址导航","send_t":new Date()});
                },
                error:function(){
                    tipMsg = '发送失败，请稍后再试！';
                    rCmd = 'err';
                    calcWinOffset();
                }
            })
        }
        else{
            tipMsg = '发送失败，请稍后再试！';
            rCmd = 'err';
            calcWinOffset();
        }
    })
}

/*点击“设备列表”*/
function clickMenuOption(){
    if(!newestEqList.length){
        console.log('if-no-newestEqList:', newestEqList);
        calcOffset(showQRWin)
    }
    else{
        console.log('else-has-newestEqList:', newestEqList);
        calcOffset(showEqWin)
    }
}

function updateEqTips(data){
    var des;
    if(data == null || data == undefined){
        if(!!localStorage.getItem("lastSentEq") && JSON.parse(localStorage.getItem("lastSentEq")).eqname !== "undefined"){
            des = '将当前网页一键发送到' + JSON.parse(localStorage.getItem("lastSentEq")).eqname;
        }
        else{
            des = "将当前网页一键发送到手机";
        }
    }
    else if(data.eqName === "nobinding"){
        des = "将当前网页一键发送到手机";
    }
    else{
        des = '将当前网页一键发送到' + data.eqName;
    }
    //工具栏hover tips
    sogouExplorer.browserAction.setDescription({description:des});
    //地址栏hover tips
    sogouExplorer.tabs.getSelected(function(tab){
        sogouExplorer.pageAction.setTitle({tabId:tab.id, title:des});
        sogouExplorer.pageAction.show(tab.id);
    })
}

/*断网提示*/
function tipForTimeout(){
    sogouExplorer.tabs.getSelected(function(tab){
        if(!window.navigator.onLine){
            /* var port2css = sogouExplorer.tabs.connect(tab.id);
             port2css.postMessage({cmd:"timeout"})*/

            tipMsg = '网络异常，请重试!';
            rCmd = 'err';
            calcWinOffset();
        }
    })
}

/*字符串比较*/
/*合法的se version格式为4.x.x.xxxx*/
/*返回值：0--相等，1--stra大于strb，-1--stra小于strb*/
function versionCompare(stra,strb){
    var straArr = stra.split('.'),
        strbArr = strb.split('.'),
        maxLen = Math.max(straArr.length,strbArr.length),
        result,sa,sb;
    for(var i=0; i<maxLen; i++){
        sa = ~~straArr[i];
        sb = ~~strbArr[i];
        if(sa > sb){
            result = 1;
        }
        else if(sa < sb){
            result = -1;
        }
        else{
            result = 0;
        }

        if(result != 0){
            return result;
        }
    }
}

/*pingback fn*/
var ping = function(params){
    var gifUrl = 'http://ping.ie.sogou.com/feichuan.gif?',gifSrc;
    if(params){
        var jsonObj = typeof params == 'string' ? JSON.parse(params) : params,paramsArr = [];
        for(var key in jsonObj){
            paramsArr.push(''+key+'='+jsonObj[key]+'');
        }
        gifSrc = paramsArr.join('&');
    }
    (new Image()).src = gifUrl + gifSrc;
};

/*close cur window*/
function closCurWin(){
    var curWinsArr = sogouExplorer.extension.getViews();
    for(var i=0,len=curWinsArr.length; i<len; i++){
        for(var j= 0,sublen=arguments.length; j<sublen; j++){
            if(curWinsArr[i].name === arguments[j]){
                curWinsArr[i].close();
            }
        }

    }
}