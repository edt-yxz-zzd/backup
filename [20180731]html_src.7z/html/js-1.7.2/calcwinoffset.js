//inject to the current page to get the offset of viewport relative to the screen.
//window.screenTop is special in SE,cuz it minuses the navigate part,the toolbar part etc which are at the top of viewport
var offset = {
    "win_width":window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth,
    "win_height":window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight,
    "win_ST":window.screenTop,
    "win_SL":window.screenLeft
};

sogouExplorer.extension.sendRequest({"cmd":"calcwinoffset","offset":offset}, function(){});


