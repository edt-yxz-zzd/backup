(function(){
    var options = {},hid,eqListData;
    var port = sogouExplorer.extension.connect();
    buildEqList();
    sogouExplorer.command.userInfo.getUserID(onGetCurrentUser);
    function onGetCurrentUser(m,opid){
        hid = m;
        /*打开eqlist页的pingback*/
        ping({"hid":hid,"page":"eqlist"});
    }

    if(localStorage.getItem("lastSentEq") == null || localStorage.getItem("lastSentEq") == "undefined"){
        selectedEq(0);
    }
    else{
        selectedEq();
    }
    if($('.eq-item').length > 2){
        $('.eqlists-wrap').addClass('scroller');
    }

    /*关闭EQ窗口，发起指令修改isOpen值*/
    window.onbeforeunload = function(){
//                sogouExplorer.extension.sendRequest({"cmd":"changeisOpen"}, function(){});
    }

    /*bind events*/
    /*选定设备*/
    $(':radio[name="eq-name"]').click(function(){
        selectedEq($(this).parents('.eqlists-li').index());
    });

    /*解绑设备*/
    $('.del').each(function(idx,item){
        $(item).on('click',function(){
            var $curli = $(this).parents('.eqlists-li'),
                isSelectedEq = $curli.hasClass('eq-selected');
//                    selectedEq($curli.index());
            if(confirm('确定将PC和'+ $curli.find('.eq-name').text() +'解绑吗？')){
                //这里要发个postMessage给bg，cmd:unbind，告知走解绑api
                var eid = $curli.attr('eid');
                $.ajax({
                    type:"GET",
                    url:"http://sync.mse.sogou.com/delcouple",
                    data:"hid="+hid+"&uuid="+eid,
                    success:function(data){
                        if(!JSON.parse(data).state){
                            $curli.fadeOut(400,function(){
                                $curli.remove();
                                if($('.del').length == 0){//需求如此，别诧异
                                    localStorage.clear();
                                    localStorage.setItem("isInstalled","1");
                                    port.postMessage({"cmd":"updateEqTips","eqName":"nobinding" });
                                    window.close();
                                }
                                else{
                                    if(isSelectedEq){
                                        if(idx == 0){
                                            selectedEq(0);
                                        }
                                        else{
                                            selectedEq(idx-1);
                                        }
                                    }
                                }
                            });
                        }
                    },
                    error:function(){
                        alert('服务器异常，请稍后重试！')
                    }
                })
            }
        })
    })

    /*添加设备*/
    $('.add-eq').off('click').on('click',function(){
        port.postMessage({cmd:"showQR"});
//                window.close();
    });

    /*发送*/
    /*发送url*/
    $('#sendUrl').on('click',function(){
        /*点击sendUrl按钮的pingback*/
        ping({"hid":hid,"btn":"sendurl"});

        if(!$('input[type=radio]:checked').length){
            alert('亲，请选择一个设备')
        }
        else{
            sogouExplorer.tabs.getSelected(function(tab){
                var $curLi = $(':radio[name="eq-name"]:checked').parents('li'),
                    eid = $curLi.attr('eid'),
                    eqname = $curLi.attr('eqname'),
                    $curGif = $curLi.find('.sendUrl-loading'),
                    $overlay = $('#overlay'),
                    $processBar = $('.upl-wrap'),
                    $recCon = $('.rec-confirm'),
                    tabtitle = tab.title.replace(/\"/g,"\\\""),taburl = tab.url,odata,tipcon = "发送失败";
                if(!!(/^se/ig).test(tab.url)){
                    taburl = "http://123.sogou.com/";
                    tabtitle = "搜狗网址导航";
                }
                odata = '{"hid":"'+hid+'","uuid":"'+eid+'","data":"'+taburl+'","title":"'+ tabtitle +'"}';
                $.ajax({
                    type:"POST",
                    url:"http://sync.mse.sogou.com/sendurl",
                    processData:false,
                    data:odata,
                    beforeSend:function(){
                        //显示出动画
                        $('#sendFile').val('');
                        $curGif.show();
                        $('.op-btn-wrap input').attr('disabled','disabled');
                        $processBar.hide();
                    },
                    success:function(data){
                        if(JSON.parse(data).ret === 1){
                            if(data.errmsg === 'no binding'){
                                tipcon = "该设备已解绑，无法发送";
                            }
                            $curGif.delay(1000).fadeOut();
                            showTips("warn",tipcon);
                        }
                        else{
                            $curGif.delay(1000).fadeOut(function(){
                                if(!localStorage.getItem('hasReceived')){
                                    checkCurWins();
                                    $recCon.show();
                                    markConfirm("setMark");
                                    $overlay.fadeIn(400);
                                }
                                else{
                                    console.log("sendurl succ tips")
                                    showTips("succ","已成功发送到 "+eqname);
                                }
                            });

                            ping({"hid":hid,"uuid":eid,"url":taburl,"title":tabtitle,"send_t":new Date()});
                        }
                        console.log('success')
                    },
                    error:function(errorinfo){
                        console.log(errorinfo)
                        $curGif.delay(1000).fadeOut();

                        showTips("warn","发送失败");
                    }
                })
            })
        }
    })

    /*上传files*/
    $('#sendFile').change(function(){
        var fileSize = 0,files = $(this).get(0).files,tempFileNames = [],tempFileSizes = [];
        for(var i=0,len=files.length; i<len; i++){
            fileSize += $(this).get(0).files[i].size;
            tempFileNames[i] = $(this).get(0).files[i].name;
            tempFileSizes[i] = $(this).get(0).files[i].size;
        }
        if( fileSize < 15728640 ){//限制15MB以内的文件
            var $curLi = $(':radio[name="eq-name"]:checked').parents('li'),
                eid = $curLi.attr('eid'),
                eqname = $curLi.attr('eqname'),
                $overlay = $('#overlay'),
                $processBar = $('.upl-wrap'),
                $recCon = $('.rec-confirm'),
                $curBar = $('.pro-bar'),
                $curPer = $('.pro-percent');
            $('<input type="hidden" name="hid">').val(hid).appendTo('#uploadForm');
            $('<input type="hidden" name="uuid">').val(eid).appendTo('#uploadForm');
            options = {
                type: 'POST',
                url: 'http://sync.mse.sogou.com/sendfile',
                beforeSend: function(xhr){
                    $('.pro-cancel').on('click',function(e){
                        xhr.abort();
                        $('#sendFile').val('');
                        $('#overlay').fadeOut(0);
                    })
                    //显示进度条
                    $('.eqn').html(eqname);
                    $curBar.width('0');
                    $overlay.fadeIn(400);
                },
                uploadProgress: function(event, position, total, percentComplete, xhr){
                    $curBar.animate({
                        width:2.33*percentComplete
                    },200,function(){
                        $curPer.html(percentComplete+'%');
                        if(percentComplete == 100){
                            $('#sendFile').val('');
                            $('input').remove(':hidden');
                           /* if(!localStorage.getItem('hasReceived')){
                                $processbar.delay(600).fadeOut(400);
                            }
                            else{
                                $overlay.delay(600).fadeOut(400);
                            }*/
                        }
                    });
                },
                success: function(data) {
                    $('#sendFile').val('');
                    $('input').remove(':hidden');
                    $('.pro-cancel').off('click');
                    $('.op-btn-wrap input').attr('disabled','disabled');

                    if(JSON.parse(data).ret === 0){
                        if(!localStorage.getItem('hasReceived')){
                            //todo show confirm,after choosing one btn,the layer gone
                            $processBar.delay(600).fadeOut(400,function(){
                                checkCurWins();
                                $recCon.show();
                                markConfirm("setMark");
                            });
                        }
                        else{
                            $overlay.delay(400).fadeOut(400,function(){
                                showTips("succ","已成功发送到"+eqname);
                            })
                        }
                        for(var j= 0,len=tempFileNames.length; j<len;j++){
                            ping({"hid":hid,"uuid":eid,"filename":tempFileNames[j],"filesize":tempFileSizes[j],"send_t":new Date()});
                        }

                    }
                    else{
                        $overlay.delay(400).fadeOut(400,function(){
                            showTips("warn","发送失败，请稍后重试!");
                        });
                    }
                },
                error:function(errinfo){
                    $('#sendFile').val('');
                    $('input').remove(':hidden');
                    $('.pro-cancel').off('click');
                    $('.op-btn-wrap input').attr('disabled','disabled');
                    $overlay.delay(1000).fadeOut(400,function(){
                        if(errinfo.statusText == "abort"){
                            showTips("succ","  已取消发送!");
                        }
                        else{
                            showTips("warn","网络异常，请稍后重试!");
                        }
                    });
                },
                complete: function(){
                    $recCon.hide();
                    $processBar.show();
                }
            };
            $('#uploadForm').ajaxForm(options);
            $('#uploadForm').submit();
        }
        else{
            $(this).val('');
            $('.op-btn-wrap input').attr('disabled','disabled');

            showTips("warn","目前仅提供15M以下大小的文件传输");
        }
    })

    /*收到与否的反馈按钮注册*/
    $('.sogou-btns-rec').click(function(){
        ping({"hid":hid,"btn":"hasreceived"});
        localStorage.setItem('hasReceived',1);
        setTimeout(function(){
            $('#overlay').fadeOut(400,function(){
                markConfirm("eraseMark");
                showTips("succ","已成功发送");
            });
        },50)
    });
    $('.sogou-btns-norec').click(function(){
        ping({"hid":hid,"btn":"notreceived"});
        setTimeout(function(){
            $('#overlay').fadeOut(400,function(){
                markConfirm("eraseMark");
                showTips("succ","已成功发送");
            });
        },50)
    });

    /*点击sendFile按钮的pingback*/
    $('#sendFile').on('click',function(){
        ping({"hid":hid,"btn":"sendfile"});
    });

    /*生成eqlist*/
    function buildEqList(){
        if(localStorage.getItem("equip") == null || localStorage.getItem("equip") == "undefined"){
            window.close();
        }
        else{
            eqListData = JSON.parse(localStorage.getItem("equip"));
            for(var key in eqListData){
                var newEqItem = '<li class="eqlists-li" eid="'+eqListData[key].uuid+'" eqname="'+eqListData[key].name+'"><label><div class="eq-item eq-item-bg"><div class="eq-look"><span class="item-chose-icon"></span><span class="sendUrl-loading" style="display: none"></span></div></div><div class="eq-radio"><input type="radio" name="eq-name"><span class="eq-name" title="'+eqListData[key].name+'">'+eqListData[key].name+'</span></div></label><span class="del" title="解绑设备"></span></li>';
                $(newEqItem).insertBefore('#addEqItem');
            }
        }
    }

    function selectedEq(idx){
        var eqid;
        if(idx == null){
            idx = JSON.parse(localStorage.getItem('lastSentEq')).idx;
            eqid = JSON.parse(localStorage.getItem('lastSentEq')).eqid;
        }
        eqid = $('.eqlists-li').eq(idx).attr('eid');
        eqname = $('.eqlists-li').eq(idx).attr('eqname');

        $('.eqlists-li').removeClass('eq-selected');
        $('.eqlists-li').eq(idx).addClass('eq-selected').find(':radio[name="eq-name"]').attr('checked','checked');
        $('.tips-cureq-name').text(eqname);
        localStorage.setItem('lastSentEq','{"idx":"'+ idx +'","eqid":"'+ eqid +'","eqname":"'+ eqname +'"}');

        //notice bg to update the hover tips
        port.postMessage({"cmd":"updateEqTips","eqName":eqname });
    }

    function showTips(status,des){
        if(!!localStorage.getItem('hasReceived')){
            switch (status){
                case "succ":
                    console.log('succ')
                    $('.upload-file-warn').addClass('upload-file-succ');

                    break;
                case "warn":
                    console.log('warn')
                    $('.upload-file-warn').removeClass('upload-file-succ');
                    break;
            }
            console.log('slidedown')
            $('.warn-con').text(des);
            $('.upload-file-warn').delay(400).slideDown(1000).delay(800).slideToggle(400,function(){
                $('.op-btn-wrap input').removeAttr('disabled');
            });
        }
        else{
            $('.op-btn-wrap input').removeAttr('disabled');
        }

    }

    function checkCurWins(){
        var curWinsArr = sogouExplorer.extension.getViews();
        for(var i=0,len=curWinsArr.length; i<len; i++){
            if(curWinsArr[i].name === 'tips'){
                curWinsArr[i].close();
            }
        }
    }

    function markConfirm(action){
        switch(action){
            case "setMark":
                localStorage.setItem('markConfirm',1);
                break;
            case "eraseMark":
                localStorage.setItem('markConfirm',0);
                break;
            default :
                break;

        }
    }

    /*pingback fn*/
    var ping = function(params){
        var gifUrl = 'http://ping.ie.sogou.com/feichuan.gif?',gifSrc;
        if(params){
            var jsonObj = typeof params == 'string' ? JSON.parse(params) : params,paramsArr = [];
            for(var key in jsonObj){
                paramsArr.push(''+key+'='+jsonObj[key]+'');
            }
            gifSrc = paramsArr.join('&');
        }
        (new Image()).src = gifUrl + gifSrc;
    };

    sogouExplorer.extension.onConnect.addListener(function(port){
        port.onMessage.addListener(function(data){
            if(data.cmd === "sendUrl"){
                $('#sendUrl').trigger('click');
            }
            if(data.cmd === "autoSend"){
                $('#sendUrl').trigger('click');
            }
        })
    });

    sogouExplorer.extension.onRequest.addListener(function(request,msg,sendResponse){

        switch(request.cmd){
            case "confirmHide":
                $('.sogou-btns-norec').trigger('click');
                break;
            case "autoSend":
                $('#sendUrl').trigger('click');
            default :
                break;
        }
    })
})();