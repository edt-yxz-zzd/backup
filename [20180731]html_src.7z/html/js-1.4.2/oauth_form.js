var OAuth = OAuth || {};
OAuth.form = OAuth.form || {};

OAuth.form.getTimestamp = function(){
	return (new Date().valueOf());
};

OAuth.form.generateBoundary = function(){
	var boundaryPrefix 	= '----multipartformboundary';
	var timestamp 		= this.getTimestamp();

	var boundary		= boundaryPrefix + timestamp;

	return boundary;
};



OAuth.form.generateFormHeader = function(uploadType, uploadHost, uploadAction, uploadReferer){
	uploadType = uploadType || 'multipart/form-data;';
	this.boundary = this.generateBoundary();

	var header = /*'POST ' + uploadHost + uploadAction + ' HTTP/1.1\r\n*/'Host: ' + this.removeFromString(uploadHost, 'http://') + '\r\nConnection: keep-alive\r\n';
	header += 'Referer: ' + uploadReferer + '\r\nCache-Control: max-age=0\r\n';
	header += 'Origin: ' + uploadHost + '\r\nUser-Agent: Mozilla/5.0 (Windows NT 6.1) AppleWebKit/534.30 (KHTML, like Gecko) Chrome/12.0.742.9 Safari/534.30\r\n';
	header += 'Content-Type: ' + uploadType + ' boundary=' + this.boundary + '\r\n';
	header += 'Accept-Language: en-US,en;q=0.8\r\nAccept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.3';

	return header;
};


OAuth.form.addFormHeaderComp = function(header, key, value){
	header += '\r\n';
	header += key + ': ' + value;

	return header;
}


OAuth.form.removeFromString = function(targetString, rmString){
	return targetString.split(rmString)[1];
};


OAuth.form.generateBody = function(data, picName){
	var body 			= '';
	var staticString 	= 'Content-Disposition: form-data; name="__replaceIt__"\r\n\r\n';

	for (var key in data){
		if (!data.hasOwnProperty(key)){
			continue;
		}

		var value = data[key];

		body += '--' + this.boundary + '\r\n';
		body += staticString.replace('__replaceIt__', key);
		body += value + '\r\n';
	}


	//add image data
	body += '--' + this.boundary + '\r\n';
	body += 'Content-Disposition: form-data; name="__replaceIt__"; filename="myphoto.png"\r\n'.replace('__replaceIt__', picName);
	body += 'Content-Type: image/png\r\n\r\n';
	body += '__PIC_BINARY__\r\n';

	body += '--' + this.boundary + '--\r\n';   //finish
	return body;
};
