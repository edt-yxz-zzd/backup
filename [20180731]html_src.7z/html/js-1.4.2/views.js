function insertText2Textarea(obj, val) {   
	//IE support   
	if (document.selection){   
		obj.focus();   
		sel = document.selection.createRange();   
		sel.text = val;   
		sel.select();   
	}else if (obj.selectionStart || obj.selectionStart == '0'){
		//MOZILLA/NETSCAPE support   
		var startPos = obj.selectionStart;
		var endPos = obj.selectionEnd;   
		// save scrollTop before insert   
		var restoreTop = obj.scrollTop;   
		obj.value = obj.value.substring(0, startPos) + val + obj.value.substring(endPos,obj.value.length);
		if (restoreTop > 0){   
			// restore previous scrollTop   
			obj.scrollTop = restoreTop;   
		}   
		obj.focus();   
		obj.selectionStart = startPos + val.length;   
		obj.selectionEnd = startPos + val.length;   
	} else {   
		obj.value += val;   
		obj.focus();   
	}   
} 

function showUserGroupList(data){
	var show = function(){
		var html = "<div id='usergrouplist'><dl><dd name='全部' gid=0>全部</dd>";
		for(k in data){
			var showName = data[k]["name"].length > 7 ? data[k]["name"].substr(0,7)+"..." : data[k]["name"];
			html += "<dd name='" + data[k]["name"] + "' gid='" + data[k]["idstr"] + "'>" + showName + " ("+data[k]["member_count"]+")</dd>";
		}
		html += "</dl></div>";
		$("body").append(html);
		$("#usergrouplist").fadeIn();
		$("#usergrouplist").mouseleave(function(){
			$("#usergrouplist").remove();
		});
		$("#usergrouplist dl dd").click(function(){
			var name = $(this).attr("name");
			var gid = $(this).attr("gid");
			$("#usergrouplist").remove();
			loadDataByGroup(gid, name);	
		});
	}
	var loadDataByGroup = function(gid, gname){
		var feature = 0;
		loadingWeibo($("#new_weibo"), feature, gid, gname);
	}
	$("#btn_grouplist").click(function(){
		show();
	});
}

function showAtList(ele, obj){
	var elem = document.getElementById(ele);
	if (obj.selectionStart || obj.selectionStart == '0'){
		var startPos = obj.selectionStart;
		var str = obj.value.substring(0, startPos);
		n = str.lastIndexOf("@");
		var s = $('#atselector');
		if(n >= 0){			
			var word = obj.value.substr(n+1, startPos-n-1);
			var p = kingwolfofsky.getInputPositon(elem);
			s.css("top", p.bottom+'px');
			s.css("left", p.left + 'px');
			var showList = function(results){
				if(results.length == 0){
					s.hide();
					return;
				}
				var html = "<dl>";
				for(k in results){
					var val = results[k];
					html += "<dd>@" + val["nickname"] + "</dd>";
					if(k == 10){
						break;
					}
				}
				html += "</dl>";
				s.html(html);
				s.show();
				$("#atselector dl dd").click(function(){
					var name = $(this).html();
					obj.value = obj.value.substring(0, n) + name + " " + obj.value.substring(startPos,obj.value.length);	
					//insertText2Textarea(obj,name + " ");
					//$("#weibo_content").val($("#weibo_content").val().replace("@" + word, ""));
					countWord($("#weibo_content"), $("#word_count"));
					obj.focus();   
					obj.selectionStart = startPos + name.length;   
					obj.selectionEnd = startPos + name.length;   
					s.hide();
				});
			}
			getFriendsSelector(word, showList);
		} else {
			s.hide();

		}
	}
}

function showEmotions(){
	var epage = 0;
	var cateSelected = "default";
	var html = "<div id='emotions_container'><div id='emotions_inner'>$1$2<a class='prev'><</a><a class='next'>></a></div></div>";
	var html1 = "<div id='emotions_category_list'></div>";
	var showEmotionsCate = function(n){
		var html = "<ul>";
		for(k in faceCateListByPage[n]){
			var cate = faceCateListByPage[n][k];
			var cateName = (cate == "default") ? "默认" : cate;
			var activeClass = (cate == cateSelected) ? "class='active'" : "";
			html += "<li name='" + cate + "' " + activeClass + ">" + cateName + "</li>"
		}
		html += "</ul>";
		$("#emotions_category_list").html(html);	
		$("#emotions_category_list ul li").click(function(){
			var cate = $(this).attr("name");
			showEmotionIcons(cate);
			$("#emotions_category_list .active").removeClass("active");
			$(this).addClass("active");
			cateSelected = cate;
		});
	}
	html2 = "<div id='emotions_icons_list'></div>";
	html = html.replace("$1", html1);
	html = html.replace("$2", html2);
	$("body").append(html);
	$("#emotions_container").fadeIn();
	var showEmotionIcons = function(cate){
		var html = "<ul>";
		for(k in facesListByCate[cate]){
			html += "<li><img src='" + facesListByCate[cate][k] + "' title='" + k + "' /></li>";
		}
		html += "</ul>";
		$("#emotions_icons_list").html(html);	
		$("#emotions_icons_list ul li").click(function(){
				var emotionTitle = $(this).children("img").attr("title");
				var cobj = document.getElementById("weibo_content");
				insertText2Textarea(cobj, emotionTitle);
				countWord($("#weibo_content"), $("#word_count"));
		});
	}
	showEmotionsCate(epage);
	$("#emotions_inner .prev").click(function(){
		if(epage == 0){
			return;
		}
		epage = epage - 1;
		showEmotionsCate(epage);
	});
	$("#emotions_inner .next").click(function(){
		if(epage == faceCateListByPage.length - 1){
			return;
		}
		epage = epage + 1;
		showEmotionsCate(epage);
	});
	showEmotionIcons("default");
}

//显示更新信息
function showUnreadInfo(results){
	var count_weibo = results["status"];
	if(count_weibo > 0){
		newWeibo = 1;
		var count_weibo_show = (count_weibo > 100) ? "100+" : count_weibo;
		$("#new_weibo b").html(count_weibo_show);
		$("#new_weibo b").fadeIn();
	} 
	
	if(results["follower"] > 0){	
		$("#new_fans b").html(results["follower"]);
		$("#new_fans b").fadeIn();
	}

	if(results["cmt"] > 0){	
		$("#new_comment b").html(results["cmt"]);
		$("#new_comment b").fadeIn();
	}
	
	var count_mentions = results["mention_status"] + results["mention_cmt"];	
	if(count_mentions > 0){
		$("#new_atme b").html(count_mentions);
		$("#new_atme b").fadeIn();
	} else {
		$("#new_atme b").html("");
		$("#new_atme b").fadeOut();
	}

	if(results["dm"] > 0){	
		$("#new_msg b").html(results["dm"]);
		$("#new_msg b").fadeIn();
	}
	
}