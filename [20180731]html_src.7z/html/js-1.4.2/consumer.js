var consumer = {
	sina: {
		consumerKey: '3264911109',
		consumerSecret: '2ac00d7c464e63bfa108f0a33628e82a',
		serviceProvider: {
			signatureMethod: 'HMAC-SHA1',
			userAuthorizationURL: 'https://api.weibo.com/oauth2/authorize',
			//userAuthorizationURL: 'https://apt.sina.com.cn/oauth2/authorize',
			authCallbackURL: 'http://sext.ie.sogou.com/app/auth.php',
			accessTokenURL: 'https://api.weibo.com/oauth2/access_token',
			uidURL:'https://api.weibo.com/2/account/get_uid.json',
			userInfoURL:"https://api.weibo.com/2/users/show.json",
			//unreadURL:'https://api.t.sina.com.cn/statuses/unread.json?with_new_status=1',
			unreadURL:'https://rm.api.weibo.com/2/remind/unread_count.json',
			resetUnreadURL:'https://rm.api.weibo.com/2/remind/set_count.json',
			postDataURL: 'https://api.weibo.com/2/statuses/update.json',
			postPicURL: 'https://api.weibo.com/2/statuses/upload.json',
			homeTimelineURL: 'https://api.weibo.com/2/statuses/friends_timeline.json',
			emoionsURL:'https://api.weibo.com/2/emotions.json',
			
			echoURL: '',
			upload: {
				host: 'http://api.t.sina.com.cn',
				action: '/statuses/upload.json',
				referer: 'http://weibo.com'
			}
		}
	}
};