var cookiestr = document.cookie;
var referurl = document.referrer;
function doCreatePort(){
	port = sogouExplorer.extension.connect();
}

function doPostMessage(data){
	port.postMessage(data);
}
if(referurl == "http://weibo.com/" || referurl == "" || referurl == undefined || referurl.indexOf("http://login.sina.com.cn/sso/login.php") >= 0){
	if(cookiestr.indexOf("SUP=") > 0){
		doCreatePort();
		var jsonData = {cmd:"openpop2",value:1};
		doPostMessage(jsonData);
	}
}