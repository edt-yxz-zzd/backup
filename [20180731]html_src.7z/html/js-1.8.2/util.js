jQuery.cookie = function(name, value, options) {
    if (typeof value != 'undefined') { // name and value given, set cookie
        options = options || {};
        if (value === null) {
            value = '';
            options.expires = -1;
        }
        var expires = '';
        if (options.expires && (typeof options.expires == 'number' || options.expires.toUTCString)) {
            var date;
            if (typeof options.expires == 'number') {
                date = new Date();
                date.setTime(date.getTime() + (options.expires * 24 * 60 * 60 * 1000));
            } else {
                date = options.expires;
            }
            expires = '; expires=' + date.toUTCString(); // use expires attribute, max-age is not supported by IE
        }
        // CAUTION: Needed to parenthesize options.path and options.domain
        // in the following expressions, otherwise they evaluate to undefined
        // in the packed version for some reason...
        var path = options.path ? '; path=' + (options.path) : '';
        var domain = options.domain ? '; domain=' + (options.domain) : '';
        var secure = options.secure ? '; secure' : '';
        document.cookie = [name, '=', encodeURIComponent(value), expires, path, domain, secure].join('');
    } else { // only name given, get cookie
        var cookieValue = null;
        if (document.cookie && document.cookie != '') {
            var cookies = document.cookie.split(';');
            for (var i = 0; i < cookies.length; i++) {
                var cookie = jQuery.trim(cookies[i]);
                // Does this cookie string begin with the name we want?
                if (cookie.substring(0, name.length + 1) == (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }
};
var PB_ROOT = "http://pb.sogou.com/";
var uigs_pbs = new Array();
var pb_pv = function(page){
	var pbLength = uigs_pbs.length;
	uigs_pbs[pbLength] = new Image();
	var uigs_d = escape((new Date().getTime())*1000+Math.round(Math.random()*1000));
	uigs_pbs[pbLength].src = PB_ROOT + 'pv.gif?uigs_productid=wan&uigs_t=' + uigs_d + '&m=2&uigs_version=v1.1&uigs_refer=gamehelper&page=' + page;
}
var pb_cl = function(page, para){
	var pbLength = uigs_pbs.length;
	uigs_pbs[pbLength] = new Image();
	var uigs_d = escape((new Date().getTime())*1000+Math.round(Math.random()*1000));
	uigs_pbs[pbLength].src = PB_ROOT + 'cl.gif?uigs_productid=wan&uigs_t=' + uigs_d + '&m=2&uigs_version=v1.1&uigs_refer=gamehelper&page=' + page + '&' + para ;
}

var uigs_clickit = function(evt){
	if($(evt.target).data("stated")){
		return;
	}
	if ((evt&&(evt.button != 0))||((!evt)&&(window.event.button != 0)))
		return;
	try{
		evt=evt||window.event;
		var srcElem=((evt.target)?evt.target:evt.srcElement);
		var tag = srcElem.tagName.toUpperCase();
		if (tag!="A"&&tag!="IMG"&&tag!="INPUT"){return;}
		if(tag=="IMG"){
			while(tag!="A"){
				if (srcElem.parentNode)
						srcElem = srcElem.parentNode;
					else
						break;
					if (!srcElem.tagName) break;
					tag = srcElem.tagName.toUpperCase();
			}
			if(tag!="A") return;
		}
		var uigs = "";
		var dHref = "";
			if (srcElem.href){
				dHref = srcElem.href;
			}
			try{
				uigs = srcElem.id||srcElem.getAttribute("id")||"";
				while(uigs==""){
					if (srcElem.parentNode)
						srcElem = srcElem.parentNode;
					else
						break;
					if (!srcElem.tagName)
						break;
					if (!uigs) {
						uigs=srcElem.id||srcElem.getAttribute("id")||"";
						//var trackparam=srcElem.getAttribute("trackparam")||"";
						//uigs+=trackparam;//trackparam like &type=1&gid=3 ,must beginwith &
					}
				}
			}catch(ee){
			}
			if(typeof(pageID)=="undefined"){
				pageID = '';
			}
			pb_cl(pageID, 'tag='+ tag + '&dh=' + encodeURIComponent(dHref) + '&id=' + uigs );
	}catch(e){}
}

;(function(){
  var cache = {};
  
  this.tmpl = function tmpl(str, data){
    // Figure out if we're getting a template, or if we need to
    // load the template - and be sure to cache the result.
    var fn = !/\W/.test(str) ?
      cache[str] = cache[str] ||
        tmpl(document.getElementById(str).innerHTML) :
      
      // Generate a reusable function that will serve as a template
      // generator (and which will be cached).
      new Function("obj",
        "var p=[],print=function(){p.push.apply(p,arguments);};" +
        
        // Introduce the data as local variables using with(){}
        "with(obj){p.push('" +
        
        // Convert the template into pure JavaScript
        str
          .replace(/[\r\t\n]/g, " ")
          .split("<%").join("\t")
          .replace(/((^|%>)[^\t]*)'/g, "$1\r")
          .replace(/\t=(.*?)%>/g, "',$1,'")
          .split("\t").join("');")
          .split("%>").join("p.push('")
          .split("\r").join("\\'")
      + "');}return p.join('');");
    
    // Provide some basic currying to the user
    return data ? fn( data ) : fn;
  };
})();
//��
function open(type){
	sogouExplorer.windows.getLastFocused(function(w){
		sogouExplorer.tabs.getSelected(w.id, function(tab){
			var icon = "";
			var url=tab.url;
			url=url=="se"?"http://123.sogou.com":url;
			if(type=="xiaohao"){
				if(pageID=="back"){
					embed1&&embed1.sendCommand("StartGame", url+"|"+" "+"|"+tab.title+"|0");
				}else{
					sogouExplorer.extension.sendRequest({
						cmd: "OpenPage",
						param:url + "|" + icon + "|" + tab.title + "|0",
						link: url,
						win:"xiaohao"
					});
				}
				
			}else{
				 sogouExplorer.windows.create({accountNumber: -1, url:url});				
			}
			//pb_cl(pageID, '&dh=' + encodeURIComponent(url) + '&id=addgame');
			//setTimeout(function(){window.close()},0);
		});
	});
}
function testwin(){
	sogouExplorer.windows.getLastFocused(function(w){
	if(!w||!w.id){
		window.close();
	}else{
		setTimeout(testwin,500);
	}});
}
if(pageID&&pageID!="back"){
	//ͳ��
	$(document).click(uigs_clickit);
	pageID&&pb_pv(pageID);
}
