var balloonversion = "0.4.4";
window.onload=function(){
	var t = new Date().getTime();
    window.frames[0].location.href = "http://wan.sogou.com/static/browserPopups/index.html" + '?new=' + t;
}
window.onmessage = function(e){
	var data = e.data;
	if (data.cmd == "BalloonCloseWin") {
		window.close();
	} else if (data.cmd == "BalloonNoTip") {
		localStorage["balloon_forbidden"] = "1";
		window.close();
	} else if (data.cmd == "BalloonStartGame") {
		sogouExplorer.tabs.create({
			url:data.url,
			selected:true
		});
		window.close();
	}
}