
var isdev = false;
var balloonversion = "0.4.4";
pb_cl("browse_open","browse_open=true");
var staticRoot = isdev ? "http://wan.sogou.com/static/gamehelper/" : "http://wan.sogou.com/static/gamehelper/";
var defaultImgSrc = "images/collect-16.png";
var config = {
	"isdev" : isdev,
	"staticRoot" : staticRoot,
	"defaultImgSrc" : defaultImgSrc
}
var myCollectList = [];
var version = 3.5;
if (!localStorage["version"] || localStorage["version"] != version) {
	localStorage["version"] = version;
	sogouExplorer.browserAction.setIcon({
		path : "default.ico",
		permanently : true
	});
}
if (localStorage["collect-games"]) {
	myCollectList = JSON.parse(localStorage["collect-games"]);
}
var MyCollection = {
	add : function (c) {
		myCollectList.push(c);
		localStorage["collect-games"] = JSON.stringify(myCollectList);
		MenuView.render();
	},
	remove : function (url) {
		for (var i = 0; i < myCollectList.length; i++) {
			if (myCollectList[i][0] == url) {
				myCollectList.splice(i, 1);
				break;
			}
		}
		localStorage["collect-games"] = JSON.stringify(myCollectList);
		MenuView.render();
	},
	rename : function (url, name) {
		for (var i = 0; i < myCollectList.length; i++) {
			if (myCollectList[i][0] == url) {
				myCollectList[i][1] = name;
				break;
			}
		}
		localStorage["collect-games"] = JSON.stringify(myCollectList);
		MenuView.render();
	}
	
}

/* start menu */
var MenuView = (function () {
	var menuItem_popup = {
		type : "normal",
		title : "打开玩游戏",
		icon : {
			path : "images/logo-16.png"
		},
		contexts : ["mainframe"],
		onclick : function (info, tab) {
			pb_cl("popup", "id=menu_open_pop");
			sogouExplorer.browserAction.showPopup();
		}
	};
	var menuItem_add = {
		type : "normal",
		title : "收藏游戏",
		icon : {
			path : "images/collect.png"
		},
		contexts : ["mainframe"],
		onclick : function (info, tab) {
			sogouExplorer.windows.create({
				url : "html/collect.html",
				focused : true,
				type : "popup",
				width : 376,
				height : 276,
				left : (screen.width - 376) / 2,
				top : (screen.height - 276) / 2
			});
		}
	};
	var menuItem_manage = {
		type : "normal",
		title : "管理我收藏的游戏",
		icon : {
			path : "images/manage.png"
		},
		contexts : ["mainframe"],
		onclick : function (info, tab) {
			sogouExplorer.windows.create({
				url : "html/manage.html",
				focused : true,
				type : "popup",
				width : 466,
				height : 358,
				left : (screen.width - 466) / 2,
				top : (screen.height - 358) / 2
			});
		}
	};
	var menuItem_config = {
		type : "normal",
		title : "设置",
		icon : {
			path : "images/config.png"
		},
		contexts : ["mainframe"],
		onclick : function (info, tab) {
			pb_cl("popup", "id=menu_config");
			embed1.sendCommand("ManageConfig", "");
		}
	};
	/*
	var menuItem_separator = {
	type: "separator",
	contexts: ["mainframe"]
	};*/
	var menuItem_open = {
		type : "normal",
		title : "小号多开",
		icon : {
			path : "images/open.png"
		},
		contexts : ["mainframe"],
		onclick : function (info, tab) {
			pb_cl("popup", "id=menu_open_xiaohao");
			if (localStorage["opentype"]) {
				open(localStorage["opentype"]);
			} else {
				sogouExplorer.windows.create({
					url : "html/open.html",
					focused : true,
					type : "popup",
					width : 278,
					height : 240,
					left : (screen.width - 278) / 2,
					top : (screen.height - 240) / 2
				});
			}
			
		}
	};
	//var sogouGameIDs = {"1":"","2":"","3":"","5":"","7":"","ddt":"","hh":"","sxd":"","mszj":"","sg":""};
	function renderGeneral() {
		sogouExplorer.contextMenus.removeAll();
		var menuItems = new Array();
		menuItems.push(menuItem_popup);
		menuItems.push(menuItem_add);
		menuItems.push(menuItem_manage);
		//menuItems.push(menuItem_separator);
		menuItems.push(menuItem_open);
		menuItems.push(menuItem_config);
		for (var i in menuItems) {
			sogouExplorer.contextMenus.create(menuItems[i]);
		}
	}
	//renderGeneral();
	function render() {
		
		renderGeneral();
		var menuItems = new Array();
		$.each(myCollectList, function (i, myGame) {
			var t = myGame[1].length > 20 ? myGame[1].substring(0, 17) + "..." : myGame[1];
			var menuItem = {
				type : "normal",
				title : t,
				icon : {
					path : "images/collect-16.png"
				},
				contexts : ["mainframe"],
				onclick : function (info, tab) {
					if (openInWin) {
						embed1.sendCommand("StartGame", myGame[0] + "|" + myGame[1] + "|" + myGame[2] + "|" + i);
					} else {
						sogouExplorer.tabs.create({
							url : myGame[0],
							selected : true,
							index : tab.index + 1
						});
					}
					pb_cl(pageID, '&dh=' + encodeURIComponent(myGame[0]) + '&id=collect_' + i);
				}
			};
			menuItems.push(menuItem);
		});
		
		for (var i in menuItems) {
			sogouExplorer.contextMenus.create(menuItems[i]);
		}
	}
	render();
	return {
		render : render
	};
})();
/* end  menu */
function parseGame(str) {
	var ret = new Array();
	var games = str.split("\n");
	if (!games) {
		return;
	}
	for (var i in games) {
		var game = games[i];
		var gamearr = game.split("\t");
		if (gamearr.length < 3)
			continue;
		ret.push([gamearr[0], gamearr[2], gamearr[1]]);
	}
	return ret;
}

var openInWin = false;
if (localStorage["openInWin"]) {
	openInWin = localStorage["openInWin"] == "true" ? true : false;
}
/* 小窗口 callback*/
function OnSendConfigList(strConfig) {
	var openMethodConfName = "openmethod";
	var parseConf = function (str) {
		var ret = {};
		var kvs = str.split("\n");
		for (var i in kvs) {
			var kv = kvs[i];
			var idx = kv.indexOf("\t");
			if (idx == -1) {
				continue;
			}
			var key = kv.substr(0, idx);
			var value = kv.substr(idx + 1);
			ret[key] = value;
		}
		return ret;
	}
	var conf = parseConf(strConfig);
	if (typeof(conf[openMethodConfName]) != "undefined") {
		if (conf[openMethodConfName] == "1") {
			openInWin = false;
		} else {
			openInWin = true;
		}
		localStorage["openInWin"] = openInWin;
	}
}
function OnSendGameList(strGameList) { //设置 我的游戏 信息
	
	try {
		if (typeof strGameList == "undefined") {
			return;
		}
		if (!localStorage["receivedold"]) {
			myCollectList = parseGame(strGameList).concat(myCollectList);
			localStorage["collect-games"] = JSON.stringify(myCollectList);
			MenuView.render(); //渲染menu
			localStorage["receivedold"] = true;
		}
	} catch (e) {
		alert(e);
	}
}
function SetLogin(loginstr) {}
var recGames = [];
$.ajax({
	url : staticRoot + "recommend_v3.0.json",
	dataType : "json",
	cache:false,
	timeout:10000,
	success : function (data) {
		recGames = data.slice(0, 6);
	}
});
var claGames = [];
$.ajax({
	url : staticRoot + "classic_v3.0.json",
	dataType : "json",
	cache:false,
	timeout:10000,
	success : function (data) {
		claGames = data.slice(0, 6);
	}
});
/* end 小窗口callback*/

/* balloon 弹泡*/
var Balloon = (function(){

	var lasttime = localStorage["last_balloon_pop_time"];
	var balloonForbidden = typeof(localStorage["balloon_forbidden"]) != "undefined";
	
	function hasPopToday() {
		var b = false;
		var oneday = config.isdev ? 1000 : 1000 * 60 * 60 * 24;
		if (lasttime) {
			var day = new Date(parseFloat(lasttime)).getDate();
			var month = new Date(parseFloat(lasttime)).getMonth();
			if (month == new Date().getMonth() && day == new Date().getDate() && ((new Date().getTime() - parseFloat(lasttime)) < oneday)) {
				b = true;
			}
		}
		return b;
	}
	
	function loadFilterUrls() {
		var urlArr;
		$.ajax({
			url : config.staticRoot + "filterurls.txt",
			type : 'GET',
			dataType : 'text',
			error : function () {},
			success : function (data) {
				var filterUrls = data.replace(/(^\s*)|(\s*$)/g, "");  //取出开头个末尾的空白字符
				urlArr = filterUrls.split(/\s+/); //在换行处分割字符串为数组
			},
			async:false
		});
		return urlArr;
	}
	
	function isValidPopUrl(url) {
		var uarr = loadFilterUrls();
		for (var i = 0; i < uarr.length; i++) {
			var r = new RegExp("(^|[.\/])" + uarr[i]);
			if (r.test(url)) {
				return true;
			}
		}
		return false;
	}
	
	if (sogouExplorer.browserAction.showHTMLBalloon){
		sogouExplorer.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
			var url = changeInfo.url;
			if (url) {
				if (typeof(localStorage["balloon_forbidden"]) == "undefined" && isValidPopUrl(url) && !hasPopToday()) {
					var timeout = isdev? 2000:30000;
					var showTime = isdev? 10000:20000;
					if(!localStorage["in30s"]){
						localStorage["in30s"] = 1;
						window.setTimeout(function(){
							sogouExplorer.browserAction.showHTMLBalloon({
								path : "html/balloon.html",
								width : 287,
								height : 186,
								timeout : showTime
							});
							lasttime = localStorage["last_balloon_pop_time"] = new Date().getTime();
							delete localStorage["in30s"];
						},timeout);
					}
				}
			}
		});
	}
})();
/*end balloon 弹泡*/