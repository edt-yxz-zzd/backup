
var myGames=[];
//var recGames=[{"img":"非的萨芬的","url":"http://baidu.com","name":"非的萨芬的撒","type":"非的萨芬的撒","score":"11","landpage":"http://baidu.com?abc=land"},{"img":"范德萨发大水发的萨菲","url":"桂丰大厦","name":"范德萨发的萨芬的","type":"","score":"12","landpage":" 躬逢盛典"},{"img":"范德萨范德萨发","url":"非的萨芬的撒","name":"范德萨发大水发","type":"","score":"23","landpage":"范德萨范德萨发"},{"img":"啊啊","url":"掉单","name":"宝贝","type":"","score":"44","landpage":"恩恩"},{"img":"图片","url":"图片链接","name":"名称","type":"","score":"3","landpage":"按钮链接"},{"img":"图片","url":"图片链接","name":"名称","type":"","score":"5.8","landpage":"按钮链接"}];
//var claGames=[{"img":"71","name":"72","url":"73"},{"img":"61","name":"62","url":"63"},{"img":"51","name":"52","url":"53"},{"img":"41","name":"42","url":"43"},{"img":"31","name":"32","url":"33"},{"img":"21","name":"22","url":"23"}];
var bgpage=sogouExplorer.extension.getBackgroundPage();
var recGames=bgpage.recGames;
var claGames=bgpage.claGames;
//data  游戏数据  tmplid 模板id dest 目标区域id
function render(data,tmplid,dest){
	var arr=[];
	for(var i=0;i<data.length;i++){
		arr[arr.length]=tmpl(tmplid,data[i]);
	}
	$(dest).html(arr.join(""));
	setTimeout(function(){
		$(dest+" .game").each(function(i,v){
			var selector=dest=="#my_game"?"":".start";
			$(v).delegate(selector,"click",function(){
				window.sogouExplorer&&sogouExplorer.extension.sendRequest({
					cmd: "StartGame",
					param: $(v).attr("data-url") + "|" + $(v).attr("data-img") + "|" +  $(v).attr("data-name") + "|0",
					link: $(v).attr("data-url")
				});
				setTimeout(function(){window.close()},0);
			});
		});
	},0);
}
window.addEventListener("message",function(e){
		if(e.data.cmd=="close"){
			$("#frame_wrapper").hide();
		}else if(e.data.cmd=="mygame"){
			if(e.data.data.code!=-1){
				var data=e.data.data.data;
				if(data&&data.length&&data.length>4){
					$("#mygame_more").show();
				}
				$("#login_info").html("<a id='logout' href='#' class='logout-link'>退出</a><span class='user-email'>您好！ "+e.data.data.email+"</span>");
							$("#logout").click(function(){
					$(".logout-box").show();
					window.resizeTo($(".root").outerWidth(),$(".root").outerHeight());
					$(".logout-box .close-btn,.logout-box .cancel-btn").click(function(){
						$(".logout-box").hide();
					});
					$(".logout-box .ok-btn").click(function(){
						$(".logout-box").hide();
						$("#plugin")[0].contentWindow.postMessage("logout","*");
					});
					
				});
				$("#my_game_wrapper").show();
				if(data&&data.length>0){
					$("#my_game_num").text(data.length);
					for(var i=0;i<4;i++)
					{
						data[i]&&myGames.push(data[i]);
					}
					render(myGames,"tmpl_mygame","#my_game");
				}
				window.resizeTo($(".root").outerWidth(),$(".root").outerHeight());
				
			}
			/*
			else{
				if(!/reload=true/.test(window.location.href)){
					window.location.href=window.location.href+"?reload=true";
				}
			}*/
		}else if(e.data.cmd&&e.data.cmd=="opentab"){
			sogouExplorer.tabs.create({url:e.data.param,focused: true});
		}
		else if(e.data.cmd&&e.data.cmd=="openurl"){
			sogouExplorer.windows.create({url:e.data.param});
		}else if(e.data.cmd&&e.data.cmd=="openlogin"){
			$("#login_link").click();
		}else if(e.data.cmd&&e.data.cmd=="openreg"){
			$("#reg_link").click();
		}else if(e.data.cmd&&e.data.cmd=="reload"){
			window.location.reload();
		}
	});
function getMyGame(){
	$(document.body).append('<iframe id="plugin" src="http://wan.sogou.com/img/plugin/plugin.html?r='+Math.random()+ '" style="display:none;"></iframe>');
}
getMyGame();
render(recGames,"tmpl_recgame","#rec_game");
setTimeout(function(){
	$("#rec_game .game-item").each(function(i,v){
		$(v).delegate(".start-game-btn","click",function(){
			window.sogouExplorer&&sogouExplorer.extension.sendRequest({
				cmd: "StartGame",
				param: $(v).attr("data-landpage") + "|" + $(v).attr("data-img") + "|" +  $(v).attr("data-name") + "|0",
				link: $(v).attr("data-landpage")
			});
			setTimeout(function(){window.close()},0);
		});
	});
},0);
render(claGames,"tmpl_clagame","#cla_game");
$("#login_link").click(function(){
	$("#frame_wrapper").removeClass();
	$("#frame_wrapper").addClass("login-wrapper");
	$("#frame_wrapper").show();
	$("#frame").attr("src","http://wan.sogou.com/img/plugin/login.html?r="+Math.random());
});
$("#reg_link").click(function(){
	$("#frame_wrapper").removeClass();
	$("#frame_wrapper").addClass("reg-wrapper");
	$("#frame_wrapper").show();
	$("#frame").attr("src","http://wan.sogou.com/img/plugin/reg.html?r="+Math.random());
});
$("#close").click(function(){
	window.close();
});
$(function(){
	window.resizeTo($(".root").outerWidth(),$(".root").outerHeight());
});

$("#config").click(function(){
	sogouExplorer.extension.sendRequest({cmd:"ManageConfig"});
	setTimeout(function(){window.close();},0);
})

//stat
$(function(){
	$(["#rec_game .img.start","#rec_game .name.start","#rec_game .start-game-btn","#my_game .start","#cla_game .game"]).each(function(i,v){
		$(v).click(function(e){
			var pb=v.replace(/[#\.]/g,"").replace(/\s/g,"-");
			pb_cl(pageID,"&id="+pb);
			$(e.target).data("stated",true);
			//e.stopPropagation();
		});
	});
	
});