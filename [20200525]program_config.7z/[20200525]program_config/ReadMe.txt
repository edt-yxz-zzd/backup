see auto_backup.py

detect "path.txt" in each folder

encoding is utf-8 or using python encoding declarations
    # -*- coding: <encoding-name> -*-
    encoding has to be compatible with ascii


each line should be:
    begin with '#' is comment
    or begin with '!' is reserved
        begin with '!#' is a warning
    or empty line
    or a path of file required to backup


