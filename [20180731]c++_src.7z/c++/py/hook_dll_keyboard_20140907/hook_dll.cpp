
#include "hook_dll.h"
#include <boost/python.hpp>


BOOST_PYTHON_MODULE(_python_hook)
{
    
    using namespace boost::python;
    PyEval_InitThreads();
    def("hook_keyboard", hook_keyboard);
    def("unhook_keyboard", unhook_keyboard);
    def("hook_mouse", hook_mouse);
    def("unhook_mouse", unhook_mouse);
}
