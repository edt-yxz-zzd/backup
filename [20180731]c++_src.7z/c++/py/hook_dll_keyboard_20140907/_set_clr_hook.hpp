#ifndef _set_clr_hook_hpp_HEAD_INCLUDED
#define _set_clr_hook_hpp_HEAD_INCLUDED
#include "_set_clr_hook.hpp"

#include <Python.h>

//-----------------
#include <boost/optional.hpp>
#include <boost/python.hpp>


#define _WIN32_WINNT 0x400
#include <windows.h>

using boost::python::object;
using boost::optional;

bool hook(int idHook, HOOKPROC lpfn, 
          HHOOK &hook, optional<object> &callback, 
          PyObject* pf_callback);
void unhook(HHOOK &hook, optional<object> &callback);

#endif
