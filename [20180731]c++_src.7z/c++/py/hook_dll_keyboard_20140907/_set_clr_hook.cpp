
#include <Python.h>
#include "_set_clr_hook.hpp"
#include "gil_lock.hpp"

//-----------------
#include <boost/none.hpp>
#include <cassert>
//#include <fstream>



using namespace std;
using boost::python::object;
using boost::optional;




bool hook(int idHook, HOOKPROC lpfn, 
          HHOOK &hook, optional<object> &callback, 
          PyObject* pf_callback)
{
    gil_lock gil;
    if (hook) return false;
    assert(!callback);
    if (!PyCallable_Check(pf_callback)) return false;
    
    HHOOK h;
    Py_BEGIN_ALLOW_THREADS
    HMODULE hMod = GetModuleHandle("_python_hook.pyd");
    //assert(hMod);
    h = SetWindowsHookEx(idHook, lpfn, hMod, 0);
    Py_END_ALLOW_THREADS
    
    if (!h) return false;
    
    
    object o(boost::python::handle<>(boost::python::borrowed(pf_callback)));
    callback = o;
    assert(!!callback);
    assert(!(*callback).is_none());
    hook = h;
    return true;
}



void unhook(HHOOK &hook, optional<object> &callback)
{
    gil_lock gil;
    if (!hook)
    {
        assert(!callback);
        return;
    }
    
    assert(!!callback);
    assert(!(*callback).is_none());
    Py_BEGIN_ALLOW_THREADS
    bool succeed = UnhookWindowsHookEx(hook);
    // check??????????
    Py_END_ALLOW_THREADS
    
    
    hook = NULL;
    callback = boost::none;
}
