
#include "hook_dll.h"
#include <Python.h>
#include "_set_clr_hook.hpp"
#include "gil_lock.hpp"



//-----------------
#include <boost/none.hpp>
#include <boost/optional.hpp>
#include <boost/python.hpp>
#include <cassert>
//#include <fstream>



#define _WIN32_WINNT 0x400
#include <windows.h>


using namespace std;
using boost::python::object;
using boost::optional;


/*
LRESULT CALLBACK LowLevelMouseProc(
  _In_  int nCode,
  _In_  WPARAM wParam,
  _In_  LPARAM lParam
);

Parameters

nCode [in]
Type: int
A code the hook procedure uses to determine how to process the message. If nCode is less than zero, the hook procedure must pass the message to the CallNextHookEx function without further processing and should return the value returned by CallNextHookEx. This parameter can be one of the following values.
Value	Meaning
HC_ACTION
0
The wParam and lParam parameters contain information about a mouse message.
 
wParam [in]
Type: WPARAM
The identifier of the mouse message. This parameter can be one of the following messages: WM_LBUTTONDOWN, WM_LBUTTONUP, WM_MOUSEMOVE, WM_MOUSEWHEEL, WM_MOUSEHWHEEL, WM_RBUTTONDOWN, or WM_RBUTTONUP.
lParam [in]
Type: LPARAM
A pointer to an MSLLHOOKSTRUCT structure.
Return value

Type:
Type: LRESULT
If nCode is less than zero, the hook procedure must return the value returned by CallNextHookEx.
If nCode is greater than or equal to zero, and the hook procedure did not process the message, it is highly recommended that you call CallNextHookEx and return the value it returns; otherwise, other applications that have installed WH_MOUSE_LL hooks will not receive hook notifications and may behave incorrectly as a result. If the hook procedure processed the message, it may return a nonzero value to prevent the system from passing the message to the rest of the hook chain or the target window procedure.
Remarks

An application installs the hook procedure by specifying the WH_MOUSE_LL hook type and a pointer to the hook procedure in a call to the SetWindowsHookEx function.
This hook is called in the context of the thread that installed it. The call is made by sending a message to the thread that installed the hook. Therefore, the thread that installed the hook must have a message loop.
The mouse input can come from the local mouse driver or from calls to the mouse_event function. If the input comes from a call to mouse_event, the input was "injected". However, the WH_MOUSE_LL hook is not injected into another process. Instead, the context switches back to the process that installed the hook and it is called in its original context. Then the context switches back to the application that generated the event.
The hook procedure should process a message in less time than the data entry specified in the LowLevelHooksTimeout value in the following registry key:
HKEY_CURRENT_USER\Control Panel\Desktop
The value is in milliseconds. If the hook procedure times out, the system passes the message to the next hook. However, on Windows 7 and later, the hook is silently removed without being called. There is no way for the application to know whether the hook is removed.
Note  Debug hooks cannot track this type of low level mouse hooks. If the application must use low level hooks, it should run the hooks on a dedicated thread that passes the work off to a worker thread and then immediately returns. In most cases where the application needs to use low level hooks, it should monitor raw input instead. This is because raw input can asynchronously monitor mouse and keyboard messages that are targeted for other threads more effectively than low level hooks can. For more information on raw input, see Raw Input.

*/




/*
typedef struct tagMSLLHOOKSTRUCT {
  POINT     pt;
  DWORD     mouseData;
  DWORD     flags;
  DWORD     time;
  ULONG_PTR dwExtraInfo;
} MSLLHOOKSTRUCT, *PMSLLHOOKSTRUCT, *LPMSLLHOOKSTRUCT;


Members

pt
Type: POINT
The x- and y-coordinates of the cursor, in screen coordinates.
mouseData
Type: DWORD
If the message is WM_MOUSEWHEEL, the high-order word of this member is the wheel delta. The low-order word is reserved. A positive value indicates that the wheel was rotated forward, away from the user; a negative value indicates that the wheel was rotated backward, toward the user. One wheel click is defined as WHEEL_DELTA, which is 120.
If the message is WM_XBUTTONDOWN, WM_XBUTTONUP, WM_XBUTTONDBLCLK, WM_NCXBUTTONDOWN, WM_NCXBUTTONUP, or WM_NCXBUTTONDBLCLK, the high-order word specifies which X button was pressed or released, and the low-order word is reserved. This value can be one or more of the following values. Otherwise, mouseData is not used.
Value	Meaning
XBUTTON1
0x0001
The first X button was pressed or released.
XBUTTON2
0x0002
The second X button was pressed or released.
 
flags
Type: DWORD
The event-injected flags. An application can use the following values to test the flags. Testing LLMHF_INJECTED (bit 0) will tell you whether the event was injected. If it was, then testing LLMHF_LOWER_IL_INJECTED (bit 1) will tell you whether or not the event was injected from a process running at lower integrity level.
Value	Meaning
LLMHF_INJECTED
0x00000001
Test the event-injected (from any process) flag.
LLMHF_LOWER_IL_INJECTED
0x00000002
Test the event-injected (from a process running at lower integrity level) flag.
 
time
Type: DWORD
The time stamp for this message.
dwExtraInfo
Type: ULONG_PTR
Additional information associated with the message.

*/




/*
GetCursorInfo, GetMessagePos
GetKeyState


----
It sounds like you are looking for GetCursorInfo and GetKeyState. The latter you call with virtual key codes that specify the mouse button of interest.

----
If you only need cursor position, you can just use GetCursorPos(). Remember that both GetCursorInfo() and GetCursorPos() return screen coordinates. Use ScreenToClient() to convert to client area offsets.

Although the OP didn't want to use Windows Messages, I just wanted to mention something as a sidenote.
Something I found was that getting the cursor position as part of a message handler (for instance WM_SETCURSOR), most of the literature recommends using GetMessagePos() to retrieve the cursor's position at the time the message was sent. However, its the position before the mouse moved, not after. So the position returned 'lags' behind a pixel when trying to do mouseover detection over an area.

----
I personally try to avoid calling GetCursorPos because of a bug on 64 bit Vista (possibly 64 bit XP), under WOW64. When the pointer you pass is in high address space (>2GB) the function fails. This is fixed in Windows 7, but I still prefer GetCursorInfo because it works everywhere.

*/


optional<object> mouse_callback;
HHOOK mouse_hook;
LRESULT CALLBACK LowLevelMouseProc(
  _In_  int nCode,
  _In_  WPARAM wParam,
  _In_  LPARAM lParam
);


bool hook_mouse(PyObject* pf_callback)
{
    return hook(WH_MOUSE_LL, LowLevelMouseProc, 
                mouse_hook, mouse_callback, pf_callback);
}

void unhook_mouse()
{
    unhook(mouse_hook, mouse_callback);
}





LRESULT CALLBACK LowLevelMouseProc(
  _In_  int nCode,
  _In_  WPARAM wParam,
  _In_  LPARAM lParam
)
{
    if (nCode < 0){}
    else if (nCode == HC_ACTION)
    {
        gil_lock gil;
        if (mouse_hook)
        {
            assert(!!mouse_callback);
            assert(!(*mouse_callback).is_none());
            MSLLHOOKSTRUCT* p_lParam = (MSLLHOOKSTRUCT*)lParam;

            object call_next_o = (*mouse_callback)(nCode, wParam, \
                p_lParam->pt.x, p_lParam->pt.y, p_lParam->mouseData, \
                p_lParam->flags, p_lParam->time, p_lParam->dwExtraInfo);


            bool call_next = boost::python::extract<bool>(call_next_o);
            if (!call_next) return 1;
        }
    }
    
    return CallNextHookEx(mouse_hook, nCode, wParam, lParam);
}





