
#ifndef gil_lock_hpp_HEAD_INCLUDED
#define gil_lock_hpp_HEAD_INCLUDED
#include "gil_lock.hpp"

#include <Python.h>

/// @brief RAII class used to lock and unlock the GIL.
class gil_lock
{
public:
  gil_lock()  { state_ = PyGILState_Ensure(); }
  ~gil_lock() { PyGILState_Release(state_);   }
private:
  PyGILState_STATE state_;
};


#endif
