#include <boost/none.hpp>
#include <boost/optional.hpp>
#include <boost/python.hpp>
#include <cassert>
//#include <vector>
//#include <cstdint> //uintptr_t
#include <fstream>
//#include <iostream>
//#include <typeinfo>


#define _WIN32_WINNT 0x400
#include <windows.h>


using namespace std;


//using std::vector;
using boost::python::object;
using boost::optional;


/*
LRESULT CALLBACK LowLevelKeyboardProc(
  _In_  int nCode,
  _In_  WPARAM wParam,
  _In_  LPARAM lParam
);



Parameters

nCode [in]
Type: int
A code the hook procedure uses to determine how to process the message. If nCode is less than zero, the hook procedure must pass the message to the CallNextHookEx function without further processing and should return the value returned by CallNextHookEx. This parameter can be one of the following values.
Value	Meaning
HC_ACTION
0
The wParam and lParam parameters contain information about a keyboard message.
 
wParam [in]
Type: WPARAM
The identifier of the keyboard message. This parameter can be one of the following messages: WM_KEYDOWN, WM_KEYUP, WM_SYSKEYDOWN, or WM_SYSKEYUP.
lParam [in]
Type: LPARAM
A pointer to a KBDLLHOOKSTRUCT structure.
Return value

Type:
Type: LRESULT
If nCode is less than zero, the hook procedure must return the value returned by CallNextHookEx.
If nCode is greater than or equal to zero, and the hook procedure did not process the message, it is highly recommended that you call CallNextHookEx and return the value it returns; otherwise, other applications that have installed WH_KEYBOARD_LL hooks will not receive hook notifications and may behave incorrectly as a result. If the hook procedure processed the message, it may return a nonzero value to prevent the system from passing the message to the rest of the hook chain or the target window procedure.

Remarks

An application installs the hook procedure by specifying the WH_KEYBOARD_LL hook type and a pointer to the hook procedure in a call to the SetWindowsHookEx function.
This hook is called in the context of the thread that installed it. The call is made by sending a message to the thread that installed the hook. Therefore, the thread that installed the hook must have a message loop.
The keyboard input can come from the local keyboard driver or from calls to the keybd_event function. If the input comes from a call to keybd_event, the input was "injected". However, the WH_KEYBOARD_LL hook is not injected into another process. Instead, the context switches back to the process that installed the hook and it is called in its original context. Then the context switches back to the application that generated the event.
The hook procedure should process a message in less time than the data entry specified in the LowLevelHooksTimeout value in the following registry key:
HKEY_CURRENT_USER\Control Panel\Desktop
The value is in milliseconds. If the hook procedure times out, the system passes the message to the next hook. However, on Windows 7 and later, the hook is silently removed without being called. There is no way for the application to know whether the hook is removed.
Note  Debug hooks cannot track this type of low level keyboard hooks. If the application must use low level hooks, it should run the hooks on a dedicated thread that passes the work off to a worker thread and then immediately returns. In most cases where the application needs to use low level hooks, it should monitor raw input instead. This is because raw input can asynchronously monitor mouse and keyboard messages that are targeted for other threads more effectively than low level hooks can. For more information on raw input, see Raw Input.


typedef struct tagKBDLLHOOKSTRUCT {
  DWORD     vkCode;
  DWORD     scanCode;
  DWORD     flags;
  DWORD     time;
  ULONG_PTR dwExtraInfo;
} KBDLLHOOKSTRUCT, *PKBDLLHOOKSTRUCT, *LPKBDLLHOOKSTRUCT;

Members

vkCode
Type: DWORD
A virtual-key code. The code must be a value in the range 1 to 254.
scanCode
Type: DWORD
A hardware scan code for the key.
flags
Type: DWORD
The extended-key flag, event-injected flags, context code, and transition-state flag. This member is specified as follows. An application can use the following values to test the keystroke flags. Testing LLKHF_INJECTED (bit 4) will tell you whether the event was injected. If it was, then testing LLKHF_LOWER_IL_INJECTED (bit 1) will tell you whether or not the event was injected from a process running at lower integrity level.
Value	Meaning
LLKHF_EXTENDED
(KF_EXTENDED >> 8)
Test the extended-key flag.
LLKHF_LOWER_IL_INJECTED
0x00000002
Test the event-injected (from a process running at lower integrity level) flag.
LLKHF_INJECTED
0x00000010
Test the event-injected (from any process) flag.
LLKHF_ALTDOWN
(KF_ALTDOWN >> 8)
Test the context code.
LLKHF_UP
(KF_UP >> 8)
Test the transition-state flag.
 
The following table describes the layout of this value.
Bits	Description
0	Specifies whether the key is an extended key, such as a function key or a key on the numeric keypad. The value is 1 if the key is an extended key; otherwise, it is 0.
1	Specifies whether the event was injected from a process running at lower integrity level. The value is 1 if that is the case; otherwise, it is 0. Note that bit 4 is also set whenever bit 1 is set.
2-3	Reserved.
4	Specifies whether the event was injected. The value is 1 if that is the case; otherwise, it is 0. Note that bit 1 is not necessarily set when bit 4 is set.
5	The context code. The value is 1 if the ALT key is pressed; otherwise, it is 0.
6	Reserved.
7	The transition state. The value is 0 if the key is pressed and 1 if it is being released.
 
time
Type: DWORD
The time stamp for this message, equivalent to what GetMessageTime would return for this message.
dwExtraInfo
Type: ULONG_PTR
Additional information associated with the message.
*/

/*

 Get window title or HWND in systemwide Keyboard hook??
In addition to ::GetFocus()

you can use ::GetParent( hWnd)

to retrieve the window of the Control 
having the focus. And ::GetWindow( hWnd, flag )

using GW_CHILD or GW_HWNDNEXT etc. 
is very helpful.... 


For what you want to do it would probably be better to use a WH_CALLWNDPROCRET, WH_CALLWNDPROC or WH_GETMESSAGE hook. You might need to also use a WH_SYSMSGFILTER hook but you are probably as familiar with hooks as I am. In the hook procedure, just process the keyboard message (WM_KEYUP and WM_KEYDOWN); of course, call CallNextHookEx for all messages, as appropriate.


GetFocus returns the window with the keyboard focus for the current thread's message queue. If GetFocus returns NULL, another thread's queue may be attached to a window that has the keyboard focus.
Use the GetForegroundWindow function to retrieve the handle to the window with which the user is currently working. You can associate your thread's message queue with the windows owned by another thread by using the AttachThreadInput function.
*/

/// @brief RAII class used to lock and unlock the GIL.
class gil_lock
{
public:
  gil_lock()  { state_ = PyGILState_Ensure(); }
  ~gil_lock() { PyGILState_Release(state_);   }
private:
  PyGILState_STATE state_;
};




//thread_local 
optional<object> keyboard_callback;
//thread_local 
HHOOK keyboard_hook;






LRESULT CALLBACK LowLevelKeyboardProc(
  _In_  int nCode,
  _In_  WPARAM wParam,
  _In_  LPARAM lParam
)
{
    //ofstream fout("E:/my_data/program_source/python3_src/virtual_input/log.txt", ios::app|ios::out);
    //fout << "callback!\n" << flush;
    if (nCode < 0){}
    else if (nCode == HC_ACTION)
    {
        // get the GIL
        gil_lock gil;
        //fout << "callback HC_ACTION!\n" << flush;
        if (keyboard_hook)
        {
            assert(!!keyboard_callback);
            assert(!(*keyboard_callback).is_none());
            KBDLLHOOKSTRUCT* p_lParam = (KBDLLHOOKSTRUCT*)lParam;
            #if 0
            //ULONG data = 0;
            if (p_lParam->dwExtraInfo)
            {
                Py_BEGIN_ALLOW_THREADS
                data = p_lParam->dwExtraInfo;
                //data = *(ULONG*)p_lParam->dwExtraInfo;
                // RtlMoveMemory(&data, (ULONG*)p_lParam->dwExtraInfo, sizeof(data));
                Py_END_ALLOW_THREADS
            }
            #endif
            object call_next_o = (*keyboard_callback)(nCode, wParam, \
                p_lParam->vkCode, p_lParam->scanCode, p_lParam->flags, \
                p_lParam->time, p_lParam->dwExtraInfo);


            bool call_next = boost::python::extract<bool>(call_next_o);
            if (!call_next) return 1;
        }
    }
    
    //fout << "callback CallNextHookEx!\n" << flush;
    return CallNextHookEx(keyboard_hook, nCode, wParam, lParam);
}

bool hook_keyboard(PyObject* callback)
{
    gil_lock gil;
    if (keyboard_hook) return false;
    assert(!keyboard_callback);
    if (!PyCallable_Check(callback)) return false;
    
    HHOOK h;
    Py_BEGIN_ALLOW_THREADS
    HMODULE hMod = GetModuleHandle("_python_hook.pyd");
    //assert(hMod);
    h = SetWindowsHookEx(WH_KEYBOARD_LL, LowLevelKeyboardProc, hMod, 0);
    Py_END_ALLOW_THREADS
    
    if (!h) return false;
    
    
    object o(boost::python::handle<>(boost::python::borrowed(callback)));
    keyboard_callback = o;
    assert(!!keyboard_callback);
    assert(!(*keyboard_callback).is_none());
    keyboard_hook = h;
    return true;
}

void unhook_keyboard()
{
    gil_lock gil;
    if (!keyboard_hook)
    {
        assert(!keyboard_callback);
        return;
    }
    
    assert(!!keyboard_callback);
    assert(!(*keyboard_callback).is_none());
    Py_BEGIN_ALLOW_THREADS
    bool succeed = UnhookWindowsHookEx(keyboard_hook);
    // check??????????
    Py_END_ALLOW_THREADS
    
    
    keyboard_hook = NULL;
    keyboard_callback = boost::none;
}


BOOST_PYTHON_MODULE(_python_hook)
{
    
    using namespace boost::python;
    PyEval_InitThreads();
    def("hook_keyboard", hook_keyboard);
    def("unhook_keyboard", unhook_keyboard);
}
