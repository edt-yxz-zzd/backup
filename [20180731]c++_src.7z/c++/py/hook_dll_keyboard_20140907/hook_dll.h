
#ifndef hook_dll_h_HEAD_INCLUDED
#define hook_dll_h_HEAD_INCLUDED
#include "hook_dll.h"


// struct PyObject; // a typedef !!!
#include <Python.h> // PyObject


bool hook_keyboard(PyObject* callback);
void unhook_keyboard();


bool hook_mouse(PyObject* callback);
void unhook_mouse();

#endif

