


#include <cassert>

#ifndef _PARTITION_HPP_
#define _PARTITION_HPP_


class Partition
{
    int *const element2loc;
    int *const loc2element;
    int *const loc2block;
    int (*const block2range)[2];
    
    int const size_of_element2loc;
    int const size_of_loc2element;
    int const size_of_loc2block;
    int const size_of_block2range;
    int _num_blocks;
public:
    //typedef int int2s[2];
    Partition(
        int *element2loc_, int size_of_element2loc_,
        int *loc2element_, int size_of_loc2element_,
        int *loc2block_, int size_of_loc2block_,
        int (*block2range_)[2], int size_of_block2range_, int num_blocks)
        
        :element2loc(element2loc_), size_of_element2loc(size_of_element2loc_), 
         loc2element(loc2element_), size_of_loc2element(size_of_loc2element_), 
         loc2block(loc2block_), size_of_loc2block(size_of_loc2block_), 
         block2range(block2range_), size_of_block2range(size_of_block2range_),
         _num_blocks(num_blocks)
        {}

    int elem2loc(int elem)const{return element2loc[elem];}
    int loc2elem(int loc)const{return loc2element[loc];}
    int loc2blk(int loc)const{return loc2block[loc];}
    int elem2blk(int elem)const{return loc2blk(elem2loc(elem));}
    //int2s const* blk_range(int block)const{return block2range + block;}
    int blk_begin_loc(int block)const{return block2range[block][0];}
    int blk_end_loc(int block)const{return block2range[block][1];}
    int blk_size(int block)const
    {
        return blk_end_loc(block) - blk_begin_loc(block);
    }
    int const* blk2elem_begin(int block)const
        {return loc2element + blk_begin_loc(block);}
    int const* blk2elem_end(int block)const
        {return loc2element + blk_end_loc(block);}
    int num_blocks(void)const{return _num_blocks;}
    int first_elem(int block)const{return *blk2elem_begin(block);}
    
    int split_tail(int block, int size)
    {
        // size of block > 0
        assert(size < blk_size(block));
        assert(size > 0);
        
        int new_end = blk_end_loc(block);
        int split_pos = new_end - size;
        block2range[block][1] = split_pos;
        int new_block = _new_block(split_pos, new_end);
        return new_block;
    }
    
    int next_blk(int block)const
    {
        int loc = blk_end_loc(block);
        if (loc >= size_of_loc2block)
            throw "next block: loc >= size_of_loc2block";
        return loc2blk(loc);
    }
    
    void split_tail_to_next(int block, int size)
    {
        int next_block = next_blk(block);
        
        // size of block > 0
        assert(size < blk_size(block));
        assert(size > 0);
        
        int split_end = blk_end_loc(block);
        int split_pos = split_end - size;
        block2range[block][1] = split_pos;
        block2range[next_block][0] = split_pos;
        
        _assign_rng_new_block_idx(split_pos, split_end, next_block);
    }
    
    void move_elem_at_loc_to_blk_end(int block, int loc)
    {
        assert(loc2blk(loc) == block);
        _swap(loc, blk_end_loc(block)-1);
    }

    
    void move_elem_at_loc_to_next(int block, int loc)
    {
        move_elem_at_loc_to_blk_end(block, loc);
        split_tail_to_next(block, 1);
    }
    void move_elem_to_next(int element)
    {
        int loc = elem2loc(element);
        int block = loc2blk(loc);
        move_elem_at_loc_to_next(block, loc);
    }
    void move_elem_to_blk_end(int element)
    {
        int loc = elem2loc(element);
        int block = loc2blk(loc);
        move_elem_at_loc_to_blk_end(block, loc);
    }

private:
    void _swap(int loc1, int loc2)
    {
        assert(loc2blk(loc1) == loc2blk(loc1));
        int e1 = loc2elem(loc1);
        int e2 = loc2elem(loc2);
        loc2element[loc1] = e2;
        loc2element[loc2] = e1;
        element2loc[e1] = loc2;
        element2loc[e2] = loc1;
    }
    int _new_block(int begin, int end)
    {
        int new_block = _num_blocks;
        if (new_block >= size_of_block2range)
            throw "new_block >= size_of_block2range";
        ++_num_blocks;
        block2range[new_block][0] = begin;
        block2range[new_block][1] = end;
        _assign_rng_new_block_idx(begin, end, new_block);
        return new_block;
    }        
    void _assign_rng_new_block_idx(int begin, int end, int block)
    {
        while(end --> begin)
        {
            loc2block[end] = block;
        }
    }
};



#endif //_PARTITION_HPP_












