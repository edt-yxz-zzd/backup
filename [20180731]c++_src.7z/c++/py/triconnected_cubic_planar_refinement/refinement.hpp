

//#include <vector>
#include "OneTimeMap.hpp"
#include "Partition.hpp"

int refinement(
    int num_dedges,
    Partition& partition, 
    OneTimeMap& block2count, 
    int const* (&leftorright2dedge2neighbor)[2]);