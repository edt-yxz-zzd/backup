

#ifndef _ONETIMEMAP_HPP_
#define _ONETIMEMAP_HPP_

//#include <cassert>
//#include <iostream>
//using namespace std;


class OneTimeMap
{
    int *const key2loc;
    int *const loc2key;
    int *const loc2data;
    
    int const size_of_key2loc;
    int const size_of_loc2key;
    int const size_of_loc2data;
    int used_size; // using size of loc2key
    
    /*
    void print_ints(
        char const *head, char const *tail, 
        int const* ints, int size)const
    {
        cout << head << endl;
        for (int i = size; i --> 0;){
            cout << ints[size-1-i] << ' ';
        }
        cout << '\n' << tail << endl;

    }
//public:
    void print()const
    {
        print_ints("key2loc", "\n", key2loc, size_of_key2loc);
        print_ints("loc2key", "\n", loc2key, size_of_loc2key);
        print_ints("loc2data", "\n", loc2data, size_of_loc2data);
        cout << "used_size " << used_size << endl;

    }*/
    
public:
    OneTimeMap(
        int *buffer_key2loc, int size_of_key2loc_,
        int *buffer_loc2key, int size_of_loc2key_,
        int *buffer_loc2data, int size_of_loc2data_)
        :key2loc(buffer_key2loc),
         loc2key(buffer_loc2key),
         loc2data(buffer_loc2data),
         size_of_key2loc(size_of_key2loc_), 
         size_of_loc2key(size_of_loc2key_), 
         size_of_loc2data(size_of_loc2data_), 
         used_size(0)
    {
        // if (key2loc == NULL)
        // if (size_of_key2loc_ <= 0)
        // if (size_of_loc2key_ != size_of_loc2data_)
    }
    
    
    void loc2key_value(int loc, int& key, int& value)
    {
        key = _get_key(loc);
        value = _get_data(loc);
    }
    int setdefault(int key, int value)
    {
        if (contains(key)){
            return getitem(key);
        }
        setitem(key, value);
        return value;
    }
    bool contains(int key)const
    {
        return -1 != find_key_loc(key);
    }
    void clear(){used_size = 0;}
    void setitem(int key, int data)
    {
        int loc = find_key_loc(key);
        if (loc < 0){
            loc = _new_loc();
            _put_key(loc, key);
        }
        _put_data(loc, data);
    }
    int getitem(int key)const
    {
        int loc = getorder(key);
        return _get_data(loc);
    }
    int operator [](int key)const
    {
        return getitem(key);
    }
    int& operator [](int key)
    {
        int loc = getorder(key);
        return _get_data_ref(loc);
    }
    
    int getorder(int key)const
    {
        int loc = find_key_loc(key);
        if (loc < 0) throw "OneTimeMap KeyError";
        return loc;
    }
    int lastkey(void)const
    {
        int loc = _last_loc();
        if (loc < 0) throw "lastkey empty map";
        return _get_key(loc);
    }
    int last(void)const
    {
        int key = lastkey();
        return getitem(key);
    }
    int poplast(void)
    {
        if (!size()) throw "pop empty map";
        int last_loc = _end_loc()-1;
        int data = last();
        _delete_loc(last_loc);
        return data;
    }
    
    int size()const{return used_size;}
    int* begin(){return loc2data;}
    int* end(){return loc2data+size();}
    int const* begin()const{return loc2data;}
    int const* end()const{return loc2data+size();}
    
    int find_key_loc(int key)const
    {
        if (key < 0 || key >= size_of_key2loc)
            throw "key < 0 || key >= size_of_key2loc";
        int loc = key2loc[key];
        if (loc < 0 || loc >= size() || loc2key[loc] != key) return -1;
        return loc;
    }
private:
    
    int _last_loc(void)const
    {
        return _end_loc()-1;
    }
    int _new_loc(void)
    {
        int loc = size();
        _check_loc(loc);
        if (loc >= size_of_loc2key) 
            throw "new_loc size() >= size_of_loc2key"; 
        if (loc >= size_of_loc2data) 
            throw "new_loc size() >= size_of_loc2data"; 
        ++used_size;
        return loc;
    }
    void _delete_loc(int loc)
    {
        if (!size()) throw "delete empty map";
        if (loc != _last_loc()) throw "delete nonlast";
        --used_size;
    }
    
    void _put_data(int loc, int data)
    {
        _check_loc(loc);
        loc2data[loc] = data;
    }
    void _check_loc(int loc)const
    {
        if (loc < 0 || loc >= size_of_loc2data) 
            throw "loc < 0 || loc >= size_of_loc2data";
        if (loc < 0 || loc >= size_of_loc2key) 
            throw "loc < 0 || loc >= size_of_loc2key";
    }
    int _get_data(int loc)const
    {
        _check_loc(loc);
        return loc2data[loc];
    }
    int& _get_data_ref(int loc)
    {
        _check_loc(loc);
        return loc2data[loc];
    }
    void _put_key(int loc, int key)
    {
        _check_loc(loc);
        loc2key[loc] = key;
        key2loc[key] = loc;
    }
    int _get_key(int loc)const
    {
        _check_loc(loc);
        return loc2key[loc];
    }
    int _begin_loc(void)const{return 0;}
    int _end_loc(void)const{return used_size;}
    

};


#endif //_ONETIMEMAP_HPP_

