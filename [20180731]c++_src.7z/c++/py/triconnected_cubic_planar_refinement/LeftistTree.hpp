




struct LeftistNode
{
    void *const key;
    void *const value;
    LeftistNode const *const left;
    LeftistNode const *const right;
    int const min_leaf_height;
    int const size;
};

inline bool is_leftist_leaf(LeftistNode const* pNode)
{
    return pNode == nullptr;
}

inline LeftistNode const* leftist_leaf(){return nullptr;}
inline LeftistNode const* leftist_node()








