

/* #define Py_LIMITED_API no Py_buffer */
// call PyBuffer_Release !! for "w*" ? "y*" ...!!
#include <Python.h>
//#include "limit_py.h"
#include "gil_lock.hpp"
#include "scoped_pyobj.hpp"

#include <vector>
#include <iostream>

#include "OneTimeMap.hpp"
#include "Partition.hpp"
#include "refinement.hpp"

using namespace std;

typedef int const* int2s[2];


static PyObject *_refinement(PyObject *self, PyObject *args)
{
    Py_buffer dedge2loc, loc2dedge, loc2block, block2range,
        py_leftorright2dedge2neighbor;
    int num_dedges, num_blocks;
    if (! PyArg_ParseTuple(args, "iiw*w*w*w*y*", 
            &num_dedges, &num_blocks, 
            &dedge2loc, &loc2dedge, &loc2block, &block2range,
            &py_leftorright2dedge2neighbor))
    {
        return NULL;
    }
    
    scoped_obj<Py_buffer> _ls[] = {
        &dedge2loc, &loc2dedge, &loc2block, &block2range,
        &py_leftorright2dedge2neighbor
    };

    
    PyObject *r = NULL;
    try
    {
        int root_dedge;
        {threads_allow _t;
        
        vector<int> block2count_loc(num_dedges), 
            count_loc2block(num_dedges), count_loc2count(num_dedges);
        
        int const* _lr = (int const*)py_leftorright2dedge2neighbor.buf;
        int const* leftorright2dedge2neighbor[2] = {_lr, _lr+num_dedges};
        
        Partition partition(
            (int*)dedge2loc.buf, num_dedges,
            (int*)loc2dedge.buf, num_dedges,
            (int*)loc2block.buf, num_dedges,
            (int(*)[2])block2range.buf, num_dedges, num_blocks);
        OneTimeMap block2count(
            &block2count_loc.front(), num_dedges,
            &count_loc2block.front(), num_dedges,
            &count_loc2count.front(), num_dedges);
        root_dedge = refinement(num_dedges, partition, block2count, 
                                    leftorright2dedge2neighbor);
        
        
        }r = PyLong_FromLong(root_dedge);
    }
    catch(char const* e){
        cerr << "C++ exception:" << e << endl;
        PyErr_SetString(PyExc_RuntimeError, e);
        r = NULL;
    }
    catch(...){
        cerr << "C++ exception" << endl;
        PyErr_SetString(PyExc_RuntimeError, "C++ exception");
        r = NULL;
    }
    
    /*
    PyBuffer_Release(&dedge2loc);
    PyBuffer_Release(&loc2dedge);
    PyBuffer_Release(&loc2block);
    PyBuffer_Release(&block2range);
    PyBuffer_Release(&py_leftorright2dedge2neighbor);
    */
    return r;
}



/*/////////////////////////////////////////////*/
static PyMethodDef pymodule_methods[] = {

    {"_refinement",  _refinement, METH_VARARGS,
     "_refinement for 3-connected cubic planar graph isomorphism"
     
    },

    {NULL, NULL, 0, NULL}        /* Sentinel */
};

static struct PyModuleDef pymodule = {
   PyModuleDef_HEAD_INIT,
   "_refinement",   /* name of module */
   NULL, /* module documentation, may be NULL */
   -1,       /* size of per-interpreter state of the module,
                or -1 if the module keeps state in global variables. */
   pymodule_methods
};

PyMODINIT_FUNC
PyInit__refinement(void)
{
    
    return PyModule_Create(&pymodule);
}


