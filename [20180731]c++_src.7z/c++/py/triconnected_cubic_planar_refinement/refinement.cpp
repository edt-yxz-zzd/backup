
//#include <iostream>
#include <set>
#include <vector>
#include <utility> // pair
#include "OneTimeMap.hpp"
#include "Partition.hpp"
#include "refinement.hpp"

using namespace std;


int const LEFTMOST = 0;
int const RIGHTMOST = 1;

class ProcessMinPriorityQueue
{
    typedef set<int> Type;
    typedef Type::iterator TypeIter;
    Type _process;
    Partition const& _partition;
public:
    ProcessMinPriorityQueue(Partition const& partition)
    :_partition(partition){}
    int encode(int block, int leftorright)
    {
        int begin_loc = _partition.blk_begin_loc(block);
        int code = 2*begin_loc + leftorright;
        
        assert(_partition.loc2blk(begin_loc) == block);
        int _blk, _lr;
        assert((decode(code, _blk, _lr), _blk==block && _lr==leftorright));
        return code;
    }
    void decode(int code, int& block, int& leftorright)
    {
        int begin_loc = code/2;
        leftorright = code%2;
        block = _partition.loc2blk(begin_loc);
    }
    void add(int block, int leftorright)
    {
        int code = encode(block, leftorright);
        pair<TypeIter,bool> r = _process.insert(code);
        assert(r.second); // not exist
    }
    void pop(int& block, int& leftorright)
    {
        int code = *_process.begin();
        _process.erase(_process.begin());
        decode(code, block, leftorright);
        
    }
    
    operator bool()const
    {
        return _process.size();
    }
    
    bool processed(int block, int leftorright)
    {
        int code = encode(block, leftorright);
        return !_process.count(code);
    }

};

int refinement(
    int num_dedges,
    Partition& partition, 
    OneTimeMap& block2count, 
    int const* (&leftorright2dedge2neighbor)[2])
{
    //assert(leftorright2dedge2neighbor.size() == 2);
    
    //int num_dedges = leftorright2dedge2neighbor[LEFTMOST].size();
    ProcessMinPriorityQueue process(partition);
    
    for (int block = partition.num_blocks(); block --> 0;){
        process.add(block, LEFTMOST);
        process.add(block, RIGHTMOST);
    }
    
    int block = -1;
    int on_block_leftorright = -1; // on_block_leftorright
    int __num_loops = 0;
    int __num_steps = 0;
    while (process){
        process.pop(block, on_block_leftorright);
        //cerr << "before clear" << endl;
        block2count.clear();
        __num_loops += 1;
        //cerr << "after clear" << endl;

        // steps 'loop' body spent = O(block_size)
        __num_steps += partition.blk_size(block);
        
        // all dedges on current block's left/right
        vector<int> moving; // dedges

        int const *const dedge2neighbor = 
            leftorright2dedge2neighbor[on_block_leftorright];

        {
            int const* begin = partition.blk2elem_begin(block);
            int const* end = partition.blk2elem_end(block);
            for (int const* p_dedge = begin; p_dedge != end; ++p_dedge){
                moving.push_back(dedge2neighbor[*p_dedge]);
            }
        }


        for (int i = moving.size(); i --> 0;){
            int block = partition.elem2blk(moving[i]);
            block2count.setdefault(block, 0);
            
            //cerr << "after setdefault" << endl;try
            {block2count[block] += 1;}
            //catch(...){cerr << "block:" << block << endl;throw;}

        }

        //cerr << "before count" << endl;

        for (int loc = block2count.size(); loc --> 0;){
            int block;
            int count;
            block2count.loc2key_value(loc, block, count);
            
            int block_size = partition.blk_size(block);
            assert(count > 0 || count <= block_size);
            if (count == block_size){
                block2count[block] = -1;
            }
            //catch(...){cerr << "count:" << count << " " << "block:" << block << endl;}
        }
        
        //cerr << "before split" << endl;

/*
        # move edges
        # split blocks
        # NOTE:
        #    order of dedges in 'moving' determine
        #    1) order of block_idc
        #       which affect the order how we put data into process
        #    2) 1) will affect the split order of a block
        #    we should control dedge order in 'moving'(hard) AND
        #    control the element order in 'process'
        #    now I use begin_location of block to identify block
        #
        #    Once I used OneTimeSet for 'process'
        #    but it failed, so I switched to SortedSet
        */
        
        for (int i = moving.size(); i --> 0;){
            int dedge = moving[i];
            int block = partition.elem2blk(dedge);
            int count = block2count[block];
            /*
            # count = -1/0/>0
            # if -1: block is subset of moving, can't split
            # if 0: we have created a new block next to it
            # if >0: we have to create a new block
            */
            
            if (count < 0)
                continue;
            if (count > 0) {
                partition.move_elem_to_blk_end(dedge);
                int new_block = partition.split_tail(block, 1);
                assert(new_block == partition.next_blk(block));
                block2count[block] = 0;
            }
            else {
                partition.move_elem_to_next(dedge);
            }
            
            int next_block = partition.elem2blk(dedge);
            assert(next_block == partition.next_blk(block));
            assert (partition.elem2loc(dedge) == 
                    partition.blk_begin_loc(next_block));
            assert (partition.blk_end_loc(block) == 
                    partition.blk_begin_loc(next_block));
        }

        //cerr << "before create new block" << endl;
        
        // new created blocks require 'process'
        for (int loc = block2count.size(); loc --> 0;){
            int block;
            int count;
            block2count.loc2key_value(loc, block, count);
            if (count < 0) continue;
            assert(0 == count);
            
            int new_block = partition.next_blk(block);
            for (int leftorright = 2; leftorright --> 0;){
                if (process.processed(block, leftorright) &&
                        partition.blk_size(block) < 
                            partition.blk_size(new_block))
                    process.add(block, leftorright);
                else
                    process.add(new_block, leftorright);
            }
        }
    }
    
    
    //E = 4*g.ne() # undirected->directed and L/R; 4 times
    //assert E*E.bit_length() >= __num_steps
    //assert __num_loops == dedge_partition.num_blocks() * 2 <= E
    int E = 2 * num_dedges;
    int E_bit_length = 0;
    for (int i=E; i; i >>= 1) ++E_bit_length;
    assert(E*E_bit_length >= __num_steps);
    assert(__num_loops == partition.num_blocks() * 2);
    assert(__num_loops <= E);
    return partition.loc2elem(0); // first dedge
}





















































