#include "hook_at_dll.h"
#include <Python.h>
#include "_set_clr_hook.hpp"
#include "gil_lock.hpp"


//-------------
#include <boost/none.hpp>
#include <boost/optional.hpp>
#include <boost/python.hpp>
#include <cassert>
//#include <vector>
//#include <cstdint> //uintptr_t
//#include <fstream>
//#include <iostream>
//#include <typeinfo>


#define _WIN32_WINNT 0x400
#include <windows.h>





using namespace std;


//using std::vector;
using boost::python::object;
using boost::optional;



typedef struct {
    optional<object> py_callback;
    HHOOK hhook;
    HOOKPROC c_callback;
} hook_data_t;

typedef hook_data_t _ls_t[hook_at_dll_h_NUM_HOOK_FUNC];


inline static _ls_t& get_hook_data_ls()
{
    static _ls_t hook_data_ls;
    return hook_data_ls;
}


#ifdef _NUM_HOOK_FUNC
    #error
#endif
#define _NUM_HOOK_FUNC (sizeof(_ls_t)/sizeof((*(_ls_t*) NULL)[0]))


/*
#if _NUM_HOOK_FUNC != hook_at_dll_h_NUM_HOOK_FUNC
    #error
#endif
*/


inline unsigned get_sizeof_hook_array()
{
    return _NUM_HOOK_FUNC;
}


static bool _hook_at(unsigned i, int idHook, PyObject* pf_py_callback)
{
    static _ls_t& hook_data_ls = get_hook_data_ls();
    return hook(idHook,
                hook_data_ls[i].c_callback, 
                hook_data_ls[i].hhook, 
                hook_data_ls[i].py_callback, 
                pf_py_callback);
}

unsigned hook_at_available_idx(int idHook, PyObject* pf_py_callback)
{
    static _ls_t& hook_data_ls = get_hook_data_ls();
    gil_lock gil;
    for (unsigned i = 0; i < get_sizeof_hook_array(); ++i)
    {
        if (hook_data_ls[i].hhook == NULL)
        {
            if (_hook_at(i, idHook, pf_py_callback))
            {
                return i;
            }
        }
    }
    
    return get_sizeof_hook_array();
}


bool hook_at(unsigned i, int idHook, PyObject* pf_py_callback)
{
    static _ls_t& hook_data_ls = get_hook_data_ls();
    gil_lock gil;
    return _hook_at(i, idHook, pf_py_callback);
}

void unhook_at(unsigned i)
{
    static _ls_t& hook_data_ls = get_hook_data_ls();
    unhook(hook_data_ls[i].hhook, hook_data_ls[i].py_callback);
}




static void _init_at(unsigned i, HOOKPROC c_callback)
{
    static _ls_t& hook_data_ls = get_hook_data_ls();
    hook_data_ls[i].hhook = NULL;
    hook_data_ls[i].c_callback = c_callback;
}

static LRESULT CALLBACK c_callback_at(
  unsigned i, 
  _In_  int nCode,
  _In_  WPARAM wParam,
  _In_  LPARAM lParam
)
{
    HHOOK hhook = NULL;
    {
        // get the GIL
        gil_lock gil;
        static _ls_t& hook_data_ls = get_hook_data_ls();
        hhook = hook_data_ls[i].hhook;
        if (hhook)
        {
            optional<object>& py_callback = hook_data_ls[i].py_callback;
            assert(!!py_callback);
            assert(!(*py_callback).is_none());
            object not_to_call_next_o = (*py_callback)(nCode, wParam, lParam);

            bool not_to_call_next = boost::python::extract<bool>(not_to_call_next_o);
            if (not_to_call_next) return 1;
        }
    }
    
    return CallNextHookEx(hhook, nCode, wParam, lParam);
}




template<unsigned N>
struct _hook_data_ls_init_t : public _hook_data_ls_init_t<N-1>
{
    _hook_data_ls_init_t()
    {
        _init_at(N-1, c_callback);
    }
    static LRESULT CALLBACK c_callback(
      _In_  int nCode,
      _In_  WPARAM wParam,
      _In_  LPARAM lParam
    )
    { return c_callback_at(N-1, nCode, wParam, lParam); } 
};

template<>
struct _hook_data_ls_init_t<0>{};

// init hook_data_ls
static _hook_data_ls_init_t<_NUM_HOOK_FUNC> _t;

#undef _NUM_HOOK_FUNC



