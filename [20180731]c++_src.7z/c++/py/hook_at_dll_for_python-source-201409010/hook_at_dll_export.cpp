
#include "hook_at_dll.h"
#include <boost/python.hpp>


BOOST_PYTHON_MODULE(_python_hook)
{
    
    using namespace boost::python;
    PyEval_InitThreads();
    def("hook_at", hook_at);
    def("unhook_at", unhook_at);
    def("get_sizeof_hook_array", get_sizeof_hook_array);
    def("hook_at_available_idx", hook_at_available_idx);

}
