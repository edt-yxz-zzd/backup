import _python_hook

# idHook: the same arg will be passed to SetWindowsHookEx
WH_KEYBOARD_LL = 13
idHook = WH_KEYBOARD_LL # for example : WH_KEYBOARD_LL, WH_MOUSE_LL

# callback(nCode, wParam, lParam)->not_to_call_CallNextHookEx
def callback(nCode, wParam, lParam):
    # the same args as the c callback saw
    not_to_call_CallNextHookEx = False
    if nCode != 0: return not_to_call_CallNextHookEx
    
    # ..............
    # do your work
    # return as soon as possible
    # ..............
    return not_to_call_CallNextHookEx


# get the marco value, the number of hooks available
hook_at_dll_h_NUM_HOOK_FUNC = _python_hook.get_sizeof_hook_array()
for i in range(hook_at_dll_h_NUM_HOOK_FUNC):
    if _python_hook.hook_at(i, idHook, callback):
        _python_hook.unhook_at(i)


for i in range(hook_at_dll_h_NUM_HOOK_FUNC):
    if not _python_hook.hook_at(i, idHook, callback):
        t = i
        print('max num of hooks:', t)
        break
else:
    t = i + 1
assert _python_hook.hook_at_available_idx(idHook, callback) == hook_at_dll_h_NUM_HOOK_FUNC
_python_hook.unhook_at(t-1)
assert _python_hook.hook_at_available_idx(idHook, callback) == t-1

for i in range(t):
    _python_hook.unhook_at(i)





########################
import ctypes
from ctypes import windll
VK_A = ord('A')
KEYEVENTF_KEYUP = 2
KEYEVENTF_KEYDOWN = 0
WM_KEYUP = 0x0101


'''
VOID WINAPI keybd_event(
  _In_  BYTE bVk,
  _In_  BYTE bScan,
  _In_  DWORD dwFlags,
  _In_  ULONG_PTR dwExtraInfo
);
'''
from ctypes import c_void_p, WINFUNCTYPE, windll
from ctypes.wintypes import BYTE, DWORD

ULONG_PTR = c_void_p
prototype = WINFUNCTYPE(None, BYTE, BYTE, DWORD, ULONG_PTR)
paramflags = (1, "bVk", 0), (1, "bScan", 0), (1, "dwFlags", 0), (1, "dwExtraInfo", 0)
keybd_event = prototype(("keybd_event", windll.user32), paramflags)




idHook = WH_KEYBOARD_LL
count = 0

def callback(nCode, wParam, lParam):
    try:
        return _callback(nCode, wParam, lParam)
    except Exception as e:
        print(type(e))
        print(e)
        raise
def _callback(nCode, wParam, lParam):
    not_to_call_CallNextHookEx = False
    if nCode != 0: return not_to_call_CallNextHookEx
    
    # ..............
    if wParam == WM_KEYUP:
        print('\tcallback')
        global count
        count += 1
    # ..............
    return not_to_call_CallNextHookEx

from sys import getrefcount as gc
p = lambda: gc(callback)#print('getrefcount(callback)', gc(callback))
assert 2 == p()
if _python_hook.hook_at(i, idHook, callback):
    assert 3 == p()
    _python_hook.unhook_at(i)
    assert 2 == p()


print('test...')
print('do not touch keyboard')
i = 0

if _python_hook.hook_at(i, idHook, callback):
    assert 3 == p()
    keybd_event(VK_A, 0, KEYEVENTF_KEYDOWN, 0)
    keybd_event(VK_A, 0, KEYEVENTF_KEYUP, 0)
    _python_hook.unhook_at(i)
    assert 2 == p()
    keybd_event(VK_A, 0, KEYEVENTF_KEYDOWN, 0)
    keybd_event(VK_A, 0, KEYEVENTF_KEYUP, 0)
        
    if count == 1:
        print('success')
    else:
        print('fail')


