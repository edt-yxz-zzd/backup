
for what:
    since some hook functions need to be in a DLL, 
    this project is here to provide such functions
    to wrap your python callback functions.
    

dependency:
    (1) python for windows
    (2) write in c++. boost.python is required. 
            
compile:
    (1) msvc is recommended:
        conflicts exist between mingw.exception and python for windows.
    (2) set the include and library path of python and boost:
        py_include   py_lib
        boost        boost_lib
    (3) define hook_at_dll_h_NUM_HOOK_FUNC in the cmdline:
        cl /Fe_python_hook.pyd /Dhook_at_dll_h_NUM_HOOK_FUNC=256 /LD /MD /EHsc hook_at_dll.cpp _set_clr_hook.cpp hook_at_dll_export.cpp User32.lib /I%py_include% /I%boost% /link /LIBPATH:%boost_lib% /LIBPATH:%py_lib%

install:
    let the output file "_python_hook.pyd" and the boost.python dll file 
    be visitable to Python
    
usage in Python:
    import _python_hook
    
    # idHook: the same arg will be passed to SetWindowsHookEx
    WH_KEYBOARD_LL = 13
    idHook = WH_KEYBOARD_LL # for example : WH_KEYBOARD_LL, WH_MOUSE_LL
    
    # callback(nCode, wParam, lParam)->not_to_call_CallNextHookEx
    def callback(nCode, wParam, lParam):
        # the same args as the c callback saw
        not_to_call_CallNextHookEx = False
        if nCode != 0: return not_to_call_CallNextHookEx
        
        # ..............
        # do your work
        # return as soon as possible
        # ..............
        return not_to_call_CallNextHookEx
    
    
    # get the marco value, the number of hooks available
    hook_at_dll_h_NUM_HOOK_FUNC = _python_hook.get_sizeof_hook_array()
    for i in range(hook_at_dll_h_NUM_HOOK_FUNC):
        if _python_hook.hook_at(i, idHook, callback):
            _python_hook.unhook_at(i)




