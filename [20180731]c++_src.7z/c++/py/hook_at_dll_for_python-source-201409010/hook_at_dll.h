
#ifndef hook_at_dll_h_HEAD_INCLUDED
#define hook_at_dll_h_HEAD_INCLUDED
#include "hook_at_dll.h"


#ifndef hook_at_dll_h_NUM_HOOK_FUNC
    #define hook_at_dll_h_NUM_HOOK_FUNC 64  // number of the hook functions
#endif


// struct PyObject; // a typedef !!!
#include <Python.h> // PyObject


bool hook_at(unsigned idx_in_hook_array, int idHook, PyObject* pf_py_callback);
void unhook_at(unsigned idx_in_hook_array);

unsigned get_sizeof_hook_array();

// return idx_in_hook_array if success
//        sizeof_hook_array otherwise
unsigned hook_at_available_idx(int idHook, PyObject* pf_py_callback);

#endif

