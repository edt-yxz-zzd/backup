#include <windows.h>
#include <iostream>
#include <typeinfo>
using namespace std;

int main()
{
    cout << typeid(HHOOK).name() << endl;
}