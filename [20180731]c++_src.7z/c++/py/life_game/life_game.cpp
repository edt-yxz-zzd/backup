#include "life_game.h"
#include <Python.h>
#include "gil_lock.hpp"


//-------------
#include <boost/none.hpp>
#include <boost/optional.hpp>
#include <boost/python.hpp>
#include <cassert>
//#include <vector>
//#include <cstdint> //uintptr_t
//#include <fstream>
#include <iostream>
//#include <typeinfo>
#include <map>
#include <set>
#include <utility> // pair

typedef long x_t;
typedef std::pair<x_t, x_t> xy_t;
typedef std::set<xy_t> xys_t;

using namespace std;
using namespace boost::python;

//using std::vector;
using boost::python::object;

xys_t xylist2std_set(boost::python::list const& xy_list)
{
    xys_t s;
    unsigned u = len(xy_list);
    for (unsigned i = 0; i < u; ++i)
    {
        object xy = xy_list[i];
        x_t x = extract<x_t>(xy[0]);
        x_t y = extract<x_t>(xy[1]);
        
        //cout << x << y << endl;
        
        s.insert(xy_t(x,y));
    }
    
    return s;
}
boost::python::list std_set2xylist(xys_t const& s)
{
    list ls;
    for (xys_t::iterator i = s.begin(); i != s.end(); ++i)
    {
        ls.append(make_tuple(i->first, i->second));
        
    }
    
    return ls;
}


xys_t life_game(xys_t const& xy_set, unsigned nsteps);
boost::python::list life_game(boost::python::list xy_set, unsigned nsteps)
{
    xys_t s = xylist2std_set(xy_set);
    //cout << nsteps << endl;
    
    return std_set2xylist(life_game(s, nsteps));
}




xys_t life_game_step1(xys_t const& s)
{
    typedef map<xy_t, unsigned> map_t;
    map_t xy2count;

    for (xys_t::iterator i = s.begin(); i != s.end(); ++i)
    {
        x_t x = i->first;
        x_t y = i->second;
        for (x_t i = x-1; i < x+2; ++i)
        {
            for (x_t j = y-1; j < y+2; ++j)
            {
                if (x == i && y == j) continue;
                ++xy2count[xy_t(i,j)];
            }
        }
    }
    

    xys_t new_xys;
    for (map_t::iterator i = xy2count.begin(); i != xy2count.end(); ++i)
    {
        xy_t xy = i->first;
        unsigned count = i->second;
        if (3 == count || (2 == count && s.count(xy))) new_xys.insert(xy);
    }

    return new_xys;
}

xys_t life_game(xys_t const& xy_set, unsigned nsteps)
{
    xys_t r(xy_set);
    for (unsigned i = 0; i < nsteps; ++i)
    {
        r = life_game_step1(r);
    }
    return r;
}

/*
//PyObject* life_game(PyObject* pyp_xy_set, unsigned nsteps)
{
    boost::python::object py_xy_set(boost::python::handle<>(pyp_xy_set));
    cout << 'call c++ life game' << endl;
    return NULL;
}*/

