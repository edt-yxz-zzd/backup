
#include "life_game.h"
#include <boost/python.hpp>


BOOST_PYTHON_MODULE(_life_game)
{
    
    using namespace boost::python;
    PyEval_InitThreads();
    def("life_game", life_game);


}
