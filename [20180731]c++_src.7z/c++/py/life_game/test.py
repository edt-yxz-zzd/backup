import _life_game as lg

print(lg.life_game([(1,2)], 3))
print(lg.life_game([(1,2), (1,1), (2,1)], 122))



