
#ifndef life_game_h_HEAD_INCLUDED
#define life_game_h_HEAD_INCLUDED
#include "life_game.h"
#include <boost/python.hpp>



// struct PyObject; // a typedef !!!
#include <Python.h> // PyObject

// return state after n steps, xy is struct{long long x, long long y}.
// PyObject* life_game(PyObject* xy_set, unsigned nsteps); 
// boost::python::object life_game(boost::python::object xy_set, boost::python::object nsteps);
boost::python::list life_game(boost::python::list xy_set, unsigned nsteps);

/*
#include <set>
#include <utility> // pair
std::set<std::pair<long long, long long>> life_game(std::set<std::pair<long long, long long>> xy_set, unsigned nsteps);
*/

#endif

