
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>

using namespace std;




char const *true_main( int argc, char const* argv[])
{
	/* argv[4] = { this.exec, file_name, file_offset, string_size} */
	if ( argc != 4) return "argc != 4";

	char const* file_name = argv[1];
	streamoff file_offset = 0;
	streamsize str_size = 0;

	istringstream s( argv[2]);
	s >> file_offset;
	if ( s.fail() || !s.eof()) return "int(argv[2]).fail";

	s.clear();
	s.str( argv[3]);
	s >> str_size;
	if ( s.fail() || !s.eof()) return "uint(argv[3]).fail";
	// if ( str_size == 0) return 0;

	ifstream fin( file_name);
	if ( !fin) return "file(argv[1]).fail";

	//fin.seekg( 0, ios::end);
	//streampos file_size = fin.tellg ( ) + streamoff(1);
	vector<char> str( str_size+1);
	fin.seekg( file_offset, file_offset < 0 ? ios::end : ios::beg);
	if ( !fin) return "file.seekg.fail";

	fin.read( &str[0], str_size); // assert( !str.empty())
	if ( fin.bad()) return "file.read.bad";
	str[ fin.gcount()] = '\0';
	cout << &str[0] << endl;

	return NULL;
}



int main( int argc, char const* argv[])
{
	char const *err = true_main( argc, argv);
	if ( err) cout << "error : " << err << endl << "usage: this.exec, file_name, file_offset, string_size";
	return !!err;
}



