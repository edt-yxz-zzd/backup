
// g++ -o line_transform.exe line_transform.cpp
// line_transform.exe "        " "\n" <print_self.cpp.tpl >print_self.cpp

#include <iostream>
#include <string>
using namespace std;

void line_transform(ostream& out, istream& in, string const prefix, string const postfix)
{
    string t;
    while(getline(in, t))
    {
        out << prefix << t << postfix << endl;
    }
}


int main(int argc, char const *const *argv)
{
    if (argc != 3)
    {
        cerr << "argc != 3" << endl;
        for (int i = 0; i < argc; i++)
        {
            cerr << i << ":\t" << argv[i] << endl;
        }
        return 1;
    }
    line_transform(cout, cin, argv[1], argv[2]);
    return 0;
}