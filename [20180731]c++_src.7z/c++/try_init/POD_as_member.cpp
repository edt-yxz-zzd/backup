// nodefault ctor; not mentioned POD member will not be initialized!!!
    struct B
    {
        int b;
        B():b(){}
    };
    struct A
    {
        // not mention == call default constructor
        int a; // POD default constructor == trivial constructor == no actions
        B b; // default constructor init....
        
        // A is aggregate??? but I provide a ctor, although trival
        // no, A is not aggregate;
        // see D
        A() // not mention a
        {
            // after call, a is not initialized!!!!
            // b is initialized!!
        }
    };
    struct C:B 
    {
        int a; // why???????????? but default ctor for int is trivial! why?
        // default ctor; all members initialized?? why
    };
    
    
    
    struct D
    {
        int a;
        B b;
        D():b(){} // not mention a, a is not initialized!!!!
    };
    
    struct E:B
    {
        int a;
        E():B(){} // not mention a, a is not initialized!!!!
    };
    struct F:B 
    {
        int a; // not initialized
        F(){} // different with NOT defined
    };
    
    #include <iostream>
    using namespace std;
    int main()
    {
        A a;
        cout << a.a << endl;    // not initialized
        cout << a.b.b << endl;  // 0
        
        C c;
        cout << c.a << endl;    // 0
        cout << c.b << endl;    // 0    
        D d;
        cout << d.a << endl;    // not initialized
        cout << d.b.b << endl;    // 0    
        E e;
        cout << e.a << endl;    // 0 / -1 not initialized
        cout << e.b << endl;    // 0   
        F f;
        cout << f.a << endl;    // 1 / 0 not initialized
        cout << f.b << endl;    // 0
    }