

struct isPOD // no, since has a ctor
{
    isPOD(int i, int j):a(i),b(j){}
    int a;
    int b;
};

struct B{};
struct A:isPOD, B
{
    // A():B(){} // isPOD no defalut ctor
    A():isPOD(0,0),B(){}
    A(int i):isPOD(i,i){}
};

#include <iostream>
using namespace std;
int main()
{
    A a;
    cout << a.a << a.b << endl;
    A b;
    cout << b.a << b.b << endl;
    A c(0);
    cout << c.a << c.b << endl;
    
    A d(a);
    cout << d.a << d.b << endl;
    A e = a;
    cout << e.a << e.b << endl;
    
    
}
