

struct POD
{
    int a;
    int b;
};

struct B{};
struct A:POD, B
{
    A():B() // not allows : POD(0,0)/POD={0,0}/POD{0,0}/POD({0,0})
    {
        // after this call, POD is not initialized!!!
    }
    // not allows: A(int){(POD&)*this = {0,0};}
};

#include <iostream>
using namespace std;
int main()
{
    A a;
    cout << a.a << a.b << endl;
    
}
