
#include <iostream>
#include <stdint.h>

using namespace std;

void g(int a)
{
    int b;
    cout << "g" << endl << (void*)(uintptr_t)g << endl;
    cout << &b << endl;
    int* p = &a;
    for (int i = -2; i < 10; ++i)
    {
        cout << p-i << " : " << p[-i] << endl;
    }
}

void* f(int a, int b) // 28byte between &a - &i; 32 b i
{
    cout << "f " << endl;
    int i = 300; // (char*)&i + size(i) + 18~23(return address ~ no gap with a) 
    int j = 301;
    try
    {
        int k = 302;
        cout << &a << ' ' << &b << endl;
        cout << &i << ' ' << &j << ' ' << &k << endl; 
        int* p = &a;
        for (int i = 0; i < 10; ++i)
        {
            cout << p-i << " : " << p[-i] << endl;
        }
        g(400);
        return (void*)*(&a-2);
    }
    catch(...)
    {
        cout << "error" << endl;
        throw;
    }
}


int main()
{
    int a = 0;
    cout << &a << endl;
    cout << f(0,0) << endl;
    cout << (void*)(uintptr_t)main << "  " <<  (void*)(uintptr_t)f << endl;
    return 0;
}



