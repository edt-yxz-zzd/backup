
#include <stdio.h>

int main(int argn, char *argv[])
{
    /* fecho.exe fname xxxxxxxx */
    const int skipN = 2;
    if (argn < skipN) return 1; /* error */
    const char *fname = argv[1];
    FILE* fout = fopen(fname, "wb");
    argv += skipN;
	while(argn --> skipN) fputs(argv++[0], fout);
	fclose(fout);
	return 0;
}
