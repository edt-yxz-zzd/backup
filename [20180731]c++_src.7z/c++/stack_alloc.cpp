
#include <vector>
#include <cstdint>
#include <memory>

template <size_t sz, unsigned N> // aligned_storage<sz,N>::type
struct alignas(N) align_POD_t {char [sz];};

template <typename T>
struct alignas_t
{
    typedef align_POD_t< sizeof(T), alignof(T) > type;
};

struct memory_allocator_t
{
    virtual void* raw_alloc(size_t sz)=0;
    virtual void raw_free(void*)noexcept =0;
};

struct stack_memory_chunk_t
{
    private:
    char* base;
    char* top;
    char* end;
    memory_allocator_t* to_free_memory;

    public:
    stack_memory_chunk_t(size_t sz, memory_allocator_t*);
    stack_memory_chunk_t(stack_memory_chunk_t&&) = delete;
    stack_memory_chunk_t& operator =(stack_memory_chunk_t&&) = delete;
    stack_memory_chunk_t(stack_memory_chunk_t&) = delete;
    stack_memory_chunk_t& operator =(stack_memory_chunk_t&) = delete;
    ~stack_memory_chunk_t();
    size_t total_size()const;
    size_t using_size()const;
    bool empty()const;
    
    size_t align_top(size_t alignment); // top == end or desired align
        // now it's a aligned allocator
        // return the increasement of top
    void* raw_alloc(size_t size); // top should be aligned! -> NULL or raw-memory
    void raw_free(void*)noexcept; // should free in reverse order!
};

struct memory_allocator_default_t::memory_allocator_t
{
    virtual void* raw_alloc(size_t sz) override;
    virtual void raw_free(void*)noexcept override;
};

template<size_t alignment, typename Memory_Allocator_T 
    = memory_allocator_default_t>
struct stack_aligned_memory_manager_t
{
    private:
    typedef std::deque<stack_memory_chunk_t> ls_t;
    typedef ls_t::iterator iter_t;
    ls_t stacks; //::emplace_back
    iter_t last; // begin <= last < end, end - last - 1 = num of discarded stacks < 3
    size_t total_sz; // in bytes
    Memory_Allocator_T memory_src;
    iter_t find_chunk(size_t sz, iter_t from, iter_t to);
    void to_use(iter_t);
    void pop();
    void pop_empty();
    void new_chunk(size_t sz);
    size_t num_reserved_stacks()const{return stacks.end() - last - 1;}
    
    public:
    stack_memory_manager_t(size_t num_pieces_first_chunk); // each piece alignment bytes
    ~stack_memory_manager_t();
    void* raw_pieces(size_t num_pieces); // > 0, no 0!!
    void raw_free(void*)noexcept; // LIFO !!
};


stack_memory_manager_t(size_t num_pieces_first_chunk); // each piece alignment bytes
    ~stack_memory_manager_t();


void* raw_pieces(size_t num_pieces)
{
    if (num_pieces == 0) throw "alloc 0 pieces";
    size_t sz = num_pieces * alignment;
    void* p = last->raw_alloc(sz);
    if (p) return p;
    
    if (num_reserved_stacks() > 0)
}

void stack_memory_manager_t::raw_free(void* p)noexcept
{
    const size_t max_num_of_reserve_chunk = 2;
    last->raw_free(p);
    if (! last->empty()) return;
    else if (last == stacks.begin()) return;
    
    total_sz -= last->total_size();
    --last;
    if (num_reserved_stacks() > max_num_of_reserve_chunk+1)
    {
        stacks.pop_back();
    }
    
}


















stack_memory_chunk_t::stack_memory_chunk_t(size_t sz, memory_allocator_t* a)
{
    top = base = a->raw_alloc(sz);
    if (base == nullptr) throw "alloc -> nullptr"; // who care!
    end = base + sz;
    to_free_memory = a;
}


stack_memory_chunk_t::~stack_memory_chunk_t()noexcept 
{
    if (top != base || end < base) throw "memory leak";
    if (to_free_memory == nullptr || base == nullptr) return;
    to_free_memory->raw_free(base);
}

size_t stack_memory_chunk_t::total_size()const
{
    return end - base; // end >= base !!
};

size_t stack_memory_chunk_t::using_size()const
{
    return top - base; // top >= base !!
};

size_t stack_memory_chunk_t::empty()const
{
    return top == base; // top >= base !!
};

size_t stack_memory_chunk_t::align_top(size_t alignment)
{
    size_t buf_sz = end - top; // end >= top !!
    size_t sz = buf_sz;

    if(std::align(alignment, 0, top, buf_sz))
    {
        return sz - buf_sz;
    }
    else
    {
        top = end;
        return sz;
    }
}


void* stack_memory_chunk_t::raw_alloc(size_t sz)
{
    size_t buf_sz = end - top; // end >= top !!

    if(buf_sz >= sz)
    {
        top += sz;
        return top - sz;
    }
    else
    {
        return nullptr;
    }
}



    
void stack_memory_chunk_t::raw_free(void* p)
{
    if (p == nullptr) return;

    // base <= p <= top <= end
    top = p;
    return;
}

void* memory_allocator_default_t::raw_alloc(size_t sz) override
{
    return ::operator new(sz);
}

void memory_allocator_default_t::raw_free(void* p)noexcept override
{
    ::operator delete(p);
}