

def uint8s2uint_ex(uint8s):
    bs = bytes(uint8s)
    L = len(bs)
    return int.from_bytes(bs, 'little'), L
def mul_little_endian_bytes(lhs_uint8s, rhs_uint8s):
    lhs, lL = uint8s2uint_ex(lhs_uint8s)
    rhs, rL = uint8s2uint_ex(rhs_uint8s)
    r = lhs*rhs
    bs = r.to_bytes(lL+rL, 'little')
    uint8s = list(bs)
    while uint8s and not uint8s[-1]: uint8s.pop()
    return uint8s


def f(lhs_uint8s, rhs_uint8s):
    r = mul_little_endian_bytes(lhs_uint8s, rhs_uint8s)
    print(f'{lhs_uint8s}*{rhs_uint8s} == {r}')

f([3,4], [5,5,3,4])
f([1,2,1], [1,2,3])
f([1,0,2,0,1,0], [1,0,2,3])

