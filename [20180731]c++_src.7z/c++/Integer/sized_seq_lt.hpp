
#ifndef NN_NS__SIZED_SEQ_LT_HPP
#define NN_NS__SIZED_SEQ_LT_HPP



//#include <type_traits> // is_same
#include <functional> // function
// see: boost::zip_iterator, boost::combine

namespace nn_ns {

struct LittleEndian_tag;
struct BigEndian_tag;

namespace {
template <typename EndianT> struct SeqLt;
template <> struct SeqLt<LittleEndian_tag>{
    // little-endian
    using F = std::function<bool()>;
    template <typename InputIterT1, typename InputIterT2
            , typename SizeT1, typename SizeT2
            , typename LtT
            >
    static bool sized_seq_lt
            ( InputIterT1 lhs_begin
            , InputIterT1 lhs_end
            , SizeT1 lhs_size
            , InputIterT1 rhs_begin
            , InputIterT2 rhs_end
            , SizeT2 rhs_size
            , LtT& lt)
    {
    #if 0
        //fail: since every lambda expression creates it's own unique type
        auto const f1 = [&]()->bool{return lhs_begin != lhs_end;};
        auto const f2 = [&]()->bool{return rhs_begin != rhs_end;};
        static_assert(std::is_same<decltype(f1), decltype(f2)>::value, "type(f1) must be type(f2)");
    #else
        F const f = lhs_size < rhs_size
            ? static_cast<F>([&]()->bool{return lhs_begin != lhs_end;})
            : static_cast<F>([&]()->bool{return rhs_begin != rhs_end;});
    #endif

    #if 0
        auto begin = lhs_size < rhs_size? lhs_begin : rhs_begin;
        auto& end = lhs_size < rhs_size? lhs_end : rhs_end;
        while(begin != end)
    #else
        while(f())
    #endif
        {
            --lhs_end; --rhs_end;
            if (lt(*lhs_end, *rhs_end)) {return true;}
            if (lt(*rhs_end, *lhs_end)) {return false;}
        }
        return lhs_size < rhs_size;
    }

    template <typename InputIterT1, typename InputIterT2
            , typename SizeT1, typename SizeT2
            >
    static bool sized_seq_lt
            ( InputIterT1 lhs_begin
            , InputIterT1 lhs_end
            , SizeT1 lhs_size
            , InputIterT1 rhs_begin
            , InputIterT2 rhs_end
            , SizeT2 rhs_size
            )
    {
        F const f = lhs_size < rhs_size
            ? static_cast<F>([&]()->bool{return lhs_begin != lhs_end;})
            : static_cast<F>([&]()->bool{return rhs_begin != rhs_end;});
        while(f()){
            --lhs_end; --rhs_end;
            if (*lhs_end < *rhs_end) {return true;}
            if (*rhs_end < *lhs_end) {return false;}
        }
        return lhs_size < rhs_size;
    }
};
template <> struct SeqLt<BigEndian_tag>{
    // big-endian
    using F = std::function<bool()>;
    template <typename InputIterT1, typename InputIterT2
            , typename SizeT1, typename SizeT2
            , typename LtT
            >
    static bool sized_seq_lt
            ( InputIterT1 lhs_begin
            , InputIterT1 lhs_end
            , SizeT1 lhs_size
            , InputIterT1 rhs_begin
            , InputIterT2 rhs_end
            , SizeT2 rhs_size
            , LtT& lt)
    {
        F const f = lhs_size < rhs_size
            ? static_cast<F>([&]()->bool{return lhs_begin != lhs_end;})
            : static_cast<F>([&]()->bool{return rhs_begin != rhs_end;});
        while(f()){
            if (lt(*lhs_begin, *rhs_begin)) {return true;}
            if (lt(*rhs_begin, *lhs_begin)) {return false;}
            ++lhs_begin; ++rhs_begin;
        }
        return lhs_size < rhs_size;
    }

    template <typename InputIterT1, typename InputIterT2
            , typename SizeT1, typename SizeT2
            >
    static bool sized_seq_lt
            ( InputIterT1 lhs_begin
            , InputIterT1 lhs_end
            , SizeT1 lhs_size
            , InputIterT1 rhs_begin
            , InputIterT2 rhs_end
            , SizeT2 rhs_size
            )
    {
        F const f = lhs_size < rhs_size
            ? static_cast<F>([&]()->bool{return lhs_begin != lhs_end;})
            : static_cast<F>([&]()->bool{return rhs_begin != rhs_end;});
        while(f()){
            if (*lhs_begin < *rhs_begin) {return true;}
            if (*rhs_begin < *lhs_begin) {return false;}
            ++lhs_begin; ++rhs_begin;
        }
        return lhs_size < rhs_size;
    }
};
} namespace {
}


template <typename EndianT, typename C1, typename C2, typename LtT>
bool sized_seq_lt(C1 const& lhs, C2 const& rhs, LtT& lt)
{
    return SeqLt<EndianT>::sized_seq_lt
                (lhs.begin(), lhs.end(), lhs.size()
                ,rhs.begin(), rhs.end(), rhs.size(), lt);
}
template <typename EndianT, typename C1, typename C2>
bool sized_seq_lt(C1 const& lhs, C2 const& rhs)
{
    return SeqLt<EndianT>::sized_seq_lt
                (lhs.begin(), lhs.end(), lhs.size()
                ,rhs.begin(), rhs.end(), rhs.size());
}


template <typename EndianT
        , typename InputIterT1, typename InputIterT2
        , typename SizeT1, typename SizeT2
        , typename LtT
        >
bool sized_seq_lt
        ( InputIterT1 lhs_begin
        , InputIterT1 lhs_end
        , SizeT1 lhs_size
        , InputIterT1 rhs_begin
        , InputIterT2 rhs_end
        , SizeT2 rhs_size
        , LtT& lt)
{
    return SeqLt<EndianT>::sized_seq_lt
                (lhs_begin, lhs_end, lhs_size
                ,rhs_begin, rhs_end, rhs_size
                , lt
                );
}

template <typename EndianT
        , typename InputIterT1, typename InputIterT2
        , typename SizeT1, typename SizeT2
        >
bool sized_seq_lt
        ( InputIterT1 lhs_begin
        , InputIterT1 lhs_end
        , SizeT1 lhs_size
        , InputIterT1 rhs_begin
        , InputIterT2 rhs_end
        , SizeT2 rhs_size
        )
{
    return SeqLt<EndianT>::sized_seq_lt
                (lhs_begin, lhs_end, lhs_size
                ,rhs_begin, rhs_end, rhs_size
                );
}





} namespace nn_ns {
}

#endif // NN_NS__SIZED_SEQ_LT_HPP

