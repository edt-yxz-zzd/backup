
#ifndef NN_NS__SIZED_SEQ_EQ_HPP
#define NN_NS__SIZED_SEQ_EQ_HPP



namespace nn_ns {


// see: boost::zip_iterator, boost::combine
template <typename InputIterT1, typename InputIterT2, typename EqT>
bool same_length_seq_eq
        ( InputIterT1 lhs_begin
        , InputIterT1 lhs_end
        , InputIterT2 rhs_begin
        , EqT& eq)
{
    for (; lhs_begin != lhs_end; ++lhs_begin, ++rhs_begin){
        if (!eq(*lhs_begin, *rhs_begin)) {return false;}
    }
    return true;

}
template <typename InputIterT1, typename InputIterT2>
bool same_length_seq_eq
        ( InputIterT1 lhs_begin
        , InputIterT1 lhs_end
        , InputIterT2 rhs_begin
        )
{
    for (; lhs_begin != lhs_end; ++lhs_begin, ++rhs_begin){
        if (*lhs_begin != *rhs_begin) {return false;}
    }
    return true;

}



template <typename C1, typename C2, typename EqT>
bool sized_seq_eq(C1 const& lhs, C2 const& rhs, EqT& eq)
{
    if (lhs.size() != rhs.size()) return false;
    return same_length_seq_eq(lhs.begin(), lhs.end(), rhs.begin(), eq);

    #if 0
    auto lhs_it = lhs.begin();
    for (auto rv : rhs){
        if (!eq(*lhs_it, rv)) {return false;}
        ++lhs_it;
    }
    return true;
    #endif
}
template <typename C1, typename C2>
bool sized_seq_eq(C1 const& lhs, C2 const& rhs)
{
    if (lhs.size() != rhs.size()) return false;
    return same_length_seq_eq(lhs.begin(), lhs.end(), rhs.begin());

    #if 0
    auto lhs_it = lhs.begin();
    for (auto rv : rhs){
        if (*lhs_it != rv) {return false;}
        ++lhs_it;
    }
    return true;
    #endif
}



} namespace nn_ns {
}


#endif // NN_NS__SIZED_SEQ_EQ_HPP

