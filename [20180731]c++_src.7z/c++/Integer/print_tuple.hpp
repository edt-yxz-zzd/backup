
#ifndef NN_NS__PRINT_TUPLE_HPP
#define NN_NS__PRINT_TUPLE_HPP


/*
    operator << for tuple
    print_tuple_with_sep
        sep :: string
    print_tuple_with_sep_chars
        p_sep :: char*
*/

///////////////////////// cout << tuple;
#include <ostream> // basic_ostream
#include <iterator> // begin, end, ostream_iterator
#include <algorithm> // copy
#include <utility> // declval
#include <string> // basic_string

#include <tuple> // tuple



namespace nn_ns {


//constexpr std::size_t operator "" _sz ( unsigned long long n ) { return n; }

///////////////////////////////
namespace {
    // https://stackoverflow.com/questions/6245735/pretty-print-stdtuple

    template <typename CharT, typename Traits, typename AllocatorT
            , typename TupleT
            , std::size_t N
            >
    class _PrintTupleBare
    {
        static void print
                ( std::basic_ostream<CharT, Traits>& ostream
                , std::basic_string<CharT, Traits, AllocatorT> const& sep
                , TupleT const& tpl
                )
        {
            _PrintTupleBare<CharT, Traits, AllocatorT, TupleT, N-1>
                ::print(ostream, sep, tpl);
            ostream << sep << std::get<N-1>(tpl);
        }
    };

    template <typename CharT, typename Traits, typename AllocatorT
            , typename TupleT
            >
    class _PrintTupleBare<CharT, Traits, AllocatorT, TupleT, 0>
    {
        static void print
            ( std::basic_ostream<CharT, Traits>& ostream
            , std::basic_string<CharT, Traits, AllocatorT> const& sep
            , TupleT const& tpl
            )
        {
            return; // no-op
        }
    };
    template <typename CharT, typename Traits, typename AllocatorT
            , typename TupleT
            >
    class _PrintTupleBare<CharT, Traits, AllocatorT, TupleT, 1>
    {
        static void print
            ( std::basic_ostream<CharT, Traits>& ostream
            , std::basic_string<CharT, Traits, AllocatorT> const& sep
            , TupleT const& tpl
            )
        {
            ostream << std::get<0>(tpl);
        }
    };
}
template <typename CharT, typename Traits, typename AllocatorT
        , typename... ArgTs
        >
void print_tuple_with_sep
        ( std::basic_ostream<CharT, Traits>& ostream
        , std::basic_string<CharT, Traits, AllocatorT> const& sep
        , std::tuple<ArgTs...> const& tpl
        )
{
    _PrintTupleBare<CharT, Traits, AllocatorT
            , std::tuple<ArgTs...>, sizeof...(ArgTs)>
            ::print(ostream, sep, tpl);
}


template <typename CharT, typename Traits, typename AllocatorT
        , typename... ArgTs
        >
void print_tuple_with_sep
        ( std::basic_ostream<CharT, Traits>& ostream
        , CharT const* p_sep
        , std::tuple<ArgTs...> const& tpl
        )
{

    std::basic_string<CharT, Traits, AllocatorT> const sep(p_sep);
    print_tuple_with_sep(ostream, sep, tpl);
}

template <typename CharT, typename Traits
        , typename... ArgTs
        >
void print_tuple_with_sep_chars
        ( std::basic_ostream<CharT, Traits>& ostream
        , CharT const* p_sep
        , std::tuple<ArgTs...> const& tpl
        )
{

    print_tuple_with_sep<CharT, Traits, std::allocator<CharT>, ArgTs...>(
        ostream, p_sep, tpl);
}


template <typename Traits, typename... ArgTs>
auto operator<< (std::basic_ostream<char, Traits>& ostream
                , std::tuple<ArgTs...> const& tpl)
-> std::basic_ostream<char, Traits>&
{
    ostream << '(';
    print_tuple_with_sep_chars(ostream, ", ", tpl);
    ostream << ')';
    return ostream;
}


} namespace nn_ns {
}


#endif // NN_NS__PRINT_TUPLE_HPP

