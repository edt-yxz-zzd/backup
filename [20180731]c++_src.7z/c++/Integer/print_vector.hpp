
#ifndef NN_NS__PRINT_VECTOR_HPP
#define NN_NS__PRINT_VECTOR_HPP


/*
    operator << for vector
    print_with_sep
        sep :: string
    print_with_sep_chars
        p_sep :: char*
*/


///////////////////////// cout << vector;
#include <ostream> // basic_ostream
#include <iterator> // begin, end, ostream_iterator
#include <algorithm> // copy
#include <utility> // declval
#include <string> // basic_string

#include <vector> // vector


namespace nn_ns {


template <typename CharT, typename Traits, typename AllocatorT
        , typename InputIterT>
void print_with_sep(std::basic_ostream<CharT, Traits>& ostream
                    , std::basic_string<CharT, Traits, AllocatorT> const& sep
                    , InputIterT begin, InputIterT const end)
{
    if (begin != end){
        ostream << *begin;
        while (++begin != end){ostream << sep << *begin;}
    }
    return;
}


template <typename CharT, typename Traits, typename AllocatorT
        , typename InputIterT>
void print_with_sep(std::basic_ostream<CharT, Traits>& ostream
                    , CharT const* p_sep
                    , InputIterT begin, InputIterT const end)
{
    using T = typename InputIterT::value_type;

    //std::ostream_iterator<T, CharT, Traits> out_it(ostream, p_sep);
    //std::copy(begin, end, out_it); // this line cause errors...
    //      https://stackoverflow.com/questions/5355081/why-cant-i-instantiate-operatorostream-vectort-with-t-vectorint
    //      namespace problem
    //          The same is true in your example: in main(), the operator<< overload is found, but inside of the std::ostream_iterator, which is in the std namespace, other << overloads are found, and so your overload is not found.
    //for (auto& u: ls){ ostream << u << sep; }
    //for (auto& u: ls){ *++out_it = u; } // this line cause errors...
    //for (T const& u: ls){ *++out_it = u; } // this line cause errors...

    std::basic_string<CharT, Traits, AllocatorT> const sep(p_sep);
    print_with_sep(ostream, sep, begin, end);
}


template <typename CharT, typename Traits
        , typename InputIterT>
void print_with_sep_chars(std::basic_ostream<CharT, Traits>& ostream
                    , CharT const* p_sep
                    , InputIterT begin, InputIterT const end)
{
    print_with_sep<CharT, Traits, std::allocator<CharT>, InputIterT>(
        ostream, p_sep, begin, end);
}








template <typename Traits, typename T>
auto operator<< (std::basic_ostream<char, Traits>& ostream, std::vector<T> const& ls)
-> std::basic_ostream<char, Traits>&
{
    ostream << '[';
    print_with_sep_chars(ostream, ", ", ls.begin(), ls.end());
    ostream << ']';
    return ostream;
}



} namespace nn_ns {
}



#endif // NN_NS__PRINT_VECTOR_HPP

