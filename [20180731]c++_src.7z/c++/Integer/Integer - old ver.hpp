
/*

data UIntModBase
    -- uint % base
data UIntModSquareBase
    -- uint % base^2

#class (Integer UIntModBase, Integer UIntModSquareBase) => Mul [UIntModBase]

prime_uint_zero :: UIntModBase
prime_uint_one :: UIntModBase
prime_uint_max :: UIntModBase

prime_complement :: UIntModBase -> UIntModBase
    # 0 - uint == result
prime_full_add :: UIntModBase -> UIntModBase -> (Bool, UIntModBase)
prime_full_sub :: UIntModBase -> UIntModBase -> (Bool, UIntModBase)
prime_full_mul :: UIntModBase -> UIntModBase -> UIntModSquareBase
prime_full_mul2 :: UIntModBase -> UIntModBase -> (UIntModBase, UIntModBase)
    -- (high, low)
prime_divmod :: UIntModSquareBase -> UIntModBase -> (UIntModBase, UIntModBase)
    -- uint2 /% uint = (quot, remainder)
pack_uint2 :: UIntModBase -> UIntModBase -> UIntModSquareBase
unpack_uint2 :: UIntModSquareBase -> (UIntModBase, UIntModBase)
    -- high*base + low ==>> (high, low)

sorted :: Ord k => (a->k) -> [a] -> [a]

# little-endian
mul :: [UIntModBase] -> [UIntModBase] -> [UIntModBase]
mul lhs rhs =
    lhs' = sorted fst [(u, i) | u <- lhs]
    rhs' = sorted fst [(u, i) | u <- rhs]
    len_lhs = length lhs
    len_rhs = length rhs
    len_set_lhs = length $ group fst lhs'
    len_set_rhs = length $ group fst rhs'
    time "mul lhs rhs" == O(len_set_lhs*len_set_rhs * prime_full_mul + len_lhs*len_rhs * prime_full_add)


std::byte
'concept' is not in C++17 / Clang6!!!!

<cstdint>
    # uint8_t
    # UINT8_MAX
    # uint_fast16_t/uint_least16_t
    # UINT_FAST16_MAX/UINT_LEAST16_MAX

<cinttypes>
<climits>
<limits>
    # std::numeric_limits
 */

// g++ -std=c++11 -c Integer.cpp
// g++ -std=c++11 Integer.cpp -o a.exe -DNDEBUG



/*
__all__
    little_endian_prime_uint_seq_mul

    UInt8Traits
    CompareViaIndex

    sort_indices_of_array
    group_by
    group_indices_via_array
    fst
    snd
*/

#include "sized_seq_eq.hpp"
#include "print_vector.hpp"
#include "print_tuple.hpp"
#include <utility> // pair
#include <cstdint>
#include <vector>
#include <algorithm> // sort
#include <cassert>
#include <iostream> // cout
//#include <type_traits> // remove_cv_t, remove_reference_t C++14
//#include<>


namespace nn_ns {


struct UInt8Traits
{
    private:
    UInt8Traits() = delete;

    typedef std::uint8_t U;
    typedef std::uint_fast16_t UU;
    //no default operator==
    struct UInt8 {U value;};
    struct UInt16 {UU value;};
    static int const num_bits_U = 8;
    //const UU low_mask = (1 << num_bits_U) - 1;

    public:
    //typedef std::uint8_t UIntModBase;
    //typedef std::uint_fast16_t UIntModSquareBase;
    typedef UInt8 UIntModBase;
    typedef UInt16 UIntModSquareBase;
    typedef std::pair<bool, UIntModBase> PrimeFullResult;
    typedef std::pair<UIntModBase, UIntModBase> UIntModBasePair;

    static UIntModBase const prime_uint_zero; // = {0};
    static UIntModBase const prime_uint_one; // = {1};
    static UIntModBase const prime_uint_max; // = {UINT8_MAX};


    static bool prime_uint_is_zero(UIntModBase u)
        {return !u.value;}
    static bool prime_uint_is_one(UIntModBase u)
        {return static_cast<U>(1) == u.value;}
    static bool prime_uint_lt(UIntModBase lhs, UIntModBase rhs)
        {return lhs.value < rhs.value;}
    static bool prime_uint_eq(UIntModBase lhs, UIntModBase rhs)
        {return lhs.value == rhs.value;}
    static void prime_half_iinc(UIntModBase& u)
        {++u.value;}

    static auto prime_complement(UIntModBase u)
    -> UIntModBase
        {return {static_cast<U>(-u.value)};}
    static auto prime_full_sub(UIntModBase lhs, UIntModBase rhs)
    -> PrimeFullResult
        {return {lhs.value<rhs.value, {static_cast<U>(lhs.value-rhs.value)}};}
    static void prime_half_iadd(UIntModBase& lhs, UIntModBase rhs)
        {lhs.value += rhs.value;}
    static auto prime_full_add(UIntModBase lhs, UIntModBase rhs)
    -> PrimeFullResult
        {return {lhs.value>static_cast<U>(lhs.value+rhs.value), {static_cast<U>(lhs.value+rhs.value)}};}

    static auto prime_full_mul(UIntModBase lhs, UIntModBase rhs)
    -> UIntModSquareBase
        {return {static_cast<UU>(lhs.value*static_cast<UU>(rhs.value))};}
    static auto prime_full_mul2(UIntModBase lhs, UIntModBase rhs)
    -> UIntModBasePair
        {return unpack_uint2(prime_full_mul(lhs, rhs));}
    static auto prime_divmod(UIntModSquareBase lhs, UIntModBase rhs)
    -> UIntModBasePair
        {return {{static_cast<U>(lhs.value/rhs.value)}
                ,{static_cast<U>(lhs.value%rhs.value)}
                };
        }

    static auto pack_uint2(UIntModBase high, UIntModBase low)
    -> UIntModSquareBase
        {return {static_cast<UU>((static_cast<UU>(high.value)<<num_bits_U)
                                | static_cast<UU>(low.value))};
        }
    static auto unpack_uint2(UIntModSquareBase uu)
    -> UIntModBasePair
        {return {{static_cast<U>(uu.value>>num_bits_U)}
                ,{static_cast<U>(uu.value)}
                };
        }

};

UInt8Traits::UIntModBase const UInt8Traits::prime_uint_zero = {0};
UInt8Traits::UIntModBase const UInt8Traits::prime_uint_one = {1};
UInt8Traits::UIntModBase const UInt8Traits::prime_uint_max = {UINT8_MAX};




template <typename UIntTraitsT>
using PrimeUIntSeq = std::vector<typename UIntTraitsT::UIntModBase>;

// little-endian
template <typename UIntTraitsT>
auto little_endian_prime_uint_seq_mul
        (std::vector<typename UIntTraitsT::UIntModBase> const& lhs
        ,std::vector<typename UIntTraitsT::UIntModBase> const& rhs)
-> std::vector<typename UIntTraitsT::UIntModBase>;

//template<>
//auto little_endian_prime_uint_seq_mul<UInt8Traits>(auto, auto)->auto;
//auto little_endian_prime_uint_seq_mul<UInt8Traits>(UInts<UInt8Traits> const&, UInts<UInt8Traits> const&)->UInts<UInt8Traits>;

//template <IndexT> auto irange(IndexT begin, IndexT end) { }


template<typename ArrayT, typename ValueLtT
        , typename IndexT = typename ArrayT::size_type>
struct CompareViaIndex
{
    // "<"
    ArrayT& array;
    ValueLtT& lt;

    using Array = ArrayT;
    using Index = IndexT;
    using IndexArray = std::vector<Index>;
    using __class__ = CompareViaIndex;

    bool operator ()(Index idx_lhs, Index idx_rhs)
        {return this->lt(this->array[idx_lhs], this->array[idx_rhs]);}
    bool operator ()(Index idx_lhs, Index idx_rhs)const
        {return this->lt(this->array[idx_lhs], this->array[idx_rhs]);}

    static auto make_indices(Index begin, Index end) -> IndexArray
    {
        // see: boost::counting_range(size_t(0), containerA.size())
        IndexArray indices;
        for (Index i = begin; i != end; ++i) {
            indices.push_back(i);
        }
        return indices;
    }

    auto sort_indices(Index begin, Index end) -> IndexArray
    {
        auto indices = __class__::make_indices(begin, end);
        std::sort(indices.begin(), indices.end(), *this);
        return indices;
    }
    auto sort_indices(Index begin, Index end)const -> IndexArray
    {
        auto indices = __class__::make_indices(begin, end);
        std::sort(indices.begin(), indices.end(), *this);
        return indices;
    }

    static auto sort_indices(
        ArrayT& array, ValueLtT& lt, Index begin, Index end)
    -> IndexArray
    {
        __class__ self = {array, lt};
        return self.sort_indices(begin, end);
    }
};

template<typename ArrayT, typename ValueLtT
        , typename IndexT = typename ArrayT::size_type>
auto sort_indices_of_array(
    ArrayT& array, ValueLtT& lt, IndexT begin, IndexT end)
-> typename CompareViaIndex<ArrayT, IndexT>::IndexArray
{
    return CompareViaIndex<ArrayT, ValueLtT, IndexT>::
            sort_indices(array, lt, begin, end);
}

template<typename PtrT, typename EqT>
auto group_by(PtrT begin, PtrT end, EqT const& eq)
-> std::vector<std::pair<PtrT, PtrT> >
{
    using Range = std::pair<PtrT, PtrT>;
    using Ranges = std::vector<std::pair<PtrT, PtrT> >;

    Ranges rngs;
    Range rng;
    while (begin != end){
        std::get<0>(rng) = begin;
        while (++begin != end){
            if (!eq(*begin, *std::get<0>(rng))) break;
        }
        std::get<1>(rng) = begin;
        rngs.push_back(std::move(rng));
    }
    return rngs;
}

template<typename IndexPtrT, typename ArrayT, typename ValueEqT>
        //, typename ValueT = typename ArrayT::value_type>
auto group_indices_via_array(IndexPtrT begin, IndexPtrT end
    , ArrayT const& array, ValueEqT& eq)
-> std::vector<std::pair<IndexPtrT, IndexPtrT> >
{
    using Index = typename IndexPtrT::value_type;
    using IndexRng = std::pair<IndexPtrT, IndexPtrT>;

    return group_by(begin, end,
                [&array, &eq](Index i, Index j){return eq(array[i], array[j]);}
           );
}

template <typename T>
auto fst(T& tpl)->decltype(std::get<0>(tpl)) {return std::get<0>(tpl);}
template <typename T>
auto snd(T& tpl)->decltype(std::get<1>(tpl)) {return std::get<1>(tpl);}


template <typename UIntTraitsT>
bool little_endian_prime_uint_seq_eq
        (std::vector<typename UIntTraitsT::UIntModBase> const& lhs
        ,std::vector<typename UIntTraitsT::UIntModBase> const& rhs)
{ return sized_seq_eq(lhs, rhs, UIntTraitsT::prime_uint_eq); }



template <typename UIntTraitsT>
auto little_endian_prime_uint_seq_mul
        (std::vector<typename UIntTraitsT::UIntModBase> const& lhs
        ,std::vector<typename UIntTraitsT::UIntModBase> const& rhs)
-> std::vector<typename UIntTraitsT::UIntModBase>
{
    // little-endian
    using BigUInt = std::vector<typename UIntTraitsT::UIntModBase>;
    using SmallUInts = BigUInt;
    using Index = typename BigUInt::size_type;
    //using Ptr = typename BigUInt::iterator;
    //using CPtr = typename BigUInt::const_iterator;
    using IndexPtr = typename std::vector<Index>::const_iterator;
    using IndexRng = std::pair<IndexPtr, IndexPtr>;
    using IndexRngs = std::vector<IndexRng>;
    using IndexRngPtr = typename IndexRngs::const_iterator;
    using U = typename UIntTraitsT::UIntModBase;


    auto const get_uint =
        [](SmallUInts const& uints, IndexRng const& index_rng) -> U
        {
            return uints[*std::get<0>(index_rng)];
        };

    auto const eval_uints_idx_rng_ptr_ge1_ge2 =
        [get_uint](BigUInt const& xhs, IndexRngs const& xhs_idx_rngs)
        -> std::pair<IndexRngPtr, IndexRngPtr>
        {
            auto xhs_idx_rng_ptr_ge1 = xhs_idx_rngs.begin();
            if (xhs_idx_rng_ptr_ge1 != xhs_idx_rngs.end()
                && UIntTraitsT::prime_uint_is_zero(get_uint(xhs, *xhs_idx_rng_ptr_ge1))){
                ++xhs_idx_rng_ptr_ge1;
            }
            auto xhs_idx_rng_ptr_ge2 = xhs_idx_rng_ptr_ge1;
            if (xhs_idx_rng_ptr_ge2 != xhs_idx_rngs.end()
                && UIntTraitsT::prime_uint_is_one(get_uint(xhs, *xhs_idx_rng_ptr_ge2))){
                ++xhs_idx_rng_ptr_ge2;
            }
            return {xhs_idx_rng_ptr_ge1, xhs_idx_rng_ptr_ge2};
        };


    auto const add_low_to_result =
        [](U const low, BigUInt& result, Index i)->void
        {
            if (UIntTraitsT::prime_uint_is_zero(low)) return;
            UIntTraitsT::prime_half_iadd(result[i], low);
            if (UIntTraitsT::prime_uint_lt(result[i], low)){
                do {
                    UIntTraitsT::prime_half_iinc(result[++i]);
                } while (UIntTraitsT::prime_uint_is_zero(result[i]));
            }
        };
    auto const add_high_low_to_result =
        [add_low_to_result]
        ( IndexRngPtr const lhs_idx_rng_ptr
        , IndexRngPtr const rhs_idx_rng_ptr
        , U const high
        , U const low
        , BigUInt& result
        )->void
        {
            auto lhs_idx_end = snd(*lhs_idx_rng_ptr);
            auto rhs_idx_end = snd(*rhs_idx_rng_ptr);
            for (auto it = fst(*rhs_idx_rng_ptr); it != rhs_idx_end; ++it){

                auto const j = *it;
                for (auto it = fst(*lhs_idx_rng_ptr); it != lhs_idx_end; ++it){
                    auto const i = *it;
                    add_low_to_result(low, result, i+j);
                    add_low_to_result(high, result, i+j+1);
                }
            }
        };


    auto const this_func =
        [get_uint, eval_uints_idx_rng_ptr_ge1_ge2, add_high_low_to_result]
        ( BigUInt const& lhs, Index const lhs_size
        , BigUInt const& rhs, Index const rhs_size
        ) -> BigUInt
        {
            assert(lhs_size >= rhs_size);
            if (!rhs_size) return {};
            //std::cout << lhs_size << ' ' << rhs_size << std::endl;

            auto const lhs_indices = sort_indices_of_array(
                        lhs, UIntTraitsT::prime_uint_lt, static_cast<Index>(0), lhs_size);
            auto const rhs_indices = sort_indices_of_array(
                        rhs, UIntTraitsT::prime_uint_lt, static_cast<Index>(0), rhs_size);
            auto const lhs_idx_rngs = group_indices_via_array(
                        lhs_indices.begin(), lhs_indices.end(), lhs
                        , UIntTraitsT::prime_uint_eq);
            auto const rhs_idx_rngs = group_indices_via_array(
                        rhs_indices.begin(), rhs_indices.end(), rhs
                        , UIntTraitsT::prime_uint_eq);

            //std::cout << lhs_indices << ' ' << rhs_indices << std::endl;


            IndexRngPtr lhs_idx_rng_ptr_ge1, lhs_idx_rng_ptr_ge2,
                        rhs_idx_rng_ptr_ge1, rhs_idx_rng_ptr_ge2;
            std::tie(lhs_idx_rng_ptr_ge1, lhs_idx_rng_ptr_ge2) =
            //auto [lhs_idx_rng_ptr_ge1, lhs_idx_rng_ptr_ge2] =
                    eval_uints_idx_rng_ptr_ge1_ge2(lhs, lhs_idx_rngs);
            std::tie(rhs_idx_rng_ptr_ge1, rhs_idx_rng_ptr_ge2) =
            //auto [rhs_idx_rng_ptr_ge1, rhs_idx_rng_ptr_ge2] =
                    eval_uints_idx_rng_ptr_ge1_ge2(rhs, rhs_idx_rngs);

            BigUInt result(lhs_size + rhs_size);

            // lhs_idx_rngs(uint==1) * rhs_idx_rngs(uint==1)
            if (lhs_idx_rng_ptr_ge1 != lhs_idx_rng_ptr_ge2
                && rhs_idx_rng_ptr_ge1 != rhs_idx_rng_ptr_ge2){
                auto lhs_idx_rng_ptr_eq1 = lhs_idx_rng_ptr_ge1;
                auto rhs_idx_rng_ptr_eq1 = rhs_idx_rng_ptr_ge1;
                //lhs_uint == 1
                //rhs_uint == 1
                U const high = UIntTraitsT::prime_uint_zero;
                U const low = UIntTraitsT::prime_uint_one;
                add_high_low_to_result(
                    lhs_idx_rng_ptr_eq1, rhs_idx_rng_ptr_eq1, high, low, result);
            }
            // lhs_idx_rngs(uint==1) * rhs_idx_rngs(uint>=2)
            if (lhs_idx_rng_ptr_ge1 != lhs_idx_rng_ptr_ge2){
                auto lhs_idx_rng_ptr_eq1 = lhs_idx_rng_ptr_ge1;
                for (auto rhs_idx_rng_ptr = rhs_idx_rng_ptr_ge2
                    ; rhs_idx_rng_ptr != rhs_idx_rngs.end()
                    ; ++rhs_idx_rng_ptr) {
                    auto const rhs_uint = get_uint(rhs, *rhs_idx_rng_ptr);

                    //lhs_uint == 1
                    U const high = UIntTraitsT::prime_uint_zero;
                    U const low = rhs_uint;
                    add_high_low_to_result(
                        lhs_idx_rng_ptr_eq1, rhs_idx_rng_ptr, high, low, result);
                }
            }
            // lhs_idx_rngs(uint>=2) * rhs_idx_rngs(uint==1)
            if (rhs_idx_rng_ptr_ge1 != rhs_idx_rng_ptr_ge2){
                auto rhs_idx_rng_ptr_eq1 = rhs_idx_rng_ptr_ge1;
                for (auto lhs_idx_rng_ptr = lhs_idx_rng_ptr_ge2
                    ; lhs_idx_rng_ptr != lhs_idx_rngs.end()
                    ; ++lhs_idx_rng_ptr) {
                    auto const lhs_uint = get_uint(lhs, *lhs_idx_rng_ptr);

                    //rhs_uint == 1
                    U const high = UIntTraitsT::prime_uint_zero;
                    U const low = lhs_uint;
                    add_high_low_to_result(
                        lhs_idx_rng_ptr, rhs_idx_rng_ptr_eq1, high, low, result);
                }
            }
            // lhs_idx_rngs(uint>=2) * rhs_idx_rngs(uint>=2)
            for (auto rhs_idx_rng_ptr = rhs_idx_rng_ptr_ge2
                ; rhs_idx_rng_ptr != rhs_idx_rngs.end()
                ; ++rhs_idx_rng_ptr) {
                auto const rhs_uint = get_uint(rhs, *rhs_idx_rng_ptr);

                for (auto lhs_idx_rng_ptr = lhs_idx_rng_ptr_ge2
                    ; lhs_idx_rng_ptr != lhs_idx_rngs.end()
                    ; ++lhs_idx_rng_ptr) {
                    auto const lhs_uint = get_uint(lhs, *lhs_idx_rng_ptr);

                    /* why not complain??
                    U const high, low;
                    */
                    U high, low;
                    std::tie(high, low) =
                    //auto const [high, low] =
                        UIntTraitsT::prime_full_mul2(lhs_uint, rhs_uint);
                    add_high_low_to_result(
                        lhs_idx_rng_ptr, rhs_idx_rng_ptr, high, low, result);

                }
            }

            if (!result.empty()
                && UIntTraitsT::prime_uint_is_zero(result.back())){
                result.pop_back();
            }
            assert(result.empty()
                || !UIntTraitsT::prime_uint_is_zero(result.back()));
            return result;
        };

    auto const calc_size =
        [](BigUInt const& us) -> Index
        {
            for (auto it = us.end(); it != us.begin();){
                if (!UIntTraitsT::prime_uint_is_zero(*--it)){
                    return static_cast<Index>((++it) - us.begin());
                }
            }
            return static_cast<Index>(0);
        };

    auto lhs_size = calc_size(lhs);
    auto rhs_size = calc_size(rhs);
    return (lhs_size < rhs_size)?
                this_func(rhs, rhs_size, lhs, lhs_size)
                : this_func(lhs, lhs_size, rhs, rhs_size);
}


#if 0
namespace {
    using U = UInt8Traits::UIntModBase;
    using BigUInt = std::vector<U>;

    auto _test_mul = little_endian_prime_uint_seq_mul<UInt8Traits>;
}
#endif

    //auto operator<< (std::ostream& ostream, U u) -> std::ostream&
    template <typename Traits>
    auto operator<< (std::basic_ostream<char, Traits>& ostream, UInt8Traits::UIntModBase u)
    -> std::basic_ostream<char, Traits>&
    {
        ostream << '{' << static_cast<unsigned int>(u.value) << '}';
        return ostream;
    }


} namespace nn_ns {
}




