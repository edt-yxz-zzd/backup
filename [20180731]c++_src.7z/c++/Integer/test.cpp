
///////////////////////////////////////////////////////
#include "Integer.hpp" // UInt8Traits, little_endian_prime_uint_seq_mul
#include "print_vector.hpp"
#include "print_tuple.hpp"

#include <iostream> // std::cout
#include <vector>

namespace {
    using namespace nn_ns;
    using U = UInt8Traits::UIntModBase;
    using BigUInt = std::vector<U>;

    auto _test_mul = little_endian_prime_uint_seq_mul<UInt8Traits>;
    auto _test_eq = little_endian_prime_uint_seq_eq<UInt8Traits>;
    auto _test_lt = little_endian_prime_uint_seq_lt<UInt8Traits>;
}




namespace {

}


int main()
{
    BigUInt const lhs = {{3}, {4}, {0}, {0}};
    BigUInt const rhs = {{5}, {5}, {3}, {4}, {0}, {0}};
    BigUInt ans = BigUInt({{15}, {35}, {29}, {24}, {16}});
    // r should be [15, 35, 29, 24, 16]
    // see: mul_little_endian_bytes.py
    //BigUInt const r = _test_mul(lhs, rhs);
    BigUInt const r = little_endian_prime_uint_seq_mul<UInt8Traits>(lhs, rhs);
    //r == ans; // compile time error, why???????????????
    //      since no default operator== for struct UInt8{...}
    //assert(r == ans);
    assert(_test_eq(r, ans));
    assert(!_test_lt(r, ans));
    assert(!_test_lt(ans, r));
    std::cout << r << std::endl;
    std::cout << "[15, 35, 29, 24, 16]" << std::endl;

    std::cout << _test_mul({}, {}) << std::endl;
    std::cout << "[]" << std::endl;
    std::cout << _test_mul({{1},{2},{1}}, {{1},{2},{3}}) << std::endl;
    std::cout << "[1, 4, 8, 8, 3]" << std::endl;
    std::cout << _test_mul({{1},{0},{2},{0},{1},{0}}, {{1},{0},{2},{3}}) << std::endl;
    std::cout << "[1, 0, 4, 3, 5, 6, 2, 3]" << std::endl;
    return 0;
}
#if 0
#endif
