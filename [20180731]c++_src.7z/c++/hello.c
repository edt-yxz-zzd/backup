
#include <stdio.h>

int main()
{
	printf( "Hi, Kids!");
	return 0;
}
