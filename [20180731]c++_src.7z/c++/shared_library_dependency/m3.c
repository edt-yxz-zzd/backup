

#define MACRO_FX f3
#include "mainx"

