

#define MACRO_FX f1
#include "mainx"

