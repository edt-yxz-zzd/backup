

#define MACRO_FX f2
#include "mainx"

