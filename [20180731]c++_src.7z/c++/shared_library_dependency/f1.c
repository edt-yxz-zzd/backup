
int f0(int i);

int f1(int i)
{
    return f0(i);
}