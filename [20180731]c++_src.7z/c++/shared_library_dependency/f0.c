

#include <stdlib.h>

int f0(int i)
{
    if (i < 0) exit(i);
    return i;
}