
#include<stdio.h>

int f2(int i)
{
    puts("f2_stub");
    return -1;
}

