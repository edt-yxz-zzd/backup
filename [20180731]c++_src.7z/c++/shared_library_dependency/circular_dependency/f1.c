

int f2(int i);

int f1(int i)
{
    return i ? f2(i >> 1) : i;
}

