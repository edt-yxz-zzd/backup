


int f1(int i);

int f2(int i)
{
    return i ? f1(i >> 1) : i;
}

