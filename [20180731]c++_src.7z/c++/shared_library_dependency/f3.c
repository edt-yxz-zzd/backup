

#include<stdio.h>

int f2(int i);

int f3(int i)
{
    puts("f3");
    if (i > 0) return f2(i/2);
    return 0;
}

