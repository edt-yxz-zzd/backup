
#include<stdio.h>

int f3(int i);

int f2(int i)
{
    puts("f2");
    return f3(i);
}

