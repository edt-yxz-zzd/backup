

#define MACRO_FX f0
#include "mainx"

