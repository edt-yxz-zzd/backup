
#include <iostream>


template <typename T>
struct s_t
{
    T t;
};

int main()
{
#define PRINT(T) \
    std::cout << "sizeof("#T") = " \
        << sizeof(T) << std::endl; \
    std::cout << "sizeof(s_t<"#T">) = " \
        << sizeof(s_t<T>) << std::endl
    
    PRINT(char);
    PRINT(int);
    PRINT(char[3]);
    PRINT(short);
    PRINT(float);
    return 0;
    
}