
#include <iostream>


static int* p;

int& f(int& i)
{
    static int& a = i;
    return a;
}

int r(int i)
{
    if (i <= 0){ f(i) = -20; return i;}
    int a = 0;
    int b = 0;
    int c = 0;
    for (; a < 5; ++a){++b;++c;}
    return r(--i);
}

class T
{
    int i;
    public:
    T();
    int g(){return i;}
    void s(){++i;}
};

T::T(){f(i);}

int main()
{
    T t;
    for (int j = 0; j < 10000; ++j) t.s();
    r(100);
    std::cout << t.g() << std::endl;
    
    int j = 2;
    f(j) = 1;
    std::cout << t.g() << std::endl;
    return 0;
}