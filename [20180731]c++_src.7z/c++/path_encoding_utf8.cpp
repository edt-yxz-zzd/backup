﻿#include <boost/filesystem/fstream.hpp>
#include <fstream>
#include <locale>
#include <string>
#include <vector>
#include <sstream>
using std::string;
using std::u32string;
typedef std::basic_ostringstream<char32_t> o32stream;
typedef std::codecvt<char32_t,char,std::mbstate_t> stdcvt;


//typedef std::codecvt<wchar_t,char,std::mbstate_t> stdcvt;
class mycvt:public stdcvt
{};

u32string utf8_to_utf32(string const s)
{
	std::vector<char32_t> s32(s.size());
	std::mbstate_t mb = std::mbstate_t(); // initial shift state
	mycvt cvt;
	const char* end_from = &*s.begin();
	char32_t* end_to = &*s32.begin();
	cvt.in(mb, &*s.begin(), &*s.end(), end_from, &*s32.begin(), &*s32.end(), end_to);
	if (end_from != &*s.end()) std::cerr << "cvt error" << std::endl;
	return u32string(&*s32.begin(), end_to);
}

namespace fs = boost::filesystem;

int main()
{
  fs::path aa(u32string());
#if 0
  char const* path = u8"工工工";
  fs::ofstream out(path);
  if (!out) std::cerr << "fail!!" << std::endl;
  fs::path p(utf8_to_utf32(path), fs::path::codecvt());
  //fs::path p(path, mycvt());
  std::cout << path << p << std::endl;
  out.open(p);
  if (!out) std::cerr << "fail!!" << std::endl;
  out << path;
  out.put('\n');
  out.close();


  std::cout << path << std::endl;
  std::ifstream fin(path);
  string line;
  while(std::getline(fin, line))
    std::cout << line << std::endl;
#endif
  return 0;
}
