

/* 
*   collatz_conjecture : 
*           test Collatz conjecture at positive number num.
*   input :
*           num > 0
*   output : 
*           -1 : run-time error
*           0  : pass this test
*           1  : fail this test
*/

int collatz_conjecture(int num);



int collatz_conjecture_triply_plusplus(int num);
int collatz_conjecture_div2(int num);


