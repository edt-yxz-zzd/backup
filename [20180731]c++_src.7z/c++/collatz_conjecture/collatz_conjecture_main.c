
#include "collatz_conjecture.h"
#include <assert.h>


int main(void)
{
    const int i = 3000;
    return collatz_conjecture(i);
}


int collatz_conjecture(int num)
{
    assert(num > 0);
    if (num != 1)
    {
        return num & 1? collatz_conjecture_triply_plusplus(num) :
                        collatz_conjecture_div2(num);
    }
    
    return 0;
}
