
#include "collatz_conjecture.h"
#include <assert.h>

int collatz_conjecture_div2(int num)
{
    assert(0 == (num & 1));
    return collatz_conjecture(num >> 1);
}