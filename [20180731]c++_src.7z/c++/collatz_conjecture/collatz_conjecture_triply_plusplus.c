

#include "collatz_conjecture.h"
#include <limits.h>
#include <assert.h>
#include <stdlib.h>

int collatz_conjecture_triply_plusplus(int num)
{
    assert(1 == (num & 1));
    if ((INT_MAX - 1) / 3 < num) exit(-1);
    return collatz_conjecture(3*num + 1);
}