
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <errno.h>

#define BIT_SIZE_OF_WORD 32
#define UINTX_T( X) uint##X##_t 
/*typedef UINTX_T( BIT_SIZE_OF_WORD) uintx;*/
typedef uint32_t uintx;
const uintx sqrt_max = 1 << (BIT_SIZE_OF_WORD /2);

void min_prime_factor_init( uintx n, uintx *pt_uints)
{
	for( uintx i = 0; i < n; i++)
	{
		pt_uints[i] = i;
	}
}


void min_prime_factor( uintx n, uintx *pt_uints)
{
	min_prime_factor_init( n, pt_uints);

	for( uintx i = 2; i < n; i++)
	{
		if ( pt_uints[i] != i) continue;

		/* i is a prime */
		if ( i >= sqrt_max) break; /* else i*i while overflow*/
		uintx n_i = n - i;
		for( uintx j = i* i- i; j < n_i; )
		{
			j += i; /* assert( j < n) */
			if ( pt_uints[j] == j)
				pt_uints[j] = i;
		}
	}
}

int write_mpf_to_file( uintx *pt_uints, uintx n, uintx skip_prime_below)
{
	char const *format_str_div = "%u/%u\n"; 
	char const *format_str_prime = "%u\n"; 
	char fname[256+BIT_SIZE_OF_WORD]; /* anti-overflow */
	sprintf( fname, "min_prime_factor_below_%u_skip_%u.txt", n, skip_prime_below);

	{
		FILE *fp = fopen( fname, "w");
		if ( fp == NULL) return -2;

		for ( uintx i = 2; i < n; i++)
		{
			if ( pt_uints[i] < skip_prime_below) continue;
			if ( i == pt_uints[i]) fprintf( fp, format_str_prime, i);
			else fprintf( fp, format_str_div, i, pt_uints[i]);
		}

		fclose( fp);
	}

	return 0;
}


char const *true_main( int argc, char const* argv[])
{
	/* argv[3] = { this.exec, upper_bound, skip_bound} */
	if ( argc != 3) return "argc != 3";
	/*char const *num_end = NULL;*/
	char *num_end = NULL;
	errno = 0;
	uintx n = strtoul( argv[1], &num_end, 0);
	if ( errno != 0) return "str(argv[1]).fail: out-of-range"; 
	if ( num_end != NULL && *num_end != '\0') return "str(argv[1]).fail";
	
	num_end = NULL;
	errno = 0;
	uintx skip_prime_below = strtoul( argv[2], &num_end, 0);
	if ( errno != 0) return "str(argv[2]).fail: out-of-range"; 
	if ( num_end != NULL && *num_end != '\0') return "str(argv[2]).fail";

	clock_t t0 = clock();
	char const* err = NULL;
	uintx *pt_uints = (uintx*) calloc( n, sizeof(uintx));
	do
	{
		if ( pt_uints == NULL && n != 0) 
		{
			err = "memory_alloc.fail";
			break;
		}

		min_prime_factor( n, pt_uints);
		if ( write_mpf_to_file( pt_uints, n, skip_prime_below))
		{
			err = "file.write.fail";
			break;
		}
	}
	while(0);
	free( pt_uints);
	clock_t t1 = clock();
	printf( "time = %f second\n", float(t1-t0)/CLOCKS_PER_SEC);
	
	return err;
}





int main( int argc, char const* argv[])
{
	char const *err = true_main( argc, argv);
	if ( err) 
	{
		printf( "error : %s\n", err);
		puts( "usage: this.exec, upper_bound, skip_bound");
	}
	return !!err;
}





