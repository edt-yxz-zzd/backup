
#ifndef OWNERPTR_HPP
#define OWNERPTR_HPP
#include <algorithm> // for swap
#include <memory> // for default_delete


template<typename T, typename D = std::default_delete<T>>
class OwnerPtr
{
    public:
    explicit OwnerPtr(T* p):ptr(p){}
    
    template<typename ... Args>
    explicit OwnerPtr(Args ... args):ptr(new T(args...)){}
    // what if Args are <T*>, <OwnerPtr&> or <OwnerPtr&&>??
    //     use "make(args...)" !!
    template<typename ... Args>
    static OwnerPtr make(Args ... args){return OwnerPtr(new T(args...));}
    
    ~OwnerPtr()throw(){delete ptr;}
    
    void swap(OwnerPtr& other){
        if (this != &other)std::swap(ptr, other.ptr);}
    OwnerPtr(OwnerPtr&& other)throw():ptr(other.ptr){other.ptr = nullptr;}
    OwnerPtr(OwnerPtr& other):OwnerPtr(*other.ptr){}
    OwnerPtr& operator=(OwnerPtr& other)
    {
        return *this = OwnerPtr(other);
    }
    
    OwnerPtr& operator=(OwnerPtr&& other)
    {
        swap(other);
        return *this;
    }
    
    
    T* operator->()const {return ptr;}
    T& operator*()const {return *ptr;}
    private:
    T* ptr;
    
};

template<typename T>
inline void swap(OwnerPtr<T>& a, OwnerPtr<T>& b)throw(){a.swap(b);}

#endif // OWNERPTR_HPP