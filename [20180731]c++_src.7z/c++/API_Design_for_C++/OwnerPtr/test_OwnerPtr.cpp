
#include <iostream>
#include "OwnerPtr.hpp"

using namespace std;

#define VERBOSE 1

#define TO_STRING(x) #x
#define TO_STMT(stmts) do{stmts}while(0)
#define TEST(expr) TO_STMT(\
        if (!(expr)) cerr << "fail : " << TO_STRING(expr) << endl;\
        else cout << "pass : " << TO_STRING(expr) << endl;\
    )

#define PRINT_VAL(v) TO_STMT(cout << TO_STRING((v)) << " = " << (v) << endl;)

int total_C = 0;
struct C
{
    template <typename ... Args>
    C(Args ... args) // default copy construct will not
    {
        sizeof___args = sizeof...(args);
        #if VERBOSE
        cout << "C::C(args...); "
                "// sizeof...(args) == " 
             << sizeof...(args) 
             << endl;
        #endif
        
        ++total_C;
    }
    ~C()
    {
        --total_C;
        #if VERBOSE
        cout << "C::~C();" << endl;
        #endif
    }
    
    ///////////
    int sizeof___args;
};
bool test_OwnerPtr_constructor()
{
    OwnerPtr<C> p(3, 0.4, "afs");
    return 3 == p->sizeof___args;
}

bool test_OwnerPtr_destructor()
{
    int const n = total_C;
    {
        OwnerPtr<C> p;
        if (n+1 != total_C)
            return false;
    }
    return n == total_C;
    
}
bool test_OwnerPtr_copy_constructor()
{
    int const n = total_C;
    OwnerPtr<C> p(3, 0.4, "afs");
    PRINT_VAL(total_C);
    OwnerPtr<C> p2(p);
    cout << n+2 << ' ' << total_C << endl;
    PRINT_VAL(p2->sizeof___args);
    return n+2 == total_C && 3 == p2->sizeof___args;
}


int main()
{
    // cout << "test_OwnerPtr_constructor():" << test_OwnerPtr_constructor() << endl;
    TEST(test_OwnerPtr_constructor());
    TEST(test_OwnerPtr_destructor());
    TEST(test_OwnerPtr_copy_constructor());
}

