
#include <iostream>
#include "pimpl.hpp"

using namespace std;


int main(int argc, char** argv)
{
    PublicClass c;
    cout << c.public_method(argc) << endl;
    return 0;
}


