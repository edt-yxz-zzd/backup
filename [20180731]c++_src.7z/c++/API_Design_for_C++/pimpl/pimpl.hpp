
#ifndef PIMPL_HPP
#define PIMPL_HPP

class PublicClass
{
    public:
    PublicClass();
    ~PublicClass()throw();
    
    int public_method(int);
    private:
    PublicClass(PublicClass const&);
    PublicClass(PublicClass const&&);
    PublicClass& operator=(PublicClass const&);
    PublicClass& operator=(PublicClass const&&);
    class Impl;
    Impl* pimpl;
};


#endif // PIMPL_HPP

