

#include "pimpl.hpp"

#ifndef _PIMPL_PRIVATE_HPP
#define _PIMPL_PRIVATE_HPP

class PublicClass::Impl
{
    // definitions
    public:
    int public_method_impl(int);
};

#endif // _PIMPL_PRIVATE_HPP












