#include "_pimpl_private.hpp"

PublicClass::PublicClass():pimpl(new Impl())
{
}

PublicClass::~PublicClass()throw()
{
    delete pimpl;
}

int PublicClass::Impl::public_method_impl(int i)
{
    return i;
}


int PublicClass::public_method(int i)
{
    return pimpl->public_method_impl(i);
}





