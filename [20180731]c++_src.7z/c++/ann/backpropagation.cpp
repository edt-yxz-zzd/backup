
#include <cassert>


#include <iostream>

#include "BackPropagation.hpp"
#include "math_func.hpp"
#include "container_io.tpl"

#define I iterator
#define CI const_iterator

// #define PRINT(s) do{std::cout << "here " << s << std::endl;}while(0)
// #define PRINT(s) do{static int i = 0;std::cout << "here " << i++ << ' ' << s << std::endl;}while(0)



using namespace ns_BackPropagation;



    WAll BackPropagation::init_weights(U const& num_nodes, 
        Value min, Value max)
    {
        WAll wall;
        assert(num_nodes.size() > 1);
        
        unsigned pre_size = num_nodes.front();
        assert(pre_size > 0);
        
        for (U::CI i = ++num_nodes.begin(); i != num_nodes.end(); ++i){
            unsigned size = *i;
            assert(size > 0);
            ++pre_size; // for 1.0 const input each layer
            
            wall.push_back(WMx());
            WMx& wmx = wall.back();
            for (unsigned k = 0; k < size; ++k){
                wmx.push_back(WV());
                WV& wv = wmx.back();
                for (unsigned j = 0; j < pre_size; ++j){
                    wv.push_back(uniform(min, max));
                }

            }
            
            pre_size = size;
            
        }
        
        /*
        PRINT(wall.size());
        for (WAll::I i = wall.begin(); i != wall.end(); ++i){
            WMx& wmx = *i;
            PRINT(wmx.size());
            for (WMx::I i = wmx.begin(); i != wmx.end(); ++i){
                WV& wv = *i;
                PRINT(wv.size());
            }
            
        }*/
        return wall;
    }
    
    WMx BackPropagation::init_outputs(U const& num_nodes)
    {
        assert(num_nodes.size() > 1);
        WMx outputs;
        for (U::CI i = num_nodes.begin(); i != num_nodes.end(); ++i){
            unsigned size = *i;
            assert(size > 0);
            
            outputs.push_back(V(size));
        }
        
        return outputs;
    }
    
    void BackPropagation::init_outputs()
    {
        outputs = init_outputs(num_nodes);
        output_errors = outputs;
    }
    
    BackPropagation::BackPropagation(WAll const& weights, WAll const& dweights, 
        U const& num_nodes, unsigned max_step, 
        double learn_speed, double threshold, 
        double weight_momentum):
        weights(weights), 
        dweights(dweights), 
        num_nodes(num_nodes), 
        max_step(max_step), 
        learn_speed(learn_speed), 
        threshold(threshold), 
        weight_momentum(weight_momentum) 
    {
        init_outputs();
    }
    
    double BackPropagation::average_error(Trans const& data)
    {
        double error = 0.;
        for (Trans::CI i = data.begin(); i != data.end(); ++i){
            calcOutputs(i->first);
            
            
            V const& last_layer_outputs = outputs.back();
            V const& target = i->second;
            for (V::size_type k = 0; k < last_layer_outputs.size(); ++k){
                error += fabs(last_layer_outputs[k] - target[k]);
            }
            
        }
        
        error /= data.size();
        error /= num_nodes.back();
        return error;

    }
    
    unsigned BackPropagation::trans(Trans const& data)   // -> step
    {
        unsigned step = 0;
        try{
        for (; step < max_step; ++step){
            bool stop = true;
            for (Trans::CI i = data.begin(); i != data.end(); ++i){
                trans(i->first, i->second);
                
                if (stop){
                    V const& last_layer_outputs = outputs.back();
                    V const& target = i->second;
                    for (V::size_type k = 0; k < last_layer_outputs.size(); ++k){
                        if (fabs(last_layer_outputs[k] - target[k]) >= threshold){
                            stop = false;
                            break;
                        }
                    }
                }
            }
            if (stop) break;
        }
        }catch(...){
            std::cout << "step " << step << " @BackPropagation::trans" << std::endl;
            throw;
        }
        
        return step;
    } 
    void BackPropagation::trans(V const& input, V const& target)
    {
        assert(input.size() == num_nodes.front());
        assert(target.size() == num_nodes.back());
        
        calcOutputs(input);
        calcLastLayerOutputErrors(target);
        calcHiddenLayersOutputErrors();
        updateWeights();
    }
    
    void BackPropagation::calcOutputs(V const& input)
    {
        calcOutputs(outputs, input, weights);
    }
    void BackPropagation::calcOutputs(Mx& outputs, V const& input, WAll const& weights)
    {
        Mx::I o = outputs.begin();
        o->assign(input.begin(), input.end());
        Mx::I i = o++;
        
        for (WAll::CI iw = weights.begin(); 
            iw != weights.end(); ++iw, ++o, ++i){
            calcOutputs(*o, *i, *iw);
        }
    }
    void BackPropagation::calcOutputs(V& outputs, V const& input, WMx const& weights)
    {
        V::I o = outputs.begin();
        for (WMx::CI iw = weights.begin(); 
            iw != weights.end(); ++iw, ++o){
            calcOutputs(*o, input, *iw);
        }
    }
    void BackPropagation::calcOutputs(Value& output, V const& input, WV const& weights)
    {
        output = weights.back();
        output += dotproduct(input.begin(), input.end(), weights.begin());
        
        output = sigmoid(output);
    }
    


    void BackPropagation::calcLastLayerOutputErrors(V const& target)
    {
        V::CI o = outputs.back().begin();
        V::CI t = target.begin();
        V::I oend = output_errors.back().end();
        for (V::I oe = output_errors.back().begin(); 
            oe != oend; ++oe, ++o, ++t){
            *oe = *o * (1. - *o) * (*t - *o);
        }
    }
    void BackPropagation::calcHiddenLayersOutputErrors()
    {
        Mx::CI o = --outputs.end();
        WAll::CI w = weights.end();
        assert(weights.size()+1 == outputs.size());
        Mx::CI ne = output_errors.end();
        Mx::I oe = --output_errors.end();
        for (; oe != output_errors.begin();){
            --o; --w; --ne; --oe;
            //PRINT("BackPropagation::calcHiddenLayersOutputErrors");
            calcHiddenLayerOutputErrors(*oe, *o, *w, *ne);
        }
    }
    
    void BackPropagation::calcHiddenLayerOutputErrors(
        V& output_errors, 
        V const& outputs, 
        WMx const& weights, 
        V const& next_layer_output_errors)
    {
        for (V::size_type i = 0; i < output_errors.size(); ++i){
            V downstream_weights;
            for (WMx::CI w = weights.begin(); w != weights.end(); ++w){
                downstream_weights.push_back((*w)[i]);
            }
            //PRINT("BackPropagation::calcHiddenLayerOutputErrors");
            Value o = outputs[i];
            Value sum = dotproduct(
                downstream_weights.begin(), 
                downstream_weights.end(), 
                next_layer_output_errors.begin());
            output_errors[i] = o * (1-o) * sum;
        }
    }
    void BackPropagation::updateWeights()
    {
        for (V::size_type i = 0; i < weights.size(); ++i){
            updateWeights(weights[i], dweights[i], 
                outputs[i], output_errors[i+1], 
                learn_speed, weight_momentum);
        }

    }
    
    void BackPropagation::updateWeights(WMx& weights, WMx& dweights, 
        V const& outputs, V const& next_layer_output_errors, 
        double learn_speed, double weight_momentum)
    {
        for (V::size_type ni = 0; ni < next_layer_output_errors.size(); ++ni){
            Value k = learn_speed * next_layer_output_errors[ni];
            WV& ni_upstream_dweights = dweights[ni];
            WV& ni_upstream_weights = weights[ni];
            
            assert(ni_upstream_weights.size() == outputs.size()+1);
            Value o;
            for (V::size_type i = 0; i < ni_upstream_weights.size(); ++i){
                if (i < outputs.size())
                    o = outputs[i];
                else o = 1.0;
                
                Value dw = k * o + weight_momentum * ni_upstream_dweights[i];
                Value w = ni_upstream_weights[i] + dw;
                
                ni_upstream_dweights[i] = dw;
                ni_upstream_weights[i] = w;
            }
        }
    }

std::ostream& operator << (std::ostream& ostr, BackPropagation const& b)
{
    ostr << "BackPropagation(";
    
    #define STATS(member) \
        ostr << #member "=" << b.member << ',' << ' ';
    
    STATS(weights);
    STATS(dweights);
    STATS(num_nodes);
    STATS(max_step);
    STATS(learn_speed);
    STATS(threshold);
    STATS(weight_momentum);
    
    #undef STATS
    /*
    ostr << "weights=" << b.weights << ',' << ' ';
    ostr << "dweights=" << b.dweights << ',' << ' ';
    ostr << "num_nodes=" << b.num_nodes << ',' << ' ';
    ostr << "max_step=" << b.max_step << ',' << ' ';
    ostr << "learn_speed=" << b.learn_speed << ',' << ' ';
    ostr << "threshold=" << b.threshold << ',' << ' ';
    ostr << "weight_momentum=" << b.weight_momentum << ',' << ' ';
    */
    
    ostr << ')';
    return ostr;
}

std::istream& operator >> (std::istream& istr, BackPropagation& b)
{
        
    std::string atfunc = "istream >> BackPropagation";
    BackPropagation tmp(b);
    
    matchStr(istr, "BackPropagation(", atfunc);
    
    
    
    #define STATS(member) \
        matchStr(istr, #member "=", atfunc);\
        istr >> tmp.member;\
        matchStr(istr, ", ", atfunc);
    
    STATS(weights);
    STATS(dweights);
    STATS(num_nodes);
    STATS(max_step);
    STATS(learn_speed);
    STATS(threshold);
    STATS(weight_momentum);
    
    #undef STATS
    
    matchStr(istr, ")", atfunc);
    
    tmp.init_outputs();
    
    b.swap(tmp);
    
}


bool operator == (BackPropagation const& self, BackPropagation const& other)
{
    #define STATS(member) \
        if (self.member != other.member) return false;
    
    STATS(weights);
    STATS(dweights);
    STATS(num_nodes);
    STATS(max_step);
    STATS(learn_speed);
    STATS(threshold);
    STATS(weight_momentum);
    
    #undef STATS
    
    return true;
}



//unsigned backpropagation(WAll& weight_all );












