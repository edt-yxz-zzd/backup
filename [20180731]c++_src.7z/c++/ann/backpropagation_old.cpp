
#include <cassert>
#include <vector>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <utility> // pair
#include <algorithm> // swap

#include <iostream>

using std::vector;
typedef double Value;
typedef vector<Value> V; // input/output/target vector
typedef vector<V> Mx; 
typedef vector<Value> WV; // weight[j][i] for any i in layer L, if j in layer L+1
typedef vector<WV> WMx;
typedef vector<WMx> WAll; // for all layer
typedef vector<unsigned> U;
typedef vector<std::pair<V, V> > Trans;


#define I iterator
#define CI const_iterator

#define PRINT(s) std::cout << "here " << s << std::endl;

template <typename T>
std::ostream& operator << (std::ostream& ostr, std::vector<T> const& v)
{
    typedef std::vector<T> V;
    ostr << '[';
    for (typename V::CI i = v.begin(); i != v.end(); ++i){
        ostr << *i << ',' << ' ';
    }
    
    ostr << ']';
    return ostr;
}

template <typename T, typename T2>
std::ostream& operator << (std::ostream& ostr, std::pair<T, T2> const& v)
{
    ostr << '(';
    ostr << v.first << ',' << ' ' << v.second;
    ostr << ')';
    return ostr;
}

template <typename It1, typename It2>
typename It1::value_type dotproduct(It1 beg1, It1 end1, It2 beg2)
{
    typename It1::value_type v;
    for (; beg1 != end1; ++beg1, ++beg2){
        v += (*beg1) * (*beg2);
    }
    return v;
    
}

double sigmoid(double x)
{
    if (x < 0)
        return exp(x)/(1.0 + exp(x));
    else
        return 1.0/(1.0 + exp(-x));
}


double random()
{
    static const int __s = (srand(time(NULL)), 0);
    int r = rand();
    return double(r)/RAND_MAX;
}

double uniform(double lbound, double ubound)
{
    double r = random();
    return lbound + (ubound - lbound)*r;
}


struct BackPropagation
{
    
    WAll weights;
    WAll dweights;
    U num_nodes; // each layer
    unsigned max_step;
    double learn_speed;
    double threshold;
    double weight_momentum;
    
    Mx outputs;
    Mx output_errors;
    
    void swap(BackPropagation& other)throw()
    {
        std::swap(weights, other.weights);
        std::swap(dweights, other.dweights);
        std::swap(num_nodes, other.num_nodes);
        std::swap(max_step, other.max_step);
        std::swap(learn_speed, other.learn_speed);
        std::swap(threshold, other.threshold);
        std::swap(weight_momentum, other.weight_momentum);
        
        std::swap(outputs, other.outputs);
        std::swap(output_errors, other.output_errors);
    }
    static WAll init_weights(U const& num_nodes, 
        Value min = 0.1, Value max = 0.1)
    {
        WAll wall;
        assert(num_nodes.size() > 1);
        
        unsigned pre_size = num_nodes.front();
        assert(pre_size > 0);
        
        for (U::CI i = ++num_nodes.begin(); i != num_nodes.end(); ++i){
            unsigned size = *i;
            assert(size > 0);
            ++pre_size; // for 1.0 const input each layer
            
            wall.push_back(WMx());
            WMx& wmx = wall.back();
            for (unsigned k = 0; k < size; ++k){
                wmx.push_back(WV());
                WV& wv = wmx.back();
                for (unsigned j = 0; j < pre_size; ++j){
                    wv.push_back(uniform(min, max));
                }

            }
            
            pre_size = size;
            
        }
        
        /*
        PRINT(wall.size());
        for (WAll::I i = wall.begin(); i != wall.end(); ++i){
            WMx& wmx = *i;
            PRINT(wmx.size());
            for (WMx::I i = wmx.begin(); i != wmx.end(); ++i){
                WV& wv = *i;
                PRINT(wv.size());
            }
            
        }*/
        return wall;
    }
    
    BackPropagation(WAll const& weights, WAll const& dweights, 
        U const& num_nodes, unsigned max_step=1000, 
        double learn_speed=.3, double threshold=.2, 
        double weight_momentum=.0):
        weights(weights), 
        dweights(dweights), 
        num_nodes(num_nodes), 
        max_step(max_step), 
        learn_speed(learn_speed), 
        threshold(threshold), 
        weight_momentum(weight_momentum) 
    {
        /*;
        PRINT("BackPropagation::BackPropagation");
        PRINT(_weights.size());
        PRINT("BackPropagation::BackPropagation");
        weights=(_weights);
        PRINT("BackPropagation::BackPropagation");
        dweights=(_dweights);
        PRINT("BackPropagation::BackPropagation"); 
        num_nodes=(_num_nodes);
        PRINT("BackPropagation::BackPropagation"); 
        max_step=(_max_step), 
        learn_speed=(_learn_speed), 
        threshold=(_threshold),
        weight_momentum=(_weight_momentum);
        PRINT("BackPropagation::BackPropagation");*/
        
        assert(num_nodes.size() > 1);
        for (U::CI i = num_nodes.begin(); i != num_nodes.end(); ++i){
            unsigned size = *i;
            assert(size > 0);
            
            outputs.push_back(V(size));
            output_errors.push_back(V(size));
        }
    }
    
    unsigned trans(Trans const& data)   // -> step
    {
        unsigned step = 0;
        try{
        for (; step < max_step; ++step){
            bool stop = true;
            for (Trans::CI i = data.begin(); i != data.end(); ++i){
                trans(i->first, i->second);
                
                if (stop){
                    V const& last_layer_outputs = outputs.back();
                    V const& target = i->second;
                    for (V::size_type k = 0; k < last_layer_outputs.size(); ++k){
                        if (fabs(last_layer_outputs[k] - target[k]) >= threshold){
                            stop = false;
                            break;
                        }
                    }
                }
            }
            if (stop) break;
        }
        }catch(...){
            std::cout << "step " << step << " @BackPropagation::trans" << std::endl;
            throw;
        }
        
        return step;
    } 
    void trans(V const& input, V const& target) // -> step
    {
        assert(input.size() == num_nodes.front());
        assert(target.size() == num_nodes.back());
        
        calcOutputs(input);
        calcLastLayerOutputErrors(target);
        calcHiddenLayersOutputErrors();
        updateWeights();
    }
    
    void calcOutputs(V const& input)
    {
        calcOutputs(outputs, input, weights);
    }
    static void calcOutputs(Mx& outputs, V const& input, WAll const& weights)
    {
        Mx::I o = outputs.begin();
        o->assign(input.begin(), input.end());
        Mx::I i = o++;
        
        for (WAll::CI iw = weights.begin(); 
            iw != weights.end(); ++iw, ++o, ++i){
            calcOutputs(*o, *i, *iw);
        }
    }
    static void calcOutputs(V& outputs, V const& input, WMx const& weights)
    {
        V::I o = outputs.begin();
        for (WMx::CI iw = weights.begin(); 
            iw != weights.end(); ++iw, ++o){
            calcOutputs(*o, input, *iw);
        }
    }
    static void calcOutputs(Value& output, V const& input, WV const& weights)
    {
        output = weights.back();
        output += dotproduct(input.begin(), input.end(), weights.begin());
        
        output = sigmoid(output);
    }
    


    void calcLastLayerOutputErrors(V const& target)
    {
        V::CI o = outputs.back().begin();
        V::CI t = target.begin();
        V::I oend = output_errors.back().end();
        for (V::I oe = output_errors.back().begin(); 
            oe != oend; ++oe, ++o, ++t){
            *oe = *o * (1. - *o) * (*t - *o);
        }
    }
    void calcHiddenLayersOutputErrors()
    {
        Mx::CI o = --outputs.end();
        WAll::CI w = weights.end();
        assert(weights.size()+1 == outputs.size());
        Mx::CI ne = output_errors.end();
        Mx::I oe = --output_errors.end();
        for (; oe != output_errors.begin();){
            --o; --w; --ne; --oe;
            //PRINT("BackPropagation::calcHiddenLayersOutputErrors");
            calcHiddenLayerOutputErrors(*oe, *o, *w, *ne);
        }
    }
    
    static void calcHiddenLayerOutputErrors(
        V& output_errors, 
        V const& outputs, 
        WMx const& weights, 
        V const& next_layer_output_errors)
    {
        for (V::size_type i = 0; i < output_errors.size(); ++i){
            V downstream_weights;
            for (WMx::CI w = weights.begin(); w != weights.end(); ++w){
                downstream_weights.push_back((*w)[i]);
            }
            //PRINT("BackPropagation::calcHiddenLayerOutputErrors");
            Value o = outputs[i];
            Value sum = dotproduct(
                downstream_weights.begin(), 
                downstream_weights.end(), 
                next_layer_output_errors.begin());
            output_errors[i] = o * (1-o) * sum;
        }
    }
    void updateWeights()
    {
        for (V::size_type i = 0; i < weights.size(); ++i){
            updateWeights(weights[i], dweights[i], 
                outputs[i], output_errors[i+1], 
                learn_speed, weight_momentum);
        }

    }
    
    static void updateWeights(WMx& weights, WMx& dweights, 
        V const& outputs, V const& next_layer_output_errors, 
        double learn_speed, double weight_momentum)
    {
        for (V::size_type ni = 0; ni < next_layer_output_errors.size(); ++ni){
            Value k = learn_speed * next_layer_output_errors[ni];
            WV& ni_upstream_dweights = dweights[ni];
            WV& ni_upstream_weights = weights[ni];
            
            assert(ni_upstream_weights.size() == outputs.size()+1);
            Value o;
            for (V::size_type i = 0; i < ni_upstream_weights.size(); ++i){
                if (i < outputs.size())
                    o = outputs[i];
                else o = 1.0;
                
                Value dw = k * o + weight_momentum * ni_upstream_dweights[i];
                Value w = ni_upstream_weights[i] + dw;
                
                ni_upstream_dweights[i] = dw;
                ni_upstream_weights[i] = w;
            }
        }
    }
    
    
};
void swap(BackPropagation& self, BackPropagation& other)throw()
{
    self.swap(other);
}

std::ostream& operator << (std::ostream& ostr, BackPropagation const& b)
{
    ostr << "BackPropagation(";
    ostr << "weights=" << b.weights << ',' << ' ';
    ostr << "dweights=" << b.dweights << ',' << ' ';
    ostr << "num_nodes=" << b.num_nodes << ',' << ' ';
    ostr << "max_step=" << b.max_step << ',' << ' ';
    ostr << "learn_speed=" << b.learn_speed << ',' << ' ';
    ostr << "threshold=" << b.threshold << ',' << ' ';
    ostr << "weight_momentum=" << b.weight_momentum << ',' << ' ';
    ostr << ')';
    return ostr;
}

typedef std::pair<BackPropagation, Trans> BTp;


//unsigned backpropagation(WAll& weight_all );

template<unsigned u>
BackPropagation num_nodes2BackPropagation(unsigned const (&a_num_nodes)[u])
{
    U num_nodes(a_num_nodes, a_num_nodes + u);
    WAll weights = BackPropagation::init_weights(num_nodes);
    WAll dweights = BackPropagation::init_weights(num_nodes, 0., 0.);
    
    //PRINT("num_nodes2BackPropagation");
    return BackPropagation(weights, dweights, num_nodes);
}

template<unsigned s, unsigned t, unsigned isize, unsigned osize>
Trans doubleVs2Trans(
    double const (&input)[s][isize], 
    double const (&target)[t][osize])
{
    assert(s == t);
    Trans r;
    for (unsigned i = 0; i < s; ++i){
        r.push_back(make_pair(
            V(input[i], input[i]+isize), 
            V(target[i], target[i]+osize)
            ));
    }
    return r;
}

BTp testdata_AND()
{
    unsigned _num_nodes[] = {2, 1};
    /*
    U num_nodes(_num_nodes, _num_nodes + sizeof(_num_nodes)/sizeof(_num_nodes[0]));
    WAll weights = BackPropagation::init_weights(num_nodes);
    WAll dweights = BackPropagation::init_weights(num_nodes, 0., 0.);
    */
    
    double input[][2] = {
        {0, 0},
        {0, 1},
        {1, 0},
        {1, 1},
    };
    double target[][1] = {
        {0},
        {0},
        {0},
        {1},
    };
    
    //PRINT("test_data_and");
    BackPropagation b = num_nodes2BackPropagation(_num_nodes);
    //PRINT("test_data_and");
    Trans t = doubleVs2Trans(input, target);

    return BTp(b, t);
    
}


void test_BTp(BTp& bt)
{
    using namespace std;
    
    BackPropagation& b = bt.first;
    Trans const& t = bt.second;
    
    cout << "init " << b << endl;
    cout << "trans " << t << endl;
    unsigned step = b.trans(t);
    cout << "step " << step << endl;
    cout << "end " << b << endl;
    return;
}


int main()
{
    BTp bt = testdata_AND();
    test_BTp(bt);
    return 0;
}














