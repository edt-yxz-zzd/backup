


#include <cmath> // exp
#include <cstdlib> // rand, srand
#include <ctime>
#include <numeric> // inner_product


// may uses inner_product
template <typename It1, typename It2>
inline typename It1::value_type dotproduct(It1 beg1, It1 end1, It2 beg2)
{
    typename It1::value_type v;
    for (; beg1 != end1; ++beg1, ++beg2){
        v += (*beg1) * (*beg2);
    }
    return v;
    
}

inline double sigmoid(double x)
{
    if (x < 0)
        return exp(x)/(1.0 + exp(x));
    else
        return 1.0/(1.0 + exp(-x));
}



inline double random()
{
    static const int __s = (srand(time(NULL)), 0);
    int r = rand();
    return double(r)/RAND_MAX;
}

inline double uniform(double lbound, double ubound)
{
    double r = random();
    return lbound + (ubound - lbound)*r;
}



