#include <ctime>
#include <iostream>

inline double dt(bool print=true) // -> in seconds
{
    static clock_t t0 = clock();
    clock_t t1 = clock();
    double dt = (t1-t0) / double(CLOCKS_PER_SEC);
    if (print) std::cout << "dt = " << dt << " seconds" << std::endl;
    t0 = t1;
    
    return dt;
}
