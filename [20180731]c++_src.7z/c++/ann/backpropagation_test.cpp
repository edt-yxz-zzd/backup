
#include "BackPropagation.hpp"
#include "container_io.tpl"
#include <iostream>
#include <sstream>

using namespace ns_BackPropagation;
using namespace std;


BTp testdata_AND()
{
    unsigned _num_nodes[] = {2, 1};
    /*
    U num_nodes(_num_nodes, _num_nodes + sizeof(_num_nodes)/sizeof(_num_nodes[0]));
    WAll weights = BackPropagation::init_weights(num_nodes);
    WAll dweights = BackPropagation::init_weights(num_nodes, 0., 0.);
    */
    
    double input[][2] = {
        {0, 0},
        {0, 1},
        {1, 0},
        {1, 1},
    };
    double target[][1] = {
        {0},
        {0},
        {0},
        {1},
    };
    
    //PRINT("test_data_and");
    BackPropagation b = num_nodes2BackPropagation(_num_nodes);
    //PRINT("test_data_and");
    Trans t = doubleVs2Trans(input, target);

    return BTp(b, t);
    
}

BTp testdata_hidden_layer_encode()
{
    unsigned _num_nodes[] = {8, 3, 8};

    double input[8][8] = {
        {0, },
    };
    
    for (int i = 0; i < 8; ++i)
        input[i][i] = 1.;
    // double target[8][8] = input
    

    BackPropagation b = num_nodes2BackPropagation(_num_nodes);
    b.max_step = 5000; // about 2500 step
    Trans t = doubleVs2Trans(input, input);

    return BTp(b, t);
    
}

BTp testdata_undetermined_generalization()
{
    unsigned _num_nodes[] = {2, 1, 1};

    double input[][2] = {
        {0, 1},
        {1, 0},
    };
    
    double target[][1] = {
        {0, },
        {1, },
    };
    
    

    BackPropagation b = num_nodes2BackPropagation(_num_nodes);
    b.max_step = 5000;
    b.weight_momentum = .9;
    b.learn_speed = .3;
    b.weights = b.init_weights(b.num_nodes, .1, .1);
    Trans t = doubleVs2Trans(input, target);

    return BTp(b, t);
    
}



void test_BTp(BTp& bt)
{
    using namespace std;
    
    BackPropagation& b = bt.first;
    Trans const& t = bt.second;
    
    stringstream ss;
    Trans tmp;
    BackPropagation tmpb(b);
    tmpb.num_nodes.clear();
    try{
        ss << t;
        //cout << ss.str() << endl;

        ss >> tmp;
        
        ss << b;
        ss >> tmpb;
    }catch(exception& e){
        cout << e.what() << endl;
    }
    assert(t == tmp);
    assert(to_string(b) == to_string(tmpb));
    
    cout << "init " << b << endl;
    cout << "trans " << t << endl;
    unsigned step = b.trans(t);
    cout << "step " << step << endl;
    cout << "end " << b << endl;
    
    cout << "end outputs" << b.outputs << endl;
    return;
}


int main()
{
    BTp bt = testdata_AND();
    test_BTp(bt);
    
    bt = testdata_hidden_layer_encode();
    test_BTp(bt);
    
    
    bt = testdata_undetermined_generalization();
    test_BTp(bt);

    
    /*
    for (int i = 0; i < 100; ++i){
        cout << rand() << endl;
        cout << uniform(-1,1) << endl;
    }*/
    return 0;
}

