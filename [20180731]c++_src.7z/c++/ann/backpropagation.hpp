

#include <vector>
#include <utility> // pair
#include <algorithm> // swap


#include <ostream>
#include <istream>
#include <cassert>



namespace ns_BackPropagation
{
    namespace this_ns = ns_BackPropagation;
    using std::vector;
    typedef double Value;
    typedef vector<Value> V; // input/output/target vector
    typedef vector<V> Mx; 
    typedef vector<Value> WV; // weight[j][i] for any i in layer L, if j in layer L+1
    typedef vector<WV> WMx;
    typedef vector<WMx> WAll; // for all layer
    typedef vector<unsigned> U;
    typedef vector<std::pair<V, V> > Trans;
    
    
    
    struct BackPropagationBase
    {
        typedef this_ns::Value Value;
        typedef this_ns::V V;
        typedef this_ns::Mx Mx;
        typedef this_ns::WV WV;
        typedef this_ns::WMx WMx;
        typedef this_ns::WAll WAll;
        typedef this_ns::U U;
        typedef this_ns::Trans Trans;
    };
}


struct BackPropagation//:public BackPropagationBase
{
    //using namespace std;
    //using namespace ns_BackPropagation;
    // typedef std::pair<BackPropagation, Trans> BTp;
    
    //namespace this_ns = ns_BackPropagation;
    typedef ns_BackPropagation::Value Value;
        typedef ns_BackPropagation::V V;
        typedef ns_BackPropagation::Mx Mx;
        typedef ns_BackPropagation::WV WV;
        typedef ns_BackPropagation::WMx WMx;
        typedef ns_BackPropagation::WAll WAll;
        typedef ns_BackPropagation::U U;
        typedef ns_BackPropagation::Trans Trans;
        
    WAll weights;
    WAll dweights;
    U num_nodes; // each layer
    unsigned max_step;
    double learn_speed;
    double threshold;
    double weight_momentum;
    
    Mx outputs;
    Mx output_errors;
    
    inline void swap(BackPropagation& other)throw()
    {
        std::swap(weights, other.weights);
        std::swap(dweights, other.dweights);
        std::swap(num_nodes, other.num_nodes);
        std::swap(max_step, other.max_step);
        std::swap(learn_speed, other.learn_speed);
        std::swap(threshold, other.threshold);
        std::swap(weight_momentum, other.weight_momentum);
        
        std::swap(outputs, other.outputs);
        std::swap(output_errors, other.output_errors);
    }
    static WAll init_weights(U const& num_nodes, 
        Value min = -0.1, Value max = 0.1);
    static WMx init_outputs(U const& num_nodes);
    void init_outputs();
    BackPropagation(WAll const& weights, WAll const& dweights, 
        U const& num_nodes, unsigned max_step=1000, 
        double learn_speed=.3, double threshold=.2, 
        double weight_momentum=.0);
    
    double average_error(Trans const& data);
    unsigned trans(Trans const& data);   // -> step
    void trans(V const& input, V const& target);
        
    void calcOutputs(V const& input);
    static void calcOutputs(Mx& outputs, V const& input, WAll const& weights);
    static void calcOutputs(V& outputs, V const& input, WMx const& weights);
    static void calcOutputs(Value& output, V const& input, WV const& weights);
    


    void calcLastLayerOutputErrors(V const& target);
    void calcHiddenLayersOutputErrors();
    
    static void calcHiddenLayerOutputErrors(
        V& output_errors, 
        V const& outputs, 
        WMx const& weights, 
        V const& next_layer_output_errors);
    void updateWeights();
    
    static void updateWeights(WMx& weights, WMx& dweights, 
        V const& outputs, V const& next_layer_output_errors, 
        double learn_speed, double weight_momentum);

    static BackPropagation illegal_init()
    {
        return BackPropagation(_WhoCare());
    }
private:
    class _WhoCare{};
    BackPropagation(_WhoCare){}
    
    
};
inline void swap(BackPropagation& self, BackPropagation& other)throw()
{
    self.swap(other);
}

std::ostream& operator << (std::ostream& ostr, BackPropagation const& b);
std::istream& operator >> (std::istream& istr, BackPropagation& b);
bool operator == (BackPropagation const& self, BackPropagation const& other);
inline bool operator != (BackPropagation const& self, BackPropagation const& other)
    {return ! (self == other);}


template<unsigned u>
BackPropagation num_nodes2BackPropagation(unsigned const (&a_num_nodes)[u])
{
    using namespace ns_BackPropagation;

    U num_nodes(a_num_nodes, a_num_nodes + u);
    WAll weights = BackPropagation::init_weights(num_nodes);
    WAll dweights = BackPropagation::init_weights(num_nodes, 0., 0.);
    
    //PRINT("num_nodes2BackPropagation");
    return BackPropagation(weights, dweights, num_nodes);
}

template<unsigned s, unsigned t, unsigned isize, unsigned osize>
BackPropagation::Trans doubleVs2Trans(
    double const (&input)[s][isize], 
    double const (&target)[t][osize])
{
    using namespace ns_BackPropagation;

    assert(s == t);
    Trans r;
    for (unsigned i = 0; i < s; ++i){
        r.push_back(make_pair(
            V(input[i], input[i]+isize), 
            V(target[i], target[i]+osize)
            ));
    }
    return r;
}

namespace ns_BackPropagation
{
    typedef std::pair<BackPropagation, Trans> BTp;
}



