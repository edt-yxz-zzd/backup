
#include <time.h>
#include <typeinfo>
#include <iostream>

int main()
{
	std::cout << typeid(clock_t).name() << std::endl;
	return 0;
}