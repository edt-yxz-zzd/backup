#include <iterator>
#include <typeinfo>
#include <iostream>


using namespace std;



//template<typename I> using reverse_iterator<reverse_iterator<I>> = I;
//template<typename I> using r=reverse_iterator<I>;

#define RSTD(I) reverse_iterator< I >
#define RX(I) riter_t< I >
#define S(T) #T
#define P(T) cout << "sizeof(" << S(T) << ") = " << sizeof(T) << endl
#define P4(r, T) P(T);P(r(T));P(r(r(T)));P(r(r(r(T))))




template <typename ptr_t>
struct X
{
    typedef reverse_iterator<ptr_t> riter_t; 
    typedef ptr_t input_t; 
    static riter_t make(input_t p){return p;}
};
template <typename ptr_t>
struct X<reverse_iterator<ptr_t> >
{
    typedef ptr_t riter_t; 
    typedef reverse_iterator<ptr_t> input_t;  
    static riter_t make(input_t p){return p.base();}
};
template <typename ptr_t>
struct X<reverse_iterator<reverse_iterator<ptr_t> > >
{
    typedef typename X<ptr_t>::riter_t riter_t; 
    typedef reverse_iterator<reverse_iterator<ptr_t> > input_t;
    static riter_t make(input_t p){return X<ptr_t>::make(p.base().base());}
};


template <typename ptr_t>
using riter_t = typename X<ptr_t>::riter_t;


template <typename I>
riter_t<I> make_r(I i){return X<I>::make(i);}


int main()
{
    P4(RSTD, char*);
    P4(RX, char*);
    P(make_r((char*)nullptr));
    P(make_r(make_r((char*)nullptr)));
    return 0;
}

/*
std::reverse_iterator<Iterator> make_reverse_iterator( Iterator i );  (since C++14 )
sizeof(char*) = 8
sizeof(reverse_iterator< char* >) = 8
sizeof(reverse_iterator< reverse_iterator< char* > >) = 16
sizeof(reverse_iterator< reverse_iterator< reverse_iterator< char* > > >) = 24
���޵����ر�󣬲�����reverse_iterator��ʵ�ֻ���make_reverse_iterator�ķ������Ͷ��е�֡�

��ʲô�򵥵İ취ʵ����������Ĺ��ܣ�
template<typename I>
 using reverse_iterator<reverse_iterator<I>> = I;


�Լ�����һ�£����ֺ��鷳������ptr_t��������Ӧ��riter<>���캯�����о����Ա�����֧�ֵĻ�����ûʲô�취��
template <typename ptr_t>
struct X
{
    typedef reverse_iterator<ptr_t> riter_t; 
    typedef ptr_t input_t; 
    static riter_t make(input_t p){return p;}
};
template <typename ptr_t>
struct X<reverse_iterator<ptr_t> >
{
    typedef ptr_t riter_t; 
    typedef reverse_iterator<ptr_t> input_t;  
    static riter_t make(input_t p){return p.base();}
};
template <typename ptr_t>
struct X<reverse_iterator<reverse_iterator<ptr_t> > >
{
    typedef typename X<ptr_t>::riter_t riter_t; 
    typedef reverse_iterator<reverse_iterator<ptr_t> > input_t;
    static riter_t make(input_t p){return X<ptr_t>::make(p.base().base());}
};


template <typename ptr_t>
using riter_t = typename X<ptr_t>::riter_t;


template <typename I>
riter_t<I> make_r(I i){return X<I>::make(i);}


*/


