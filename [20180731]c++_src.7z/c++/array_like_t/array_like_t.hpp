


#ifndef ARRAY_LIKE_T_HPP
#define ARRAY_LIKE_T_HPP
//#include "array_like_t.hpp"


//#include <iosfwd>
//#include <ios>
#include <istream> 
#include <string>  // throw ...

/*
1.
    array_like_t<V,H,I> ptr;
        ++ptr; // == ++i // ++I
        ptr == another_ptr;
        *ptr; // == h[i] // V(H[I])
2.
    file_object_t{istr, start, size}
    char* buf = new char[size];
    istr.seekg(start);
    istr.read(buf, size);
    // [buf, buf+size) is the object in file.
    delete buf;
    
    ostr << fobj; // for <sstream>ostringstream or <fstream>ofstream
    fobj == another

3. 
    file_object_array_t<E>{fobj}
    fobj_arr[i]; // E(istr) if streamoff i
    
    array_like_t<V, file_object_array_t<E>, streamoff> iter, end;// if V(E)
    for (v : range_among(iter,end))...
*/

template<typename V, typename H, typename I>struct array_like_t;
template<typename V, typename H, typename I>
I operator -(array_like_t<V,H,I> const& lhs, array_like_t<V,H,I> const& rhs);

template<typename Value, typename Head, typename Index>
struct array_like_t // require: (Value)head[index]
{
    Head head;
    Index index;
    
    typedef Value value_type;
    typedef Head array_head_t;
    typedef Index array_index_t;

    array_like_t()=default;
    array_like_t(array_like_t const&)=default;
    array_like_t& operator=(array_like_t const&)=default;
    array_like_t(Head const& head_, Index index_):head(head_),index(index_){}
    
    array_like_t& operator++(){++index; return *this;}
    array_like_t operator++(int){array_like_t old(*this); ++index; return old;}
    Value operator*(){return head[index];}
    bool operator==(array_like_t const& that)const{return that.index == this->index && that.head == this->head;}
    bool operator!=(array_like_t const& that)const{return !(*this == that);}
    array_like_t& operator+=(Index i){this->index += i; return *this;}
    array_like_t& operator-=(Index i){this->index -= i; return *this;}
    friend Index operator-<Value, Head, Index>(array_like_t const&, array_like_t const&);
};

template<typename Value, typename Head, typename Index>
Index operator -(array_like_t<Value, Head, Index> const& lhs, 
    array_like_t<Value, Head, Index> const& rhs)
{
    if (lhs.head != rhs.head)
        throw std::string("bad subtraction between array_like_t");
    return lhs.index - rhs.index;
}

struct file_object_t
{
private:
    //using streampos = std::streampos;
    //using streamoff = std::streamoff;
    //using istream = std::istream;
    //using ostream = std::ostream; // work but...
    typedef std::ostream ostream;
    typedef std::istream istream;
    typedef std::streamoff streamoff;
    typedef std::streampos streampos;
    
public:
    istream* p_istr;
    streampos offset;
    streamoff size;
    bool operator==(file_object_t const& that)const{
        return that.p_istr == this->p_istr 
            && that.offset == this->offset 
            && that.size == this->size;
    }
    friend ostream& operator<<(ostream&, file_object_t const&);
    
    
    typedef file_object_t ThisType;
private:
    template<typename T1, typename T2, typename T3>
    file_object_t(T1,T2,T3); // non-implement
public:
    file_object_t()=default;
    file_object_t(ThisType const&)=default;
    //template<>file_object_t<istream, streampos, streamoff>
    //  (istream&, streampos, streamoff);!!!error!!!
    file_object_t(istream& istr, streampos start, streamoff length)
        :p_istr(&istr), offset(start), size(length){}
    ThisType& operator=(ThisType const&)=default;
};
std::ostream& operator<<(std::ostream&, file_object_t const&);








template<typename Entry>  // require: Entry(istream&)
struct file_object_array_t
{
private:
    //using namespace std; !!!error!!!
    //using streamoff = std::streamoff; !!!error!!!
    //namespace xx = std; !!!error!!!
    typedef std::streamoff streamoff;
    typedef file_object_array_t ThisType;
public:
    file_object_t from;
    Entry operator[](streamoff index) {
        from.p_istr->seekg(from.offset +from.size * index); 
        return *from.p_istr;
    }
    bool operator==(file_object_array_t const& that)const
        {return that.from == this->from;}
    file_object_array_t()=default;
    file_object_array_t(ThisType const&)=default;
    file_object_array_t(file_object_t f):from(f){}
    ThisType& operator=(ThisType const&)=default;
};




#endif//ARRAY_LIKE_T_HPP
