

#include "array_like_t.hpp"

//using namespace std;
using std::ostream;
using std::istream;
using std::size_t;
ostream& operator << (ostream& out, file_object_t const& in)
{
    size_t const chunk_size = 1024;
    char chunk[chunk_size];
    istream& istr = *in.p_istr;
    istr.seekg(in.offset);
    auto remain_size = in.size;
    for(; remain_size >= chunk_size; remain_size -= chunk_size)
    {
        istr.read(chunk, chunk_size);
        out.write(chunk, chunk_size);
    }
    
    istr.read(chunk, remain_size);
    out.write(chunk, remain_size);
    return out;
}


