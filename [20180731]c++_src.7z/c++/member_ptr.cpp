
#include <iostream>



struct A
{
    ~A(){i += c;} // non-POD
    char c; 
    int i;  // alignof(int) > alignof(char)
    char b;
    void p()const;
};

struct B
{
    ~B(){i += c;} // non-POD
    int i;  // alignof(int) > alignof(char)
    char c;
    char b;
    void p()const;
};


struct D
{
    ~D(){i += c;} // non-POD
    public: char c; 
    public: int i;  // two public will yield{i,c}?
    char b;
    void p()const;
};

struct E
{
    ~E(){i += c;} // non-POD
    public: char c; 
    private: int i;  // public/private will yield{i,b,c}?
    char b;
    public: void p()const;
};

#define FBODY {std::cout << (void*)&c << ' ' << (void*)&i << ' ' << (void*)&b << ' ' << sizeof(*this) << std::endl;}

void A::p()const FBODY
void B::p()const FBODY
void D::p()const FBODY
void E::p()const FBODY

/*
struct A1{virtual ~A1(){};};
struct A2{virtual ~A2(){};};
struct A3:A1{A2 a; A2 b;};
struct A4:A1,A2{};
*/

struct A1{virtual ~A1(){}; char c;};
struct A2{virtual ~A2(){}; char c;};
struct A3:A1{A2 a; A2 b; char c;};
struct A4:A1,A2{char c;};


int main()
{
    A a;
    B b;
    D d;
    E e;
    
    a.p();
    b.p();
    d.p();
    e.p();
    std::cout << (void*)new char << ' ' << (void*)new char << ' ' << std::endl;
    
    std::cout << sizeof(A1) << ' ' 
        << sizeof(A2) << ' ' 
        << sizeof(A3) << ' ' 
        << sizeof(A4) << std::endl;
    return 0;
}
