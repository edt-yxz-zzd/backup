
namespace hh{ namespace integer{

using std::string;
using std::vector;
using std::uint8_t;

template<typename uint_data_t, typename uint_func_t = uint_data_traits<uint_data_t> >
class integer_tpl;
template<typename uint_data_t, typename uint_func_t = uint_data_traits<uint_data_t> >
class unsigned_integer_tpl;

// b(a//b) + a%b = a
// b(-(a//b)) + (-a%b) = -a => (-a)//b = -(a//b), (-a)%b = -(a%b)
// (-b)(-(a//b)) + a%b = a  => a//(-b) = -(a//b), a%(-b) = a%b
template<typename uint_data_t, typename uint_func_t = uint_data_traits<uint_data_t> >
class integer_tpl
{
    uint_data_t _data;
    bool _sign; // true for negative
    typedef integer_tpl<uint_data_t, uint_func_t> integer_t;
    typedef unsigned_integer_tpl<uint_data_t, uint_func_t> unsigned_integer_t;
public:
    uint_data_t const& get_uint_data()const;
    explict integer_tpl(unsigned_integer_t, bool = false);
    explict integer_tpl(uint_data_t, bool = false);
    
    static integer_tpl neg_one();
    static integer_tpl zero();
    static integer_tpl one();

    void from_bytes(uint8_t* beg, uint8_t* end, bool); // little-endian
    vector<uint8_t> to_bytes(bool&)const;
    void from_string(string const&, int base = 10, char[] symbol_table = null_ptr); // 2 8 10 16 64
    string to_string(int base = 10, char[] = null_ptr)const;
    
    
    integer_tpl& operator++();
    integer_tpl& operator--();
    integer_tpl& operator+=(integer_tpl);
    integer_tpl& operator-=(integer_tpl);
    integer_tpl& operator*=(integer_tpl);
    integer_tpl& operator/=(integer_tpl);
    integer_tpl& operator%=(integer_tpl);
    integer_tpl& operator<<=(integer_tpl);
    integer_tpl& operator>>=(integer_tpl);

};

template<typename uint_data_t, typename uint_func_t = uint_data_traits<uint_data_t> >
class unsigned_integer_tpl
{
    uint_data_t _data;
    typedef integer_tpl<uint_data_t, uint_func_t> integer_t;
    typedef unsigned_integer_tpl unsigned_integer_t;
public:
    uint_data_t const& get_uint_data()const;
    explict unsigned_integer_tpl(integer_t);
    explict unsigned_integer_tpl(uint_data_t);
    
    void from_bytes(uint8_t* beg, uint8_t* end); // little-endian
    vector<uint8_t> to_bytes()const;
    
    unsigned_integer_tpl& operator++();
    unsigned_integer_tpl& operator--();
    unsigned_integer_tpl& operator+=(unsigned_integer_tpl);
    unsigned_integer_tpl& operator-=(unsigned_integer_tpl);
    unsigned_integer_tpl& operator*=(unsigned_integer_tpl);
    unsigned_integer_tpl& operator/=(unsigned_integer_tpl);
    unsigned_integer_tpl& operator%=(unsigned_integer_tpl);
    unsigned_integer_tpl& operator<<=(unsigned_integer_tpl);
    unsigned_integer_tpl& operator>>=(unsigned_integer_tpl);
    
    unsigned_integer_tpl& operator+=(integer_tpl);
    unsigned_integer_tpl& operator-=(integer_tpl);
    unsigned_integer_tpl& operator*=(integer_tpl);
    unsigned_integer_tpl& operator/=(integer_tpl);
    unsigned_integer_tpl& operator%=(integer_tpl);
    unsigned_integer_tpl& operator<<=(integer_tpl);
    unsigned_integer_tpl& operator>>=(integer_tpl);
};



template<typename uint_data_t, typename uint_func_t>
std::ostream& operater<<(std::ostream&, unsigned_integer_tpl<uint_data_t, uint_func_t> const&);
template<typename uint_data_t, typename uint_func_t>
std::istream& operater>>(std::istream&, unsigned_integer_tpl<uint_data_t, uint_func_t>&);


template<typename T> inline T operator+(T a, T b){return a += std::move(b);}
template<typename T> inline T operator-(T a, T b){return a -= std::move(b);}
template<typename T> inline T operator*(T a, T b){return a *= std::move(b);}
template<typename T> inline T operator/(T a, T b){return a /= std::move(b);}
template<typename T> inline T operator%(T a, T b){return a %= std::move(b);}
template<typename T> inline T operator<<(T a, T b){return a <<= std::move(b);}
template<typename T> inline T operator>>(T a, T b){return a >>= std::move(b);}




//////////////////////
template<typename uint_data_t, typename uint_func_t>
inline uint_data_t const& integer_tpl<uint_data_t, uint_func_t>::
get_uint_data()const{return _data;}
template<typename uint_data_t, typename uint_func_t>
inline integer_tpl<uint_data_t, uint_func_t>::
integer_tpl(unsigned_integer_tpl<uint_data_t, uint_func_t> u, bool s)
:_sign(s), _data(std::move(u._data)){}
template<typename uint_data_t, typename uint_func_t>
inline integer_tpl<uint_data_t, uint_func_t>::
integer_tpl(uint_data_t d, bool s)
:_sign(s), _data(std::move(d)){}
    
template<typename uint_data_t, typename uint_func_t>
inline void integer_tpl<uint_data_t, uint_func_t>::
from_bytes(uint8_t* beg, uint8_t* end, bool s)
{_data = uint_func_t::from_bytes(beg, end); _sign = s;}
template<typename uint_data_t, typename uint_func_t>
inline vector<uint8_t> integer_tpl<uint_data_t, uint_func_t>::
to_bytes(bool& sign)const
{sign = _sign; return uint_func_t::to_bytes(_data);}
template<typename uint_data_t, typename uint_func_t>
inline integer_tpl<uint_data_t, uint_func_t>& integer_tpl<uint_data_t, uint_func_t>::
operator++(){return *this += one();}
template<typename uint_data_t, typename uint_func_t>
inline integer_tpl<uint_data_t, uint_func_t>& integer_tpl<uint_data_t, uint_func_t>::
operator--(){return *this -= one();}
    integer_tpl& operator+=(integer_tpl);
    integer_tpl& operator-=(integer_tpl);
    integer_tpl& operator*=(integer_tpl);
    integer_tpl& operator/=(integer_tpl);
    integer_tpl& operator%=(integer_tpl);
    integer_tpl& operator<<=(integer_tpl);
    integer_tpl& operator>>=(integer_tpl);



}}
