
#include <iostream>


class T
{
    static int j;
    int i;
    public:
    T():i(++j){std::cout << "c: " << j << ',' << i << std::endl;}
    ~T(){std::cout << "d: " << j << ',' << i << std::endl; j--;}
};

int T::j = 0;


int main()
{
    T t;
    T* p = new T; // call T()
    delete p; // call ~T()
    p = new T();
    delete p;
    p = new T[2]();
    delete[] p; // ~T
    p = new T[3]; // T()!!!!
    delete[] p;
}
