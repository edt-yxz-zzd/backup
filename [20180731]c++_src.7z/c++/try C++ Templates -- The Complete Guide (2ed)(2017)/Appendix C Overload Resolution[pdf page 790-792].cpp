#if 0
C++ Templates -- The Complete Guide (2ed)(2017).pdf
    Appendix C Overload Resolution
    page 790-791
#endif

template<typename T> void strange(T&&, T&&);
template<typename T> void bizarre(T&&, double&&);
int main()
{
    strange(1.2, 3.4); // OK: with T deduced to double
        // T=double ==>> T&&=double&&
    double val = 1.2;

    strange(val, val); // OK: with T deduced to double&
        // why OK?????????????????
        // val is lvalue!!
        // without std::move, how can it be compiled???????????
        // T=double& ==>> T&&=double& &&=double&???
        // YES, see "reference collapsing.txt"
    strange(val, 3.4); // ERROR: conflicting deductions
    bizarre(val, val); // ERROR: lvalue val doesn’t match double&&
}

