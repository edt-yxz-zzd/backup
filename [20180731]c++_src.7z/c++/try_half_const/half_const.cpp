

#include <map>

template <typename K, typename T>
struct MapHalfConst
{
    // user cannot resize or change keys
    // the same can apply to vector<>
    // we guarantee that the iterators are all valid
    // after we pass MapHalfConst into other funtion 
    // which will modify its values.
    
    int size()const throw();
    T& get(K);
    T const& get(K)const;
    bool contains(K)const throw();
protected:
    void set(K, T);
    MapHalfConst(){}
    MapHalfConst(MapHalfConst const&);
    ~MapHalfConst() throw(){}
    MapHalfConst& operator=(MapHalfConst const&);

private:
    std::map<K,T> _map;
};

template <typename K, typename T>
struct Map:MapHalfConst<K,T>
{
    using MapHalfConst<K,T>::set;
    MapHalfConst<K,T>& halfconst()throw(){return *this;}
    MapHalfConst<K,T> const& halfconst()const throw(){return *this;}
};


#define MapHalfConstMember(R) template <typename K, typename T> \
    inline R MapHalfConst<K,T>::
#define MapHalfConstInstance MapHalfConst<K,T>


MapHalfConstMember(int) size()const throw(){return _map.size();}
MapHalfConstMember(T&) get(K key)
    {if (contains(key)) throw "key not exits"; return _map[key];}
MapHalfConstMember(T const&) get(K key)const
    {if (contains(key)) throw "key not exits"; return _map[key];}
MapHalfConstMember(bool) contains(K key)const throw()
    {return _map.count(key);}

MapHalfConstMember(void) set(K key, T value){_map[key] = value;}
MapHalfConstMember() MapHalfConst(MapHalfConst const& other)
    :_map(other._map){}
MapHalfConstMember(MapHalfConstInstance&) operator=(MapHalfConstInstance const& other)
    {_map=other._map; return *this;}

#undef MapHalfConstMember
#undef MapHalfConstInstance

int main()
{
    Map<int, bool> m;
    m.set(1, true);
    m.halfconst();
    return 0;
}










