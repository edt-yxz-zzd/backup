
/*
how can I cover between:
pair<const K, const V>
pair<const K, V>
pair<K, V>


why struct with implicity-defined destructor cannot switch its member's constness??


*/

// c++11
#include <type_traits>
#include <iostream>
using namespace std;

struct A
{
    virtual ~A();
};

struct B
{
    A a;
};


int main()
{
    std::cout << std::boolalpha;
    std::cout << is_standard_layout<A>::value << '\n'; // false
    std::cout << is_standard_layout<B>::value << '\n'; // false
}

