
#include <iostream>


#include "graph0.hpp"


typedef unsigned int uint_t;
struct EMPTY{};

typedef EMPTY UsrDataT, ColorT, WeightT, LABEL;
typedef unsigned char VertexUintT;
typedef unsigned short DedgeUintT, UedgeUintT;
typedef uint_t DedgeSizeT, UedgeSizeT, VertexSizeT, DedgeListLocationT;

using namespace nn_graph;
typedef GraphInfo<VertexSizeT, DedgeSizeT, UsrDataT> g_info_t;
typedef UedgeInfo<VertexUintT, DedgeListLocationT, WeightT> ue_info_t;
typedef DedgeList<DedgeUintT> de_ls_t;
typedef VertexInfo<de_ls_t, ColorT> v_info_t;
typedef GraphUintMap<VertexUintT, v_info_t, VertexSizeT> v_map_t;
typedef GraphUintMap<UedgeUintT, ue_info_t, UedgeSizeT> ue_map_t;
typedef BasicGraph<v_map_t, ue_map_t, DedgeSizeT, UsrDataT, LABEL> g_t;




using std::vector;
using namespace std;
int main()
{
    try{
    g_t g;
    vector<int> ls = Reader<vector<int> >::read(cin);
    cout << "read!" << endl;
    write(cout, ls);
    cout << endl;
    cin >> g;
    cout << g << endl;
    }catch(const char* s){cerr << s << endl;}
    return 0;
}