

struct B
{
    int a;
};

struct D:B
{
    int b;
    bool operator==(D & other){return b==other.b;}
    bool cmp(D& other){return a == other.a;}
};

template <typename T>struct A{int a;typedef int i;void g();};

template <typename T> struct A<A<T> >
{int a;typedef int i; void g();};

template <typename T>
void A<T>::g(){i i;}


template <typename T>
struct C:A<T>{int get(){return this->a;}};
//incomplete template <typename T>void A<C<T> >::g(){i i;}

template <template <typename> class T>
struct F:T<int>{};

//struct K{void a;};

struct K : private A<int>
{
    using A<int>::a;
};

int main(){
    D d, e;
    d==e;
    d.cmp(e);
    
    
    C<int> c;
    F<A> f;
    A<A<int> > a;
    //a.g(); should be defined... all member functions should be redefined!!!!!
    // too terrible.
    return 0;
    
    
    
}