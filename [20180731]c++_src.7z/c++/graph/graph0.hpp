/*
basic graph:
    multi 
    undirected/directed
    loop
    finite/infinite  // how easy to get nv/degree
    static/increase/stacklike/dynamic

not take care with embedding, no location information are visible.
    DFS may want to use embedding intead of just a graph.
    so DFS API should not support graph directly but be more abstract.



require two args: V/E to indicate the max num_vertices/num_edges
    using bucket-sort, so vertex/dedge are both unsigned int
    V/E may be larger than actual num_vertices/num_edges
    they are used in bucket-sort. larger value will slow down sort.
    why to use V/E? 
        when we require 'delete vertex/edge' op and 
        use some map like unorder_map/vector, 
        we have to take the max vertex number to use in sort.

delete vertex/edge:
    we may try to reduce the max vertex/edge number to fasten sort.
    so, the numberings are changing.
    user should take care of vertex color/edge weight 
    which is not the task of 'basic' graph.




// for subclassing, not for direct use
struct BasicGraph<VertexMapT, UedgeMapT, DedgeSizeT, UsrDataT, LABEL>
{
    typedef VertexMapT VertexMap;
    typedef UedgeMapT UedgeMap;
    typedef UsrDataT usr_data_type;
    
    typedef VertexMap::value_type VertexInfo;
    typedef VertexMap::size_type VertexSize; // i.e. unsigned short
    typedef VertexMap::key_type VertexUint;  // i.e. unsigned char
    typedef VertexMap::range_type VertexRange;
    
    typedef UedgeMap::value_type UedgeInfo;
    typedef UedgeMap::size_type UedgeSize;
    typedef UedgeMap::key_type UedgeUint;
    typedef UedgeMap::range_type UedgeRange;
    
    
    typedef VertexInfo::DedgeList::range_type DedgeRange;
    typedef VertexInfo::VertexColor VertexColor;
    typedef UedgeInfo::UedgeWeight UedgeWeight;
    
    typedef GraphInfo<DedgeSizeT, UsrDataT> GraphInfoType;
    typedef DedgeSizeT DedgeSize;


    typedef VertexTpl<VertexUint, LABEL> Vertex;
    typedef UedgeTpl<UedgeUint, LABEL> Uedge;
    typedef DedgeTpl<UedgeUint, LABEL> Dedge;
    
    VertexMap vtx2info;
    UedgeMap uedge2info;
    GraphInfoType graph_info;
    
    // 0 for no limits; 
    // since time/space depences maxV/maxE not V/E
    // if performed lots of deletions, 
    ///   when finish construction, we may create a new one at best.
    BasicGraph(VertexSize maxV=0, UedgeSize maxE=0);
    VertexSize get_maxV()const;
    UedgeSize get_maxE()const;
    void set_maxV(VertexSize maxV);
    void set_maxE(UedgeSize maxE);
    Vertex new_vertex();
    Uedge new_edge(Vertex u, Vertex v, bool is_directed);
    Vertex del_vertex(Vertex v); // return which be deleted; data swapped
    Uedge del_uedge(Uedge uedge);
    void pack(); // all vertices and edges are relabelled!!!!!!!! TAKE CARE!
    void swap(BasicGraph& other)throw();
    
    
        
    VertexColor& operator[](Vertex v); // == color
    UedgeWeight& operator[](Uedge uedge); // == weight
    usr_data_type& operator[](void); // == get_usr_data
    const VertexColor& operator[](Vertex v)const; // == color
    const UedgeWeight& operator[](Uedge uedge)const; // == weight
    const usr_data_type& operator[](void)const; // == get_usr_data
    
    VertexColor& color(Vertex v);
    UedgeWeight& weight(Uedge uedge);
    usr_data_type& get_usr_data();
    const VertexColor& color(Vertex v)const;
    const UedgeWeight& weight(Uedge uedge)const;
    const usr_data_type& get_usr_data()const;
    
    // iterator
    // valid but not complete if new_*() calls
    // not valid if del_*() or pack() calls
    VertexRange vertices()const;
    UedgeRange uedges()const;
    DedgeRange dedges(Vertex v)const; // == incident_dedges
    DedgeRange incident_dedges(Vertex v)const;
    
    
    
    
    // globals
    VertexSize order()const; // prime
    VertexSize num_vertices()const; // == order()
    UedgeSize num_uedges()const; // not num_undirected_uedges() // prime
    DedgeSize num_dedges()const; // not num_directed_uedges()
    UedgeSize num_undirected_uedges()const;
    UedgeSize num_directed_uedges()const; // prime
    UedgeSize num_loops()const; // prime
    UedgeSize num_undirected_loops()const;
    UedgeSize num_directed_loops()const; // prime
    bool is_undirected_graph()const;
    bool is_pure_directed_graph()const;
    bool empty()const;
    bool contains(Vertex v)const;
    bool contains(Uedge u)const;
    bool contains(Dedge d)const;
    
    
    // each vertex
    DedgeSize degree(Vertex v)const; // == num_dedges // prime
    DedgeSize in_degree(Vertex v)const; // == num_in_dedges // prime
    DedgeSize out_degree(Vertex v)const; // == num_out_dedges // prime
    
    UedgeSize num_uedges(Vertex v)const; // not num_undirected_uedges
    DedgeSize num_dedges(Vertex v)const; // not num_directed_dedges
    DedgeSize num_in_dedges(Vertex v)const;
    DedgeSize num_out_dedges(Vertex v)const;
    
    UedgeSize num_undirected_uedges(Vertex v)const;
    DedgeSize num_undirected_dedges(Vertex v)const; // == num_undirected_uedges+num_undirected_loops
    // NO: DedgeSize num_undirected_in_dedges(Vertex v)const;
    // NO: DedgeSize num_undirected_out_dedges(Vertex v)const;
    UedgeSize num_directed_uedges(Vertex v)const;
    DedgeSize num_directed_dedges(Vertex v)const; // == num_directed_uedges+num_directed_loops
    DedgeSize num_directed_in_dedges(Vertex v)const;
    DedgeSize num_directed_out_dedges(Vertex v)const;
    UedgeSize num_loops(Vertex v)const; // prime
    UedgeSize num_undirected_loops(Vertex v)const;
    UedgeSize num_directed_loops(Vertex v)const; // prime
    
    
    // each edge
    Dedge to_dedge(Uedge uedge)const;
    Dedge flip(Dedge dedge)const;
    bool is_same(Dedge dedge, Uedge uedge)const;
    Uedge normal(Dedge dedge)const; // to_uedge may confuse...
    Vertex head(Dedge dedge)const;
    Vertex tail(Dedge dedge)const;
    

    

};


// VertexMap/UedgeMap are subclass of GraphUintMap or act as it.
struct GraphUintMap<UintT, InfoT, SizeT>
{
    
    typedef SizeT size_type;
    typedef UintT key_type;
    typedef InfoT value_type;
    typedef ... const_key_range_type;
    typedef ... const_value_range_type;
    typedef ... value_range_type;
    typedef ... const_iterator;
    typedef ... iterator;
    typedef key_type location_type;
    
    struct Rollback{
        Rollback(GraphUintMap* m, location_type loc_):p(m), loc(loc_){}
        Rollback(Rollback& other):p(other.p), loc(other.loc){other.clear();}
        void clear(){p=nullptr;}
        ~Rollback(){if (p)rollback(*p);} // rollback if not cleared or moved
    private:
        Rollback& operator==(Rollback& other); // not such function
        void rollback(GraphUintMap& m){m.pop(loc);}
        GraphUintMap* p; location_type loc;
    };
    
    
    // if max_size == 0, then acts as max_size == inf
    GraphUintMap(size_type max_size = 0);
    void set_max_size(size_type max_size); // throw if size() > max_size
    size_type get_max_size()const;
    size_type size()const;
    operator bool()const;
    bool full()const;
    void swap(GraphUintMap& other)throw();
    
    key_type get_last_key()const;
    const_key_range_type keys()const;
    
    const_value_range_type values()const;
    value_range_type values();
    
    bool contains(key_type key)const;
    const value_type& operator[](key_type key)const; // throw if not contains()
    value_type& operator[](key_type key);
    
    // all locations should keep valid after 
    //    push_back/pop_back/move_to_end/swap_values
    //    except the last location when poplast
    location_type push(const value_type& val);
    void pop(location_type key); // throw if key not popable
    bool popable(location_type key)const throw();
    location_type move_to_end(location_type key); // popable(return_loc) should be true.
    void swap_values(location_type loc1, location_type loc2)throw();
    
    
};


struct VertexInfo<DedgeListT, VertexColor>
{
    typedef VertexColor color_type;
    typedef DedgeListT DedgeList;
    
    // incident dedges
    DedgeList in_dedges;
    DedgeList out_dedges;
    DedgeList::size_type degree; // == in_degree + out_degree - undirected_degree;
    DedgeList::size_type num_directed_loops;
    DedgeList::size_type num_loops;

    
    VertexColor color; // or nothing
    void swap(VertexInfo& other)throw();
};


struct DedgeList<DedgeUintT>
{
        
    typedef ... size_type;
    typedef ... value_type;
    typedef ... const_value_range_type;
    typedef ... value_range_type;
    typedef ... const_iterator;
    typedef ... iterator;
    
    // if using list, location_type can be iterator
    // if using vector, location_type should be size_type(index).
    typedef ... location_type; 
    
    DedgeList();
    size_type size()const;
    operator bool()const;
    void swap(DedgeList& other)throw();

    const_value_range_type values()const;
    value_range_type values();
        
    // all locations should keep valid after 
    //    push_back/pop_back/move_to_end/swap_values
    //    except the last location when poplast
    location_type push(const value_type& val);
    void pop(location_type key); // throw if key not popable
    bool popable(location_type key)const throw();
    location_type move_to_end(location_type key); // popable(return_loc) should be true.
    void swap_values(location_type loc1, location_type loc2)throw();
    
};

struct UedgeInfo<VertexUint, DedgeListLocationT, EdgeWeight>
{
    typedef EdgeWeight weight_type;
    typedef DedgeListLocationT LocationType;
    
    // incident vertices
    VertexUint head;
    VertexUint tail;
    LocationType head_loc;
    LocationType tail_loc;
    bool directed;

    EdgeWeight weight; // or nothing
    void swap(UedgeInfo& other)throw();
};

GraphInfo is subclass of 
struct GraphInfo<VertexSizeT, DedgeSizeT, InfoT>
{
    typedef InfoT usr_data_type;
    typedef VertexSizeT VertexSize;
    typedef DedgeSizeT DedgeSize;
    
    VertexSizeT num_vertices;
    //DedgeSizeT num_dedges; == 2*num_uedges
    DedgeSizeT num_uedges;
    DedgeSizeT num_loops;
    DedgeSizeT num_directed_loops;
    DedgeSizeT num_directed_edges;
    usr_data_type usr_data;
    void swap(GraphInfo& other)throw();
};

Vertex/Uedge/Dedge are subclass of 
struct GraphUint<UintT, LABEL>;
struct GraphUint<UintT, LABEL>:GraphUint<UintT, void>
{
    // should use GraphUint<UintT, void> as a public baseclass
    typedef UintT value_type;
    
};

struct GraphUint<UintT, void>
{
    // LABEL is used to distinguish diff graph objs.
    // each graph obj best to have its label...
    // LABEL will be ignored by all algorithm
    // it just serves as a 'static type' check
    // to avoid using vertex of graph A in graph B.
    // LABEL should not make this class different.
    // this class and its subclass should be POD.
    // they should be the same with those LABEL = void
    typedef UintT value_type;
    
    // POD explicit GraphUint(value_type u=0);
    value_type value()const;
    value_type& operator*();
    const value_type& operator*()const;
    //GraphUint& operator ++()const;
    bool operator ==()const;
    bool operator !=()const;
    void swap(GraphUint& other)throw();
    
};

struct UedgeTpl<UintT, LABEL>:GraphUint<UintT, LABEL>{};
struct DedgeTpl<UintT, LABEL>:GraphUint<UintT, LABEL>{};
struct VertexTpl<UintT, LABEL>:GraphUint<UintT, LABEL>{};


struct Range <IteratorT>
{
    typedef IteratorT iterator;
    typedef std::iterator_traits<iterator>::value_type value_type;
    
    iterator _begin, _end;
    
    Range(iterator begin, iterator end);
    operator bool()const;
    
    iterator begin()const; // const????
    iterator end()const;
    Range& operator++(); // prefix
    value_type& operator*()const;// const????
    void swap(Range& other)throw();
};


*/















namespace nn_graph{

// as base of Vertex/Uedge/Dedge
template <typename ValueT> struct ValueWrapper; 
template <typename UintT, typename LABEL> struct GraphUint;

template <typename UintT, typename LABEL> struct UedgeTpl;
template <typename UintT, typename LABEL> struct DedgeTpl;
template <typename UintT, typename LABEL> struct VertexTpl;

template <typename IteratorT> struct Range;
template <typename VertexSizeT, typename DedgeSizeT, typename UsrDataT> 
    struct GraphInfo;

template <typename VertexUint, typename DedgeListLocationT, typename EdgeWeight> 
    struct UedgeInfo;
template <typename DedgeUintT> struct DedgeList;
template <typename DedgeListT, typename VertexColor> struct VertexInfo;
template <typename UintT, typename InfoT, typename SizeT> struct GraphUintMap;
template <typename VertexMapT, typename UedgeMapT, 
    typename DedgeSizeT, typename UsrDataT, typename LABEL> 
    struct BasicGraph;



}//namespace nn_graph






























////////////////////////////////////////////////////////////////////
#include <algorithm> // swap
#include <cassert>
#include <vector>
#include <iosfwd> // istream/ostream
#include <string>
#include <utility>






namespace nn_graph{
using std::swap;

using namespace std;

template <typename ValueT> struct ValueWrapper
{
    typedef ValueT value_type;

    //ValueWrapper(){}
    //ValueWrapper(ValueWrapper const& other):_value(*other){}
    explicit ValueWrapper(value_type u):_value(u){}
    //ValueWrapper& operator =(ValueWrapper const& other){_value = other._value;return *this;}
    
    value_type& value(){return _value;}
    const value_type& value()const{return _value;}
    value_type& operator*(){return _value;}
    const value_type& operator*()const{return _value;}
    void swap(ValueWrapper& other)throw()
    {
        using std::swap;
        swap(_value, other._value);
    }
    
protected:
    value_type _value;
}; 

template <typename ValueT>
void swap(ValueWrapper<ValueT>& lhs, ValueWrapper<ValueT>& rhs)throw()
{
    lhs.swap(rhs);
}



template <typename UintT, typename LABEL>
struct GraphUint:ValueWrapper<UintT>
{
    explicit GraphUint(UintT u=0):ValueWrapper<UintT>(u){}
    bool operator ==(GraphUint const& other)const
        {return _value == other._value;}
    bool operator !=(GraphUint const& other)const
        {return !(*this == other);}
};


template <typename UintT>
struct UintPtr:GraphUint<UintT, void>
{
    typedef UintT value_type;
    typedef std::input_iterator_tag iterator_category;
    typedef int difference_type;
    typedef value_type* pointer; 
    typedef value_type& reference;

    
    UintPtr(UintT u=0):GraphUint<UintT, void>(u){}
    UintPtr& operator ++(){++_value; return *this;}
};


template <typename UintT>
struct ConstUintPtr:GraphUint<UintT, void>
{
    typedef UintT value_type;
    typedef std::input_iterator_tag iterator_category;
    typedef int difference_type;
    typedef value_type const* pointer; 
    typedef value_type const& reference;

    
    ConstUintPtr(UintT u=0):GraphUint<UintT, void>(u){cerr<<"ConstUintPtr"<<u<<endl;}
    ConstUintPtr& operator ++(){++_value; return *this;}
    reference operator *()const{return this->GraphUint<UintT, void>::operator*();}
    reference operator *(){return **(ConstUintPtr const*)this;}
};
template <typename UintT, typename LABEL>
struct UedgeTpl:GraphUint<UintT, LABEL>
    {UedgeTpl(UintT u):GraphUint<UintT, LABEL>(u){};};
template <typename UintT, typename LABEL>
struct DedgeTpl:GraphUint<UintT, LABEL>
    {DedgeTpl(UintT u):GraphUint<UintT, LABEL>(u){};};
template <typename UintT, typename LABEL>
struct VertexTpl:GraphUint<UintT, LABEL>
    {VertexTpl(UintT u):GraphUint<UintT, LABEL>(u){};};


template <typename OutputT, typename UnderlyRange>
struct ConstConvertRange
{
    typedef OutputT value_type;
    typedef OutputT const reference;
    
    ConstConvertRange(UnderlyRange range):_range(range){}
    ConstConvertRange(){}
    ConstConvertRange(ConstConvertRange const& other):_range(other._range){}
    operator bool()const{return _range;}
    
    bool operator ==(ConstConvertRange const& other)const
        {return _range == other._range;}
    bool operator !=(ConstConvertRange const& other)const
        {return !(*this == other);}
    
    ConstConvertRange& operator++(){++_range; return *this;} // prefix
    reference operator*()const{return OutputT(*_range);}// const????
    void swap(ConstConvertRange& other)throw()
        {swap(_range, other._range);
        }
        
private:
    UnderlyRange _range;
};



template <typename IteratorT>
//, typename DerefT = typename std::iterator_traits<iterator>::value_type> 
struct Range
{
    typedef IteratorT iterator;
    typedef typename std::iterator_traits<iterator>::value_type value_type;
    typedef typename std::iterator_traits<iterator>::reference reference;
    
    Range(iterator begin, iterator end):_begin(begin), _end(end){}
    Range(Range const& other):_begin(other._begin), _end(other._end){}
    operator bool()const{return _begin != _end;}
    Range& operator =(Range const& other){_begin = other._begin; _end=other._end;}
    
    iterator begin()const{return _begin;} // const????
    iterator end()const{return _end;}
    Range& operator++(){++_begin; return *this;} // prefix
    reference operator*()const{return *_begin;}// const????
    void swap(Range& other)throw()
        {swap(_begin, other._begin); swap(_end, other._end);
        }
    
private:
    iterator _begin, _end;
};
/*
template <typename IteratorT> struct Range:RangeBase<IteratorT>
{
    Range(iterator begin, iterator end):RangeBase<IteratorT>(begin, end){}
    Range& operator++(){this->RangeBase<IteratorT>::operater++(); return *this;} // prefix
    value_type& operator*()const{return *begin();}
};
template <typename IteratorT> struct ConstRange:RangeBase<IteratorT>
{
    ConstRange(iterator begin, iterator end):RangeBase<IteratorT>(begin, end){}
    ConstRange& operator++(){this->RangeBase<IteratorT>::operater++(); return *this;} // prefix
    value_type const& operator*()const{return *begin();}
};*/

template <typename VertexSizeT, typename DedgeSizeT, typename UsrDataT> 
struct GraphInfo
{
    typedef UsrDataT usr_data_type;
    typedef VertexSizeT VertexSize;
    typedef DedgeSizeT DedgeSize;
    
    VertexSizeT num_vertices;
    //DedgeSizeT num_dedges; == 2*num_uedges
    DedgeSizeT num_uedges;
    DedgeSizeT num_loops;
    DedgeSizeT num_directed_loops;
    DedgeSizeT num_directed_edges;
    usr_data_type usr_data;
    void swap(GraphInfo& other)throw()
        {swap(num_vertices, other.num_vertices); 
        swap(num_uedges, other.num_uedges);
        swap(num_loops, other.num_loops); 
        swap(num_directed_loops, other.num_directed_loops);
        swap(num_directed_edges, other.num_directed_edges); 
        swap(usr_data, other.usr_data);
        }
};

template <typename VertexUint, typename DedgeListLocationT, typename EdgeWeight> 
struct UedgeInfo
{
    typedef EdgeWeight weight_type;
    typedef DedgeListLocationT LocationType;
    
    // incident vertices
    VertexUint head;
    VertexUint tail;
    LocationType head_loc;
    LocationType tail_loc;
    bool directed;

    EdgeWeight weight; // or nothing
    
    void swap(UedgeInfo& other)throw()
        {swap(head, other.head); 
        swap(tail, other.tail);
        swap(head_loc, other.head_loc); 
        swap(tail_loc, other.tail_loc);
        swap(directed, other.directed); 
        swap(weight, other.weight);
        }

};




template<typename T>
    struct RollbackPop{
        typedef typename T::location_type location_type;
        RollbackPop():p(nullptr){}
        RollbackPop(T* m, location_type loc_):p(m), loc(loc_){}
        RollbackPop(RollbackPop& other):p(other.p), loc(other.loc){other.clear();}
        void clear()throw(){p=nullptr;}
        void set(T* m, location_type loc_)
            {if (p) throw "set without clear"; p=m; loc=loc_;}
        ~RollbackPop()throw(){if (p)rollback(*p);}// rollback if not cleared or moved
    private:
        RollbackPop& operator==(RollbackPop& other); // not such function
        void rollback(T& m)throw(){m.pop(loc);}
        T* p; location_type loc;
    };

template<typename T>
    struct RollbackSwap{
        typedef typename T::location_type location_type;

        RollbackSwap():p(nullptr){}
        RollbackSwap(T* m, 
            location_type loc1_, location_type loc2_)
            :p(m), loc1(loc1_), loc2(loc2_){}
        RollbackSwap(RollbackPop& other)
            :p(other.p), loc1(other.loc1), loc2(other.loc2){other.clear();}
        void clear()throw(){p=nullptr;}
        void set(T* m, location_type loc1_, location_type loc2_)
            {if (p) throw "set without clear"; p=m; loc1=loc1_; loc2=loc2_;}
        ~RollbackSwap()throw(){if (p)rollback(*p);}// rollback if not cleared or moved
    private:
        RollbackSwap& operator==(RollbackSwap& other); // not such function
        void rollback(T& m)throw(){m.swap_values(loc1, loc2);}
        T* p; location_type loc1, loc2;
    };






template <typename DedgeUintT> struct DedgeList
{
    typedef std::vector<DedgeUintT> _UnderlyT;
    typedef typename _UnderlyT::size_type size_type;
    typedef typename _UnderlyT::value_type value_type;
    typedef typename _UnderlyT::const_iterator const_iterator;
    typedef typename _UnderlyT::iterator iterator;
    typedef Range<const_iterator> const_value_range_type;
    typedef Range<iterator> value_range_type;
    
    // if using list, location_type can be iterator
    // if using vector, location_type should be size_type(index).
    typedef size_type location_type; 
    
        
    typedef RollbackPop<DedgeList> RollbackPopType;
    typedef RollbackSwap<DedgeList> RollbackSwapType;
    
    DedgeList(){}
    size_type size()const{return _underly.size();}
    operator bool()const{return _underly;}
    location_type get_popable_location()const
        {if (! size()) throw "no key in empty map"; 
        return size()-1;}
    value_type& location2value(location_type loc){return _underly[loc];}
    value_type const& location2value(location_type loc)const{return _underly[loc];}
    
    const_value_range_type values()const
        {return const_value_range_type(_underly.begin(), _underly.end());}
    value_range_type values()
        {return value_range_type(_underly.begin(), _underly.end());}
        
    // all locations should keep valid after 
    //    push_back/pop_back/move_to_end/swap_values
    //    except the last location when poplast
    location_type push(const value_type& val)
        {_underly.push_back(val); return _underly.size()-1;}
    void pop(location_type key) // throw if key not popable
        {if (popable(key)) throw "pop nonlast";
        _underly.pop_back();}
    bool popable(location_type key)const throw(){return key == _underly.size()-1;}
    location_type move_to_end(location_type key) // popable(return_loc) should be true.
        {location_type last = _underly.size()-1;
        if (key != last) swap_values(key, last);
        assert(popable(last));
        return last;
        }
    void swap_values(location_type loc1, location_type loc2)throw()
    {
        swap(_underly[loc1], _underly[loc2]);
    }

    
    void swap(DedgeList& other)throw()
        {swap(_underly, other._underly);
        }
protected:
    _UnderlyT _underly;
};



template <typename DedgeListT, typename VertexColor> struct VertexInfo
{
    typedef VertexColor color_type;
    typedef DedgeListT DedgeList;
    
    // incident dedges
    DedgeList in_dedges;
    DedgeList out_dedges;
    DedgeList inout_dedges; // hence undirected
    typename DedgeList::size_type degree; // == in_degree + out_degree - undirected_degree;
    typename DedgeList::size_type num_directed_loops;
    typename DedgeList::size_type num_loops;

    
    VertexColor color; // or nothing
    

    void swap(VertexInfo& other)throw()
        {swap(in_dedges, other.in_dedges);
        swap(out_dedges, other.out_dedges);
        swap(degree, other.degree);
        swap(num_directed_loops, other.num_directed_loops);
        swap(num_loops, other.num_loops);
        }
};

template <typename UintT, typename InfoT, typename SizeT> 
struct GraphUintMap
{
    typedef std::vector<InfoT> _UnderlyT;
    //typedef SizeT size_type;
    //typedef UintT key_type;
    typedef typename _UnderlyT::size_type size_type;
    typedef typename _UnderlyT::size_type key_type;
    typedef InfoT value_type;
    typedef typename _UnderlyT::const_iterator const_iterator;
    typedef typename _UnderlyT::iterator iterator;
    typedef key_type location_type;
    typedef Range<ConstUintPtr<UintT> > const_key_range_type;
    typedef Range<const_iterator> const_value_range_type;
    typedef Range<iterator> value_range_type;
    
        
    typedef RollbackPop<GraphUintMap> RollbackPopType;
    typedef RollbackSwap<GraphUintMap> RollbackSwapType;
    
    
    // if max_size == 0, then acts as max_size == inf
    GraphUintMap(size_type max_size = 0):_max(max_size), _underly(){}
    void set_max_size(size_type max_size) // throw if size() > max_size
    {
        if (size() > max_size) throw "size() > max_size";
        _max = max_size;
    }
    size_type get_max_size()const{return _max;}
    size_type size()const{return _underly.size();}
    operator bool()const{return _underly;}
    bool full()const{return _max && size() == _max;}
    
    location_type get_popable_location()const
        {if (! size()) throw "no key in empty map"; 
        return size()-1;}
    value_type& location2value(location_type loc){return (*this)[loc];}
    value_type const& location2value(location_type loc)const{return (*this)[loc];}
    const_key_range_type keys()const
        {const_key_range_type result = const_key_range_type(0, size());
        cerr << "keys()" << *result << endl;
        return result;
        }
    
    const_value_range_type values()const
        {return const_value_range_type(_underly.begin(), _underly.end());}
    value_range_type values()
        {return value_range_type(_underly.begin(), _underly.end());}
    
    bool contains(key_type key)const{return key >= 0 && key < size();}
    const value_type& operator[](key_type key)const // throw if not contains()
        {if (! contains(key)) throw "no such key";
        return _underly[key];}
    value_type& operator[](key_type key)
        {if (! contains(key)) throw "no such key";
        return _underly[key];}
    
    // all locations should keep valid after 
    //    push_back/pop_back/move_to_end/swap_values
    //    except the last location when poplast
    location_type push(const value_type& val)
        {if (full()) throw "push while max size";
        _underly.push_back(val);
        return get_popable_location();}
    void pop(location_type key) // throw if key not popable
        {if (! popable(key)) throw "pop nonlast";
        _underly.pop_back();}
    bool popable(location_type key)const throw(){return key == get_popable_location();}
    location_type move_to_end(location_type key) // popable(return_loc) should be true.
        {location_type last = get_popable_location();
        if (key != last) swap_values(key, last);
        assert(popable(last));
        return last;
        }
    void swap_values(location_type loc1, location_type loc2)throw()
    {
        swap(_underly[loc1], _underly[loc2]);
    }
    
    void swap(GraphUintMap& other)throw()
        {swap(_max, other._max);
        swap(_underly, other._underly);
        }
private:
    _UnderlyT _underly;
    size_type _max;
};




template <typename VertexMapT, typename UedgeMapT, 
    typename DedgeSizeT, typename UsrDataT, typename LABEL> 
    struct BasicGraph

{
    typedef VertexMapT VertexMap;
    typedef UedgeMapT UedgeMap;
    typedef UsrDataT usr_data_type;
    typedef DedgeSizeT DedgeSize;
    
    typedef typename VertexMap::value_type VertexInfo;
    typedef typename VertexMap::size_type VertexSize; // i.e. unsigned short
    typedef typename VertexMap::key_type VertexUint;  // i.e. unsigned char
    
    typedef typename UedgeMap::value_type UedgeInfo;
    typedef typename UedgeMap::size_type UedgeSize;
    typedef typename UedgeMap::key_type UedgeUint;
    
    
    typedef typename VertexInfo::DedgeList DedgeList;
    typedef typename VertexInfo::color_type VertexColor;
    typedef typename UedgeInfo::weight_type UedgeWeight;

    typedef GraphInfo<VertexSize, DedgeSize, UsrDataT> GraphInfoType;


    typedef VertexTpl<VertexUint, LABEL> Vertex;
    typedef UedgeTpl<UedgeUint, LABEL> Uedge;
    typedef DedgeTpl<UedgeUint, LABEL> Dedge;
    
    typedef ConstConvertRange<Vertex, typename VertexMap::const_key_range_type> VertexRange;
    typedef ConstConvertRange<Uedge, typename UedgeMap::const_key_range_type> UedgeRange;
    typedef ConstConvertRange<Dedge, typename DedgeList::const_value_range_type> DedgeRange;
private:
    VertexMap vtx2info;
    UedgeMap uedge2info;
    GraphInfoType graph_info;
public:
    // 0 for no limits; 
    // since time/space depences maxV/maxE not V/E
    // if performed lots of deletions, 
    ///   when finish construction, we may create a new one at best.
    BasicGraph(VertexSize maxV=0, UedgeSize maxE=0)
        :vtx2info(maxV), uedge2info(maxE), graph_info(){}
    VertexSize get_maxV()const{return vtx2info.get_max_size();}
    UedgeSize get_maxE()const{return uedge2info.get_max_size();}
    void set_maxV(VertexSize maxV){vtx2info.set_max_size(maxV);}
    void set_maxE(UedgeSize maxE){uedge2info.set_max_size(maxE);}
    Vertex new_vertex()
        {++graph_info.num_vertices; 
        return Vertex(vtx2info.push(VertexInfo()));}
    

private:
    void _new_edge__update(Vertex u, Vertex v, UedgeInfo const& edge_info)throw()
    {
        VertexInfo& head_info = _info(u);
        VertexInfo& tail_info = _info(v);
        if (edge_info.directed){
            if (u == v) ++head_info.num_directed_loops;
        }
        if (u==v) ++head_info.num_loops;
        
        ++head_info.degree;
        ++tail_info.degree;
        
        // globals
        if (edge_info.directed){
            if (u == v) ++graph_info.num_directed_loops;
            ++graph_info.num_directed_edges;
        }
        if (u==v) ++graph_info.num_loops;
        
        ++graph_info.num_uedges;
        return;
    }
public:
    Uedge new_edge(Vertex u, Vertex v, bool is_directed)
        {
        if (! (contains(u) && contains(v))) throw "vertex not exists";
        
        Uedge result = Uedge(uedge2info.push(UedgeInfo()));
        typename UedgeMap::RollbackPopType _erb(&uedge2info, *result);
        
        
        UedgeInfo& info = _info(result);
        info.directed = is_directed;
        info.head = *u; info.tail = *v;
        
        typename DedgeList::RollbackPopType _urb, _vrb;
        VertexUint ue = *result, re = *flip(to_dedge(result));
        if (is_directed){
            info.head_loc = _info(u).out_dedges.push(ue);
            _urb.set(&_info(u).out_dedges, info.head_loc);
            info.tail_loc = _info(v).in_dedges.push(re);
            _vrb.set(&_info(v).in_dedges, info.tail_loc);
        }
        else{
            info.head_loc = _info(u).inout_dedges.push(ue);
            _urb.set(&_info(u).inout_dedges, info.head_loc);
            info.tail_loc = _info(v).inout_dedges.push(re);
            _vrb.set(&_info(v).inout_dedges, info.tail_loc);
        }
        
        _urb.clear(); _vrb.clear(); _erb.clear();
        _new_edge__update(u, v, info);
        return result;
        }
    Vertex del_vertex(Vertex v)
        {if (degree(v)) throw "delete vtx while degree > 0";
        
        Vertex r = vtx2info.move_to_end(*v);
        vtx2info.pop(*r);
        --graph_info.num_vertices; 
        return r;
        }
    Vertex del_vertex_and_its_edge(Vertex v)
        {del_all_incident_edge(v);
        return del_vertex(v);
        }
    void del_all_incident_edge(Vertex v)
    {
        VertexInfo info(_info(v));
        _clear_dedge_ls(info.in_dedges);
        _clear_dedge_ls(info.out_dedges);
        _clear_dedge_ls(info.inout_dedges);
    }

private:
    void _clear_dedge_ls(DedgeList& ls)
        {while(ls){
            Dedge d = ls.location2value(ls.get_popable_location());
            del_uedge(normal(d));
        }}
    DedgeList& _get_head_dedges(UedgeInfo const& edge_info, 
                                VertexInfo& head_info)
        {if (edge_info.directed) return head_info.out_dedges();
        return head_info.inout_dedges();}
    DedgeList& _get_tail_dedges(UedgeInfo const& edge_info, 
                                VertexInfo& tail_info)
        {if (edge_info.directed) return tail_info.in_dedges();
        return tail_info.inout_dedges();}
    void _move_uedge_to_end_and_pop(Uedge uedge)throw()
        {
        //UedgeMap::RollbackSwapType _erb(&uedge2info, *result, *uedge);
        
        // IF undirected loop...
        UedgeInfo& edge_info = uedge2info[result];
        VertexInfo& head_info = vtx2info[edge_info.head];
        DedgeList& head_ns = _get_head_dedges(edge_info, head_info);
        DedgeList::LocationType old_head_loc = edge_info.head_loc;
        DedgeList::LocationType new_head_loc = head_ns.move_to_end(old_head_loc);
        head_ns.pop(new_head_loc);
        //DedgeList::RollbackSwapType _hrb(&head_ns, old_head_loc, new_head_loc);
        
        VertexInfo& tail_info = vtx2info[edge_info.tail];
        DedgeList& tail_ns = _get_tail_dedges(edge_info, tail_info);
        DedgeList::LocationType old_tail_loc = edge_info.tail_loc;
        DedgeList::LocationType new_tail_loc = tail_ns.move_to_end(old_tail_loc);
        tail_ns.pop(new_tail_loc);
        //DedgeList::RollbackSwapType _trb(&tail_ns, old_tail_loc, new_tail_loc);
        
        //_hrb.clear(); _erb.clear();
        edge_info.head_loc = new_head_loc;
        edge_info.tail_loc = new_tail_loc;
        return;
        }
    void _del_uedge__update(UedgeInfo const& edge_info)throw()
    {
        VertexInfo& head_info = vtx2info[edge_info.head];
        VertexInfo& tail_info = vtx2info[edge_info.tail];
        if (edge_info.directed){
            if (u == v) --head_info.num_directed_loops;
        }
        if (u==v) --head_info.num_loops;
        
        --head_info.degree;
        --tail_info.degree;
        
        // globals
        if (edge_info.directed){
            if (u == v) --graph_info.num_directed_loops;
            --graph_info.num_directed_edges;
        }
        if (u==v) --graph_info.num_loops;
        
        --graph_info.num_uedges;
        return;
    }

public:
    Uedge del_uedge(Uedge uedge)
    {
        Uedge result = uedge2info.move_to_end(*uedge);
        _move_uedge_to_end_and_pop(result); // I don't know how to handle error so...
        _del_uedge__update(r);
        uedge2info.pop(result);
        return result;
    }
    void pack(){throw "not implemented";} // all vertices and edges are relabelled!!!!!!!! TAKE CARE!
    void swap(BasicGraph& other)throw()
        {swap(vtx2info, other.vtx2info);
        swap(uedge2info, other.uedge2info);
        swap(graph_info, other.graph_info);
        }
    
    
        
    VertexColor& operator[](Vertex v) // == color
        {return vtx2info[*v].color;}
    UedgeWeight& operator[](Uedge uedge) // == weight
        {return uedge2info[*uedge].weight;}
    //usr_data_type& operator[](void) // == get_usr_data{return get_usr_data();}
    const VertexColor& operator[](Vertex v)const // == color
        {return vtx2info[*v].color;}
    const UedgeWeight& operator[](Uedge uedge)const // == weight
        {return uedge2info[*uedge].weight;}
    //const usr_data_type& operator[](void)const // == get_usr_data{return get_usr_data();}
    
    VertexColor& color(Vertex v){return (*this)[v];}
    UedgeWeight& weight(Uedge uedge){return (*this)[uedge];}
    usr_data_type& get_usr_data(){return graph_info.usr_data;}
    const VertexColor& color(Vertex v)const{return (*this)[v];}
    const UedgeWeight& weight(Uedge uedge)const{return (*this)[uedge];}
    const usr_data_type& get_usr_data()const{returngraph_info.usr_data;}
    
    // iterator
    // valid but not complete if new_*() calls
    // not valid if del_*() or pack() calls
    VertexRange vertices()const{return vtx2info.keys();}
    UedgeRange uedges()const{return uedge2info.keys();}
    DedgeRange in_dedges(Vertex v)const{return vtx2info[*v].in_dedges.values();}
    DedgeRange out_dedges(Vertex v)const{return vtx2info[*v].out_dedges.values();}
    DedgeRange inout_dedges(Vertex v)const{return vtx2info[*v].inout_dedges.values();}
    //DedgeRange dedges(Vertex v)const; // == incident_dedges
    //DedgeRange incident_dedges(Vertex v)const;
    
    
    
    
    // globals
    VertexSize order()const // prime
        {return graph_info.num_vertices;}
    VertexSize num_vertices()const // == order()
        {return order();}
    UedgeSize num_uedges()const // not num_undirected_uedges() // prime
        {return graph_info.num_uedges;}
    DedgeSize num_dedges()const // not num_directed_uedges()
        {return 2*DedgeSize::value_type(num_uedges());}
    UedgeSize num_undirected_uedges()const
        {return num_uedges() - num_directed_uedges();}
    UedgeSize num_directed_uedges()const // prime
        {return graph_info.num_directed_uedges;}
    UedgeSize num_loops()const // prime
        {return graph_info.num_loops;}
    UedgeSize num_undirected_loops()const
        {return num_loops() - num_directed_loops();}
    UedgeSize num_directed_loops()const // prime
        {return graph_info.num_directed_loops;}
    bool is_undirected_graph()const {return !num_directed_uedges();}
    bool is_pure_directed_graph()const {return !num_undirected_uedges();}
    bool empty()const{return !order();}
    bool contains(Vertex v)const{return vtx2info.contains(*v);}
    bool contains(Uedge u)const{return uedge2info.contains(*u);}
    bool contains(Dedge d)const{return contains(normal(d));}
private:
    VertexInfo& _info(Vertex v){return vtx2info[*v];}
    UedgeInfo& _info(Uedge u){return uedge2info[*u];}
    VertexInfo const& _info(Vertex v)const{return vtx2info[*v];}
    UedgeInfo const& _info(Uedge u)const{return uedge2info[*u];}


public:
    // each vertex
    DedgeSize degree(Vertex v)const // == num_dedges
        {return num_dedges(v);}
    DedgeSize in_degree(Vertex v)const // != num_in_dedges
        {return num_undirected_dedges(v) + num_directed_in_dedges(v);}
    DedgeSize out_degree(Vertex v)const // != num_out_dedges
        {return num_undirected_dedges(v) + num_directed_out_dedges(v);}
    //NO: DedgeSize inout_degree(Vertex v)const;
    
    UedgeSize num_uedges(Vertex v)const // not num_undirected_uedges
        {return degree(v) - num_loops(v);}
    DedgeSize num_dedges(Vertex v)const // not num_directed_dedges
        {return num_undirected_dedges(v) + num_directed_uedges(v);}

    
    UedgeSize num_undirected_uedges(Vertex v)const
        {return num_undirected_dedges(v) - num_undirected_loops(v);}
    DedgeSize num_undirected_dedges(Vertex v)const  // prime // == num_undirected_uedges+num_undirected_loops
        {return _info(v).inout_dedges.size();}
    // NO: DedgeSize num_undirected_in_dedges(Vertex v)const;
    // NO: DedgeSize num_undirected_out_dedges(Vertex v)const;
    UedgeSize num_directed_uedges(Vertex v)const
        {return num_directed_dedges(v) - num_directed_loops(v);}
    DedgeSize num_directed_dedges(Vertex v)const // == num_directed_uedges+num_directed_loops
        {return num_directed_in_dedges(v) + num_directed_out_dedges(v);}
    DedgeSize num_directed_in_dedges(Vertex v)const // prime
        {return _info(v).in_dedges.size();}
    DedgeSize num_directed_out_dedges(Vertex v)const // prime
        {return _info(v).out_dedges.size();}
    UedgeSize num_loops(Vertex v)const // prime
        {return _info(v).num_loops;}
    UedgeSize num_undirected_loops(Vertex v)const
        {return num_loops(v) - num_directed_loops(v);}
    UedgeSize num_directed_loops(Vertex v)const // prime
        {return _info(v).num_directed_loops;}
    
    
    // each edge
    Dedge to_dedge(Uedge uedge)const{return Dedge::value_type(*uedge);}
    Dedge flip(Dedge dedge)const{return ~*dedge;}
    bool is_same(Dedge dedge, Uedge uedge)const{return dedge==to_dedge(uedge);}
    bool is_normal(Dedge dedge)const{return *dedge < *flip(dedge);}
    Uedge normal(Dedge dedge)const // to_uedge may confuse...
        {if (! is_normal(dedge)) dedge = flip(dedge);
        return Uedge::value_type(*dedge);}
    Vertex head(Dedge dedge)const
        {UedgeInfo const& info = _info(normal(dedge));
        return is_normal(dedge)? info.head : info.tail;}
    Vertex tail(Dedge dedge)const
        {UedgeInfo const& info = _info(normal(dedge));
        return is_normal(dedge)? info.tail : info.head;}
    bool is_directed(Dedge dedge)const{return is_directed(normal(dedge));}
    bool is_directed(Uedge uedge)const{return _info(uedge).directed;}
    

    

};



std::istream& skip_string(std::istream& istr, std::string const& s)
{
    std::vector<char> skip(s.size());
    if (! istr.read(&*skip.begin(), skip.size()))
        throw "bad format: !istream";
    if (std::string(skip.begin(), skip.end()) != s){
        //std::cerr << s.size() << '\t' << s << std::endl;
        throw "bad format: not match skip string";
    }
    return istr;
}

template <typename T> struct Reader
{
    static T read(std::istream& istr)
    {
        T t;
        istr >> t;
        if (! istr) throw "bad format or EOF";
        return t;
    }
};

template <typename T> struct Reader<std::vector<T> >
{
    
    static std::vector<T> read(std::istream& istr)
    {
        skip_string(istr, "[");
        std::vector<T> ls;
        
        if (']' != istr.peek())
            ls.push_back(Reader<T>::read(istr));
        while (istr) {
            if (']' == istr.peek()) break;
            //cerr << istr.peek() << endl;
            skip_string(istr, ",");
            ls.push_back(Reader<T>::read(istr));
        }
        skip_string(istr, "]");
        return ls;
    }
};

template <typename T, typename C> struct Reader<std::pair<T,C> >
{
    static std::pair<T,C> read(std::istream& istr)
    {
        skip_string(istr, "(");
        std::pair<T,C> pair;
        pair.first = Reader<T>::read(istr);
        skip_string(istr, ",");
        pair.second = Reader<C>::read(istr);
        
        skip_string(istr, ")");
        return pair;
    }
};



template <typename GraphT>
std::istream& operator >>(std::istream& istr, GraphT& g)
{
    using std::vector;
    using std::pair;
    typedef unsigned int VtxUint, VtxSize;
    // typedef vector<VtxUint> vtc_t;
    typedef pair<bool, pair<VtxUint, VtxUint> > edge_info_t;
    typedef vector<edge_info_t> edges_t;
    typedef pair<VtxSize, edges_t> g_info_t;
    typedef typename GraphT::Vertex Vertex;
    
    if (! g.empty()) throw "read while graph not empty";
    g_info_t g_info(Reader<g_info_t>::read(istr));
    cerr << "read!" << endl;
    if (! istr) throw "bad format";
    
    // g.clear();
    
    VtxSize x = g_info.first;
    cerr << x << endl;
    write(cerr, g_info);
    
    while (x --> 0) g.new_vertex();

    edges_t::iterator i = g_info.second.begin();
    for (; i != g_info.second.end(); ++i)
    {
        cerr << "size" << g_info.second.size() << endl;
        g.new_edge(Vertex(i->second.first), Vertex(i->second.second), i->first);
    }
    return istr;
    
}




















//////////////////////////
template <typename T> 
    std::ostream&  write(std::ostream& ostr, T const& t)
    {
        ostr << t;
        return ostr;
    }

template <typename T> 
    std::ostream&  write(std::ostream& ostr, std::vector<T> const& t)
    {
        ostr << "[";
        std::vector<T>::const_iterator i = t.begin();
        if (i != t.end()){
            write(ostr, *i++);
        }
        for (; i != t.end(); ++i){
            ostr << ',';
            write(ostr, *i);
        }
        ostr << "]";
        return ostr;
    }




template <typename T, typename C> 
    std::ostream&  write(std::ostream& ostr, std::pair<T,C> const& t)
    {
        ostr << '(';
        write(ostr, t.first);
        ostr << ',';
        write(ostr, t.second);
        ostr << ')';
        return ostr;
    }


template <typename VtxMap, typename UeMap, typename DedgeSizeT, 
            typename UsrDataT, typename LABEL>
    std::ostream&  operator <<(std::ostream& ostr, 
        BasicGraph<VtxMap, UeMap, DedgeSizeT, UsrDataT, LABEL> const& g)
{
    using std::vector;
    using std::pair;
    typedef unsigned int VtxUint, VtxSize;
    
    typedef BasicGraph<VtxMap, UeMap, DedgeSizeT, UsrDataT, LABEL> GraphT;
    // typedef vector<VtxUint> vtc_t;
    typedef pair<VtxUint, VtxUint> head_tail_t;
    typedef pair<bool, head_tail_t> edge_info_t;
    typedef vector<edge_info_t> edges_t;
    typedef pair<VtxSize, edges_t> g_info_t;
    typedef typename GraphT::Vertex Vertex;
    
    g_info_t g_info;
    g_info.first = g.order();
    cerr << "g.order()" << g.order() << g.num_uedges() << endl;
    edges_t& edges = g_info.second;
    edges.resize(g.num_uedges());
    cerr << "edges.size" << edges.size() << endl;
    for (GraphT::UedgeRange rng = g.uedges(); rng; ++rng){
        GraphT::Dedge dedge = g.to_dedge(*rng);
        GraphT::VertexUint u = **rng;
        if (u >= edges.size()) cerr << "u =" << u << endl;
        assert(u < edges.size());
        edges[u].first = g.is_directed(dedge);
        head_tail_t& head_tail = edges[u].second;
        head_tail.first = *g.head(dedge);
        head_tail.second = *g.tail(dedge);
    }
    
    write(ostr, g_info);
    return ostr;
    
}



}//namespace nn_graph





















































































