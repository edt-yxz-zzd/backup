/*
basic graph:
    multi 
    undirected/directed
    loop
    finite/infinite  // how easy to get nv/degree
    static/increase/stacklike/dynamic

not take care with embedding, no location information are visible.
    DFS may want to use embedding intead of just a graph.
    so DFS API should not support graph directly but be more abstract.



require two args: V/E to indicate the max num_vertices/num_edges
    using bucket-sort, so vertex/dedge are both unsigned int
    V/E may be larger than actual num_vertices/num_edges
    they are used in bucket-sort. larger value will slow down sort.
    why to use V/E? 
        when we require 'delete vertex/edge' op and 
        use some map like unorder_map/vector, 
        we have to take the max vertex number to use in sort.

delete vertex/edge:
    we may try to reduce the max vertex/edge number to fasten sort.
    so, the numberings are changing.
    user should take care of vertex color/edge weight 
    which is not the task of 'basic' graph.


I decide to implement two basic class undirected/directed
deletion should be stacklike, otherwise user should swap the number by himself.
contains(u, v)? O(degree)??? O(log(degree))??


sparse-graph:
    Map for vtx2info/uedge2info
        simply, we can use vector or file, we may use an extra map to map v/e name to v/e number.
        if use bounded integer, then we can use bucket-sort, but we may need to set a MAX size or renumber when deletion or limits the deletion as stack pop
        if use map/double-list-in-array/unorder_map/array-with-bookmark, we can remove vertex/edge without to rename others.
    List for incident_edges
        we can use list, vector, set, multiset, map... any container.
        if use multimap, then we can find/count/iter edges between two vertices faster.
        
dense-graph:
    MAX_N + vector<vector<bool> > adjacency_matrix
    + vector<bool> vertex_exists + order + num_edges?




VertexNumber/VertexSize
UedgeNumber/UedgeSize
DedgeNumber/DedgeSize
VertexColor
UedgeWeight
GraphUserData

DedgeListImplTag/VertexMapImplTag/UedgeMapImplTag/BasicGraphImplTag




//DedgeList<DedgeNumber, DedgeListImplTag>::Location
List<ValueT, ImplTag>::Location
//UedgeInfo<directed, allow_loops, VertexNumber, DedgeList<DedgeNumber, DedgeListImplTag>::Location, UedgeWeight>
//VertexInfo<directed, allow_loops, DedgeSize, DedgeList<DedgeNumber, DedgeListImplTag>, VertexColor>
//GraphInfo<directed, allow_loops, DedgeT, DedgeSize, GraphUsrDataT>
//VertexMap<VertexNumber, VertexInfo, VertexMapImplTag>::Location is VertexNumber
//UedgeMap<UedgeNumber, UedgeInfo, UedgeMapImplTag>::Location is UedgeNumber
NumberMap<NumberT, ValueT, ImplTag>::Location/Key is NumberT
ConstLocationIter<Location>
NumberWrapper<NumberT, ImplTag, LABEL>
IterConvertor<IterT, OutValueT>
Generator<OutValueT, ImplTag>
Reference<T>::type T& or void
ConstReference<T>::type const T& or void


typedef NumberWrapper<VertexNumber, IamVertexNumber_tag, GraphLABEL> Vertex;
typedef NumberWrapper<UedgeNumber, IamUedgeNumber_tag, GraphLABEL> Uedge;
typedef NumberWrapper<DedgeNumber, IamDedgeNumber_tag, GraphLABEL> Dedge;

typedef List<Dedge, DedgeListImplTag> DedgeList;
typedef typename DedgeList::location_type DedgeListLocation;
typedef VertexInfo_Internal<directed, allow_loops, DedgeSize, DedgeList, VertexColor> VertexInfoInternalType;
typedef UedgeInfo_Internal<directed, allow_loops, Vertex, DedgeListLocation, UedgeWeight> UedgeInfoInternalType;
typedef typename VertexInfoInternalType::extern_type VertexInfo;
typedef typename UedgeInfoInternalType::extern_type UedgeInfo;
typedef NumberMap<VertexNumber, VertexInfoInternalType, VertexMapImplTag> VertexMap;
typedef NumberMap<UedgeNumber, UedgeInfoInternalType, UedgeMapImplTag> UedgeMap;






BasicGraph<
    bool directed, bool allow_loops,
    VertexNumber, VertexSize,
    UedgeNumber, UedgeSize,
    DedgeNumber, DedgeSize,
    VertexColor,
    UedgeWeight,
    GraphUserData,
    List, DedgeListImplTag,
    NumberMap, VertexMapImplTag, UedgeMapImplTag,
    BasicGraphImplTag, GraphLABEL
>;


//ConstLocationIter<Location>
template <typename Location, typename DifferenceT=int>
struct ConstLocationIter
{
    typedef Location value_type;
    typedef DifferenceT difference_type;
    typedef value_type const& reference;
    typedef value_type const* pointer;
    typedef std::input_iterator_tag iterator_category;

    
    
    ConstLocationIter(Location);
    ConstLocationIter(ConstLocationIter&);
    ConstLocationIter& operator =(ConstLocationIter const&);
    bool operator ==(ConstLocationIter const&)const throw();
    bool operator !=(ConstLocationIter const&)const throw();
    
    
    ConstLocationIter& operator++();
    ConstLocationIter& operator++(int);
    
    reference operator *()const throw();
    pointer operator->()const throw();

private:
    ConstLocationIter(); // NO
};


//NumberWrapper<NumberT, ImplTag, LABEL>
template <typename NumberT, typename ImplTag, typename LABEL>
struct NumberWrapper
{
    NumberWrapper(NumberT const&);
    NumberWrapper(NumberWrapper const&);
    NumberWrapper& operator =(NumberWrapper const&);
    NumberT& operator *();
private:
    NumberWrapper();
};


//IterConvertor<IterT, OutValueT>
template <typename IterT, typename OutValueT>
struct IterConvertor;
template <typename OutValueT, typename ImplTag>
struct Generator
{
    //?? Generator(Generator&);
    operator bool()const;
    OutValueT next();
};

template<IterT, OutValueT>
struct Generator<OutValueT, IterConvertor<IterT, OutValueT> >
{
    Generator(IterT begin, IterT end);
    operator bool()const{return begin!=end;}
    OutValueT next(){return *begin++;}
    
};




//List<ValueT, ImplTag>
template <typename ValueT, typename ImplTag>
struct List
{
    typedef Location location_type;
    typedef ValueT value_type;
    typedef ValueT const* const_iterator;
    typedef ConstLocationIter<Location> const_location_iterator;
    
    List();
    List(List const&);
    List& =(List const&);
    void swap(List&)throw();
    
    size_type size()const throw();
    Location add(ValueT);
    //NO: void remove(Location);
    ValueT const& get(Location)const throw();
    Location swap_to_removable(Location)throw();
    Location swap_to_removable_and_remove(Location)throw();
    
    const_iterator begin()const throw();
    const_iterator end()const throw();
    const_location_iterator location_begin()const throw();
    const_location_iterator location_end()const throw();
    
    bool removable(Location)const throw();
    Location removable_location(Location)const throw();
    void clear()throw();
};


// NumberMap<NumberT, ValueT, ImplTag>
// we can use NumberMap to implement List
template <typename NumberT, typename ValueT, typename ImplTag>
struct NumberMap
{
    typedef NumberT Location;  // diff with List
    typedef Location location_type;
    typedef ValueT value_type;
    typedef ValueT* iterator;  // diff with List
    typedef ValueT const* const_iterator;
    typedef ConstLocationIter<Location> const_location_iterator;
    
    NumberMap();
    NumberMap(NumberMap const&);
    NumberMap& =(NumberMap const&);
    void swap(NumberMap&)throw();
    
    size_type size()const throw();
    Location add(ValueT); // yield a new key
    //NO: void remove(Location);
    ValueT& get(Location)throw(); // diff with List
    ValueT const& get(Location)const throw();
    Location swap_to_removable(Location)throw();
    Location swap_to_removable_and_remove(Location)throw();
    void swap_locations(Location, Location)throw();
    
    iterator begin()throw(); // diff with List
    iterator end()throw();   // diff with List
    const_iterator begin()const throw();
    const_iterator end()const throw();
    const_location_iterator location_begin()const throw();
    const_location_iterator location_end()const throw();
    
    bool removable(Location)const throw();
    Location removable_location(Location)const throw();
    void clear()throw();
};



template <typename DataT>
struct MaybeData
{
    //MaybeData(){}
    MaybeData(DataT const&);
    typename Reference<DataT>::type data();
    typename ConstReference<DataT>::type data()const;
private:
    DataT _data;
};
template <>
struct MaybeData<void>
{
    MaybeData(){}
    typename Reference<DataT>::type data(){}
    typename ConstReference<DataT>::type data()const{}
};





//UedgeInfo<directed, allow_loops, Vertex, DedgeListLocation, UedgeWeight>
template <bool directed, bool allow_loops, typename Vertex
          typename DedgeListLocation, 
          typename UedgeWeight>
struct UedgeInfo_External : MaybeData<UedgeWeight>
{
    Vertex head()const throw();
    Vertex tail()const throw();
    bool is_directed()const throw();
    bool is_loop()const throw();

protected:
    void swap(UedgeInfo& other)throw();
    Vertex _head, _tail;
    DedgeListLocation head_loc, tail_loc;
    
    UedgeInfo_External();
    UedgeInfo_External(UedgeInfo_External const&);
    ~UedgeInfo_External();
private:
    UedgeInfo_External operator =(UedgeInfo_External const&); // deleted
};
template <bool directed, bool allow_loops, typename Vertex
          typename DedgeListLocation, 
          typename UedgeWeight>
struct UedgeInfo_Internal : UedgeInfo_External<directed, allow_loops, Vertex, DedgeListLocation, UedgeWeight>
{
    typedef UedgeInfo_External<directed, allow_loops, Vertex, DedgeListLocation, UedgeWeight>
        extern_type;
    using extern_type::swap;
    using extern_type::_head;
    using extern_type::_tail;
    using extern_type::head_loc;
    using extern_type::tail_loc;
    // no _weight
};


template <bool directed, typename DedgeSize> struct NumDirectedOutgoingEdge;

template <typename DedgeSize>
struct NumDirectedOutgoingEdge<true, DedgeSize>
{
protected:
    NumDirectedOutgoingEdge(){}
    void add(bool is_uedge){_num_out_dedges += is_outgoing;}
    void remove(bool is_uedge){_num_out_dedges -= is_outgoing;}
    DedgeSize get_num_out_dedges(DedgeSize total_dedges)const{return _num_out_dedges;}
    DedgeSize get_num_in_dedges(DedgeSize total_dedges)const{return total_dedges - _num_out_dedges;}
private:
    DedgeSize _num_out_dedges;
};
template <typename DedgeSize>
struct NumDirectedOutgoingEdge<false, DedgeSize>
{
protected:
    NumDirectedOutgoingEdge(){}
    void add(bool is_uedge){}
    void remove(bool is_uedge){}
    DedgeSize get_num_out_dedges(DedgeSize total_dedges)const{return total_dedges;}
    DedgeSize get_num_in_dedges(DedgeSize total_dedges)const{return total_dedges;}

};

template <bool allow_loops, typename DedgeSize> struct NumLoops;
template <typename DedgeSize>
struct NumLoops<false, DedgeSize>
{
protected:
    NumLoops(){}
    void add(bool is_loop){}
    void remove(bool is_loop){}
    DedgeSize get_num_loops()const{return DedgeSize();}
};
template <typename DedgeSize>
struct NumLoops<true, DedgeSize>
{
protected:
    NumLoops(){}
    void add(bool is_loop){_num_loops += is_loops;}
    void remove(bool is_loop){_num_loops -= is_loops;}
    DedgeSize get_num_loops()const{return _num_loops;}
private:
    DedgeSize _num_loops;
};








// VertexInfo<directed, allow_loops, DedgeSize, DedgeList, VertexColor>
template <bool directed, bool allow_loops,
          typename DedgeSize, typename DedgeList, typename VertexColor>
struct VertexInfo_External  : MaybeData<VertexColor>, 
        NumDirectedOutgoingEdge<directed, DedgeSize>,
        NumLoops<allow_loops, DedgeSize> // for usr
{
    typedef DedgeList::location_type location_type;
    typedef DedgeList::value_type value_type;
    typedef value_type Dedge;

    
    //typedef NumberWrapper<DedgeNumber, IamDedgeNumber_tag, GraphLABEL> Dedge;
    typedef Generator<Dedge, IterConvertor<typename DedgeList::const_iterator, Dedge> > dedge_generator_type;

    
    DedgeSize degree()const throw();
    DedgeSize in_degree()const throw();
    DedgeSize out_degree()const throw();
    
    DedgeSize num_uedges()const throw(); // num_dedges-num_loops
    DedgeSize num_dedges()const throw();
    DedgeSize num_out_dedges()const throw();
    DedgeSize num_in_dedges()const throw();
    DedgeSize num_loops()const throw();
    
    DedgeSize num_uedges(bool directed)const throw();
    DedgeSize num_dedges(bool directed)const throw();
    DedgeSize num_out_dedges(bool directed)const throw();
    DedgeSize num_in_dedges(bool directed)const throw();
    DedgeSize num_loops(bool directed)const throw(); 

    
    dedge_generator_type dedges()const;

protected:
    location_type add(value_type dedge_number, bool is_uedge); // is_uedge==is_outgoing
    location_type swap_and_remove(location_type, bool is_uedge)throw();
    void swap(VertexInfo_External&)throw();
    
    VertexInfo_External();
    VertexInfo_External(VertexInfo_External const&);
    ~VertexInfo_External();
private:
    DedgeList _dedges; // undirected all inout/directed in/out
    // only digraph: DedgeSize _num_out_dedges;
    // only allow loops: DedgeSize _num_loops;
    VertexInfo_External& operator=(VertexInfo_External const&); // not exists
};

template <bool directed, bool allow_loops,
          typename DedgeSize, typename DedgeList, typename VertexColor>
struct VertexInfo_Internal : VertexInfo_External<directed, allow_loops, DedgeSize, DedgeList, VertexColor>
{
    typedef VertexInfo_External<directed, allow_loops, DedgeSize, DedgeList, VertexColor>
        extern_type;
    using extern_type::add;
    using extern_type::swap_and_remove;
    using extern_type::swap;
};










//GraphInfo<directed, allow_loops, VertexSize, DedgeSize, VertexT, UedgeT, VertexMap, UedgeMap, GraphUsrDataT>
template <bool directed, bool allow_loops,
          typename VertexSize, typename DedgeSize,  
          typename VertexT, typename UedgeT, 
          typename VertexMap, typename UedgeMap, 
          typename GraphUsrDataT>
struct GraphInfo_External  : MaybeData<GraphUsrDataT>, 
        NumDirectedOutgoingEdge<directed, DedgeSize>,
        NumLoops<allow_loops, DedgeSize> // for usr
{
    typedef UedgeT Uedge;
    typedef VertexT Vertex;
    typedef VertexMap::location_type vertex_location_type;
    typedef UedgeMap::location_type uedge_location_type;
    typedef Generator<Uedge, IterConvertor<typename UedgeMap::const_location_iterator, Uedge> > uedge_generator_type;
    typedef Generator<Vertex, IterConvertor<typename VertexMap::const_location_iterator, Vertex> > vertex_generator_type;
    

    DedgeSize num_uedges()const throw(); // num_dedges-num_loops
    DedgeSize num_dedges()const throw();
    DedgeSize num_out_dedges()const throw();
    DedgeSize num_in_dedges()const throw();
    DedgeSize num_loops()const throw();
    
    DedgeSize num_uedges(bool directed)const throw();
    DedgeSize num_dedges(bool directed)const throw();
    DedgeSize num_out_dedges(bool directed)const throw();
    DedgeSize num_in_dedges(bool directed)const throw();
    DedgeSize num_loops(bool directed)const throw(); 

    VertexSize num_vertices()const throw();
    
    vertex_generator_type vertices()const;
    uedge_generator_type uedges()const;

protected:
    void swap(GraphInfo_External&)throw();
    
    GraphInfo_External();
    GraphInfo_External(GraphInfo_External const&);
    ~GraphInfo_External();
    
    VertexMap vtx2info;
    UedgeMap uedge2info;
private:
    GraphInfo_External& operator=(GraphInfo_External const&); // not exists
};

template <typename BasicGraphTypeDef>
struct GraphInfo_Internal : 
    GraphInfo_External<
        BasicGraphTypeDef::directed, 
        BasicGraphTypeDef::allow_loops, 
        typename BasicGraphTypeDef::VertexSize, 
        typename BasicGraphTypeDef::DedgeSize, 
        typename BasicGraphTypeDef::Vertex, 
        typename BasicGraphTypeDef::Uedge, 
        typename BasicGraphTypeDef::VertexMap, 
        typename BasicGraphTypeDef::UedgeMap, 
        typename BasicGraphTypeDef::usrdata_type>
{
    typedef GraphInfo_External<
        BasicGraphTypeDef::directed, 
        BasicGraphTypeDef::allow_loops, 
        typename BasicGraphTypeDef::VertexSize, 
        typename BasicGraphTypeDef::DedgeSize, 
        typename BasicGraphTypeDef::Vertex, 
        typename BasicGraphTypeDef::Uedge, 
        typename BasicGraphTypeDef::VertexMap, 
        typename BasicGraphTypeDef::UedgeMap, 
        typename BasicGraphTypeDef::usrdata_type>
        extern_type;
    using extern_type::swap;
};













struct IamVertexNumber_tag{};
struct IamUedgeNumber_tag{};
struct IamDedgeNumber_tag{};

template <
    bool directed, bool allow_loops,
    typename VertexNumberT, typename VertexSizeT,
    //typename UedgeNumberT, typename UedgeSizeT,
    typename DedgeNumberT, typename DedgeSizeT,
    typename VertexColor,
    typename UedgeWeight,
    typename GraphUserData,
    template <typename ValueT, typename ImplTag>class List, typename DedgeListImplTag,
    template <typename NumberT, typename ValueT, typename ImplTag>class NumberMap, typename VertexMapImplTag, typename UedgeMapImplTag,
    typename BasicGraphImplTag, typename GraphLABEL
>
struct BasicGraphTypeDef
{
    static const bool directed = directed_, allow_loops = allow_loops_;
    typedef VertexNumberT VertexNumber;
    typedef VertexSizeT VertexSize;
    typedef DedgeNumberT DedgeNumber;
    typedef DedgeSizeT DedgeSize;
    
    typedef NumberWrapper<VertexNumber, IamVertexNumber_tag, GraphLABEL> Vertex;
    typedef NumberWrapper<UedgeNumber, IamUedgeNumber_tag, GraphLABEL> Uedge;
    typedef NumberWrapper<DedgeNumber, IamDedgeNumber_tag, GraphLABEL> Dedge;
    
    typedef List<Dedge, DedgeListImplTag> DedgeList;
    typedef typename DedgeList::location_type DedgeListLocation;
    typedef VertexInfo_Internal<directed, allow_loops, DedgeSize, DedgeList, VertexColor> VertexInfoInternalType;
    typedef UedgeInfo_Internal<directed, allow_loops, Vertex, DedgeListLocation, UedgeWeight> UedgeInfoInternalType;
    typedef typename VertexInfoInternalType::extern_type VertexInfo;
    typedef typename UedgeInfoInternalType::extern_type UedgeInfo;
    typedef NumberMap<VertexNumber, VertexInfoInternalType, VertexMapImplTag> VertexMap;
    typedef NumberMap<UedgeNumber, UedgeInfoInternalType, UedgeMapImplTag> UedgeMap;
    
    typedef GraphUserData usrdata_type;
    typedef typename ConstReference<usrdata_type>::type usrdata_const_reference;
    typedef typename Reference<usrdata_type>::type usrdata_reference;
    typedef VertexColor color_type;
    typedef typename ConstReference<color_type>::type color_const_reference;
    typedef typename Reference<color_type>::type color_reference;
    typedef UedgeWeight weight_type;
    typedef typename ConstReference<weight_type>::type weight_const_reference;
    typedef typename Reference<weight_type>::type weight_reference;
    
};


template <
    bool directed, bool allow_loops,
    typename VertexNumber, typename VertexSize,
    //typename UedgeNumber, typename UedgeSize,
    typename DedgeNumber, typename DedgeSize,
    typename VertexColor,
    typename UedgeWeight,
    typename GraphUserData,
    template <typename ValueT, typename ImplTag>class List, typename DedgeListImplTag,
    template <typename NumberT, typename ValueT, typename ImplTag>class NumberMap, typename VertexMapImplTag, typename UedgeMapImplTag,
    typename BasicGraphImplTag, typename GraphLABEL
>
struct BasicGraph : GraphInfo_Internal<
    BasicGraphTypeDef <directed, allow_loops,
        VertexNumber, VertexSize,
        DedgeNumber, DedgeSize,
        VertexColor, UedgeWeight, GraphUserData,
        List, DedgeListImplTag,
        NumberMap, VertexMapImplTag, UedgeMapImplTag,
        BasicGraphImplTag, GraphLABEL> >
{

    typedef NumberWrapper<VertexNumber, IamVertexNumber_tag, GraphLABEL> Vertex;
    typedef NumberWrapper<UedgeNumber, IamUedgeNumber_tag, GraphLABEL> Uedge;
    typedef NumberWrapper<DedgeNumber, IamDedgeNumber_tag, GraphLABEL> Dedge;
    
    typedef List<Dedge, DedgeListImplTag> DedgeList;
    typedef typename DedgeList::location_type DedgeListLocation;
    typedef VertexInfo_Internal<directed, allow_loops, DedgeSize, DedgeList, VertexColor> VertexInfoInternalType;
    typedef UedgeInfo_Internal<directed, allow_loops, Vertex, DedgeListLocation, UedgeWeight> UedgeInfoInternalType;
    typedef typename VertexInfoInternalType::extern_type VertexInfo;
    typedef typename UedgeInfoInternalType::extern_type UedgeInfo;
    typedef NumberMap<VertexNumber, VertexInfoInternalType, VertexMapImplTag> VertexMap;
    typedef NumberMap<UedgeNumber, UedgeInfoInternalType, UedgeMapImplTag> UedgeMap;
    
    typedef GraphUserData usrdata_type;
    typedef typename ConstReference<usrdata_type>::type usrdata_const_reference;
    typedef typename Reference<usrdata_type>::type usrdata_reference;
    typedef VertexColor color_type;
    typedef typename ConstReference<color_type>::type color_const_reference;
    typedef typename Reference<color_type>::type color_reference;
    typedef UedgeWeight weight_type;
    typedef typename ConstReference<weight_type>::type weight_const_reference;
    typedef typename Reference<weight_type>::type weight_reference;
    
    
    BasicGraph();
    BasicGraph(usrdata_const_reference usrdata);
    BasicGraph(BasicGraph const&);
    BasicGraph& operator=(BasicGraph&);
    void swap(BasicGraph&)throw();
    
    Vertex new_vertex();
    Uedge new_edge(Vertex u, Vertex v);
    Vertex swap_to_removable(Vertex)throw();
    void remove(Vertex);
    Uedge swap_to_removable(Uedge)throw();
    void remove(Uedge);
    //void clear(Vertex); to many uedge changed
    void clear()throw();
    
    VertexInfo const& operator[](Vertex)const;
    UedgeInfo const& operator[](Uedge)const;
    VertexInfo& operator[](Vertex);
    UedgeInfo& operator[](Uedge);
    
    Dedge to_dedge(Uedge uedge)const throw();
    Dedge flip(Dedge dedge)const throw();
    bool is_same(Dedge dedge, Uedge uedge)const throw();
    Uedge normal(Dedge dedge)const throw(); // to_uedge may confuse...
    Vertex head(Dedge dedge)const throw();
    Vertex tail(Dedge dedge)const throw();
    
    bool is_undirected_graph()const throw();
    bool is_directed_graph()const throw();
    bool empty()const throw();
    bool contains(Vertex v)const throw();
    bool contains(Uedge u)const throw();
    bool contains(Dedge d)const throw();
    VertexSize order()const;

};

































////////////////////////////////////////////////////////////////////////////

















namespace nn_graph{


std::istream& skip_string(std::istream& istr, std::string const& s)
{
    std::vector<char> skip(s.size());
    if (! istr.read(&*skip.begin(), skip.size()))
        throw "bad format: !istream";
    if (std::string(skip.begin(), skip.end()) != s){
        //std::cerr << s.size() << '\t' << s << std::endl;
        throw "bad format: not match skip string";
    }
    return istr;
}

template <typename T> struct Reader
{
    static T read(std::istream& istr)
    {
        T t;
        istr >> t;
        if (! istr) throw "bad format or EOF";
        return t;
    }
};

template <typename T> struct Reader<std::vector<T> >
{
    
    static std::vector<T> read(std::istream& istr)
    {
        skip_string(istr, "[");
        std::vector<T> ls;
        
        if (']' != istr.peek())
            ls.push_back(Reader<T>::read(istr));
        while (istr) {
            if (']' == istr.peek()) break;
            //cerr << istr.peek() << endl;
            skip_string(istr, ",");
            ls.push_back(Reader<T>::read(istr));
        }
        skip_string(istr, "]");
        return ls;
    }
};

template <typename T, typename C> struct Reader<std::pair<T,C> >
{
    static std::pair<T,C> read(std::istream& istr)
    {
        skip_string(istr, "(");
        std::pair<T,C> pair;
        pair.first = Reader<T>::read(istr);
        skip_string(istr, ",");
        pair.second = Reader<C>::read(istr);
        
        skip_string(istr, ")");
        return pair;
    }
};



template <typename GraphT>
std::istream& operator >>(std::istream& istr, GraphT& g)
{
    using std::vector;
    using std::pair;
    typedef unsigned int VtxUint, VtxSize;
    // typedef vector<VtxUint> vtc_t;
    typedef pair<bool, pair<VtxUint, VtxUint> > edge_info_t;
    typedef vector<edge_info_t> edges_t;
    typedef pair<VtxSize, edges_t> g_info_t;
    typedef typename GraphT::Vertex Vertex;
    
    if (! g.empty()) throw "read while graph not empty";
    g_info_t g_info(Reader<g_info_t>::read(istr));
    cerr << "read!" << endl;
    if (! istr) throw "bad format";
    
    // g.clear();
    
    VtxSize x = g_info.first;
    cerr << x << endl;
    write(cerr, g_info);
    
    while (x --> 0) g.new_vertex();

    edges_t::iterator i = g_info.second.begin();
    for (; i != g_info.second.end(); ++i)
    {
        cerr << "size" << g_info.second.size() << endl;
        g.new_edge(Vertex(i->second.first), Vertex(i->second.second), i->first);
    }
    return istr;
    
}




















//////////////////////////
template <typename T> 
    std::ostream&  write(std::ostream& ostr, T const& t)
    {
        ostr << t;
        return ostr;
    }

template <typename T> 
    std::ostream&  write(std::ostream& ostr, std::vector<T> const& t)
    {
        ostr << "[";
        std::vector<T>::const_iterator i = t.begin();
        if (i != t.end()){
            write(ostr, *i++);
        }
        for (; i != t.end(); ++i){
            ostr << ',';
            write(ostr, *i);
        }
        ostr << "]";
        return ostr;
    }




template <typename T, typename C> 
    std::ostream&  write(std::ostream& ostr, std::pair<T,C> const& t)
    {
        ostr << '(';
        write(ostr, t.first);
        ostr << ',';
        write(ostr, t.second);
        ostr << ')';
        return ostr;
    }


template <typename VtxMap, typename UeMap, typename DedgeSizeT, 
            typename UsrDataT, typename LABEL>
    std::ostream&  operator <<(std::ostream& ostr, 
        BasicGraph<VtxMap, UeMap, DedgeSizeT, UsrDataT, LABEL> const& g)
{
    using std::vector;
    using std::pair;
    typedef unsigned int VtxUint, VtxSize;
    
    typedef BasicGraph<VtxMap, UeMap, DedgeSizeT, UsrDataT, LABEL> GraphT;
    // typedef vector<VtxUint> vtc_t;
    typedef pair<VtxUint, VtxUint> head_tail_t;
    typedef pair<bool, head_tail_t> edge_info_t;
    typedef vector<edge_info_t> edges_t;
    typedef pair<VtxSize, edges_t> g_info_t;
    typedef typename GraphT::Vertex Vertex;
    
    g_info_t g_info;
    g_info.first = g.order();
    cerr << "g.order()" << g.order() << g.num_uedges() << endl;
    edges_t& edges = g_info.second;
    edges.resize(g.num_uedges());
    cerr << "edges.size" << edges.size() << endl;
    for (GraphT::UedgeRange rng = g.uedges(); rng; ++rng){
        GraphT::Dedge dedge = g.to_dedge(*rng);
        GraphT::VertexUint u = **rng;
        if (u >= edges.size()) cerr << "u =" << u << endl;
        assert(u < edges.size());
        edges[u].first = g.is_directed(dedge);
        head_tail_t& head_tail = edges[u].second;
        head_tail.first = *g.head(dedge);
        head_tail.second = *g.tail(dedge);
    }
    
    write(ostr, g_info);
    return ostr;
    
}



}//namespace nn_graph





















































































