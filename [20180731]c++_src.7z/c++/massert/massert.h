
#ifndef MASSERT_H
#define MASSERT_H
    #include "massert.h.impl"
#endif