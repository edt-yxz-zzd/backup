
/* 
    Contract Programming
    
    macros for errors that should never occur
    macros will be turned off if "-DNDEBUG" 
        ; the same as "assert"
*/



#include <assert.h> /* for assert ; NOTE : -DNDEBUG */

/* redefine require, ensure, check */
#undef require
#undef ensure
#undef check

#define require(expr) assert(expr)
#define ensure(expr) assert(expr)
#define check(expr) assert(expr)



