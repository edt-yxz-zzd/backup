#include "massert.h"

int main()
{
    massert_ex(true, "should not fire");
    massert_ex(false, "expect to fire");
    return 0;
}

