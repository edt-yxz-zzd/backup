
/*
    how to implement two static functions which depend on each other?
*/

#include <stdio.h>



static int funcA(int i);
static int funcB(int i)
{
    return funcA(--i);
}

static int funcA(int i)
{
    if (i > 0){
        return funcB(i);
    }
    
    puts("funcA return 0;");
    return 0;
}

int main(void)
{
    return funcB(3);
}




