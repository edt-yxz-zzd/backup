
/*
    how to implement two static functions which depend on each other?
*/

#include <iostream>
using namespace std;


#if 0
    // fail
    namespace{
        // using unnamed namespace
        
        extern int funcA(int i);
        #include "./two_static_funcs.cpp.funcB.impl"
    }
    #include "./two_static_funcs.cpp.funcA.impl"
#endif

#if 0
    // success
    namespace{
            // using unnamed namespace
            static int funcA(int i); 
            // why! I once thought C++ forbids declaring static functions!!
            #include "./two_static_funcs.cpp.funcB.impl"
            #include "./two_static_funcs.cpp.funcA.impl"
    }
#endif

static int funcA(int i);
        #include "./two_static_funcs.cpp.funcB.impl"
        #include "./two_static_funcs.cpp.funcA.impl"
int main(void)
{
    return funcB(3);
}




