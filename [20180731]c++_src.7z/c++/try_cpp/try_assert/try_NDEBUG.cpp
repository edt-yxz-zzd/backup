
#if NDEBUG==0
    #define OLD_NDEBUG NDEBUG
    #undef NDEBUG
    #define NDEBUG OLD_NDEBUG
    #if NDEBUG != 0
        #error "-DNDEBUG=0 but now not 0"
    #endif
#else
    #ifdef NDEBUG
        #error "should -DNDEBUG=0 for this .cpp"
    #endif
#endif

#ifdef NDEBUG
    #ifdef massert__OLD_NDEBUG
        #error "massert__OLD_NDEBUG has been defined"
    #endif
    
    #define massert__OLD_NDEBUG NDEBUG
    #undef NDEBUG
    #include <cassert>
    #define massert assert
    #define NDEBUG massert__OLD_NDEBUG
    #undef massert__OLD_NDEBUG
#else
    #include <cassert>
    #define massert assert

#endif

#define TO_STRING(x) #x

#include <cstdio>
#define NDEBUG
#include <cassert>
#define nassert assert

int main()
{
    // puts(TO_STRING(NDEBUG)); // always print "NDEBUG" instead of contents
    // puts(TO_STRING(OLD_NDEBUG));
    nassert(false);
    nassert(true);
    puts("pass nassert");
    
    massert(true);
    massert(false);
}