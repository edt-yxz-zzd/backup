
#include <stdio.h>

int main(int argn, char *argv[])
{
	while(argn --> 0) puts(*(argv++));
	return 0;
}
