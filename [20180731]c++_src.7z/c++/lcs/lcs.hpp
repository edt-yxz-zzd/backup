// Longest common subsequence problem
// Hirschberg's algorithm
#include <cassert>
#include <limits>       // std::numeric_limits
#include <deque>
#include <stack>
#include <iterator> // reverse_iterator prev next distance back_insert_iterator
#include <utility>      // std::swap C++11
#include <algorithm>    // std::find copy min // std::swap C++98
#include <stdexcept> 


template<typename BidirectionalIteratorType>
    std::reverse_iterator<BidirectionalIteratorType> make_reverse_iterator(BidirectionalIteratorType iter);
template<typename BidirectionalIteratorType>
    BidirectionalIteratorType make_reverse_iterator(std::reverse_iterator<BidirectionalIteratorType> iter);

template<typename InputIteratorTypeX, typename InputIteratorTypeY>
    bool is_subsequence_of(InputIteratorTypeX x_begin, InputIteratorTypeX x_end, InputIteratorTypeY y_begin, InputIteratorTypeY y_end);

template<typename ValueType, typename SizeType>
struct longest_common_subsequence_tpl
{
    struct Needleman_Wunsch_algorithm
    {
        typedef std::deque<SizeType> score_row_t;
        typedef std::deque<score_row_t> score_matrix_t;
        typedef std::stack<SizeType> indices_t;
        // enum class arrow : unsigned char {};
        enum arrow_mask : unsigned char {arrow_left_eq = 1, arrow_up_eq = 1<<1, arrow_upleft_inc = 1<<2};
        typedef unsigned char arrow_t;
        typedef std::deque<arrow_t> arrow_row_t;
        typedef std::deque<arrow_row_t> arrow_matrix_t;
        template<typename ForwardIteratorTypeX, typename ForwardIteratorTypeY>
            static score_row_t calc_last_score_row(ForwardIteratorTypeX x_begin, ForwardIteratorTypeX x_end, ForwardIteratorTypeY y_begin, ForwardIteratorTypeY y_end);
        template<typename ForwardIteratorTypeX, typename ForwardIteratorTypeY>
            static arrow_matrix_t calc_arrow_matrix(ForwardIteratorTypeX x_begin, ForwardIteratorTypeX x_end, ForwardIteratorTypeY y_begin, ForwardIteratorTypeY y_end);
        template<typename ForwardIteratorTypeX, typename ForwardIteratorTypeY>
            static score_matrix_t calc_score_matrix(ForwardIteratorTypeX x_begin, ForwardIteratorTypeX x_end, ForwardIteratorTypeY y_begin, ForwardIteratorTypeY y_end);
        template<typename ForwardIteratorTypeX, typename ForwardIteratorTypeY, typename OutputIteratorType>
            static SizeType find_one_lcs(ForwardIteratorTypeX x_begin, ForwardIteratorTypeX x_end, ForwardIteratorTypeY y_begin, ForwardIteratorTypeY y_end, OutputIteratorType out);
        template<typename ForwardIteratorTypeX, typename ForwardIteratorTypeY>
            static SizeType calc_length_of_lcs(ForwardIteratorTypeX x_begin, ForwardIteratorTypeX x_end, ForwardIteratorTypeY y_begin, ForwardIteratorTypeY y_end);
        template<typename InputIteratorType>
            static void check_input_size(InputIteratorType begin, InputIteratorType end);
        template<typename ForwardIteratorTypeZ, typename ForwardIteratorTypeX, typename ForwardIteratorTypeY>
            static bool is_lcs_of(ForwardIteratorTypeZ z_begin, ForwardIteratorTypeZ z_end, ForwardIteratorTypeX x_begin, ForwardIteratorTypeX x_end, ForwardIteratorTypeY y_begin, ForwardIteratorTypeY y_end);
    private:
        struct inner
        {
            template<typename T, typename LimitT>
            static inline void check(T size, LimitT const& limit = std::numeric_limits<LimitT>::max())
            {
                if (limit < 1 || limit-1 < size) 
                {
                    throw std::runtime_error("input size is too large!");
                }
            }
        };
    };

    struct Hirschberg_algorithm
    {
        template<typename BidirectionalIteratorTypeX, typename BidirectionalIteratorTypeY, typename OutputIteratorType>
            static SizeType find_one_lcs(BidirectionalIteratorTypeX x_begin, BidirectionalIteratorTypeX x_end, BidirectionalIteratorTypeY y_begin, BidirectionalIteratorTypeY y_end, OutputIteratorType out);
    };

    struct Eugene_Myers_algorithm
    {
        template<typename InputIteratorTypeX, typename InputIteratorTypeY>
            static void check_input_size(InputIteratorTypeX x_begin, InputIteratorTypeX x_end, InputIteratorTypeY y_begin, InputIteratorTypeY y_end);
        // L be the length of a longest common subsequence 
        // D = M+N-2*L be the length of a shortest edit script
        // assume D < limit
        struct greedy
        {
            template<typename ForwardIteratorType>
            struct indexed_iterator_t : public ForwardIteratorType
            {
                SizeType index;
                indexed_iterator_t() = default;
                indexed_iterator_t(ForwardIteratorType it, SizeType s)
                    :ForwardIteratorType(it), index(s){}
                bool before(indexed_iterator_t& other)const{return index < other.index;}
                indexed_iterator_t& operator++(){this->ForwardIteratorType::operator++(); ++index;}
                //bool operator==()
            };
            template<typename ForwardIteratorTypeX, typename ForwardIteratorTypeY>
            using frontier_t = std::deque<std::pair<indexed_iterator_t<ForwardIteratorTypeX>, ForwardIteratorTypeY> >;
            template<typename ForwardIteratorTypeX, typename ForwardIteratorTypeY>
                static SizeType calc_length_of_ses(frontier_t<ForwardIteratorTypeX, ForwardIteratorTypeY>& frontier, SizeType limit, ForwardIteratorTypeX x_begin, ForwardIteratorTypeX x_end, ForwardIteratorTypeY y_begin, ForwardIteratorTypeY y_end);
            template<typename BidirectionalIteratorTypeX, typename BidirectionalIteratorTypeY, typename OutputIteratorType>
                static SizeType find_one_lcs(BidirectionalIteratorTypeX x_begin, BidirectionalIteratorTypeX x_end, BidirectionalIteratorTypeY y_begin, BidirectionalIteratorTypeY y_end, OutputIteratorType out);
        private:
            struct inner
            {
                template<typename A, typename B>
                static inline auto make_index_pair(A a, SizeType ai, B b, SizeType bi)->std::pair<indexed_iterator_t<A>, indexed_iterator_t<B> >
                    {return std::make_pair(indexed_iterator_t<A>(a, ai), indexed_iterator_t<B>(b, bi));}
                template<typename A, typename B>
                static inline auto make_index_pair(A a, SizeType ai, B b)->std::pair<indexed_iterator_t<A>, B>
                    {return std::make_pair(indexed_iterator_t<A>(a, ai), b);}
                template<typename T>
                static inline bool no_match(T xy, T xy_end)
                    {return xy.second != xy_end.second && 
                            xy.first != xy_end.first;}
                template<typename T>
                static void go_further(T& xy, T xy_end)
                {
                    while (no_match(xy, xy_end) && *xy.first == *xy.second)
                    {
                        ++xy.first;
                        ++xy.second;
                    }
                }
            };
        };
        
        struct divide_and_conquer
        {
            template<typename BidirectionalIteratorTypeX, typename BidirectionalIteratorTypeY, typename OutputIteratorType>
                static SizeType find_one_lcs(BidirectionalIteratorTypeX x_begin, BidirectionalIteratorTypeX x_end, BidirectionalIteratorTypeY y_begin, BidirectionalIteratorTypeY y_end, OutputIteratorType out);
        private:
            template<typename BidirectionalIteratorTypeX, typename BidirectionalIteratorTypeY, typename OutputIteratorType>
            struct inner
            {
                template<typename ForwardIteratorTypeX, typename ForwardIteratorTypeY>
                static inline SizeType find_one_lcs_if_one_size_no_more_than_1(
                    ForwardIteratorTypeX x_begin, ForwardIteratorTypeX x_end, 
                    ForwardIteratorTypeY y_begin, ForwardIteratorTypeY y_end, 
                    OutputIteratorType out, SizeType x_size, SizeType y_size)
                {
                    if (y_size < x_size) return find_one_lcs_if_one_size_no_more_than_1(y_begin, y_end, x_begin, x_end, out, y_size, x_size);
                    assert(x_size < 2);
                    if (0 == x_size) return 0;
                    auto result_iter = std::find(y_begin, y_end, *x_begin);
                    if (result_iter != y_end)
                    {
                        std::copy(x_begin, x_end, out);
                        return 1;
                    }
                    else return 0;
                }
                template<typename ForwardIteratorTypeX, typename ForwardIteratorTypeY>
                static inline SizeType calc_len_lcs_if_one_size_no_more_than_1(
                    ForwardIteratorTypeX x_begin, ForwardIteratorTypeX x_end, 
                    ForwardIteratorTypeY y_begin, ForwardIteratorTypeY y_end, 
                    SizeType x_size, SizeType y_size)
                {
                    if (y_size < x_size) return calc_len_lcs_if_one_size_no_more_than_1(y_begin, y_end, x_begin, x_end, y_size, x_size);
                    assert(x_size < 2);
                    if (0 == x_size) return 0;
                    auto result_iter = std::find(y_begin, y_end, *x_begin);
                    if (result_iter != y_end) return 1;
                    else return 0;
                }
                template<typename ForwardIteratorTypeX, typename ForwardIteratorTypeY>
                static inline SizeType calc_len_ses_if_one_size_no_more_than_1(
                    ForwardIteratorTypeX x_begin, ForwardIteratorTypeX x_end, 
                    ForwardIteratorTypeY y_begin, ForwardIteratorTypeY y_end, 
                    SizeType x_size, SizeType y_size)
                {
                    return x_size + y_size - 2*calc_len_lcs_if_one_size_no_more_than_1(x_begin, x_end, y_begin, y_end, x_size, y_size);
                }
                
                
                template<typename ForwardIteratorTypeX, typename ForwardIteratorTypeY>
                static inline SizeType calc_len_ses(
                    ForwardIteratorTypeX x_begin, ForwardIteratorTypeX x_end, 
                    ForwardIteratorTypeY y_begin, ForwardIteratorTypeY y_end, 
                    SizeType x_size, SizeType y_size)
                {
                    if (x_size < 2 || y_size < 2)
                    {
                        return calc_len_ses_if_one_size_no_more_than_1(x_begin, x_end, y_begin, y_end, x_size, y_size);
                    }
                    SizeType const limit = SizeType(x_size) + SizeType(y_size) + 1;
                    decltype(inner::calc_frontier(limit, x_begin, x_end, y_begin, y_end)) tmp;
                    return greedy::calc_length_of_ses(
                        //std::move(decltype(inner::calc_frontier(limit, x_begin, x_end, y_begin, y_end))()), 
                        tmp,
                        limit, x_begin, x_end, y_begin, y_end);
                }
                struct tuple
                {
                    BidirectionalIteratorTypeX x_begin;
                    BidirectionalIteratorTypeX x_end;
                    BidirectionalIteratorTypeY y_begin;
                    BidirectionalIteratorTypeY y_end;
                    SizeType len_ses;
                    SizeType x_size;
                    SizeType y_size;
                };
                
                template<typename ForwardIteratorTypeX, typename ForwardIteratorTypeY>
                    static inline greedy::frontier_t<ForwardIteratorTypeX, ForwardIteratorTypeY>
                calc_frontier(SizeType const limit, ForwardIteratorTypeX x_begin, ForwardIteratorTypeX x_end, ForwardIteratorTypeY y_begin, ForwardIteratorTypeY y_end)
                {
                    decltype(calc_frontier(limit, x_begin, x_end, y_begin, y_end)) frontier;
                    greedy::calc_length_of_ses(frontier, limit, x_begin, x_end, y_begin, y_end);
                    return frontier;
                }
        
            };
        };
    };
};


//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
////////////////////////  inline   ///////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
template<typename BidirectionalIteratorType>
    inline std::reverse_iterator<BidirectionalIteratorType> 
make_reverse_iterator(BidirectionalIteratorType iter)
{
    return std::reverse_iterator<BidirectionalIteratorType>(iter);
}

template<typename BidirectionalIteratorType>
    inline BidirectionalIteratorType 
make_reverse_iterator(std::reverse_iterator<BidirectionalIteratorType> iter)
{
    return iter.base();
}



   
template<typename ValueType, typename SizeType>
    template<typename ForwardIteratorTypeX, typename ForwardIteratorTypeY>
    inline SizeType longest_common_subsequence_tpl<ValueType, SizeType>::Needleman_Wunsch_algorithm::
calc_length_of_lcs(ForwardIteratorTypeX x_begin, ForwardIteratorTypeX x_end, ForwardIteratorTypeY y_begin, ForwardIteratorTypeY y_end)
{
    return calc_last_score_row(x_begin, x_end, y_begin, y_end).back();
}

template<typename ValueType, typename SizeType>
    template<typename InputIteratorType>
    inline void longest_common_subsequence_tpl<ValueType, SizeType>::Needleman_Wunsch_algorithm::
check_input_size(InputIteratorType begin, InputIteratorType end)
{
    auto size = std::distance(begin, end);
    
    inner::check<decltype(size), typename score_row_t::size_type>(size);
    inner::check<decltype(size), typename score_matrix_t::size_type>(size);
    inner::check<decltype(size), typename arrow_row_t::size_type>(size);
    inner::check<decltype(size), typename arrow_matrix_t::size_type>(size);
}

template<typename ValueType, typename SizeType>
    template<typename ForwardIteratorTypeZ, typename ForwardIteratorTypeX, typename ForwardIteratorTypeY>
    inline bool longest_common_subsequence_tpl<ValueType, SizeType>::Needleman_Wunsch_algorithm::
is_lcs_of(ForwardIteratorTypeZ z_begin, ForwardIteratorTypeZ z_end, ForwardIteratorTypeX x_begin, ForwardIteratorTypeX x_end, ForwardIteratorTypeY y_begin, ForwardIteratorTypeY y_end)
    
{
    if (! is_subsequence_of(z_begin, z_end, x_begin, x_end)) return false;
    if (! is_subsequence_of(z_begin, z_end, y_begin, y_end)) return false;
    auto const z_size = std::distance(z_begin, z_end);
    auto const lcs_length = calc_length_of_lcs(x_begin, x_end, y_begin, y_end);
    return z_size == lcs_length;
}



//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
///////////////////////  template  ///////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////

template<typename InputIteratorTypeX, typename InputIteratorTypeY>
bool is_subsequence_of(InputIteratorTypeX x_begin, InputIteratorTypeX x_end, InputIteratorTypeY y_begin, InputIteratorTypeY y_end)
{
    auto x_size = std::distance(x_begin, x_end);
    auto y_size = std::distance(y_begin, y_end);
    for (; x_begin != x_end; ++x_begin, --x_size, ++y_begin, --y_size)
    {
        for (; y_size >= x_size; ++y_begin, --y_size)
        {
            if (*x_begin == *y_begin) break;
        }
        
        if (y_size < x_size) return false;
    }
    return true;
}



template<typename ValueType, typename SizeType>
    template<typename ForwardIteratorTypeX, typename ForwardIteratorTypeY>
    typename longest_common_subsequence_tpl<ValueType, SizeType>::Needleman_Wunsch_algorithm::score_row_t 
    longest_common_subsequence_tpl<ValueType, SizeType>::Needleman_Wunsch_algorithm::
calc_last_score_row(ForwardIteratorTypeX x_begin, ForwardIteratorTypeX x_end, ForwardIteratorTypeY y_begin, ForwardIteratorTypeY y_end)
{
    auto const y_size = std::distance(y_begin, y_end);
    score_row_t scores(y_size + 1, 0);
    for (auto x_iter = x_begin; x_iter != x_end; ++x_iter)
    {
        auto score_prev_iter = scores.begin();
        auto score_up_iter = std::next(score_prev_iter);
        SizeType score_upleft = 0;
        
        // prev_row   : .... score_upleft  score_up      ....
        // current_row: ...  score_prev    score_current 
        // scores = {0, current_row[0:score_current_index], prev_row[score_up_index:]}
        for (auto y_iter = y_begin; y_iter != y_end; ++y_iter, ++score_prev_iter, ++score_up_iter)
        {
            if (*x_iter == *y_iter)
            {
                // score_current = score_upleft+1
                // next score_upleft = current score_up
                ++score_upleft;
                std::swap(score_upleft, *score_up_iter); 
            }
            else if (! (*score_up_iter < *score_prev_iter))
            {
                // score_current = score_up; do nothing
                // next score_upleft = current score_up
                score_upleft = *score_up_iter;
            }
            else
            {
                // score_current = score_prev
                // next score_upleft = current score_up
                score_upleft = *score_up_iter;
                *score_up_iter = *score_prev_iter;
            }
        }
    }
    return scores;
}


template<typename ValueType, typename SizeType>
    template<typename ForwardIteratorTypeX, typename ForwardIteratorTypeY>
    typename longest_common_subsequence_tpl<ValueType, SizeType>::Needleman_Wunsch_algorithm::arrow_matrix_t 
    longest_common_subsequence_tpl<ValueType, SizeType>::Needleman_Wunsch_algorithm::
calc_arrow_matrix(ForwardIteratorTypeX x_begin, ForwardIteratorTypeX x_end, ForwardIteratorTypeY y_begin, ForwardIteratorTypeY y_end)
{
    auto const x_size = std::distance(x_begin, x_end);
    auto const y_size = std::distance(y_begin, y_end);
    arrow_matrix_t matrix(x_size + 1, arrow_row_t(y_size + 1, arrow_left_eq | arrow_up_eq));
    auto prev_row_iter = matrix.cbegin();
    auto curr_row_iter = std::next(matrix.begin());
    struct inner
    {
        static inline auto calc_score(SizeType prev, arrow_t arrow_curr)->SizeType
            {return arrow_curr & arrow_left_eq? prev : prev+1;}
    };
    for (auto x_iter = x_begin; x_iter != x_end; ++x_iter, ++prev_row_iter, ++curr_row_iter)
    {
        auto up_iter = std::next(prev_row_iter->cbegin());
        auto curr_iter = std::next(curr_row_iter->begin());
        SizeType score_upleft = 0, score_prev = 0, score_up, score_curr;

        for (auto y_iter = y_begin; y_iter != y_end; ++y_iter, ++up_iter, ++curr_iter,
            score_upleft = score_up, score_prev = score_curr)
        {
            score_up = inner::calc_score(score_upleft, *up_iter); 
            if (*x_iter == *y_iter)
            {
                score_curr = 1 + score_upleft;
                *curr_iter |= arrow_upleft_inc;
            }
            else if (score_prev < score_up)
            {
                score_curr = score_up;
            }
            else
            {
                score_curr = score_prev;
            }
            
            if (score_curr != score_prev)
            {
                *curr_iter &= ~arrow_left_eq;
            }
            
            if (score_curr != score_up)
            {
                *curr_iter &= ~arrow_up_eq;
            }
        }
    }
    return matrix;
}
        

template<typename ValueType, typename SizeType>
    template<typename ForwardIteratorTypeX, typename ForwardIteratorTypeY>
    typename longest_common_subsequence_tpl<ValueType, SizeType>::Needleman_Wunsch_algorithm::score_matrix_t 
    longest_common_subsequence_tpl<ValueType, SizeType>::Needleman_Wunsch_algorithm::
calc_score_matrix(ForwardIteratorTypeX x_begin, ForwardIteratorTypeX x_end, ForwardIteratorTypeY y_begin, ForwardIteratorTypeY y_end)
{
    auto const x_size = std::distance(x_begin, x_end);
    auto const y_size = std::distance(y_begin, y_end);
    score_matrix_t score_matrix(x_size + 1, score_row_t(y_size + 1, 0));
    auto prev_row_iter = score_matrix.begin();
    auto curr_row_iter = std::next(prev_row_iter);
    for (auto x_iter = x_begin; x_iter != x_end; ++x_iter, ++prev_row_iter, ++curr_row_iter)
    {
        auto score_upleft_iter = prev_row_iter->begin();
        auto score_up_iter = std::next(score_upleft_iter);
        auto score_prev_iter = curr_row_iter->begin();
        auto score_curr_iter = std::next(score_prev_iter);
        
        for (auto y_iter = y_begin; y_iter != y_end; ++y_iter, ++score_upleft_iter, ++score_up_iter, ++score_prev_iter, ++score_curr_iter)
        {
            if (*x_iter == *y_iter)
            {
                *score_curr_iter = 1 + *score_upleft_iter;
            }
            else if (*score_prev_iter < *score_up_iter)
            {
                *score_curr_iter = *score_up_iter;
            }
            else
            {
                *score_curr_iter = *score_prev_iter;
            }
        }
    }
    return score_matrix;
}

template<typename ValueType, typename SizeType>
    template<typename ForwardIteratorTypeX, typename ForwardIteratorTypeY, typename OutputIteratorType>
    SizeType longest_common_subsequence_tpl<ValueType, SizeType>::Needleman_Wunsch_algorithm::
find_one_lcs(ForwardIteratorTypeX x_begin, ForwardIteratorTypeX x_end, ForwardIteratorTypeY y_begin, ForwardIteratorTypeY y_end, OutputIteratorType out)
{
    auto const matrix = calc_arrow_matrix(x_begin, x_end, y_begin, y_end);
    auto i = matrix.size() - 1;
    auto j = matrix[0].size() - 1;
    indices_t indices;
    while (i > 0 && j > 0)
    {
        if (matrix[i][j] & arrow_upleft_inc)
        {
            indices.push(i-1);
            --i;
            --j;
        }
        else if (matrix[i][j] & arrow_left_eq)
        {
            --j;
        }
        else
        {
            --i;
        }
    }
    
    SizeType const ret = indices.size();
    
    struct inner
    {
        static SizeType count(arrow_row_t const& row)
        {
            SizeType ret = 0; 
            for (auto arrow: row)
                if (! (arrow & arrow_left_eq)) 
                    ++ret;
            return ret;
        }
    };
    assert(ret == inner::count(matrix.back()));
    auto x_iter = x_begin;
    SizeType prev_index = 0;
    while (! indices.empty())
    {
        x_iter = std::next(x_iter, indices.top() - prev_index);
        prev_index = indices.top();
        indices.pop();
        
        *out = *x_iter;
        ++out;
    }
    
    return ret;
}
     




template<typename ValueType, typename SizeType>
    template<typename BidirectionalIteratorTypeX, typename BidirectionalIteratorTypeY, typename OutputIteratorType>
    SizeType 
    longest_common_subsequence_tpl<ValueType, SizeType>::Hirschberg_algorithm::
find_one_lcs(BidirectionalIteratorTypeX x_begin, BidirectionalIteratorTypeX x_end, BidirectionalIteratorTypeY y_begin, BidirectionalIteratorTypeY y_end, OutputIteratorType out)
{
    auto x_size = std::distance(x_begin, x_end);
    auto y_size = std::distance(y_begin, y_end); 
    if (y_size < x_size)
    {
        return find_one_lcs(y_begin, y_end, x_begin, x_end, out);
    }
    else if (0 == x_size)
    {
        return 0; // empty
    }
    else if (1 == x_size)
    {
        auto result_iter = std::find(y_begin, y_end, *x_begin);
        if (result_iter != y_end)
        {
            std::copy(x_begin, x_end, out);
            return 1;
        }
        else return 0;
    }
    
    auto x_middle = std::next(x_begin, x_size/2);
    auto score_left_half = Needleman_Wunsch_algorithm::calc_last_score_row(x_begin, x_middle, y_begin, y_end);
    auto score_right_half = Needleman_Wunsch_algorithm::calc_last_score_row(
        make_reverse_iterator(x_end), make_reverse_iterator(x_middle), 
        make_reverse_iterator(y_end), make_reverse_iterator(y_begin));
        
    // Partition Y
    SizeType max_score = 0;
    SizeType partition_index = 0, index = 0;
    auto j = score_right_half.rbegin();
    for (auto i = score_left_half.begin(); i != score_left_half.end(); ++i, ++j, ++index)
    {
        if (max_score < *i + *j)
        {
            partition_index = index;
            max_score = *i + *j;
        }
    }
    
    auto y_partition = std::next(y_begin, partition_index);
    auto lcs_left_half_size = find_one_lcs(x_begin, x_middle, y_begin, y_partition, out);
    auto lcs_right_half_size = find_one_lcs(x_middle, x_end, y_partition, y_end, out);
    return lcs_left_half_size + lcs_right_half_size;
}












template<typename ValueType, typename SizeType>
    template<typename ForwardIteratorTypeX, typename ForwardIteratorTypeY>
    SizeType
    longest_common_subsequence_tpl<ValueType, SizeType>::Eugene_Myers_algorithm::greedy::
calc_length_of_ses(
    longest_common_subsequence_tpl<ValueType, SizeType>::Eugene_Myers_algorithm::greedy::frontier_t<ForwardIteratorTypeX, ForwardIteratorTypeY>& frontier, 
    SizeType const limit, ForwardIteratorTypeX x_begin, ForwardIteratorTypeX x_end, ForwardIteratorTypeY y_begin, ForwardIteratorTypeY y_end)
{
    // check_input_size(x_begin, x_end, y_begin, y_end);
    assert(limit > 0); // 0 <= D < limit
    auto max = limit - 1; 
    auto const x_size = std::distance(x_begin, x_end);
    auto const y_size = std::distance(y_begin, y_end);
    if (x_size < max && y_size < max - x_size)
    {
        max = decltype(max)(x_size) + decltype(max)(y_size);
    }
    ++max;
    
    frontier.clear();
    auto const xy_begin = inner::make_index_pair(x_begin, 0, y_begin);
    auto const xy_end = inner::make_index_pair(x_end, x_size, y_end);
    auto xy_begin_snake = xy_begin;
    inner::go_further(xy_begin_snake, xy_end);
    SizeType len_ses = 0;
    for (; len_ses < max; ++len_ses)
    {
        frontier.push_front(xy_begin_snake);
        auto prev_iter = frontier.begin();
        for (auto xy_iter = std::next(prev_iter); xy_iter != frontier.end(); ++xy_iter)
        {
            assert(*xy_iter != xy_end);
            if (xy_iter->first != xy_end.first)
            {
                auto tmp = *xy_iter;
                ++tmp.first;
                inner::go_further(tmp, xy_end);
                if (prev_iter->first.before(tmp.first))
                {
                    *prev_iter = tmp;
                }
                else
                {
                    // maynot assert(prev_iter != frontier.begin());
                }
                
                if (! inner::no_match(*prev_iter, xy_end))
                {
                    if (*prev_iter == xy_end)
                    {
                        frontier.clear();
                        return len_ses;
                    }
                    else if (prev_iter->second == xy_end.second)
                    {
                        frontier.erase(xy_iter, frontier.end());
                        // ++xy_iter invalid
                        break;
                    }
                    else
                    {
                        frontier.erase(frontier.begin(), prev_iter);
                    }
                }
            }
            else
            {
                assert(prev_iter == frontier.begin());
                frontier.erase(frontier.begin(), xy_iter);
                // prev_iter invalid
            }
            
            if (xy_iter->second != xy_end.second)
            {
                ++xy_iter->second;
                inner::go_further(*xy_iter, xy_end);
            }
            else
            {
                assert(std::next(xy_iter) == frontier.end());
                frontier.erase(xy_iter, frontier.end());
                // ++xy_iter invalid
                break;
            }
            
            prev_iter = xy_iter; // prev_iter may invalid
        }
        
        if (! inner::no_match(frontier.back(), xy_end))
        {
            if (frontier.back() == xy_end)
            {
                frontier.clear();
                return len_ses;
            }
            else if (frontier.back().second == xy_end.second)
            {
                // pass
                // frontier.erase(frontier.end(), frontier.end());
            }
            else
            {
                frontier.erase(frontier.begin(), --frontier.end());
            }
        }

    }
    
    return len_ses;
}

template<typename ValueType, typename SizeType>
    template<typename BidirectionalIteratorTypeX, typename BidirectionalIteratorTypeY, typename OutputIteratorType>
    SizeType
    longest_common_subsequence_tpl<ValueType, SizeType>::Eugene_Myers_algorithm::divide_and_conquer::
find_one_lcs(BidirectionalIteratorTypeX x_begin, BidirectionalIteratorTypeX x_end, BidirectionalIteratorTypeY y_begin, BidirectionalIteratorTypeY y_end, OutputIteratorType out)
{
    typedef inner<BidirectionalIteratorTypeX, BidirectionalIteratorTypeY, OutputIteratorType> inner_base;
    struct inner : public inner_base
    {typedef typename inner_base::tuple tuple;};
    typedef typename inner::tuple tuple;
    // check input
    auto const i_x_size = std::distance(x_begin, x_end);
    auto const i_y_size = std::distance(y_begin, y_end);
    {
        SizeType const limit = SizeType(i_x_size) + SizeType(i_y_size) + 1;
        if (i_x_size < limit && i_y_size < limit - i_x_size)
        {
            // pass
        }
        else
        {
            throw std::runtime_error("input size is too large!");
        }
    }
    
    tuple original{x_begin, x_end, y_begin, y_end};
    while (x_begin != x_end && y_begin != y_end && *x_begin == *y_begin)
    {
        ++x_begin;
        ++y_begin;
    }
    while (x_begin != x_end && y_begin != y_end && *--x_end == *--y_end)
    {
        // pass;
    }
    ++x_end;
    ++y_end;
    SizeType const begin_snake_size = std::distance(original.x_begin, x_begin);
    SizeType const end_snake_size = std::distance(x_end, original.x_end);
    
    
    SizeType const x_size = i_x_size - (begin_snake_size + end_snake_size);
    SizeType const y_size = i_y_size - (begin_snake_size + end_snake_size);
    auto const len_ses = inner::calc_len_ses(x_begin, x_end, y_begin, y_end, x_size, y_size);
    
    std::stack<tuple> stack;
    stack.emplace(tuple{x_end, original.x_end, y_end, original.y_end, 0, end_snake_size, end_snake_size});
    stack.emplace(tuple{x_begin, x_end, y_begin, y_end, len_ses, x_size, y_size});
    stack.emplace(tuple{original.x_begin, x_begin, original.y_begin, y_begin, 0, begin_snake_size, begin_snake_size});
    
    while (! stack.empty())
    {
        auto top = stack.top();
        stack.pop(); 
        if (0 == top.len_ses)
        {
            std::copy(top.x_begin, top.x_end, out);
            continue;
        }
        else if (1 == top.len_ses)
        {
            if (top.x_size < top.y_size) 
            {
                std::copy(top.x_begin, top.x_end, out);
            }
            else
            {
                std::copy(top.y_begin, top.y_end, out);
            }  
            continue;
        }
        else if (top.x_size < 2 || top.y_size < 2)
        {
            inner::find_one_lcs_if_one_size_no_more_than_1(top.x_begin, top.x_end, top.y_begin, top.y_end, out, top.x_size, top.y_size); 
            continue;
        }
        
        auto const left_ses = top.len_ses/2;
        auto const right_ses = top.len_ses - left_ses;
        
        auto left_frontier = inner::calc_frontier(left_ses + 1, top.x_begin, top.x_end, top.y_begin, top.y_end);
        SizeType left_x0_index = left_frontier.front().first.index;
        SizeType left_y0_index = std::distance(top.y_begin, left_frontier.front().second);
        // for (xy: left_frontier) assert(y[i].index - x[i].index == k + 2*i);
        
        auto x_rbegin = make_reverse_iterator(top.x_end);
        auto x_rend = make_reverse_iterator(top.x_begin);
        auto y_rbegin = make_reverse_iterator(top.y_end);
        auto y_rend = make_reverse_iterator(top.y_begin);
        auto right_frontier = inner::calc_frontier(right_ses + 1, x_rbegin, x_rend, y_rbegin, y_rend);
        SizeType right_x0_rindex = right_frontier.back().first.index;
        SizeType right_y0_rindex = std::distance(y_rbegin, right_frontier.back().second);
        SizeType right_x0_index = top.x_size - right_x0_rindex;
        SizeType right_y0_index = top.y_size - right_y0_rindex;
        
        auto left_iter = left_frontier.begin();
        auto right_iter = right_frontier.rbegin();
        if (left_y0_index + right_x0_index < 
            left_x0_index + right_y0_index)
        {
            // left[0].k < right[-1].k
            left_iter = std::next(left_iter, 
                (left_x0_index + right_y0_index - 
                (left_y0_index + right_x0_index)) / 2);
        }
        else
        {
            right_iter = std::next(right_iter,
                (left_y0_index + right_x0_index - 
                (left_x0_index + right_y0_index)) / 2);
        }
        
        while (left_iter->first.index < (top.x_size - right_iter->first.index))
        {
            ++left_iter;
            ++right_iter;
        }
        
        SizeType middle_snake_size = left_iter->first.index - (top.x_size - right_iter->first.index);
        tuple left{top.x_begin, right_iter->first.base(), top.y_begin, right_iter->second.base(), left_ses, top.x_size - right_iter->first.index, 0};
        left.y_size = std::distance(left.y_begin, left.y_end);
        tuple right{left_iter->first, top.x_end, left_iter->second, top.y_end, right_ses, top.x_size - left_iter->first.index, top.y_size - left.y_size - middle_snake_size};
        tuple middle_snake{left.x_end, right.x_begin, left.y_end, right.y_begin, 0, middle_snake_size, middle_snake_size};

        stack.push(right);
        stack.push(middle_snake);
        stack.push(left);
    }
    
    return ((SizeType(i_x_size) + SizeType(i_y_size)) - len_ses)/2;
}

