#include <cassert>
#include <cstring>
#include <cstddef> // size_t
#include <iterator>     // std::back_inserter
#include <string>
#include <list>
#include <deque>
#include <iostream>
#include <algorithm>    // std::reverse
#include "lcs.hpp"


int main(int argc, char* argv[])
{
    assert(argc == 3);
    using std::string;
    using std::list;
    using std::deque;
    string const str_x(argv[1]);
    string const str_y(argv[2]);
    list<char> const x(str_x.begin(), str_x.end());
    deque<char> const y(str_y.begin(), str_y.end());
    string str;
    auto out = std::back_inserter(str);
    typedef longest_common_subsequence_tpl<char, size_t> lcs_tpl;
    lcs_tpl::Hirschberg_algorithm::
        find_one_lcs(x.rbegin(), x.rend(), make_reverse_iterator(y.end()), make_reverse_iterator(y.begin()), out);
    std::reverse(str.begin(), str.end());
    string str2;
    out = std::back_inserter(str2);
    lcs_tpl::Needleman_Wunsch_algorithm::
        find_one_lcs(x.begin(), x.end(), y.begin(), y.end(), out);
    // may not xxxassert(str == str2);
    string str3;
    out = std::back_inserter(str3);
    lcs_tpl::Eugene_Myers_algorithm::divide_and_conquer::
        find_one_lcs(x.begin(), x.end(), y.begin(), y.end(), out);
    std::cout << str << std::endl;
    std::cout << str2 << std::endl;
    std::cout << str3 << std::endl;
    assert(lcs_tpl::Needleman_Wunsch_algorithm::
        is_lcs_of(str.begin(), str.end(), x.begin(), x.end(), y.begin(), y.end()));
    assert(lcs_tpl::Needleman_Wunsch_algorithm::
        is_lcs_of(str2.begin(), str2.end(), x.begin(), x.end(), y.begin(), y.end()));
    assert(lcs_tpl::Needleman_Wunsch_algorithm::
        is_lcs_of(str3.begin(), str3.end(), x.begin(), x.end(), y.begin(), y.end()));
    
    return 0;
}