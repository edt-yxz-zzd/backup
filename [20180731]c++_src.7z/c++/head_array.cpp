



template<typename head_t, typename data_t>
struct head_array_t
{
    head_t* p;
    static const size_t align = alignof(data_t);
    static const size_t padding = // d buf_pt ??std::align(alignment, size, buf_pt, buf_sz)?? //(align - sizeof(head_t) % align) % align;
    static const size_t offset = sizeof(head_t) + padding;
    inline data_t& operater[](size_t i){return *get(i);}
    inline data_t* get(size_t i){return (data*)((char*)p+offset);}
    static size_t length2size(size_t length){return offset + sizeof(data_t)*length;}
    static void* raw_alloc(size_t length){return ::operator new(length2size(length));}
    static void raw_free(void* ph){::operator delete(ph);}
};
