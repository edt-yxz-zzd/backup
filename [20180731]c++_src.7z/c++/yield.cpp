
stack->stack_base_ptr, stack_current_ptr



struct jmp_diff_stacks_t
{
    // one stack can own no more than one active jmp_pt
    // if set a new jmp_pt, should find out which stack is using
    // my_stack = find_stack_using() <- search address of local variable
    // my_env = get_jmp_pt(my_stack)
    // to_stack = find_stack("to-do-job/who-resumed-me/the-one-gived")
    // to_env = get_jmp_pt(to_stack)
    // if is_valid(to_stack, to_env) <- what job it waited for?
    // push(my_env, my_waiting); update(my_env, my_waiting);
    // jump(to_env, job) 
    //   // wait to be resumed
    // who = get-who-resumed-me
    // if who != to_env ? reject(who) or try the job
    // elif reject-me // bad-call, I'm not the one to_env expected!
    //    ?????
    // elif total_return // to_stack finish its life
    //   // this should be performed by call_on_stack(stack,f)
    //   // since it begins the work in a new stack and then be frozen by f's yield.
    //   // when it return, it should return to the nearest one that resumed it 
    //   // or let the resource manage to free this stack first.
    // elif output_data is bad....
    //
    
    void* output_data;
    void* input_data;
    // jmp_buf* return_address;
    jmp_buf* resume_address;
    // 1) def y;
    // 2) y.resume <- here
    //    y.input <- ?
    //    call child(&y);
    //    if child -> yield
    //       look <- y.output
    //       if wait
    //          y.resume
    //    
    void yield()
    {
        jmp_buf mine;
        resume_address = &mine;
        if (setjmp(mine))
        {
            // resume
            return;
        }
        else // after setjmp
        {
            unsafe_jump();
            // ! we go to ?
            // if to a child, error!
            //    since who makes this call have modify the stack in middle!
            // so we must go back!
            // the function we go back should not modify the stack
            //     before resume this call
            // but if we keep the two space seperate,
            //     than no problem
            // how? 
            // 1) reserve the child-stack on previous one
            //    yield_t y;jmp_buf e;
            //    if (!setjmp(e)){ 
            //       call r(10000,f,&e) -> (stack_I_use[100000] or r(n-1,f,&e)) + f(&e)
            //    }
            //    
            //         
        }
    }
    
    private:
    void unsafe_jump()
    {
        // if we setjmp here, this local variable
        longjmp(*return_address); // may be destroyed by longjmp
        
    }
};


struct func_stack;
class func_stack_data
{
    typedef unsigned char byte_t;
    vector<byte_t> stack_data; // this data should be unique!
    void* stack_base; // where the stack should be
    stared_ptr<func_stack> pstack; // before destruct, we should cleanup stack_data
    func_stack_data(byte_t* begin, byte_t* end, void* base):
        stack_data(begin,end), stack_base(base){}
        
    public:
    byte_t* original_begin();
    byte_t* original_end();
    ~func_stack_data(){pstack->cleanup(*this);}
};
struct func_stack
{
    func_stack(size_t size); 
    size_t total_size()const;
    size_t used_size()const;
    
    
};


template<typename T>
struct yield
{
    yield(size_t size);
};