
// g++ -o print_self.exe print_self.cpp -std=c++11

#include <iostream>
#include <string>
#include <sstream>
using namespace std;


string source_block_unindent(string const head, string const source_block)
{
    istringstream in(source_block);
    string out;
    string t;
    while(getline(in, t))
    {
        if (t.size() >= head.size() && 
            0 == t.compare(0, head.size(), head))
        {
            t = t.substr(head.size());
        }
        
        out += t + "\n";
    }
    
    if (!out.empty()) 
        if (source_block.empty() || *source_block.rbegin() != '\n')
            out.erase(out.size()-1);
    return out;
}


void print_self_impl(
    string const source_begin, 
    string const source_end, 
    string const line_head
)
{
    string const raw_beg = "R\"hh_hhh_hhhhh(";
    string const raw_end = ")hh_hhh_hhhhh\"";
    cout << source_block_unindent(line_head, source_begin) << endl
         << raw_beg << endl
         << source_begin << endl
         << raw_end << "," << endl
         << raw_beg << endl
         << source_end << endl
         << raw_end << "," << endl
         << source_block_unindent(line_head, source_end);
}

/* to remove the two extra <newline> in each raw string */
void print_self(
    string const source_begin, 
    string const source_end, 
    string const line_head
)
{
    print_self_impl(
        source_begin.substr(1, source_begin.size()-2),
        source_end.substr(1, source_end.size()-2),
        line_head);
}


int main(void)
{
    /*
    use raw strings in this form:
    R"(
    [block_indent]the_raw_string
    )"
    Note the two extra <newline> above
    */
    print_self(
R"hh_hhh_hhhhh(
        
        // g++ -o print_self.exe print_self.cpp -std=c++11
        
        #include <iostream>
        #include <string>
        #include <sstream>
        using namespace std;
        
        
        string source_block_unindent(string const head, string const source_block)
        {
            istringstream in(source_block);
            string out;
            string t;
            while(getline(in, t))
            {
                if (t.size() >= head.size() && 
                    0 == t.compare(0, head.size(), head))
                {
                    t = t.substr(head.size());
                }
                
                out += t + "\n";
            }
            
            if (!out.empty()) 
                if (source_block.empty() || *source_block.rbegin() != '\n')
                    out.erase(out.size()-1);
            return out;
        }
        
        
        void print_self_impl(
            string const source_begin, 
            string const source_end, 
            string const line_head
        )
        {
            string const raw_beg = "R\"hh_hhh_hhhhh(";
            string const raw_end = ")hh_hhh_hhhhh\"";
            cout << source_block_unindent(line_head, source_begin) << endl
                 << raw_beg << endl
                 << source_begin << endl
                 << raw_end << "," << endl
                 << raw_beg << endl
                 << source_end << endl
                 << raw_end << "," << endl
                 << source_block_unindent(line_head, source_end);
        }
        
        /* to remove the two extra <newline> in each raw string */
        void print_self(
            string const source_begin, 
            string const source_end, 
            string const line_head
        )
        {
            print_self_impl(
                source_begin.substr(1, source_begin.size()-2),
                source_end.substr(1, source_end.size()-2),
                line_head);
        }
        
        
        int main(void)
        {
            /*
            use raw strings in this form:
            R"(
            [block_indent]the_raw_string
            )"
            Note the two extra <newline> above
            */
            print_self(
)hh_hhh_hhhhh",
R"hh_hhh_hhhhh(
                "        " // 8 spaces as the block_indent in the above raw strings
            );
            
            return 0;
        } // this line ends up with a <newline>

)hh_hhh_hhhhh",
        "        " // 8 spaces as the block_indent in the above raw strings
    );
    
    return 0;
} // this line ends up with a <newline>
