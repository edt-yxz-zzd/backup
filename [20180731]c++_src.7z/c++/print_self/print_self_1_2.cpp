#include <iostream>
extern char const *const s;
int main(void){std::cout << s << s << ")\"+1;";}
char const *const s = R"(
#include <iostream>
extern char const *const s;
int main(void){std::cout << s << s << ")\"+1;";}
char const *const s = R"(
)"+1;