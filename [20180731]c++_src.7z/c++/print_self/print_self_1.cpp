#include <iostream>
extern char const *const s;
int main(void){std::cout << s+1 << "R\"(" << s << ")\";";}
char const *const s = 
R"(
#include <iostream>
extern char const *const s;
int main(void){std::cout << s+1 << "R\"(" << s << ")\";";}
char const *const s = 
)";