#include <stdio.h>
#include <string.h>
extern char s[];
void f(char* t){
    for(char* e;e=strchr(t,s[0]);t=e+1)
        {*e=0;putchar(s[3]);printf(s+5,t);puts(s+1);}
}
void g(){
    int idx[]={3,1,2,1,1,2,1,3,1,9,5,6,1,9,8,9,3,0};
    for(int i=0;i<sizeof(idx)/sizeof(int);++i)putchar(idx[i][s]);
}
void h(){putchar(s[8]);putchar(s[0]);}
int main(void){printf(s+5,s+10);g();f(s+10);h();return 0;}
char s[] =
"\n\\n\"\0%s\0;0"
"#include <stdio.h>\n"
"#include <string.h>\n"
"extern char s[];\n"
"void f(char* t){\n"
"    for(char* e;e=strchr(t,s[0]);t=e+1)\n"
"        {*e=0;putchar(s[3]);printf(s+5,t);puts(s+1);}\n"
"}\n"
"void g(){\n"
"    int idx[]={3,1,2,1,1,2,1,3,1,9,5,6,1,9,8,9,3,0};\n"
"    for(int i=0;i<sizeof(idx)/sizeof(int);++i)putchar(idx[i][s]);\n"
"}\n"
"void h(){putchar(s[8]);putchar(s[0]);}\n"
"int main(void){printf(s+5,s+10);g();f(s+10);h();return 0;}\n"
"char s[] =\n"
;
