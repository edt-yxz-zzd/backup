#include <boost/filesystem/fstream.hpp>
#include <fstream>
#include <string>
using std::string;

namespace fs = boost::filesystem;

int main()
{
  char const* path = u8"������";
  fs::ofstream out(path);
  out << path;
  out.put('\n');
  out.close();
  std::cout << path << std::endl;
  std::ifstream fin(path);
  string line;
  while(std::getline(fin, line))
    std::cout << line << std::endl;
  return 0;
}
