

import sys
from seed.windows.cmd_parse import cmd_parse
hex_args = sys.argv[1:]
print(hex_args)
if 1:
    encoding = 'utf8' # windows
    b_dirname_ansi, b_args_utf8 = map(bytes.fromhex, hex_args)
    dirname_str = b_dirname_ansi.decode('ansi')
    args_str = b_args_utf8.decode('utf8')
    args = cmd_parse(args_str)
    print(dirname_str)
    print(args_str)
    print(args)
else:
    print(list(map(bytes.fromhex, hex_args)))
