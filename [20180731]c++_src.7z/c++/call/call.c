
/*
 * call the first line in text file "call.cmd.cfg" using system()
 *  ==>> "dirname(this)/call.cmd.cfg::line[0]" hex(ansi(dirname(this))) hex(utf8(argv))
 */

/*

Here's code to get the full path to the executing app:

Windows:
    int bytes = GetModuleFileName(NULL, pBuf, len);
    if(bytes == 0)
        return -1;
    else
        return bytes;

Linux:
    char szTmp[32];
    sprintf(szTmp, "/proc/%d/exe", getpid());
    int bytes = MIN(readlink(szTmp, pBuf, len), len - 1);
    if(bytes >= 0)
        pBuf[bytes] = '\0';
    return bytes;

###############
where is GetModuleFileName?
    Header  Winbase.h (include Windows.h)
    Library Kernel32.lib
    DLL     Kernel32.dll
*/


/*
void _splitpath(
   const char *path,
   char *drive,
   char *dir,
   char *fname,
   char *ext
);
*/


/*
argv encoding
on Windows the argv is encoded using the current code page. However, you can retrieve the command line as UTF-16 using GetCommandLineW. Use of argv is not recommended for modern Windows apps with unicode support because code pages are deprecated.
GetModuleFileName
GetCommandLineW
utf16?
    utf16le? or utf16be?
    utf16le likely

*/
#include <stdio.h>      /* printf, fopen */
#include <stdlib.h>     /* system, NULL, EXIT_FAILURE, _splitpath??? */
/*#include <Winbase.h> error!!!!!*/
#include <windows.h> /* GetModuleFileName, GetCommandLineW, _fullpath???, _splitpath??? */
#include <string.h> /* strlen, strncpy */
#include <assert.h>

typedef struct
{
    char* p;
    int i;
} Result;

char* str2hex(char* buffer, size_t sz_buf, const char* bytes, size_t size)
{
    /* return end; *end == '\0' */
    assert(sz_buf >= 2*size+1);
    for (const char* end = bytes + size; bytes != end; ++bytes, buffer+=2){
        sprintf(buffer, "%02X", *bytes);
    }
    *buffer = '\0';
    return buffer;
}


void _main(Result* r, int argc, char **argv)
{
    /*printf ("Checking if processor is available...");*/
    if (!system(NULL)) exit (EXIT_FAILURE);

    /*printf ("Executing command DIR...\n");*/
    /* system example : DIR */
    /*i=system ("dir");*/
    /*printf ("The value returned was: %d.\n",i);*/

    FILE * pFile;
    const char* fname_cfg = "call.cmd.cfg";
    /*const char* fname_err = "call.cmd.err";*/
    char exe_path[1024*8];
    char buffer[1024*10];
    char* exe_dir = buffer;
    char* exe_drive = buffer;
    char* cfg_path = buffer;
    char cmd[10240];
    size_t len, exe_dir_len;


    int bytes = GetModuleFileName(NULL, exe_path, sizeof(exe_path));
    if (bytes == 0){
        printf("cannot GetModuleFileName");
        r->i = -1;
        return;
    }
    _splitpath(exe_path, exe_drive, NULL, NULL, NULL); /* get drive */
    len = strlen(exe_drive);
    _splitpath(exe_path, NULL, exe_dir+len, NULL, NULL); /* get dir */

    /*sprintf(cfg_path, "%s\\%s", exe_dir, fname_cfg);*/
    exe_dir_len = len = strlen(exe_dir); /* include the last "\\" */
    strncpy(cfg_path+len, fname_cfg, sizeof(buffer)-len-1);
    /*puts(cfg_path);*/

    pFile = fopen (cfg_path, "r");
    if (NULL == pFile){
        /*pFile = fopen (fname_err, "a");*/
        /*fprintf("")*/
        printf("cannot open: %s", cfg_path);
        r->i = -2;
        return;
    }

    cmd[sizeof(cmd)-1] = '\0';
    if (NULL == fgets(cmd, sizeof(cmd), pFile)){
        printf("fail to read command from: %s", cfg_path);
        r->i = -3;
        return;
    }
    fclose (pFile);
    /*puts(cmd);*/

    if ('\0' != cmd[sizeof(cmd)-1]){
        printf("fail to read command(too long) from: %s", cfg_path);
        r->i = -4;
        return;
    }

    /* remove [\n\r]* */
    len = strlen(cmd);
    for (size_t i = strlen(cmd)-1; i >= 0; --i){
        if ('\n' != cmd[i] && '\r' != cmd[i]){
            cmd[i+1] = '\0';
            assert(i+1 == strlen(cmd));
            break;
        }
    }
    size_t hex_argv_len = strlen(cmd)+(exe_dir_len*2+3)+1; /* ' ' and '\"'*2 and '\0' */

#if 1
    LPWSTR arg_utf16le = GetCommandLineW();
    int len_arg_utf8 = WideCharToMultiByte(CP_UTF8, 0, arg_utf16le, -1, 0, 0, 0, 0);

    hex_argv_len += len_arg_utf8*2+3; /* ' ' and '\"'*2 */

    char* arg_utf8 = (char*) malloc(len_arg_utf8);
    if (NULL == arg_utf8){
        printf("fail to malloc: %zu", hex_argv_len);
        r->i = -5;
        return;
    }
    WideCharToMultiByte(CP_UTF8, 0, arg_utf16le, -1, arg_utf8, len_arg_utf8,0,0);
    --len_arg_utf8; /* exclude tail "\0" */


    char* cmd_with_args = (char*) malloc(hex_argv_len);
    if (NULL == cmd_with_args){
        printf("fail to malloc: %zu", hex_argv_len);
        r->i = -5;
        return;
    }

    char* begin = cmd_with_args;
    char* end = cmd_with_args + hex_argv_len;
    len = strlen(cmd);
    strcpy(begin, cmd); begin += len;

    /* hex(exe_dir) */
        *begin = ' '; ++begin;
        *begin = '\"'; ++begin;
        begin = str2hex(begin, end-begin, exe_dir, exe_dir_len);
        *begin = '\"'; ++begin;
    /* hex(args) */
        *begin = ' '; ++begin;
        *begin = '\"'; ++begin;
        begin = str2hex(begin, end-begin, arg_utf8, len_arg_utf8);
        *begin = '\"'; ++begin;

#else
    for (int i = 0; i < argc; ++i){
        /* " \"{hex(arg)}\"" per arg; NOTE: empty string!!*/
        hex_argv_len += strlen(argv[i])*2+3;
    }

    char* cmd_with_args = (char*) malloc(hex_argv_len);
    if (NULL == cmd_with_args){
        printf("fail to malloc: %zu", hex_argv_len);
        r->i = -5;
        return;
    }

    char* begin = cmd_with_args;
    char* end = cmd_with_args + hex_argv_len;
    len = strlen(cmd);
    strcpy(begin, cmd); begin += len;

    /* hex(exe_dir) */
        *begin = ' '; ++begin;
        *begin = '\"'; ++begin;
        begin = str2hex(begin, end-begin, exe_dir, exe_dir_len);
        *begin = '\"'; ++begin;
    for (int i = 0; i < argc; ++i){
        *begin = ' '; ++begin;
        *begin = '\"'; ++begin;
        len = strlen(argv[i]);
        begin = str2hex(begin, end-begin, argv[i], len);
        *begin = '\"'; ++begin;
    }
#endif

    *begin = '\0';
    assert (begin < end);

    /* puts(cmd_with_args); */
    r->p = cmd_with_args;
    return;
}

int main(int argc, char **argv)
{
    Result r = {NULL, 0};
    _main(&r, argc, argv);
    char* cmd_with_args = r.p;
    if (NULL == cmd_with_args){
        return r.i;
    }

    exit(system(cmd_with_args));
    free(cmd_with_args);
    return 0;
}
