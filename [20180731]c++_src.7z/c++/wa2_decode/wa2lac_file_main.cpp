
#include "wa2lac_file_t.hpp"
#include <iostream> // cout
#include <fstream>
#include <vector>




//g++ -std=c++11 -pedantic -I%boost%  WA2PAK.cpp -c

//using namespace std;

// is xx file?
// init head
// get range of entries
// for e in rng: e.offset/length/fname/compressed





std::vector<std::string> dir_lac_file(std::istream& lac);
void extract_lac_inner_file(std::istream& lac, std::string path);
//////////////////////////////////////////////////////////
static void ls_nc_lac_file(std::ostream& out, std::istream& lac);
static void ls_n_lac_file(std::ostream& out, std::istream& lac);
int tmain(int argc, char* argv[]);



//////////////////////////////////////////////////////////
std::vector<std::string> dir_lac_file(std::istream& lac)
{
    std::vector<std::string> fnames;
    lac.seekg(0);
    auto rng = lac_file_t::get_entries_range(lac);
    for (auto inner_file : rng)
        fnames.push_back(inner_file.get_file_name());
    return fnames;
}

template<typename PredicatorFunctor>
void extract_lac_inner_file(std::istream& lac, std::string path_prefix, PredicatorFunctor pred)
{
    auto rng = lac_file_t::get_entries_range(lac);
    for (auto inner_file : rng) {
        std::string fname = inner_file.get_file_name();
        if (!pred(fname)) continue;
        std::ofstream fout(path_prefix + fname, std::ofstream::out | std::ofstream::binary);
        fout << inner_file.get_file_object();
    }

}

//////////////////////////////////////////////////////////
static void ls_nc_lac_file(std::ostream& out, std::istream& lac)
{
    lac.seekg(0);
    auto rng = lac_file_t::get_entries_range(lac);
    for (auto inner_file : rng)
        out << inner_file.get_file_name() << ' ' 
            << inner_file.compression_method() << std::endl;
}


static void ls_n_lac_file(std::ostream& out, std::istream& lac)
{
    auto ls = dir_lac_file(lac);
    if  (!lac) throw std::string("error...");
    for (auto const& name : ls)
        out << name << std::endl;
}

int tmain(int argc, char* argv[]) try
{
    std::vector<std::string> fnames(argv+1, argv + argc);
    for (auto const& fn : fnames){
        std::ifstream fin(fn, std::ifstream::in | std::ifstream::binary);
        if (!fin) throw "fail to open file:" + fn;
        ls_nc_lac_file(std::cout, fin);   
        //ls_n_lac_file(std::cout, fin);      
        std::cout << std::endl;
    }
    return 0;
}
catch(const std::string& s)
{
    std::cerr << s << std::endl;
    throw;
}
catch(const char* s)
{
    std::cerr << s << std::endl;
    throw;
}



int main(int argc, char* argv[])
{
    try{
        return tmain(argc, argv);
    }
    catch(std::string&){
        return -1;
    }
}


