
#include "wa2kcap_file_t.hpp"
#include "file_uint.hpp"
#include "numeric_cast_assign.hpp"
#include "array_size_t.hpp"
#include <cstring>

//g++ -std=c++11 -pedantic -I%boost%  WA2PAK.cpp -c

//using namespace std;

// is xx file?
// init head
// get range of entries
// for e in rng: e.offset/length/fname/compressed

/*
([b'KCAP)\x00#H\xbe\x18\x00\x00G\x00\x00\x00'], 'script.pak')
([b'KCAP)\x00#H\xbe\x18\x00\x00\x8e\x00\x00\x00'], 'bak.pak')
([b'KCAP)\x00#H\xbe\x18\x00\x00\x95\x01\x00\x00'], 'char.pak')
([b'KCAP)\x00#H\xbe\x18\x00\x00\xa9\x00\x00\x00'], 'grp.pak')
([b'KCAP,E1M\x85\x19\x00\x00\n\x00\x00\x00'], 'fnt.pak')

White Album2 -IC-::grp.pak::
tv000000.tga               // LZSS
tv100100.tga~tv103300.tga  // LZSS
These may be the pictures of names of bgms. It turns out no...

*/

static std::string c_strn2string(char const* str, size_t n)
{
    std::string s(str, n); // s.length == n
    return s.c_str(); // .length <= n
}




size_t const kcap_file_t::head_t::head_size;
size_t const kcap_file_t::entry_t::entry_size;





/////////////////////////////////////////////////////
//string kcap_file_t::read_label(istream&);
//bool kcap_file_t::is_kcap_file(istream&);
//kcap_file_t::entry_range_t kcap_file_t::get_entries_range(istream&);
/////////////////////////////////////////////////////
//kcap_file_t::head_t::head_t(istream& istr);
/////////////////////////////////////////////////////
//void kcap_file_t::entry_t::assign(istream& istr);
std::istream& operator >> (std::istream&, kcap_file_t::entry_t&);
/////////////////////////////////////////////////////
//kcap_file_t::inner_file_t::inner_file_t(istream& istr);





/////////////////////////////////////////////////////
std::string kcap_file_t::read_label(std::istream& istr)
{
    //size_t const sz = get_array_size_of(get_file_type()); //!!! no!!! why this make ftype a variable length array?
    //size_t const sz = sizeof(string_of_array_size(get_file_type())); // this one works!
    size_t const sz = array_size_t<decltype(get_file_type())>::size;
    char ftype[sz] = {};
    istr.seekg(0);
    istr.read(ftype, sz);
    if (istr) return {ftype, sz};
    else return {};
}
bool kcap_file_t::is_kcap_file(istream& istr)
{
    string s = read_label(istr);
    return istr && s == string(get_file_type(), s.size());
}



kcap_file_t::entry_range_t kcap_file_t::get_entries_range(istream& istr)
{
    head_t head(istr);
    
    istream::streampos pos = 0;
    istream::streamoff sz = 0;
    istream::streamoff idx = 0;
    numeric_cast_assign(pos, head_t::head_size);
    numeric_cast_assign(sz, entry_t::entry_size);
    //inner_file_iter_t::array_head_t array{istr, sz, pos}; !!!this must be forbiden!!!
    inner_file_iter_t::array_head_t array{file_object_t{istr, pos, sz}};
    inner_file_iter_t iter{array, idx};
    
    numeric_cast_assign(idx, head.num_entries);
    inner_file_iter_t end{array, idx};
    
    if (overflow_mul(idx, sz))
        throw string("fail: overflow");
    return {iter, end};
}




/////////////////////////////////////////////////////
kcap_file_t::head_t::head_t(istream& istr)
{
    if (!is_kcap_file(istr)) throw string("not KCAP file!");
    string s = read_label(istr);
    strncpy(ftype, s.c_str(), sizeof(ftype)/sizeof(char));
    x1_ = file_read_LE<uint32_t>(istr);
    x2_ = file_read_LE<uint32_t>(istr);
    num_entries = file_read_LE<uint32_t>(istr);
    if (!istr) throw string("fail: when read file");
}





/////////////////////////////////////////////////////
void kcap_file_t::entry_t::assign(istream& istr)
{
    compressed = file_read_LE<uint32_t>(istr);
    istr.read(fname, sizeof(fname));
    x1_ = file_read_LE<uint32_t>(istr);
    x2_ = file_read_LE<uint32_t>(istr);
    offset = file_read_LE<uint32_t>(istr);
    length = file_read_LE<uint32_t>(istr);
    
    /// fname = ~fname
    //for (auto& ch : fname) // ch = ~ch;
    //    if (!ch) break;
    //    else ch = ~ch;
}


std::istream& operator >> (std::istream& istr, kcap_file_t::entry_t& e)
{
    e.assign(istr);
    return istr;
}





/////////////////////////////////////////////////////
kcap_file_t::inner_file_t::inner_file_t(istream& istr)
{
    entry_t entry;
    istr >> entry;
    fname = c_strn2string(entry.fname, array_size_t<decltype(entry.fname)>::size);
    compressed = !!(entry.compressed);
    istream::streampos pos = 0;
    istream::streamoff sz = 0;
    numeric_cast_assign(pos, entry.offset);
    numeric_cast_assign(sz, entry.length);
    file = file_object_t(istr, pos, sz);
    if (!istr) throw string("fail: reading file@inner_file_t(istream&)");
}



