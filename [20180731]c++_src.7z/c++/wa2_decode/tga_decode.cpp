
#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <cstdint>
#include "file_uint.hpp"
#include "unlzss.h"

using namespace std;



void decode_tga(string fnin, string fnout) try
{
    //string const path = "C:/game/WHITE_ALBUM2_-introductory_chapter-/WHITE ALBUM2 -introductory chapter-/tmp/";
    //string const fnin = path + "tv100100.tga";
    //string const fnout = path + "_tv100100.tga";
    typedef uint32_t u_t;
    cout << fnin << endl;
    ifstream fin(fnin, ifstream::in | ifstream::binary);
    if (!fin) throw string("fail: open in file");
    fin.seekg(0,ios::end);
    if (fin.tellg() < sizeof(u_t)*2) {cout << "tiny file!" << endl; return;}
    fin.seekg(0);
    u_t sz = file_read_LE<u_t>(fin);
    u_t org_sz = file_read_LE<u_t>(fin);
    //cout << sz << ' ' << org_sz << endl;
    vector<char> data(sz - sizeof(u_t)*2);
    fin.read(data.data(), data.size());
    if (!fin) throw string("fail: read in file: ") + fnin;
    if (EOF != fin.get()) throw string("fail: file size mismatch! in file");
    
    vector<char> buf(org_sz);
    auto len = unlzss((uint8_t*)buf.data(), buf.size(), (uint8_t*)data.data(), data.size());
    if (len != buf.size()) throw string("fail: file size mismatch! out file");
    ofstream fout(fnout, ofstream::out | ofstream::binary);
    fout.write(buf.data(), buf.size());
}
catch(string const& s)
{
    cerr << s << endl;
    throw;
}

char const* fns[] = {
#include "fn.txt"
};

int tmain()
{
    string const path = "C:/game/WHITE_ALBUM2_-introductory_chapter-/WHITE ALBUM2 -introductory chapter-/tmp/";
    //fn = "tv100100.tga"; // 
    for (auto fn : fns) decode_tga(path+fn, path+"_"+fn);
    return 0;
}



int main()
{
    try {return tmain();}
    catch(...) {return -1;}
}



