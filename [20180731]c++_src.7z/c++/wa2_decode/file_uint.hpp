

#ifndef FILE_UINT_HPP
#define FILE_UINT_HPP

#include <climits> // CHAR_BIT
#include <cstddef> // size_t
//#include <iosfwd>
//#include <ios>
#include <istream>
#include <ostream>
//#include "file_uint.hpp"

/*
    file_read_LE<uint32_t>(istr);
*/


template<typename T> T file_read_LE(std::istream&);
template<typename T> void file_write_LE(std::ostream&, T);
template<typename T> T file_read_BE(std::istream&);
template<typename T> void file_write_BE(std::ostream&, T);


template<typename T> T file_read_LE(std::istream& istr)
{
    typedef T u_t;
    size_t const sz = sizeof(u_t);
    unsigned char buf[sz];
    istr.read((char*)buf, sz);
    u_t u = 0;
    auto p = buf + sz;
    while(buf != p)
    {
        --p;
        u <<= CHAR_BIT;
        u |= *p;
    }
    return u;
}

template<typename T> void file_write_LE(std::ostream& out, T const& t)
{
    typedef T u_t;
    size_t const sz = sizeof(u_t);
    unsigned char buf[sz];
    u_t u = t;
    for (auto p = buf; p != buf + sz; ++p)
    {
        *p = (unsigned char)u;
        u >>= CHAR_BIT;
    }
    out.write((char const*)buf, sz);
}


template<typename T> T file_read_BE(std::istream& istr)
{
    typedef T u_t;
    size_t const sz = sizeof(u_t);
    unsigned char buf[sz];
    istr.read((char*)buf, sz);
    u_t u = 0;
    for (auto p = buf; p != buf + sz; ++p)
    {
        u <<= CHAR_BIT;
        u |= *p;
    }
    return u;
}


template<typename T> void file_write_BE(std::ostream& out, T const& t)
{
    typedef T u_t;
    size_t const sz = sizeof(u_t);
    unsigned char buf[sz];
    u_t u = t;
    auto p = buf + sz;
    while(buf != p)
    {
        --p;
        *p = (unsigned char)u;
        u >>= CHAR_BIT;
    }
    out.write((char const*)buf, sz);
}


#endif//FILE_UINT_HPP
