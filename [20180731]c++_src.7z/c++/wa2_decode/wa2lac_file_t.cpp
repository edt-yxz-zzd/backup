
#include "wa2lac_file_t.hpp"
#include "file_uint.hpp"
#include "numeric_cast_assign.hpp"
#include "array_size_t.hpp"
#include <cstring>

//g++ -std=c++11 -pedantic -I%boost%  WA2PAK.cpp -c

//using namespace std;

// is xx file?
// init head
// get range of entries
// for e in rng: e.offset/length/fname/compressed


static std::string c_strn2string(char const* str, size_t n)
{
    std::string s(str, n); // s.length == n
    return s.c_str(); // .length <= n
}




size_t const lac_file_t::head_t::head_size;
size_t const lac_file_t::entry_t::entry_size;





/////////////////////////////////////////////////////
//string lac_file_t::read_label(istream&);
//bool lac_file_t::is_lac_file(istream&);
//lac_file_t::entry_range_t lac_file_t::get_entries_range(istream&);
/////////////////////////////////////////////////////
//lac_file_t::head_t::head_t(istream& istr);
/////////////////////////////////////////////////////
//void lac_file_t::entry_t::assign(istream& istr);
std::istream& operator >> (std::istream&, lac_file_t::entry_t&);
/////////////////////////////////////////////////////
//lac_file_t::inner_file_t::inner_file_t(istream& istr);





/////////////////////////////////////////////////////
std::string lac_file_t::read_label(std::istream& istr)
{
    //size_t const sz = get_array_size_of(get_file_type()); //!!! no!!! why this make ftype a variable length array?
    //size_t const sz = sizeof(string_of_array_size(get_file_type())); // this one works!
    size_t const sz = array_size_t<decltype(get_file_type())>::size;
    char ftype[sz] = {};
    istr.seekg(0);
    istr.read(ftype, sz);
    if (istr) return {ftype, sz};
    else return {};
}
bool lac_file_t::is_lac_file(istream& istr)
{
    string s = read_label(istr);
    return istr && s == string(get_file_type(), s.size());
}



lac_file_t::entry_range_t lac_file_t::get_entries_range(istream& istr)
{
    head_t head(istr);
    
    istream::streampos pos = 0;
    istream::streamoff sz = 0;
    istream::streamoff idx = 0;
    numeric_cast_assign(pos, head_t::head_size);
    numeric_cast_assign(sz, entry_t::entry_size);
    //inner_file_iter_t::array_head_t array{istr, sz, pos}; !!!this must be forbiden!!!
    inner_file_iter_t::array_head_t array{file_object_t{istr, pos, sz}};
    inner_file_iter_t iter{array, idx};
    
    numeric_cast_assign(idx, head.num_entries);
    inner_file_iter_t end{array, idx};
    
    if (overflow_mul(idx, sz))
        throw string("fail: overflow");
    return {iter, end};
}




/////////////////////////////////////////////////////
lac_file_t::head_t::head_t(istream& istr)
{
    if (!is_lac_file(istr)) throw string("not LAC file!");
    string s = read_label(istr);
    strncpy(ftype, s.c_str(), sizeof(ftype)/sizeof(char));
    num_entries = file_read_LE<uint32_t>(istr);
    if (!istr) throw string("fail: when read file");
}





/////////////////////////////////////////////////////
void lac_file_t::entry_t::assign(istream& istr)
{
    istr.read(fname, sizeof(fname));
    // istr >> entry.compressed; !!! error here !!!
    // istr.read(&entry.compressed, sizeof(entry.compressed));
    compressed = istr.get();
    length = file_read_LE<uint32_t>(istr);
    offset = file_read_LE<uint32_t>(istr);
    
    /// fname = ~fname
    for (auto& ch : fname) // ch = ~ch;
        if (!ch) break;
        else ch = ~ch;
}


std::istream& operator >> (std::istream& istr, lac_file_t::entry_t& e)
{
    e.assign(istr);
    return istr;
}





/////////////////////////////////////////////////////
lac_file_t::inner_file_t::inner_file_t(istream& istr)
{
    entry_t entry;
    istr >> entry;
    fname = c_strn2string(entry.fname, array_size_t<decltype(entry.fname)>::size);
    compressed = !!(entry.compressed);
    istream::streampos pos = 0;
    istream::streamoff sz = 0;
    numeric_cast_assign(pos, entry.offset);
    numeric_cast_assign(sz, entry.length);
    file = file_object_t(istr, pos, sz);
    if (!istr) throw string("fail: reading file@inner_file_t(istream&)");
}



