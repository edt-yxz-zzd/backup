
#ifndef RANGE_BASED_LOOP_HPP
#define RANGE_BASED_LOOP_HPP
//#include "range_based_loop.hpp"

/*
    for (auto& x : range_among(p, p+size))...
*/

template<typename IterTL, typename IterTR = IterTL>
class range_t
{
    IterTL iter_l;
    IterTR iter_r;
    public:
    range_t(IterTL iterl, IterTR iterr):iter_l(iterl), iter_r(iterr){}
    IterTL begin()const{return iter_l;}
    IterTR end()const{return iter_r;}
};

template<typename IterTL, typename IterTR>
    inline range_t<IterTL, IterTR> 
        range_among(IterTL iterl, IterTR iterr){return {iterl,iterr};}



#endif//RANGE_BASED_LOOP_HPP
