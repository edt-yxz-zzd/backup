

#ifndef WA2KCAP_FILE_T_HPP
#define WA2KCAP_FILE_T_HPP
//#include "wa2kcap_file_t.hpp"

#include "array_like_t.hpp"
#include "range_based_loop.hpp"
#include <cstdint> // uint32_t
#include <istream>
#include <ostream>
#include <string>
#include <cstddef> // size_t

struct kcap_file_t // file format of bgm.pak in white album 2 -ic-
{
    private: static const size_t format_label_length = 4;
    typedef std::ostream ostream;
    typedef std::istream istream;
    typedef std::streamoff streamoff;
    typedef std::streampos streampos;
    //typedef std::size_t size_t; !!!no std::size_t!!! it's a C type
    typedef std::uint32_t uint32_t;
    typedef std::string string;
    
    public: 
    static auto get_file_type() -> char const (&)[format_label_length]
        {static char const type[] = {'K','C','A','P'}; return type;}
    static string read_label(istream&);

    struct head_t 
    {
        char ftype[format_label_length]; // "KCAP"
        uint32_t x1_;
        uint32_t x2_;
        uint32_t num_entries;
        head_t(istream&);
        static const size_t head_size = sizeof(ftype) + sizeof(num_entries)
            + sizeof(x1_) + sizeof(x2_);
    };
    
    struct entry_t 
    {
        uint32_t compressed;
        char fname[24];
        uint32_t x1_;
        uint32_t x2_;
        uint32_t offset;
        uint32_t length;
        void assign(istream&);
        static const size_t entry_size = sizeof(fname) + sizeof(compressed)
            + sizeof(length) + sizeof(offset) + sizeof(x1_) + sizeof(x2_);
    };
    
    class inner_file_t
    {
        string fname;
        file_object_t file;
        bool compressed;
        public:
        inner_file_t(istream&);
        string get_file_name()const{return fname;}
        file_object_t const& get_file_object()const{return file;}
        string compression_method()const{return compressed? "lzss" : "";}
        streamoff get_inner_file_size()const{return file.size;}
        streamoff get_compressed_file_size()const;
        streamoff get_original_file_size()const;
    };

    static bool is_kcap_file(istream&);
    typedef array_like_t<
        inner_file_t, 
        file_object_array_t<inner_file_t>, 
        istream::streamoff
        > inner_file_iter_t;
    typedef range_t<inner_file_iter_t> entry_range_t;
    static entry_range_t get_entries_range(istream&);

};

std::istream& operator >> (std::istream&, kcap_file_t::entry_t&);



#endif//WA2KCAP_FILE_T_HPP
