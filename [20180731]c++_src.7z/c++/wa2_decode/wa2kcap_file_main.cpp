
#include "wa2kcap_file_t.hpp"
#include <iostream> // cout
#include <fstream>
#include <vector>




//g++ -std=c++11 -pedantic -I%boost%  WA2PAK.cpp -c

//using namespace std;

// is xx file?
// init head
// get range of entries
// for e in rng: e.offset/length/fname/compressed





std::vector<std::string> dir_kcap_file(std::istream& kcap);
void extract_kcap_inner_file(std::istream& kcap, std::string path);
//////////////////////////////////////////////////////////
static void ls_nc_kcap_file(std::ostream& out, std::istream& kcap);
static void ls_n_kcap_file(std::ostream& out, std::istream& kcap);
int tmain(int argc, char* argv[]);



//////////////////////////////////////////////////////////
std::vector<std::string> dir_kcap_file(std::istream& kcap)
{
    std::vector<std::string> fnames;
    kcap.seekg(0);
    auto rng = kcap_file_t::get_entries_range(kcap);
    for (auto inner_file : rng)
        fnames.push_back(inner_file.get_file_name());
    return fnames;
}

template<typename PredicatorFunctor>
void extract_kcap_inner_file(std::istream& kcap, std::string path_prefix, PredicatorFunctor pred)
{
    auto rng = kcap_file_t::get_entries_range(kcap);
    for (auto inner_file : rng) {
        std::string fname = inner_file.get_file_name();
        if (!pred(fname)) continue;
        std::ofstream fout(path_prefix + fname, std::ofstream::out | std::ofstream::binary);
        fout << inner_file.get_file_object();
    }

}

//////////////////////////////////////////////////////////
static void ls_fns_kcap_file(std::ostream& out, std::istream& kcap)
{ // filter fname size
    using std::string;
    using std::ofstream;
    //const string fn0 = "tv000000.tga";
    const string path = "./tmp/";
    std::streamoff total = 0;
    kcap.seekg(0);
    auto rng = kcap_file_t::get_entries_range(kcap);
    for (auto inner_file : rng){
        auto fn = inner_file.get_file_name();
        //if (fn.size() < fn0.size() || string(fn.c_str(), 2) != "tv") continue;
        auto sz = inner_file.get_inner_file_size();
        out << fn << ' ' <<  sz << ' ' 
            << inner_file.compression_method() << std::endl;
        total += sz;
        bool nocompress = string("") == inner_file.compression_method();
        ofstream fout(path + fn + (nocompress?"XX":""), ofstream::out | ofstream::binary);
        if (!fout){throw string("fail write open!");}
        fout << inner_file.get_file_object();
    }
    out << "total: " << total << std::endl;
}

static void ls_nc_kcap_file(std::ostream& out, std::istream& kcap)
{ // fname compression_method
    kcap.seekg(0);
    auto rng = kcap_file_t::get_entries_range(kcap);
    for (auto inner_file : rng)
        out << inner_file.get_file_name() << ' ' 
            << inner_file.compression_method() << std::endl;
}


static void ls_n_kcap_file(std::ostream& out, std::istream& kcap)
{
    auto ls = dir_kcap_file(kcap);
    if  (!kcap) throw std::string("error...");
    for (auto const& name : ls)
        out << name << std::endl;
}

int tmain(int argc, char* argv[]) try
{
    std::vector<std::string> fnames(argv+1, argv + argc);
    for (auto const& fn : fnames){
        std::ifstream fin(fn, std::ifstream::in | std::ifstream::binary);
        if (!fin) throw "fail to open file:" + fn;
        ls_fns_kcap_file(std::cout, fin);
        //ls_nc_kcap_file(std::cout, fin);   
        //ls_n_kcap_file(std::cout, fin);      
        std::cout << std::endl;
    }
    return 0;
}
catch(const std::string& s)
{
    std::cerr << s << std::endl;
    throw;
}
catch(const char* s)
{
    std::cerr << s << std::endl;
    throw;
}



int main(int argc, char* argv[])
{
    try{
        return tmain(argc, argv);
    }
    catch(std::string&){
        return -1;
    }
}


