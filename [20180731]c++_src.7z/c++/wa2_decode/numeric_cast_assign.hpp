
#ifndef NUMERIC_CAST_ASSIGN_HPP
#define NUMERIC_CAST_ASSIGN_HPP
//#include "numeric_cast_assign.hpp"

#include <limits>
#include <boost/numeric/conversion/cast.hpp>
//using boost::numeric_cast;

template<typename T, typename S>
inline void numeric_cast_assign(T& t, S const& src){t = boost::numeric_cast<T>(src);}

//template<typename T, typename S> bool overflow_mul(T t, S s);
template<typename T> 
inline bool overflow_mul(T t, T s)
{
    return s != 0 && std::numeric_limits<T>::max()/s < t;
}

#endif//NUMERIC_CAST_ASSIGN_HPP
