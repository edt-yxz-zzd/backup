

#ifndef WA2LAC_FILE_T_HPP
#define WA2LAC_FILE_T_HPP
//#include "wa2lac_file_t.hpp"

#include "array_like_t.hpp"
#include "range_based_loop.hpp"
#include <cstdint> // uint32_t
#include <istream>
#include <ostream>
#include <string>
#include <cstddef> // size_t

struct lac_file_t // file format of bgm.pak in white album 2 -ic-
{
    private: static const size_t format_label_length = 4;
    typedef std::ostream ostream;
    typedef std::istream istream;
    typedef std::streamoff streamoff;
    typedef std::streampos streampos;
    //typedef std::size_t size_t; !!!no std::size_t!!! it's a C type
    typedef std::uint32_t uint32_t;
    typedef std::string string;
    
    public: 
    static auto get_file_type() -> char const (&)[format_label_length]
        {static char const type[] = "LAC"; return type;}
    static string read_label(istream&);

    struct head_t 
    {
        char ftype[format_label_length]; // "LAC"
        uint32_t num_entries;
        head_t(istream&);
        static const size_t head_size = sizeof(ftype) + sizeof(num_entries);
        //enum : size_t {head_size = sizeof(ftype) + sizeof(num_entries)};
    };
    
    struct entry_t 
    {
        char fname[31];
        char compressed;
        uint32_t length;
        uint32_t offset;
        void assign(istream&);
        static const size_t entry_size = sizeof(fname) + sizeof(compressed)
            + sizeof(length) + sizeof(offset);
    };
    
    class inner_file_t
    {
        string fname;
        file_object_t file;
        bool compressed;
        public:
        inner_file_t(istream&);
        string get_file_name()const{return fname;}
        file_object_t const& get_file_object()const{return file;}
        string compression_method()const{return compressed? "lzss" : "";}
        streamoff get_inner_file_size()const{return file.size;}
        streamoff get_compressed_file_size()const;
        streamoff get_original_file_size()const;
    };

    static bool is_lac_file(istream&);
    typedef array_like_t<
        inner_file_t, 
        file_object_array_t<inner_file_t>, 
        istream::streamoff
        > inner_file_iter_t;
    typedef range_t<inner_file_iter_t> entry_range_t;
    static entry_range_t get_entries_range(istream&);

};

std::istream& operator >> (std::istream&, lac_file_t::entry_t&);



#endif//WA2LAC_FILE_T_HPP
