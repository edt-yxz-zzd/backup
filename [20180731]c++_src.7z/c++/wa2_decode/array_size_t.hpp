
#ifndef ARRAY_SIZE_T_HPP
#define ARRAY_SIZE_T_HPP
//#include "array_size_t.hpp"
//g++ -std=c++11 -pedantic -I%boost%  -c


/*
    let T = decltype(expr) be a array A[sz]
    array_size_t<T>::size        // size_t sz
    array_size_t<T>::element_t   // A&
*/








//template<typename T, size_t sz> // constexpr doesn't work!!
//    constexpr size_t get_array_size_of(T const(&)[sz]){return sz;}

//template<typename T, size_t sz>struct array_t{typedef T type[sz];};
template<typename T, size_t sz>
    //typename array_t<char,sz>::type& string_of_array_size(T const(&)[sz]);
    auto string_of_array_size(T const(&)[sz])->T(&)[sz];
template<typename T, size_t sz>
    T& element_of_array(T const(&)[sz]);
template <typename T> T& object_of();//{throw "non-implement!";}
template <typename T>
struct array_size_t
{
    typedef T array_t;
    typedef decltype(element_of_array(object_of<T>())) element_t;
    static size_t const size = sizeof(string_of_array_size(object_of<T>()))/sizeof(char);
};


#endif//ARRAY_SIZE_T_HPP

