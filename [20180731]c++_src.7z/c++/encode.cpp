#include <cerrno>
#include <cassert>
#include <iconv.h>
#include <iostream>
#include <algorithm>    // std::copy
#include <fstream>
#include <string>
#include <vector>
#include <stdexcept>

using std::size_t;
using std::vector;
using std::cin;
using std::cout;
using std::istream;
using std::string;

class scoped_errno
{
    typedef decltype(errno) err_t;
    err_t err;
public:
    scoped_errno():err(errno){}
    ~scoped_errno(){errno = err;}
};




struct iconv_error : public std::runtime_error
{
    explicit iconv_error(const string& what_arg)
        :runtime_error(what_arg){}
};

struct iconv_construct_error : public iconv_error
{
    explicit iconv_construct_error(const string& what_arg)
        :iconv_error(what_arg){}
};

struct iconv_invalid_error : public iconv_error
{
    explicit iconv_invalid_error(const string& what_arg)
        :iconv_error(what_arg){}
};

struct iconv_incomplete_error : public iconv_error
{
    explicit iconv_incomplete_error(const string& what_arg)
        :iconv_error(what_arg){}
};

struct iconv_unknown_error : public iconv_error
{
    explicit iconv_unknown_error(const string& what_arg)
        :iconv_error(what_arg){}
};


class scoped_iconv
{
    typedef iconv_t scoped_t;
    scoped_t cd;
public:
    scoped_iconv(const char* tocode, const char* fromcode)
        :cd(iconv_open(tocode, fromcode))
    {
        if ((decltype(cd))(-1) == cd)
        {
            throw iconv_construct_error(std::string() + 
                "The conversion from <" + fromcode + "> to <" + tocode + "> is not supported by the implementation."
            );
        }
    }
    ~scoped_iconv(){iconv_close(cd);}
    scoped_t get()const{return cd;}
};


bool do_partial_conv(iconv_t cd, vector<char> const& in, vector<char>& out); // return whether complete; throw if bad conversion
bool do_stream_conv(iconv_t cd, istream& in, vector<char>& out);//istream& read (char* s, streamsize n);streamsize gcount() const;
void reset(iconv_t cd);
class encoding_conversion_t : public scoped_iconv
{
public:
    typedef std::string string;
    encoding_conversion_t(std::string const& tocode, std::string const& fromcode)
        : scoped_iconv(tocode.c_str(), fromcode.c_str()){}
    
    void reset(){iconv(get(), NULL, NULL, NULL, NULL);}
    string incremental_converse(string const& frombytes);
    bool is_incomplete()const;
    string get_input_bytes_left()const;
    
    string converse(string const& frombytes);
    string converse(istream& frombytes);
    
private:
    string inbytesleft;
};


class u32conversion_t : public std::u32string // encoding_conversion_t
{
    typedef std::string string;
    typedef std::string bytes_t;
    typedef std::u32string chars_t;
    static bytes_t encode(string const& tocode, chars_t const& from_string);
    static chars_t decode(string const& fromcode, bytes_t const& from_bytes);
    bytes_t encode(string const& tocode);
    
};



void reset(iconv_t cd)
{
    iconv(cd, NULL, NULL, NULL, NULL);
}


// return whether incomplete; throw if invalid 
vector<char> do_partial_conv(iconv_t cd, char* in, size_t in_size, vector<char>& out)
{
    scoped_errno _errno_holder;
    int const outbuf_size = 0x400;
    
    char outbuf[outbuf_size];
    char* pout = outbuf;
    size_t out_left = outbuf_size;
    
    char* inbuf = in; // in.data();
    char* pin = inbuf;
    size_t in_left = in_size; // in.size();
    
    vector<char> tmp;
    // (size_t)(-1) !! WTF !!
    while((size_t)(-1) == iconv(cd, &pin, &in_left, &pout, &out_left))
    {
        if (EINVAL == errno) break;
        else if (E2BIG == errno)
        {
            tmp.insert(tmp.end(), outbuf, pout);
            pout = outbuf;
            out_left = outbuf_size;
            continue;
        }
        else if (EILSEQ == errno)
        {
            throw iconv_invalid_error(
                "An invalid multibyte sequence is encountered in the input.");
        }
        else
        {
            throw iconv_unknown_error("unknown case...");
        }
    }
    
    // std::cerr << in_left << ' ' << errno << std::endl;
    // std::cerr << EINVAL << ' ' << E2BIG << ' ' << EILSEQ << std::endl;
    assert(EINVAL == errno || 0 == in_left);
    tmp.insert(tmp.end(), outbuf, pout);
    out.insert(out.end(), tmp.begin(), tmp.end());
    return vector<char>(in + in_size - in_left, in + in_size);
}

//istream& read (char* s, streamsize n);streamsize gcount() const;
vector<char> do_istream_conv(iconv_t cd, istream& in)
{
    vector<char> tmp;
    int const buf_size = 0x400;
    
    char buf[buf_size];
    char* pbuf = buf;
    size_t buf_left = buf_size;
    while(in.read(pbuf, buf_left))
    {
        auto left = do_partial_conv(cd, buf, buf_size, tmp);
        pbuf = std::copy(left.begin(), left.end(), buf);
        buf_left = buf_size - left.size();
    }
    
    if (in.eof())
    {
        auto left = do_partial_conv(cd, buf, in.gcount(), tmp);
        if (left.empty()) return tmp;
    }
    
    throw iconv_incomplete_error("fail of file or An incomplete multibyte sequence is encountered in the input stream");
}

// g++ -std=c++11 encode.cpp -liconv
// UTF-16LE UTF-8 GB18030
// encode::= iconv -t <encoding> -f UTF-32LE <<utf32le.txt> ><encoding.txt>
// decode::= iconv -t UTF-32LE -f <encoding> <<encoding.txt> ><utf32le.txt>
int t_main(int argc, char* argv[])
{
    assert(3 == argc);
    scoped_iconv cd(argv[1], argv[2]);
    auto tmp = do_istream_conv(cd.get(), cin);
    cout.write(tmp.data(), tmp.size());
    return 0;
}

int main(int argc, char* argv[])
{
    try
    {
        return t_main(argc, argv);
    }
    catch(std::exception& e)
    {
        std::cerr << e.what() << std::endl;
        return 1;
    }
}


/*
The values permitted for fromcode and tocode and the supported combinations are system dependent. For the libiconv library, the following encodings are supported, in all combinations.

European languages

ASCII, ISO-8859-{1,2,3,4,5,7,9,10,13,14,15,16}, KOI8-R, KOI8-U, KOI8-RU, CP{1250,1251,1252,1253,1254,1257}, CP{850,866,1131}, Mac{Roman,CentralEurope,Iceland,Croatian,Romania}, Mac{Cyrillic,Ukraine,Greek,Turkish}, Macintosh

Semitic languages

ISO-8859-{6,8}, CP{1255,1256}, CP862, Mac{Hebrew,Arabic}

Japanese

EUC-JP, SHIFT_JIS, CP932, ISO-2022-JP, ISO-2022-JP-2, ISO-2022-JP-1

Chinese

EUC-CN, HZ, GBK, CP936, GB18030, EUC-TW, BIG5, CP950, BIG5-HKSCS, BIG5-HKSCS:2001, BIG5-HKSCS:1999, ISO-2022-CN, ISO-2022-CN-EXT

Korean

EUC-KR, CP949, ISO-2022-KR, JOHAB

Armenian

ARMSCII-8

Georgian

Georgian-Academy, Georgian-PS

Tajik

KOI8-T

Kazakh

PT154, RK1048

Thai

TIS-620, CP874, MacThai

Laotian

MuleLao-1, CP1133

Vietnamese

VISCII, TCVN, CP1258

Platform specifics

HP-ROMAN8, NEXTSTEP

Full Unicode

UTF-8

UCS-2, UCS-2BE, UCS-2LE

UCS-4, UCS-4BE, UCS-4LE

UTF-16, UTF-16BE, UTF-16LE

UTF-32, UTF-32BE, UTF-32LE

UTF-7

C99, JAVA

Full Unicode, in terms of uint16_t or uint32_t

(with machine dependent endianness and alignment)

UCS-2-INTERNAL, UCS-4-INTERNAL

Locale dependent, in terms of char or wchar_t

(with machine dependent endianness and alignment, and with semantics depending on the OS and the current LC_CTYPE locale facet)

char, wchar_t
*/