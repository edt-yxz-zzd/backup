
#include <cstdlib>
#include <cstdio>

typedef int (*f_t)(void*);
int call(f_t func, void* data, void* stack); // call func(data) on stack!!


int call(f_t f, void* data, void* buffer_end)
{
    // push ebp; outer
    // mov esp->ebp;
    // mov ebp->stack -> esp; using new stack!
    // push ebp->data // make them as input for f
    
    // call f;
    // leave
    __asm__(
        //"pushl  %ebp    ; "
        //"movl   %esp,      %ebp; "
        //"movl   16(%ebp),  %esp; " // stack
        "movl "
        "andl   $-16,      %esp; " // zero lower 4 bits
        "subl	$16,       %esp; "
        /*
        "movl   16(%ebp),  %eax; "
        "movl   %eax,      8(%esp); "
        "movl   12(%ebp),  %eax; "
        "movl   %eax,      4(%esp); "
        "movl   8(%ebp),   %eax; "
        "movl   %eax,      (%esp); "
        "call	*%eax; "
        "leave; "
        "ret; " */
    );
    return (*f)(data);
}


int f(void*)
{
    int s[100];
    printf("%p\n", s);
    for (int i = 0; i < 100; ++i)
        s[i] = i;
    return 0;
}


int main()
{
    void* s = malloc(10000);
    printf("%p\n", &s);
    printf("%p\n", s);
    void* t = (char*)s+10000-1;
    //call(f, 0, t);
    printf("%d\n", call(f, 0, t));
    f(0);
    
    for (int i = 2390; i < 2500; ++i)
        printf("%d\n", i[(int*)s]);
    free(s);
    return 0;
}

