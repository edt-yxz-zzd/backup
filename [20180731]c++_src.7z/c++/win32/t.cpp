#define _WIN32_WINNT 0x400
#include <windows.h>
#include <iostream>
#include <string>

using namespace std;
#define wchar_t char
int main()
{
    HWND hwnd = (HWND)3802898;
    int win_len = GetWindowTextLength(hwnd);
    string win_name;
    if(win_len > 0) {
      win_name = string(sizeof(wchar_t) * (win_len + 1), '!');
      GetWindowText(hwnd, &win_name[0], sizeof(wchar_t) * (win_len + 1));
    }

    cout << hwnd << ' ' << win_len << ' ' << win_name << endl;
    for(int i=0; i<win_name.size();i++)cout<<win_name[i]<<' ';
    for(int i=0; i<win_name.size();i++)cout<<int(win_name[i])<<' ';
}
