
#include <stdio.h>

int main(int argn, char *argv[])
{
    /* fecho_fix.exe xxxxxxxx */
    const int skipN = 0;
    /*if (argn < skipN) return 1; /* error */
    argv += skipN;
    const char *fname = "c:/fecho_fix.out.txt";
    FILE* fout = fopen(fname, "ab");
	while(argn --> skipN){
	   fputs(argv++[0], fout);
	   fputc('\n', fout);
	}
	fclose(fout);
	return 0;
}
