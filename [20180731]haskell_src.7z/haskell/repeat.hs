
a = 0:a
-- b = a



c = take 3 a

main = return $ show c


