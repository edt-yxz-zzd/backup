
-- getMember record gettor = gettor record
(/.) :: a -> (a->b) -> b
a /. a2b = a2b a
-- why be 0? infixl 1000000000000000000000000000000000000000 /.
-- why max 9?
-- infixl 9 /.


