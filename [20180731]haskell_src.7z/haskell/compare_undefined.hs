
a = undefined :: Int
b = undefined :: Int
c = 1 :: Int

-- a == b -- Parse error: naked expression at top level

r = a == b -- when show: *** Exception: Prelude.undefined