module Try_polymorphism2 where

f :: [a] -> a
f = head

