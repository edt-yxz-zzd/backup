
-- fails:

(i :: Int) = 1
i :: Integer = 2

