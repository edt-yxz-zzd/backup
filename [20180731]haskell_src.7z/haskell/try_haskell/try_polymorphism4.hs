
-- fails:

i = 1 :: Int
i = 2 :: Integer

