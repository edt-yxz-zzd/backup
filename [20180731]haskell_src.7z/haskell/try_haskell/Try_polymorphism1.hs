
module Try_polymorphism1 where
f :: (a, b) -> a
f = fst


