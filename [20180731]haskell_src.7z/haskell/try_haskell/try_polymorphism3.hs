-- fails:


import Try_polymorphism1
import Try_polymorphism2

i = f (1,2)

j = f [1,2]

