

module1:
    class Get a b | a -> b
    data Policy
    data UsingXXX
    instance Get Policy UsingXXX

module2:
    instance Policy UsingYYY -- override UsingXXX??