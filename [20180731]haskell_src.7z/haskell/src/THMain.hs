
import TH.PrintQ
import TH.Transform
import TH.Data2Doc
import TH.SeedUtils
import TH.DefNew
import qualified TH.TryTransform as TT
main = TT.main


