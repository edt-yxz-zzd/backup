{-# LANGUAGE TemplateHaskell #-}

module IntDefs.IntGe1 (IntGe1())
where


import IntDefs.IntGeX_tpl (defs)


$(defs 1)



