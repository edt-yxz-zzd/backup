
import ADT.OpUncurry
{-
import Control.Arrow
import ADT.IPair
import ADT.IFunctorBy
import ADT.IFunctorA
import ADT.IArrowBy
import ADT.ISemigroupBy
import ADT.IMonoidBy
--import ADT.IArrowExit
import ADT.IArrowEE
import ADT.IArrowCatch
import ADT.IArrowState
import ADT.IArrowRandom
import ADT.IGenerater
import ADT.IArrowLift
import ADT.IArrowSuccessBy
import ADT.OpDefaultValue
import ADT.OpArrowPlusBy
import ADT.IArrowCount
--import ADT.ArrowXO
--import ADT.MonadError


--class (Functor (arr *)) => A arr
--class (Functor (arr _)) => A arr
--}
--}
--}
--}
--}
--}
--}
--}
--}
