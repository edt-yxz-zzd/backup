
import IntDefs.IntDefs
import IntDefs.IntGe
import IntDefs.IntGe0
import IntDefs.IntGe1
import IntDefs.IntGe2
import IntDefs.IntGe3
import IntDefs.IntGeX_tpl
import IntDefs.DNat
{-
import IntDefs.UInt
import IntDefs.PInt
import IntDefs.QInt
-}


