
module ListDefs.List0x
where

type List0x = []


