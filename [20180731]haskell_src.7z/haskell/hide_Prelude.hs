
import qualified Prelude as P
-- if not hidden Prelude, 1+1 will be ambiguous
(+) :: a -> a -> a
a+b = a


