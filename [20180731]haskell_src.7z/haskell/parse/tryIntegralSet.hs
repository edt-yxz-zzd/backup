import IntegralSet
import Container
-- Not in scope: data constructor `IntegralSet'
--  module IntegralSet (IntegralSet, ...) where...
-- i = IntegralSet empty

e, s :: IntegralSet Integer
e = empty
s = singleton 1
