//package chapter4;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import javax.swing.*;

public class Life extends JApplet {
  public static void main(String s[]){
    JFrame frame = new JFrame();
    frame.setTitle("Life");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    JApplet applet = new Life();
    applet.init();
    frame.getContentPane().add(applet);
    frame.pack();
    frame.setVisible(true);
  }
  public void init(){
    JPanel panel = new LifePanel();
    getContentPane().add(panel);
  }
}


class LifePanel extends JPanel implements ActionListener {
  int n = 50; // n*n
  int c = 16;
  int len = n*c;
  
  boolean[][] cells_curr;
  boolean[][] cells_next;
  
  public LifePanel() {
    setPreferredSize(new Dimension(len, len));
    setBackground(Color.white);
    cells_curr = new boolean[n][n];
    cells_next = new boolean[n][n];
    
    for (int i = 0; i < n; i++) {
      for (int j = 0; j < n; j++) {
        cells_curr[i][j] = Math.random() < 0.1;
        cells_next[i][j] = false;
      }
    }
    
    Timer t = new Timer(1000, this);
    t.start();
    
  }
  
  
  public void paintComponent(Graphics g) {
    super.paintComponent(g);
    Graphics2D g2 = (Graphics2D)g;
    g2.setColor(Color.lightGray);
    int p = 0;
    for (int i = 0; i < n; i++) {
      g2.drawLine(0, p, len, p);
      g2.drawLine(p, 0, p, len);
      p += c;
    }
    
    g2.setColor(Color.black);
    for (int i = 0; i < n; i++) {
      for (int j = 0; j < n; j++) {
        if (cells_curr[i][j]) {
          int x = i*c;
          int y = j*c;
          g2.fillOval(x, y, c, c);
        }
      }
    }
  }
  
  public void actionPerformed(ActionEvent e){
    boolean[][] cells = cells_curr;
    for (int i = 0; i < n; i++) {
      for (int j = 0; j < n; j++) {
        cells_next[i][j] = cells[i][j];
        int nb = neighbors(cells, i, j);
        if (nb == 3)
          cells_next[i][j] = true;
        else if (nb != 2) 
          cells_next[i][j] = false;
      }
    }
    
    cells_curr = cells_next;
    cells_next = cells;
    
    repaint();
  }
  
  private int neighbors(boolean[][] cells, int x, int y) {
    int x0 = (x>0)? x-1:x;
    int x1 = (x<n-1)? x+2:x+1;
    int y0 = (y>0)? y-1:y;
    int y1 = (y<n-1)? y+2:y+1;
    
    int count = 0;
    for (int i = x0; i < x1; i++) {
      for (int j = y0; j < y1; j++) {
        if (cells[i][j]) count++;
      }
    }
    
    if (cells[x][y]) count--;
    return count;
  }
        
}






















































































































































































