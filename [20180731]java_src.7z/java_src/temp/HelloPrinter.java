public class HelloPrinter
{
   public static void main(String[] args)
   {

    // Display a greeting in the console window

    System.out.println("Hello World");
   }
}

