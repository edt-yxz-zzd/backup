/*
    virtual i.e. polymorphism
    instance methods are all virtual
    but static mehtods and static/instance fields are not virtual
    
    output:
        static Super.f()
        Sub.g()
        static String Super.a
        String Super.b
*/



package try_java;

public class TryVirtual extends Base
{
    public static void main(String[] args)
    {
        Base ref = new TryVirtual();
        ref.f();
        ref.g();
        System.out.println(ref.a);
        System.out.println(ref.b);
    }
    public static void f()
    {
        System.out.println("static Sub.f()");
    }
    public void g()
    {
        System.out.println("Sub.g()");
    }
    
    public static String a = "static String Sub.a";
    public String b = "String Sub.b";
}

class Base
{
    public static void f()
    {
        System.out.println("static Super.f()");
    }
    public void g()
    {
        System.out.println("Super.g()");
    }
    
    public static String a = "static String Super.a";
    public String b = "String Super.b";
}



