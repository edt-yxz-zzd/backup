
import java.util.logging.Logger;
import static java.util.logging.Level.*;
import java.util.logging.ConsoleHandler;
import java.util.logging.Handler;




class try_logger {
    public static void main(String[] args){
        Logger.getGlobal().info("logging... info");
        
        Logger.getGlobal().setLevel(ALL);
        Handler h = new ConsoleHandler();
        h.setLevel(ALL);
        Logger.getGlobal().addHandler(h);


        Logger.getGlobal().finest("logging... finest");
        Logger.getGlobal().finest(()->"logging by supplier... finest");
    }
}