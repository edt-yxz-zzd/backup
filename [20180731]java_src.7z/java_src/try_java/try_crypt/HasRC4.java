package try_java.try_crypt;
import javax.crypto.Cipher;
import java.security.NoSuchAlgorithmException;

public class HasRC4 {
    static void println(Object... ss){
        for (Object s : ss)
            System.out.println(s);
    }
    static void print(Object... ss){
        for (Object s : ss){
            System.out.print(s);
            System.out.print("  ");
        }
        System.out.println();
    }
    public static void main(String[] args){
        System.out.println("");
        try {
            Cipher c = Cipher.getInstance("RC4");
            if (c == null) println("fail");
            else print("success");
        } catch (Exception e){
            println(e);
        }
    }
}

