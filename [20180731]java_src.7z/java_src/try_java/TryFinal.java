package try_java;
// immutable reference, but object is mutable

public class TryFinal{
    public static void main(String[] args){
        String s = "abc";
        System.out.println(s);
        //s[0] = '5'; // try_java\TryFinal.java:7: ����: ��Ҫ����, ���ҵ�String
        
        final TryFinal ref = new TryFinal();
        System.out.println(ref.i);
        ref.i = 3;
        System.out.println(ref.i);
        System.exit(0);
    }
    
    public TryFinal(int j){i=j;}
    public TryFinal(){this(0);}
    
    int i;
}