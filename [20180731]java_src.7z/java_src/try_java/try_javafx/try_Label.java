
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.Parent;

import javafx.beans.binding.Bindings;
import javafx.scene.control.Label;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.paint.Color;
import javafx.scene.layout.Pane;

// Node::public boolean isResizable()

public class try_Label extends Application {
    public void start(final Stage stage){
        Label a = new Label("afa/faf/ffffffffffffffffffffffffffffff");
        Pane pane = new Pane(a);
        Scene scene = new Scene(pane);
        stage.setScene(scene);
        stage.show();
        
        // background color
        BackgroundFill fill = new BackgroundFill(Color.RED, null, null);
        a.setBackground(new Background(fill));
        
        // fixed
        a.minWidthProperty().bind(Bindings.divide(pane.widthProperty(), 2));
        a.maxWidthProperty().bind(Bindings.divide(pane.widthProperty(), 2));
        a.minHeightProperty().bind(Bindings.divide(pane.heightProperty(), 2));
        a.maxHeightProperty().bind(Bindings.divide(pane.heightProperty(), 2));
        //a.maxWidthProperty(a.getPrefWidth());
    }
}


