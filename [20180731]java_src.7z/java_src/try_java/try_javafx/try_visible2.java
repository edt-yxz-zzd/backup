
/*
    try_visible2
        no matter whether the rectangle is hidden, 
            computeAreaInScreen == 120000

*/

import javafx.beans.property.ReadOnlyDoubleProperty;
import javafx.beans.property.DoubleProperty;
import javafx.geometry.Bounds;

import javafx.scene.control.ScrollPane; 
import javafx.scene.layout.VBox;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.Region;
import javafx.scene.shape.Rectangle;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.application.Application;

import javafx.scene.paint.Color;
//import static seed.BackgroundColorSettor.*;

public class try_visible2 extends Application {

    static void print(Object... ss){
        for (Object s : ss)
            System.out.println(s);
    }
    public void start(final Stage stage){
        System.out.println("");
        int width = 300;
        int height = 400;
        final Rectangle r1 = new Rectangle(width, height, Color.RED);
        final Rectangle r2 = new Rectangle(width, height, Color.GREEN);
        final Rectangle r3 = new Rectangle(width, height, Color.BLUE);
        
        final VBox vbox = new VBox(r1, r2, r3);
        final ScrollPane pane = new ScrollPane(vbox);
        Scene scene = new Scene(pane);
        stage.setScene(scene);
        stage.show();
        
        
        pane.viewportBoundsProperty().addListener(
            (observable, oldValue, newValue) -> {

                for (int i = 0; i < vbox.getChildren().size(); ++i){
                    Node r = vbox.getChildren().get(i);
                    print(r.computeAreaInScreen());
                }
            }
        );


    }
}





