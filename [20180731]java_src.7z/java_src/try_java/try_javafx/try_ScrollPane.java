

import javafx.beans.property.ReadOnlyDoubleProperty;
import javafx.beans.property.DoubleProperty;
import javafx.geometry.Bounds;
import javafx.geometry.BoundingBox;

import javafx.scene.control.ScrollPane; 
import javafx.scene.layout.VBox;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.Region;
import javafx.scene.shape.Rectangle;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.application.Application;

import javafx.scene.paint.Color;
//import static seed.BackgroundColorSettor.*;

public class try_ScrollPane extends Application {

    static void print(Object... ss){
        for (Object s : ss){
            System.out.print(s);
            System.out.print("  ");
        }
        System.out.println();
    }
    
    public static Bounds trasformBounds(Bounds b){
        // maxY = h - miny = maxy - 2*miny
        
        double width = b.getWidth();
        double height = b.getHeight();
        double depth = b.getDepth();
        
        //double maxX = b.width - b.minX;
        double minX = width - b.getMaxX();
        
        //double maxY = b.height - b.minY;
        double minY = height - b.getMaxY();
        
        //double maxZ = b.depth - b.minZ;
        double minZ = depth - b.getMaxZ();
        return new BoundingBox(minX, minY, minZ, width, height, depth);
    }
    
    public void start(final Stage stage){
        System.out.println("");
        int width = 300;
        int height = 400;
        final Rectangle r1 = new Rectangle(width, height, Color.RED);
        final Rectangle r2 = new Rectangle(width, height, Color.GREEN);
        final Rectangle r3 = new Rectangle(width, height, Color.BLUE);
        
        final VBox vbox = new VBox(r1, r2, r3);
        final ScrollPane pane = new ScrollPane(vbox);
        Scene scene = new Scene(pane);
        stage.setScene(scene);
        stage.show();
        
        /*
        viewportBounds:: .minY + .height == .maxY
        when thumb at top most
            viewportBounds.minY == 0 
            // miny = 0 ==>> maxY = h
            .maxY = .height
        when thumb at buttom
            viewportBounds.minY == - (vbox.height - viewportBounds.height)
            // miny = -(H-h) = h-H ==>> maxY = H
            .maxY = 2 * .height - vbox.height # meanling less !!!
        when scrolling till finish
            do not trigger viewportBoundsProperty!
            but if focus other program, viewportBoundsProperty varies!!
        
        [miny = 0 ==>> maxY = h][miny = -(H-h) = h-H ==>> maxY = H]
            ==>> maxY = h - miny = maxy - 2*miny
            Y is y in vbox coordinate
            h is view.height = maxy-miny
            H is vbox.height
            
        
        */
        pane.viewportBoundsProperty().addListener(
                        (observable, oldValue, newValue) -> {
                            //print("width:", oldValue, newValue);
                            //print("vbox.sceneToLocal(ViewPortBounds):", vbox.sceneToLocal(pane.getViewPortBounds()));
                            //print("vbox.getBoundsInLocal():", vbox.getBoundsInLocal());
                            //print("vbox.parentToLocal(viewportBounds):", vbox.parentToLocal(pane.getViewportBounds()));
                            
                            print("  ", r2.getBoundsInParent());
                            print("transformed viewportBounds", trasformBounds(pane.getViewportBounds()));
                            assert vbox.getBoundsInLocal().equals(vbox.parentToLocal(pane.getViewportBounds()));
                            print();

                            if (false)for (int i = 0; i < vbox.getChildren().size(); ++i){
                                Node r = vbox.getChildren().get(i);
                                print(i);
                                //print("  ", r.getBoundsInLocal());
                                //print("  ", r.getLayoutBounds());
                                
                                // right one !!!
                                print("  ", r.getBoundsInParent());
                            }
                        }
                    );
    }
}





