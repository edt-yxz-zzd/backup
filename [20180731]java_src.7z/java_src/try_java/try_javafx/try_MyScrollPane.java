

import javafx.beans.property.ReadOnlyDoubleProperty;
import javafx.beans.property.DoubleProperty;
import javafx.geometry.Bounds;

import javafx.scene.control.ScrollPane; 
import javafx.scene.layout.VBox;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.Region;
import javafx.scene.shape.Rectangle;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.application.Application;

import javafx.scene.paint.Color;
import java.util.function.Consumer;







import javafx.beans.property.ObjectProperty;
import javafx.scene.Node;
import javafx.scene.SubScene;
import javafx.scene.layout.Pane;




public class SubSceneResizer extends Pane {
    private SubScene subScene;
    private final Node controlsPanel;

    public SubSceneResizer(SubScene subScene, Node controlsPanel) {
        this.subScene = subScene;
        this.controlsPanel = controlsPanel;
        setPrefSize(subScene.getWidth(),subScene.getHeight());
        setMinSize(50,50);
        setMaxSize(Double.MAX_VALUE,Double.MAX_VALUE);
        getChildren().addAll(subScene, controlsPanel);
    }

    public SubSceneResizer(ObjectProperty<SubScene> subScene, Node controlsPanel) {
        this.subScene = subScene.get();
        this.controlsPanel = controlsPanel;
        if (this.subScene != null) {
            setPrefSize(this.subScene.getWidth(),this.subScene.getHeight());
            getChildren().add(this.subScene);
        }
        subScene.addListener((o,old,newSubScene) -> {
            this.subScene = newSubScene;
            if (this.subScene != null) {
                setPrefSize(this.subScene.getWidth(),this.subScene.getHeight());
                if (getChildren().size() == 1) {
                    getChildren().add(0,this.subScene);
                } else {
                    getChildren().set(0,this.subScene);
                }
            }
        });
        setMinSize(50,50);
        setMaxSize(Double.MAX_VALUE,Double.MAX_VALUE);
        getChildren().add(controlsPanel);
    }

    @Override protected void layoutChildren() {
        final double width = getWidth();
        final double height = getHeight();
        if (subScene!=null) {
            subScene.setWidth(width);
            subScene.setHeight(height);
        }
        final int controlsWidth = (int)snapSize(controlsPanel.prefWidth(-1));
        final int controlsHeight = (int)snapSize(controlsPanel.prefHeight(-1));
        controlsPanel.resizeRelocate(width-controlsWidth,0,controlsWidth,controlsHeight);
    }
}


















@FunctionalInterface
interface Visitor<T> extends Consumer<T>{
}

interface MyScrollPaneVisible{
    void acceptMyScrollPaneVisitor(Consumer<Node> consumer);
}

class MyScrollPane extends Region {
    public MyScrollPane(){
        super();
    }
    // <? extends Node implements MyScrollPaneVisible>
    // <? extends Node & MyScrollPaneVisible>
    public MyScrollPane(<? extends Node> node){
        super(node);
    }
    
    protected void layoutChildren(){
        super().layoutChildren();
        getContent().layoutChildren();
    }
    /*
    getChildren, getChildrenUnmodifiable, getManagedChildren
    protected <E extends Node> List<E> getManagedChildren()
    public ObservableList<Node> getChildrenUnmodifiable()
    protected ObservableList<Node> getChildren()
    */
    
    public final void visitNodesInViewport(Consumer<Node> consumer){
        return getMyContent().acceptMyScrollPaneVisitor(visible then consumer);
    }
    
    protect final MyScrollPaneVisible getMyContent(){
        return (MyScrollPaneVisible) getContent();
    }

    public final Bounds getMyViewportBounds(){
        return transform(getViewportBounds());
    }

}


public class try_MyScrollPane extends Application {
    static void println(Object... ss){
        for (Object s : ss)
            System.out.println(s);
    }
    static void print(Object... ss){
        for (Object s : ss){
            System.out.print(s);
            System.out.print("  ");
        }
        System.out.println();
    }

    @Override
    public void start(final Stage stage){
        System.out.println("");
    }
}







