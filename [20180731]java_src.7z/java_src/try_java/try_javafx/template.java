


import javafx.beans.property.ReadOnlyDoubleProperty;
import javafx.beans.property.DoubleProperty;
import javafx.geometry.Bounds;

import javafx.scene.control.ScrollPane; 
import javafx.scene.layout.VBox;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.Region;
import javafx.scene.shape.Rectangle;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.application.Application;

import javafx.scene.paint.Color;
//import static seed.BackgroundColorSettor.*;

public class  extends Application {
    static void println(Object... ss){
        for (Object s : ss)
            System.out.println(s);
    }
    static void print(Object... ss){
        for (Object s : ss){
            System.out.print(s);
            System.out.print("  ");
        }
        System.out.println();
    }
    //public static void main(String[] args)
    @Override
    public void start(final Stage stage){
        System.out.println("");
    }
    //public void start(final Stage stage){}
}