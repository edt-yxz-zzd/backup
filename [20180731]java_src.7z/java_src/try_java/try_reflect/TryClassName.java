
import java.util.ArrayList;
import java.util.Arrays;


public class TryClassName{
    static <T> String to(T... args){
        return Arrays.toString(args);
    }
    public static void main(String[] args){
        ArrayList<? extends String> a = new ArrayList<>();
        assert a.getClass().getName().equals("java.util.ArrayList");
        assert a.getClass().getTypeParameters().equals(new String[]{"E"});
        assert a.getClass().toGenericString().equals("public class java.util.ArrayList<E>");
        System.out.println("6:" + 
            (a.getClass().toGenericString())
            );
    }
}