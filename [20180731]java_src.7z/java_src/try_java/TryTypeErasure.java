



public class TryTypeErasure<T>{
    public void f(Object b){
        assert b instanceof T; // fail at compile
        return;
    }
    public Object f(){
        return T.class; // fail at compile
    }
    public static void main(String[] args){
        System.out.println(new TryTypeErasure<String>().f());
    }
}