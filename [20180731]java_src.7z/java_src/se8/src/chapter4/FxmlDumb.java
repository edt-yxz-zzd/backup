package chapter4;

import java.io.File;
import java.net.URL;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import java.io.IOException;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.Parent;


import javafx.scene.control.Label;
import javafx.scene.text.Font;
import java.util.List;
import java.util.ArrayList;


public class FxmlDumb extends Application {
    public void start(Stage stage) {
        // File path = new File("../../fxml/FxmlDumb.fxml");
        String fname = "../fxml/FxmlDumb.fxml"; //path.getAbsolutePath();//getCanonicalPath();
        
        List<String> ls = this.getParameters().getUnnamed();
        if (ls.isEmpty()){
            ls = new ArrayList<String>();
            ls.add(fname);
        }
        
        for (String fn : ls)
        {
            this._start(fn, stage);
            //stage.close();
            //System.out.println("   success: " + fn);
            break;
        }
    }
    
    private void _start(String fname, Stage stage) {
        try {
            URL url = this.getClass().getResource(fname);
            if (url == null){
                System.err.println("not found fxml file : " + fname);
                return;
            }
            
            Parent root = FXMLLoader.load(url);
            stage.setScene(new Scene(root));
            stage.show();
            // stage.wait();
            if (false){
                String s = "";
                    System.out.println("here");
                stage.setOnHidden(event -> {synchronized (s) {s.notify();}});
                            System.out.println("here");
                synchronized (s) {s.wait();}
            }
            System.out.println("success: " + fname);
        } catch (Exception ex) {
            System.err.println(fname);
            System.err.println(ex);
            ex.printStackTrace();
            // System.exit(0);
        }
    }
}