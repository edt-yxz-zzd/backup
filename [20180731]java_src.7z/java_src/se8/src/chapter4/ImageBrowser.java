

package chapter4;

import javafx.stage.DirectoryChooser;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.VBox;

import java.io.File;
import java.net.URL;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import java.io.IOException;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.Parent;
import javafx.scene.Node;


import javafx.beans.binding.Bindings;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.text.Font;
import javafx.scene.shape.Rectangle;

/*
    Node:
        public Node lookup(String selector)
    
    Parent extends Node
        protected ObservableList<Node> getChildren()
        public ObservableList<Node> getChildrenUnmodifiable()
    
    Pane extends Parent
        public ObservableList<Node> getChildren()

    ScrollPane extends Control extends Parent
        protected ObservableList<Node> getChildren()
        
        assert scrollPane.getChildrenUnmodifiable().isEmpty();
        even when scrollPane.getContext() != null !!!!!!
        Java BUG:
            scrollPane.lookup(...) donot perform over scrollPane.getContext()!
*/



public class ImageBrowser extends Application {
    private void _init(Parent root){
    }

    
    public void start(Stage stage) {
        String fname = "../fxml/ImageBrowser.fxml";
            
        try {
            URL url = this.getClass().getResource(fname);
            if (url == null) 
                System.err.println("not found fxml file : " + fname);
            final Parent root = FXMLLoader.load(url);
            final ScrollPane pane = (ScrollPane) root;
            if (false){
            final VBox vbox = (VBox) pane.lookup("vbox");
            //final Button b = (Button) pane.lookup("#ok");
            //assert b != null;
            assert vbox != null;
            }

            {assert pane.getContent() != null;
            final VBox vbox = (VBox) pane.getContent();
            assert vbox != null;
            assert vbox.getChildren() != null;
            vbox.getChildren().add(new Rectangle(100.0, 100.0));
            // System.out.println(vbox.getId());
            assert vbox.getId().equals("vbox");
            assert pane.lookup("#vbox") == null; // why??
            assert ((Node)pane).lookup("#vbox") == null;
            assert vbox.lookup("#vbox") != null;
            assert pane.getChildrenUnmodifiable() != null;
            assert pane.getChildrenUnmodifiable().isEmpty();
            }
            
            stage.setScene(new Scene(root));
            stage.show();
            System.out.println("success: " + fname);
        } catch (Exception | AssertionError ex) {
            System.out.println(ex);
            System.out.println(fname);
            ex.printStackTrace();
            System.exit(0);
        }
    }
}
