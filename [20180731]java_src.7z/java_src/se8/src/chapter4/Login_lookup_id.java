package chapter4;

import java.io.File;
import java.net.URL;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import java.io.IOException;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.Parent;

import javafx.beans.binding.Bindings;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.text.Font;

public class Login_lookup_id extends Application {
    private void _init(Parent root){
            final TextField username = (TextField) root.lookup("#username");
            final PasswordField password = (PasswordField) root.lookup("#password");
            final Button ok = (Button) root.lookup("#ok");
            final Button cancel = (Button) root.lookup("#cancel");
            
            ok.disableProperty().bind(
                Bindings.createBooleanBinding(
                    () -> username.getText().length() == 0 
                    || password.getText().length() == 0,
                    username.textProperty(),
                    password.textProperty()));
            ok.setOnAction(event ->
                System.out.println("Verifying " + username.getText() + ":" + password.getText()));
            
            cancel.setOnAction(event -> this.onCancel());
    }
    
    //public void onOk(){}
    public void onCancel(){
        System.out.println("Cancel!");
        System.exit(0);
    }
    
    public void start(Stage stage) {
        String fname = "../fxml/Login_lookup_id.fxml"; //path.getAbsolutePath();//getCanonicalPath();
            
        try {
            URL url = this.getClass().getResource(fname);
            if (url == null) 
                System.err.println("not found fxml file : " + fname);
            Parent root = FXMLLoader.load(url);
            this._init(root);
            
            stage.setScene(new Scene(root));
            stage.show();
            System.out.println("success: " + fname);
        } catch (Exception ex) {
            System.out.println(ex);
            System.out.println(fname);
            ex.printStackTrace();
            System.exit(0);
        }
    }
}