package chapter4;


import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.application.Application;
import javafx.scene.layout.GridPane;


import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.Parent;

import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Button;

import java.io.IOException;



// private
abstract class Login_customFXML_ControlABC implements Initializable {
        @FXML protected TextField username;
        @FXML protected PasswordField password;
        //@FXML protected Button ok;
        //@FXML protected Button cancel;
        
        @FXML abstract protected void onOkAction(ActionEvent event);
        @FXML abstract protected void onCancelAction(ActionEvent event);
        
}

public class Login_customFXML extends Application {
    private class Login_customFXML_Control extends Login_customFXML_ControlABC
    {
        @Override
        public void initialize(URL url, ResourceBundle rb) {
        }
        @Override
        public void onOkAction(ActionEvent event) {
            System.out.println("Verifying " + username.getText() + 
                                           ":" + password.getText());
        }
        @Override
        public void onCancelAction(ActionEvent event) {
            System.out.println("Cancel...");
            stage.close();
        }
    }
    
    private Stage stage;
    public void start(final Stage stage) {
        this.stage = stage;
        String fname = "../fxml/Login_customFXML.fxml";            
        try {
            URL url = this.getClass().getResource(fname);
            if (url == null) 
                // System.out.println("url == null");
                System.err.println("not found fxml file : " + fname);
            
            FXMLLoader fxmlLoader = new FXMLLoader(url);
            fxmlLoader.setRoot(new GridPane());
            fxmlLoader.setController(new Login_customFXML_Control());

            Parent root = fxmlLoader.load();
            
            stage.setScene(new Scene(root));
            stage.show();
            System.out.println("success: " + fname);
        } catch (Exception ex) {
            System.err.println(fname);
            System.err.println(ex);
            ex.printStackTrace();
            System.exit(0);
        }
    }
}











