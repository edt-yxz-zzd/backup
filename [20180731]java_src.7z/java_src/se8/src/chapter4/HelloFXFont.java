package chapter4;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.control.Label;
import javafx.scene.text.Font;
import javafx.scene.Scene;
import javafx.scene.control.Slider;
import javafx.scene.layout.VBox;


public class HelloFXFont extends Application {
    public void start(Stage stage) {
        Label message = new Label("Hello, JavaFX!");
        //
        
        Slider fontSize = new Slider(5, 256, 100);
        fontSize.setShowTickMarks(true);
        fontSize.setShowTickLabels(true);
        fontSize.setMajorTickUnit(5f);
        fontSize.setBlockIncrement(50f);
        fontSize.valueProperty().addListener(property 
            -> message.setFont(new Font(fontSize.getValue())));
            
        fontSize.setValue(100);
        message.setFont(new Font(100));
        
        VBox vbox = new VBox(8); // spacing = 8
        vbox.getChildren().addAll(fontSize, message);

        stage.setScene(new Scene(vbox));
        stage.setTitle("Hello");
        stage.show();
    }
}