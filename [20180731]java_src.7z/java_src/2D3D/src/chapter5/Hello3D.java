package chapter5;

import java.awt.*;
//import java.awt.event.*;
//import java.awt.geom.*;
import javax.swing.*;
import javax.media.j3d.*;
import javax.vecmath.*;
import com.sun.j3d.utils.universe.*;
import com.sun.j3d.utils.geometry.*;
import com.sun.j3d.utils.applet.MainFrame;



public class Hello3D extends Applet {
  public static void main(String s[]){
    new MainFrame(new Hello3D(), 640, 480);
  }
  public void init(){
    JPanel panel = new Hello3DPanel();
    getContentPane().add(panel);
  }
}


class Hello3DPanel extends JPanel {
  public Hello3DPanel() {
    setPreferredSize(new Dimension(640, 480));
  }
  public void paintComponent(Graphics g) {
    super.paintComponent(g);
    Graphics2D g2 = (Graphics2D)g;
    g2.setColor(Color.blue);
    Ellipse2D e = new Ellipse2D.Double(-100, -50, 200, 100);
    AffineTransform tr = new AffineTransform();
    tr.rotate(Math.PI/6.0);
    Shape shape = tr.createTransformedShape(e);
    g2.translate(300, 200);
    //g2.scale(2,2);
    g2.draw(shape);
    g2.drawString("Hello 2D", 0, 0);
    g2.drawString("Hello", 0, 50);
    g2.drawString("2D", 100, 50);
    g2.drawString("300, 200", 300, 200);
    g2.drawString("0, 0", 0, 0);
  }
}


















