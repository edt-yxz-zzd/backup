package chapter4;

import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;


public class BaGuaShape extends ShapeBase{
  public static Shape circle(double x, double y, double r){
    return new Arc2D.Double(x-r, y-r, 2*r, 2*r, 0, 360, Arc2D.OPEN);
  }
  public static Shape circleLeft(double x, double y, double r){
    return new Arc2D.Double(x-r, y-r, 2*r, 2*r, 90, 180, Arc2D.CHORD);
  }
  public static Shape circleRight(double x, double y, double r){
    return new Arc2D.Double(x-r, y-r, 2*r, 2*r, -90, 180, Arc2D.CHORD);
  }
  public static PathIterator iter(Shape s){
    return s.getPathIterator(new AffineTransform());
  }
  
  public void append(Shape s){
    path.append(iter(s), false);
    path.closePath();
  }
  public BaGuaShape(double r, double R, double dR){
    super();
    
    append(circle(0, 0, R));
    
    R -= dR;
    append(circleLeft(0, 0, R));
    append(circleRight(0, -R/2, R/2));
    append(circleLeft(0, R/2, R/2));
    
    append(circle(0, R/2, r));
    append(circle(0, -R/2, r));
    
    
    
    //path.moveTo(R, 0);
    /*
    path.curveTo(R, -R, -R, -R, -R, 0);
    path.curveTo(-R, R, R, R, R, 0);
    
    path.quadTo(R, -R, 0, -R);
    path.quadTo(-R, -R, -R, 0);
    
    path.quadTo(-R, R, 0, R);
    path.quadTo(R, R, R, 0);
    //*/
    
  }

}