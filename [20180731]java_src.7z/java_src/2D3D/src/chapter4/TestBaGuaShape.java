package chapter4;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import javax.swing.*;


public class TestBaGuaShape extends JApplet {
  public static void main(String s[]){
    JFrame frame = new JFrame();
    frame.setTitle("TestBaGuaShape");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    JApplet applet = new TestBaGuaShape();
    applet.init();
    frame.getContentPane().add(applet);
    frame.pack();
    frame.setVisible(true);
  }
  public void init(){
    JPanel panel = new TestBaGuaShapePanel();
    getContentPane().add(panel);
  }
}


class TestBaGuaShapePanel extends JPanel {
  public TestBaGuaShapePanel() {
    setPreferredSize(new Dimension(640, 480));
    setBackground(Color.white);
  }
  public void paintComponent(Graphics g) {
    super.paintComponent(g);
    Graphics2D g2 = (Graphics2D)g;
    g2.setColor(Color.blue);
    Shape e = new BaGuaShape(4, 100, 30);
    
    AffineTransform tr = new AffineTransform();
    tr.rotate(Math.PI/6.0);
    e = tr.createTransformedShape(e);
    g2.translate(300, 200);
    g2.fill(e);

  }
}


















