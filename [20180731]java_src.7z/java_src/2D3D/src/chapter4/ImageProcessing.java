package chapter4;

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.color.*;
import java.awt.image.*;

import javax.imageio.*;
import javax.swing.*;

//import java.util.*;


public class ImageProcessing extends JFrame {
  public static void main(String s[]){
    JFrame frame = new ImageProcessing();
    frame.setTitle("ImageProcessing");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.pack();
    frame.setVisible(true);
  }
  public ImageProcessing(){
    super();
    init();
  }
  
  
  ImageProcessingPanel imgSrc, imgDst;
  JFileChooser fc = new JFileChooser();
  
  String fs[] = {
      "Open image",
      "Open image (awt)",
      "Save image",
      "Exit"
    };
  String ss[] = {
      "Copy",
      "Smooth",
      "Sharpen",
      "Edge",
      "Rescale",
      "Gray scale"
    };
    
  //ImageProcessingPanel panel = null;
  public void init(){
    Container cp = getContentPane();
    cp.setLayout(new GridLayout(1,2));
    
    imgSrc = new ImageProcessingPanel(this);
    imgDst = new ImageProcessingPanel(this);
    cp.add(imgSrc);
    cp.add(imgDst);
    
    
    JMenuBar mb = new JMenuBar();
    setJMenuBar(mb);

    
    JMenu menu;
    JMenuItem mi;

    String[] menuItemss[] = {
      fs, ss
    };
    String menuName[] = {
      "File", "Process"
    };
    ActionListener als[] = {
      new FileMenuListener(this),
      new ProcessMenuListener(this)
    };
    for (int j = 0; j < menuName.length; ++j){
        String[] menuItems = menuItemss[j];
        ActionListener al = als[j];
        menu = new JMenu(menuName[j]);
        mb.add(menu);
        for (int i = 0; i < menuItems.length; ++i){
          mi = new JMenuItem(menuItems[i]);
          mi.addActionListener(al);
          menu.add(mi);
        }
    } 
  }
}

abstract class MenuListener implements ActionListener{
  ImageProcessing c;
  JFileChooser fc;
  public MenuListener(ImageProcessing c){
    this.c = c;
    fc = c.fc;
  }
}

class FileMenuListener extends MenuListener{
  public FileMenuListener(ImageProcessing c){
    super(c);
  }
  public void actionPerformed(ActionEvent ev){
    String command = ev.getActionCommand();
    if ("Open image".equals(command)){
      int r = fc.showOpenDialog(c);
      if (r == fc.APPROVE_OPTION){
        try{
          BufferedImage bi = ImageIO.read(fc.getSelectedFile());
          c.imgSrc.setImage(bi);
        } catch (IOException ex){
          ex.printStackTrace();
        }
      }
    } else if ("Save image".equals(command)){
      int r = fc.showOpenDialog(c);
      if (r == fc.APPROVE_OPTION){
        try{
          ImageIO.write(c.imgDst.getImage(), "png", fc.getSelectedFile());
        } catch (IOException ex){
          ex.printStackTrace();
        }
      }
    } else if ("Open image (awt)".equals(command)){
      int r = fc.showSaveDialog(c);
      if (r == fc.APPROVE_OPTION){
        Toolkit tk = Toolkit.getDefaultToolkit();
        Image img = tk.getImage(fc.getSelectedFile().getPath());
        MediaTracker tracker = new MediaTracker(new Component(){});
        tracker.addImage(img, 0);
        try{
          tracker.waitForID(0);
          BufferedImage bi = new BufferedImage(
            img.getWidth(c), img.getHeight(c), BufferedImage.TYPE_INT_RGB);
          c.imgSrc.setImage(bi);
        } catch (InterruptedException ex){
          ex.printStackTrace();
        }
      }
    } else if ("Exit".equals(command)){
      System.exit(0);
    }
  }
}
class ProcessMenuListener extends MenuListener{
  public ProcessMenuListener(ImageProcessing c){
    super(c);
  }
  public void actionPerformed(ActionEvent ev){
    String command = ev.getActionCommand();
    BufferedImageOp op = null;
    float[] data = new float[9];
    if ("Copy".equals(command)){
      BufferedImage bi = c.imgDst.getImage();
      if (bi != null)
        c.imgSrc.setImage(bi);
      return;
    } else if (c.imgSrc.getImage() == null) {
      return;
    }else if ("Rotate".equals(command)){
      AffineTransform t = new AffineTransform();
      t.setToRotation(Math.PI/6);
      op = new AffineTransformOp(t, AffineTransformOp.TYPE_BILINEAR);
    } else if ("Gray scale".equals(command)){
      op = new ColorConvertOp(ColorSpace.getInstance(ColorSpace.CS_GRAY), null);
    } else if ("Rescale".equals(command)){
      op = new RescaleOp(1.5f, 0f, null);
      
    } else if ("Smooth".equals(command)){
      for (int i = 0; i < 9; ++i) data[i] = 1.f/9;
    } else if ("Sharpen".equals(command)){
      float[] d = {0f, -1f, 0f, -1f, 5f, -1f, 0f, -1f, 0f};
      data = d;
    } else if ("Edge".equals(command)){
      float[] d = {0f, -1f, 0f, -1f, 4f, -1f, 0f, -1f, 0f};
      data = d;
    } else {return;}
    
    if (op == null){
      Kernel ker = new Kernel(3, 3, data);
      op = new ConvolveOp(ker);
    }
    
    BufferedImage bi = op.filter(c.imgSrc.getImage(), null);
    c.imgDst.setImage(bi);
    //c.pack();

  }
}


class ImageProcessingPanel extends JPanel {
  BufferedImage image = null;
  JFrame frame = null;

  public ImageProcessingPanel(JFrame frame) {
    image = null;
    this.frame = frame;
    setPreferredSize(new Dimension(256, 256));
  }

  
  public void paintComponent(Graphics g) {
    super.paintComponent(g);
    Graphics2D g2 = (Graphics2D)g;
    
    if (image == null)
      g2.drawRect(0, 0, getWidth()-1, getHeight()-1);
    else
      g2.drawImage(image, 0, 0, this);
    
  }
  
  public BufferedImage getImage(){
    return image;
  }
  
  public void setImage(BufferedImage bi){
    image = bi;
    setPreferredSize(new Dimension(bi.getWidth(), bi.getHeight()));
    invalidate();
    frame.pack();
    repaint();
    //frame.repaint();
  }

}
































































