package chapter4;

import java.awt.Shape;
import java.awt.Rectangle;

//import java.awt.geom.*;
import java.awt.geom.Path2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.PathIterator;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;


public class ShapeBase implements Shape{
  protected Path2D path;
  
  public ShapeBase(){
    path = new Path2D.Double(Path2D.WIND_EVEN_ODD);
  }
  
  public boolean contains(double x, double y){
    return path.contains(x, y);
  }
  public boolean contains(double x, double y, double w, double h){
    return path.contains(x, y, w, h);
  }
  public boolean contains(Point2D p){
    return path.contains(p);
  }
  public boolean contains(Rectangle2D r){
    return path.contains(r);
  }
  public Rectangle getBounds(){
    return path.getBounds();
  }
  public Rectangle2D getBounds2D(){
    return path.getBounds2D();
  }
  public PathIterator getPathIterator(AffineTransform at){
    return path.getPathIterator(at);
  }
  public PathIterator getPathIterator(AffineTransform at, double flatness){
    return path.getPathIterator(at, flatness);
  }
  public boolean intersects(double x, double y, double w, double h){
    return path.intersects(x, y, w, h);
  }
  public boolean intersects(Rectangle2D r){
    return path.intersects(r);
  }
  
}