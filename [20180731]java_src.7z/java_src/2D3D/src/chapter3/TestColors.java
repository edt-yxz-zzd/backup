package chapter3;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import javax.swing.*;
import javax.swing.event.*;


public class TestColors extends JApplet {
  public static void main(String s[]){
    JFrame frame = new JFrame();
    frame.setTitle("TestColors");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    JApplet applet = new TestColors();
    applet.init();
    frame.getContentPane().add(applet);
    frame.pack();
    frame.setVisible(true);
  }
  
  TestColorsPanel panel = null;
  public void init(){
    panel = new TestColorsPanel();
    Container cp = getContentPane();
    cp.setLayout(new BorderLayout());
    cp.add(panel, BorderLayout.CENTER);
    
    JPanel p = new JPanel();
    cp.add(p, BorderLayout.EAST);
    p.setLayout(new GridLayout(1,3,30,10));
    
    
    JSlider sl = null;
    
    sl = new JSlider(JSlider.VERTICAL, 0, 255, 100);
    p.add(sl);
    sl.addChangeListener(new ChangeListener(){
      public void stateChanged(ChangeEvent ev){
        panel.red = ((JSlider)ev.getSource()).getValue();
        panel.repaint();
      }
    });
    
    sl = new JSlider(JSlider.VERTICAL, 0, 255, 100);
    p.add(sl);
    sl.addChangeListener(new ChangeListener(){
      public void stateChanged(ChangeEvent ev){
        panel.green = ((JSlider)ev.getSource()).getValue();
        panel.repaint();
      }
    });
    
    sl = new JSlider(JSlider.VERTICAL, 0, 255, 100);
    p.add(sl);
    sl.addChangeListener(new ChangeListener(){
      public void stateChanged(ChangeEvent ev){
        panel.blue = ((JSlider)ev.getSource()).getValue();
        panel.repaint();
      }
    });
    
    
  }
}


class TestColorsPanel extends JPanel {
  int red = 100;
  int green = 100;
  int blue = 100;
  
  public TestColorsPanel() {
    setPreferredSize(new Dimension(500, 500));
    setBackground(Color.white);
  }
  public void paintComponent(Graphics g) {
    super.paintComponent(g);
    Graphics2D g2 = (Graphics2D)g;
    
    Shape rs = new Ellipse2D.Double(100, 113, 200, 200);
    Shape gs = new Ellipse2D.Double(50, 200, 200, 200);
    Shape bs = new Ellipse2D.Double(150, 200, 200, 200);
    
    Area ra = new Area(rs);
    Area ga = new Area(gs);
    Area ba = new Area(bs);
    
    Area rga = new Area(rs);
    Area gba = new Area(gs);
    Area bra = new Area(bs);
    
    rga.intersect(ga);
    gba.intersect(ba);
    bra.intersect(ra);
    /*
    ra.subtract(rga);
    ra.subtract(bra);
    ga.subtract(gba);
    ga.subtract(rga);
    ba.subtract(bra);
    ba.subtract(gba);
    //*/
    
    Area rgba = new Area(rs);
    rgba.intersect(ga);
    rgba.intersect(ba);
    
    
    
    
    g2.setColor(new Color(red, 0, 0));
    g2.fill(ra);
    g2.setColor(new Color(0, green, 0));
    g2.fill(ga);
    g2.setColor(new Color(0, 0, blue));
    g2.fill(ba);
    
    g2.setColor(new Color(red, green, 0));
    g2.fill(rga);
    g2.setColor(new Color(0, green, blue));
    g2.fill(gba);
    g2.setColor(new Color(red, 0, blue));
    g2.fill(bra);
    
    
    g2.setColor(new Color(red, green, blue));
    g2.fill(rgba);

  }
}


















