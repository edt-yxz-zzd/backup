package chapter3;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
import java.awt.font.*;
import java.io.*;
import java.net.URL;
import javax.swing.*;
import javax.imageio.*;

public class TestPaints extends JApplet {
  public static void main(String s[]){
    JFrame frame = new JFrame();
    frame.setTitle("TestPaints");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    JApplet applet = new TestPaints();
    applet.init();
    frame.getContentPane().add(applet);
    frame.pack();
    frame.setVisible(true);
  }
  public void init() {
    JPanel panel = new TestPaintsPanel();
    getContentPane().add(panel);
  }
}


class TestPaintsPanel extends JPanel {
  private BufferedImage image;
  
  public static BufferedImage loadImage(Object o, String path) {
    URL url = o.getClass().getClassLoader().getResource(path);
    try {
      return ImageIO.read(url);
    }
    catch (IOException e){
      e.printStackTrace();
      //throw e;
      java.lang.Runtime.getRuntime().exit(1);
      return null;
    }
  }
  public TestPaintsPanel() {
    setPreferredSize(new Dimension(500, 500));
    setBackground(Color.white);
    
    image = loadImage(this, "images/earth.jpg");
  }
  public void paintComponent(Graphics g) {
    super.paintComponent(g);
    Graphics2D g2 = (Graphics2D)g;
    
    GradientPaint gp = new GradientPaint(0, 0, Color.white, 50, 0, Color.gray, true);
    g2.setPaint(gp);
    g2.fillRect(100, 40, 300, 20);
    
    TexturePaint tp = new TexturePaint(image, 
      new Rectangle(100, 100, image.getWidth(), image.getHeight()));
    g2.setPaint(tp);
    g2.fillOval(100, 100, 300, 200);
    
    Font font = new Font("Serif", Font.BOLD, 144);
    g2.setFont(font);
    g2.drawString("Java", 100, 400);
  }
}


















