package chapter3;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import javax.swing.*;
import java.util.*;


public class Transforms extends JApplet implements ActionListener{
  public static void main(String s[]){
    JFrame frame = new JFrame();
    frame.setTitle("Transforms");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    JApplet applet = new Transforms();
    applet.init();
    frame.getContentPane().add(applet);
    frame.pack();
    frame.setVisible(true);
  }
  
  String ss[] = {
      "Translation",
      "Rotation",
      "Scaling",
      "Shearing",
      "Reflection"
    };
  int st[] = {
      TransformsPanel.TRANSLATION,
      TransformsPanel.ROTATION,
      TransformsPanel.SCALING,
      TransformsPanel.SHEARING,
      TransformsPanel.REFLECTION
    };
    
  TransformsPanel panel = null;
  public void init(){
    panel = new TransformsPanel();
    getContentPane().add(panel);
    
    JMenuBar mb = new JMenuBar();
    setJMenuBar(mb);
    JMenu menu = new JMenu("Transforms");
    mb.add(menu);
    
    JMenuItem mi;
    
    
    for (int i = 0; i < ss.length; ++i){
      mi = new JMenuItem(ss[i]);
      mi.addActionListener(this);
      menu.add(mi);
    } 
  }
  
  public void actionPerformed(ActionEvent ev){
    String command = ev.getActionCommand();
    for (int i = 0; i < ss.length; ++i){
      if (command == ss[i]){
        panel.transformType = st[i];
        break;
      }
    }
  }
}



class TransformsPanel extends JPanel implements MouseListener, MouseMotionListener {
  static final int NONE = 0;
  static final int TRANSLATION = 1;
  static final int ROTATION = 2;
  static final int SCALING = 3;
  static final int SHEARING = 4;
  static final int REFLECTION = 5;
  
  int transformType = NONE;
  
  Shape drawShape = null;
  Shape tempShape = null;
  Point p = null;
  int x0 = 400;
  int y0 = 300;
  
  
  public TransformsPanel() {
    super();
    setPreferredSize(new Dimension(800, 600));
    setBackground(Color.white);
    
    drawShape = new Rectangle(-50, -50, 100, 100);
    
    addMouseListener(this);
    addMouseMotionListener(this);
  }
  public void paintComponent(Graphics g) {
    super.paintComponent(g);
    Graphics2D g2 = (Graphics2D)g;
    g2.translate(x0, y0);
    g2.drawLine(-200, 0, 200, 0);
    g2.drawLine(0, -200, 0, 200);
    g2.draw(drawShape);
    
  }
  
  public double pt2angle(Point pt){
    return Math.atan2(pt.y-y0, pt.x-x0);
  }
  
  public AffineTransform p12transform(Point p1){
    AffineTransform tr = new AffineTransform();
    double sx = 1.0*(p1.x-x0)/(p.x-x0) - 1;
    double sy = 1.0*(p1.y-y0)/(p.y-y0) - 1;
    switch (transformType){
      case TRANSLATION:
        tr.setToTranslation(p1.x-p.x, p1.y-p.y);
        break;
      case ROTATION:
        double da = pt2angle(p1) - pt2angle(p);
        tr.setToRotation(da);
        break;
      case SCALING:
        sx = Math.abs(sx+1);
        sy = Math.abs(sy+1);
        tr.setToScale(sx, sy);
        break;
      case SHEARING:
        tr.setToShear(sx, sy);
        break;
      case REFLECTION:
        tr.setTransform(-1, 0, 0, 1, 0, 0);
        break;
    }
    
    return tr;
  }
  
  public void mouseClicked(MouseEvent ev){}
  public void mouseEntered(MouseEvent ev){}
  public void mouseExited(MouseEvent ev){}
  public void mouseMoved(MouseEvent ev){}
  public void mousePressed(MouseEvent ev){
    p = ev.getPoint();
  }
  
  public void mouseReleased(MouseEvent ev){
    Point p1 = ev.getPoint();
    AffineTransform tr = p12transform(p1);
    drawShape = tr.createTransformedShape(drawShape);
    repaint();
  }
  
  public void mouseDragged(MouseEvent ev){
    Graphics2D g = (Graphics2D)getGraphics();
    g.setXORMode(Color.white);
    
    Point p1 = ev.getPoint();
    AffineTransform tr = p12transform(p1);
    
    g.translate(x0, y0);
    if (tempShape != null) g.draw(tempShape);
    tempShape = tr.createTransformedShape(drawShape);
    g.draw(tempShape);

  }
}
































































































