package chapter2;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import javax.swing.*;

public class BaGua extends JApplet {
  public static void main(String s[]){
    JFrame frame = new JFrame();
    frame.setTitle("BaGua");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    JApplet applet = new BaGua();
    applet.init();
    frame.getContentPane().add(applet);
    frame.pack();
    frame.setVisible(true);
  }
  public void init(){
    JPanel panel = new BaGuaPanel();
    getContentPane().add(panel);
  }
}


class BaGuaPanel extends JPanel {
  public BaGuaPanel() {
    setPreferredSize(new Dimension(200, 200));
  }
  public static Shape circle(double r, double x, double y){
    return new Ellipse2D.Double(x-r, y-r, 2*r, 2*r);
  }
  public static Shape circle(double r){
    return circle(r, 0, 0);
  }
  public static Area areaBaGua(double r, double R, double dR){
    R -= dR;
    Area bg = new Area(circle(R+dR));
    Area left_half = new Area(circle(R));
    left_half.subtract(new Area(new Rectangle.Double(0, -R, R, 2*R)));
    
    Area up_circle = new Area(circle(R/2, 0, -R/2));
    Area down_circle = new Area(circle(R/2, 0, R/2));
    Area up_dot = new Area(circle(r, 0, -R/2));
    Area down_dot = new Area(circle(r, 0, R/2));
    
    bg.subtract(left_half);
    //bg = left_half;
    //*
    bg.subtract(up_circle);
    bg.add(down_circle);
    bg.subtract(down_dot);
    bg.add(up_dot);//*/
    return bg;
  }
  public static Area areaBaGua(double r, double R){
    return areaBaGua(r, R, 1);
  }
  public void paintComponent(Graphics g) {
    super.paintComponent(g);
    Graphics2D g2 = (Graphics2D)g;
    g2.setColor(Color.blue);
    g2.translate(100, 100);
    Area bg = areaBaGua(4, 100);
    g2.fill(bg);
  }
}


















