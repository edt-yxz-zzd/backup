
package seed;

import javafx.stage.DirectoryChooser;
import javafx.scene.control.ScrollPane;
//import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.layout.Pane;

/*
 javafx.scene.control.ListView<T>
 javafx.scene.web.WebView 
        .getEngine()
 javafx.scene.web.WebEngine 
        .loadContent(html_content)
        .reload()
        .executeScript(script)
 static String format(String format, Object... args)
 
*/
import javafx.scene.web.WebView;
import javafx.scene.web.WebEngine;

import java.nio.file.Path; // prefer Path than File
import java.nio.file.Paths;
import java.nio.file.Files;

import javax.swing.text.html.parser.DTD;
import javax.swing.text.html.parser.DocumentParser;
import java.nio.charset.StandardCharsets;



import java.io.File;
import java.net.URL;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import java.io.IOException;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.Parent;
import javafx.scene.Node;


import javafx.beans.binding.Bindings;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.text.Font;
import javafx.scene.shape.Rectangle;


// class Rect extends ; // Rect = EmptyBox<W,H> | Image<W,H>

public class T extends Application {
    public void start(Stage stage) {
        WebView view = new WebView();
        WebEngine engine = view.getEngine();
        stage.setScene(new Scene(view));
        stage.show();
        stage.setTitle("ImageBrowser");
        
        //Reader reader = Files.newBufferedReader(path);
        //DTD dtd = DTD.getDTD("http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd");
        //DocumentParser p = DocumentParser(dtd);
        
        if (false) {
            String html_fname = "E:/my_data/program_source/java_src/src/seed/T.html";
            engine.load("file:///" + html_fname);
        }
        else {
            Path path = Paths.get("E:/my_data/program_source/java_src/src/seed/T.html");
            try{
                byte[] bytes = Files.readAllBytes(path);
                String html = new String(bytes, StandardCharsets.UTF_8);
        
                engine.loadContent(html);
            } catch(IOException e) {
                //System.err.println(e);
                e.printStackTrace();
            }
        }
        // engine.load("file:///D:/software/programming/Java/javafx-8u25-apidocs/api/index.html");
    }
}



