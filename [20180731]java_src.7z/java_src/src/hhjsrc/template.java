


public class {
    static void println(Object... ss){
        for (Object s : ss)
            System.out.println(s);
    }
    static void print(Object... ss){
        for (Object s : ss){
            System.out.print(s);
            System.out.print("  ");
        }
        System.out.println();
    }
    public static void main(String[] args){
        System.out.println("");
    }
}