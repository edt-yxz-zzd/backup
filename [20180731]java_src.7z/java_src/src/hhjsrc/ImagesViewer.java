package hhjsrc;

import java.lang.Integer;
import java.lang.String;

import java.awt.Component;
import java.awt.Container;
import javax.swing.BoxLayout;
import java.awt.CardLayout;
import java.awt.GridLayout;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Dialog;
import java.awt.FileDialog;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JApplet;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JFileChooser;
import javax.swing.plaf.metal.MetalFileChooserUI;
import javax.swing.JTree;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.TreeCellRenderer;

import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.FileSystems;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;

import java.util.Hashtable;
import java.util.stream.Stream;


public class ImagesViewer extends JApplet {
  private JFrame frame;
  private ImagesViewer(JFrame frame){this.frame = frame;}
  public static void main(String s[]){
    JFrame frame = new JFrame();
    frame.setTitle("ImagesViewer");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    JApplet applet = new ImagesViewer(frame);
    applet.init();
    frame.getContentPane().add(applet);
    frame.pack();
    frame.setVisible(true);
  }
  public void init(){
    JPanel panel = new ImagesViewerPanel(frame);
    getContentPane().add(panel);
  }
}


class ImagesViewerPanel extends JPanel {
  private JPanel output;
  private JFrame frame;
  private JScrollPane view;
  public ImagesViewerPanel(JFrame frame) {
    this.frame = frame;
    setPreferredSize(new Dimension(640, 480));
    setLayout(new BorderLayout());
    
    output = new JPanel(new CardLayout());
    BoxLayout blout = new BoxLayout(output, BoxLayout.Y_AXIS);
    output.setLayout(blout);
    view = new JScrollPane(output);
    add(view, BorderLayout.CENTER);
    
    //String path = "E:\\multimedia\\picture\\funny";
    //String uglygirl = path + "\\ugly_girl.jpg";
    String path = "E:\\temp_output\\comic\\t";
    Path ppath = FileSystems.getDefault().getPath(path);
    //ImageIcon im = new ImageIcon(uglygirl);
    //JTree.DynamicUtilTreeNode = 
    //typedef Hashtable<String, Object> Ht;
    Hashtable<String, Object> ht = new Hashtable<String, Object>();
    Hashtable<String, Object> root = new Hashtable<String, Object>();
    String leaf = "";
    //ht.put(path, root);
    
    Hashtable<String, Object> tmp = new Hashtable<String, Object>();
    try{
    for (Object o: Files.walk(ppath).toArray()){
      Path p = (Path) o;
      Path u = p.getParent();
      if (u == p || u == null)continue;
      
      String k = u.toString();
      if (!tmp.containsKey(k)) tmp.put(k, new Hashtable<String, Object>());
      
      Hashtable<String, Object> t = (Hashtable<String, Object>)tmp.get(k);
      String sp = p.toString();
      File file = new File(sp);
      if (file.isFile()){
        t.put(sp, "");
      }
      else{
        t.put(sp, new Hashtable<String, Object>());
        tmp.put(sp, t.get(sp));
      }
    }}catch(IOException _){}
    
    root = (Hashtable<String, Object>)tmp.get(path);
    ht.put(path, root);
    // treated as leaf ht.put("''", "");
    // xxx ht.put("null", null);
    //r3.put(uglygirl, leaf);
    //ht.put("r3", r3);
    
    /*
    JTree.DynamicUtilTreeNode null_leaf = new JTree.DynamicUtilTreeNode("leaf", "");
    JTree.DynamicUtilTreeNode uglygirl_leaf = new JTree.DynamicUtilTreeNode(uglygirl, "");
    JTree.DynamicUtilTreeNode node3 = new JTree.DynamicUtilTreeNode("3", new Object[]{uglygirl_leaf.clone()});
    Object[] fr = new Object[]{uglygirl_leaf, null_leaf, node3};
    for (Object n : fr) System.out.println(((JTree.DynamicUtilTreeNode) n).isLeaf());
    
    JTree.DynamicUtilTreeNode root = new JTree.DynamicUtilTreeNode("root)yyy", fr);
    for (Object n : fr) System.out.println(((JTree.DynamicUtilTreeNode) n).isLeaf());
    */

    JTree tree = new JTree(ht);

    //tree.setRootVisible(true);
    view.setViewportView(tree);
    
    tree.setCellRenderer(new TreeCellRenderer(){
      public Component getTreeCellRendererComponent(JTree tree, Object value, 
        boolean selected, boolean expanded, boolean leaf, 
        int row, boolean hasFocus){
        String s = value.toString();
        System.out.print(leaf);
        System.out.println(s);
        
        if (!leaf || s == ""){
          System.out.println("\tdefault\n");
          return new DefaultTreeCellRenderer().getTreeCellRendererComponent(
                 tree, value, selected, expanded, leaf, row, hasFocus);
        }

          
        System.out.println("\timage\n");
        return new JLabel(new ImageIcon(s));
      }
    });
    
    JPanel input = new JPanel(new BorderLayout());
    add(input, BorderLayout.NORTH);
    
    
    JPanel input_east = new JPanel(new GridLayout(1, 2));
    input.add(input_east, BorderLayout.EAST);
    
    JTextField pattern = new JTextField("pattern");
    JButton opendir = new JButton("opendir");
    JTextField dirname = new JTextField("dirname");
    
    input_east.add(pattern);
    input_east.add(opendir);
    input.add(dirname, BorderLayout.CENTER);
    
    
    pattern.setText("*.jpg");
    dirname.setText(path);
    
    opendir.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
          Path path = FileSystems.getDefault().getPath(dirname.getText());
          
          DirectoryStream<Path> ds;
          try{
            ds = Files.newDirectoryStream(path, pattern.getText());
            for (Path p: ds){
              addImage(p);
              System.out.println("addImage");
            }
            
          }catch(IOException ex){}

          
        }
    });
    
    
    /*
    
    
    JPanel input_west = new JPanel(new GridLayout(1, 2));
    input.add(input_west, BorderLayout.WEST);
    
    JTextField pattern = new JTextField("pattern");
    JButton opendir = new JButton("opendir");
    JLabel dirname = new JLabel("dirname");
    
    input_west.add(pattern);
    input_west.add(opendir);
    input.add(dirname, BorderLayout.CENTER);
    
    
    
    // Files.newDirectoryStream("E:/my_data/program_source/python3_src/root/temp", "*.bmp");
    // MetalFileChooserUI.DirectoryComboBoxModel d = createDirectoryComboBoxModel(JFileChooser fc) 
    //for (int i = 0; i < 100; ++i) addInt(i);
    
    opendir.addActionListener(new ActionListener(){
        public void actionPerformed(ActionEvent e){
          //JFileChooser fc = new JFileChooser(dirname.getText());
          //MetalFileChooserUI ui = new MetalFileChooserUI(fc);
          //dirname.setText(ui.getDirectoryName());
          //Dialog d = new Dialog(this);
          //FileDialog fd = new FileDialog(frame, "select images", FileDialog.LOAD);
          //fd.setFilenameFilter(FilenameFilter filter);
          //fd.setDirectory("E:\\my_data\\program_source\\python3_src\\root\\temp");
          //fd.setMultipleMode(true);
          //fd.setVisible(true);
          
          JFileChooser fc = new JFileChooser(dirname.getText());
          //System.out.println("here");
          File[] fs = fd.getFiles();
          for (File f: fs)
            addImage(f.getPath());
          
          //view.setViewportView(output);
        }
    });*/
  }
  private void addInt(int i){addLabel(Integer.toString(i));}
  private void addImage(String fname)
  {
    JLabel lb = new JLabel(new ImageIcon(fname));
    output.add(lb);
  }
  private void addImage(Path fname)
  {
    JLabel lb = new JLabel(new ImageIcon(fname.toString()));
    output.add(lb);
  }
  private void addLabel(String s)
  {
    JLabel lb = new JLabel(s);
    output.add(lb);
  }
}

