
import seed.Box;

import javafx.beans.property.ReadOnlyDoubleProperty;
import javafx.beans.property.DoubleProperty;
import javafx.geometry.Bounds;
import javafx.geometry.BoundingBox;

import javafx.scene.control.ScrollPane; 
import javafx.scene.layout.VBox;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.Region;
import javafx.scene.shape.Rectangle;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.application.Application;

import javafx.scene.paint.Color;
//import static seed.BackgroundColorSettor.*;

public class try_Box extends Application {

    static void print(Object... ss){
        for (Object s : ss){
            System.out.print(s);
            System.out.print("  ");
        }
        System.out.println();
    }
    
    
    public void start(final Stage stage){
        System.out.println("");
        int width = 300;
        int height = 400;
        final Rectangle r1 = new Rectangle(width, height, Color.RED);
        final Rectangle r2 = new Rectangle(width, height, Color.GREEN);
        final Rectangle r3 = new Rectangle(width, height, Color.BLUE);
        
        final Box box = new Box(100, 200, 3, r1);
        final VBox vbox = new VBox(box);
        Scene scene = new Scene(vbox);
        stage.setScene(scene);
        stage.show();
        
        print(vbox.getWidth(), vbox.getHeight());
        print(r1.getWidth(), r1.getHeight());
        print(r1.getMinWidth(), r1.getMinHeight());
    }
}





