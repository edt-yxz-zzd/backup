package seed;

import java.nio.file.Path;
import java.util.Comparator;
import java.util.List;
import static seed.util.Pairs.*;
import static seed.Funcs.*;
import seed.util.IIterator;

import seed.annotations.NonNull;

class State {
    public final Path root;
    private final Comparator<Path> dir_cmp;
    private final Comparator<Path> file_cmp;
    
    private Path curr_dir;
    private List<Path> paths;
    public List<Path> get_paths(){return paths;}
    public final IIterator<Pair<Path, Pair<PathType, Info> > > 
        iter_get_infos()
    {
        return Funcs.iter_get_infos(paths);
    }
    //private List<Pair<Path, Pair<PathType, Info> > > path_info_ls;
    //public final List<Pair<Path, Pair<PathType, Info> > > get_path_infos(){
    //    return path_info_ls;
    //}
    
     
    public State(@NonNull Path root, @NonNull Path curr_dir, 
                 @NonNull Comparator<Path> dir_cmp, 
                 @NonNull Comparator<Path> file_cmp)
    {
        this.root = root;
        this.dir_cmp = dir_cmp;
        this.file_cmp = file_cmp;
        open(curr_dir);
    }

    public void open(Path curr_dir){
        // [Path]
        List<Path> ls = Funcs.list_entries(root, curr_dir, dir_cmp, file_cmp);
        // [(Path, PathInfo)]
        //path_info_ls = Funcs.get_infos(ls);
        this.curr_dir = curr_dir;
        this.paths = ls;
    }
    
    public Path getCurrDir(){
        return curr_dir;
    }
}
