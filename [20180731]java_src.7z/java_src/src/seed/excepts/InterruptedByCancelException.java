
package seed.excepts;

//import seed.excepts.InterruptedByCancelException;

import java.io.IOException;

public class InterruptedByCancelException extends IOException {
    public InterruptedByCancelException(){super();}
    public InterruptedByCancelException(String message){super(message);}
    public InterruptedByCancelException(String message, Throwable cause){super(message, cause);}
    public InterruptedByCancelException(Throwable cause){super(cause);}

}