
/*


fixed bug:
    double - NaN // in MyViewportBounds  BoundingBox
fixed bug:
    an uncaught exception (unjust Nothing) occured in turn_images_on__task
    leave some images unloaded
    
    I print information without thread ID
    so, I mislead that the latest task was cancelled...
    

fixed bug:
    since Java does not support RAII
    I remove all the images, but they still in memory...

    open to many files ==>> OutOfMemoryError??
    aImageView.imageProperty().setValue(null); // it works!!
    
mistake
    stage.setOnShown(...) instead of stage.onShownProperty().addListener(...)
    // ERROR:  assert stage.isShowing() == stage is shown;

keypoint .layout();
    1) scrollpane.layout() dont work; 
        use scrollpane.getContent().layout() instead
    2) on_width_change/repaint -> on_visibles_change
        so, call vbox.layout() in on_visibles_change instead of just repaint

scrollpane.viewportBounds was wrong, need to transform


repaint - ver1
    // has read all images info
    // but to read all images info at once is too slow
    
    draw_place_holders 
    set_actions
    
repaint
    // only know paths to draw
    task.laterUpdateCancel()
    vbox.getChildren().clear()
    task = new LaterUpdateTask(
        self -> {
            for path in paths:
                if isLaterUpdateCancelled(): break
                info = path2info(path)
                // image = load path if (isImage info) else None
                node = make_place_holder(path, info)
                report((node, path, info))
        },
        (self, (node, path, info)) -> {
            if node is Box: imagebox_path_infos.add((node, path, info))
            vbox.getChildren().add(node);
        },
        null
    );


init_listen()
    my_viewportBounds.addListener((p,o,n)->on_visibles_change())
    

on_visibles_change()
    IN: imagebox_path_infos, path2image_cache, viewportBounds, box2bounds, base_width_property
    DO: turn image on/off in box

    pre_turnon_task.my_cancel()
    turn off directly
    turn on -> LaterTask(imageonbox_paths, base_width_property, path2image_cache)
repaint()
    IN: path2type_info_cache; open_dir, root ==>> paths;
    DO: draw place holder boxes on vbox one by one on background
    pre_addchildren_task.my_cancel()
    add children -> LaterTask(paths, path2type_info_cache)


recycle_size = total_size - using_size
path2type_info_cache := a large map since data small; ~ 200
path2image_cache := a small map since data huge; recycle_size = total - using < 10


turn_images_on__task
add_vbox_children__task
*/















package seed;
import javafx.event.EventDispatcher;
import javafx.scene.input.PickResult;
import javafx.event.Event;
import javafx.event.EventType;
import javafx.concurrent.Service;
import javafx.concurrent.Task;

import static seed.util.Iters.*;
import static seed.util.Tasks.*;
import seed.excepts.InterruptedByCancelException;
import seed.Box;
import seed.MyScrollPane;
import static seed.io.Prints.*;
import javafx.scene.paint.Paint;
import javafx.geometry.Orientation;
import javafx.scene.shape.Rectangle;
import javafx.geometry.BoundingBox;
import javafx.stage.Stage;
import javafx.beans.binding.Bindings;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.MouseButton;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent; 

import javafx.beans.binding.Bindings;
import javafx.beans.binding.DoubleBinding;


import seed.annotations.NonNull;
import java.nio.file.Path;

import javafx.beans.property.DoubleProperty;
import javafx.geometry.Bounds;
import javafx.scene.control.ScrollPane; 
import javafx.scene.layout.VBox;
import javafx.scene.control.Label;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.paint.Color;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.util.function.Function;
import seed.util.CacheLRU;
import seed.util.LaterUpdateTask;
import seed.State;
import seed.Funcs;
import static seed.Funcs.PathType;
import static seed.Funcs.Info;

import static seed.util.Pairs.*;
import static seed.util.Tuple3s.*;
import java.util.List;
import java.util.Set;
import java.util.ArrayList;
import java.util.HashSet;
import static seed.BackgroundColorSettor.*;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.beans.property.ReadOnlyDoubleProperty;

// Node::public boolean isResizable()
// javafx.scene.layout.Region::backgroundProperty







class FontInfo{}

// Mnemonic : KeyCombination -> Node // Scene getAccelerators(), addMnemonic getMnemonics
// javafx.scene.text.Font
class View{
    private static final boolean vbox__set_action__same = true;
    private final VBox vbox = new VBox();
    private final VBox top_layer = new VBox(); 
    // mouseTransparent/eventDispatcher/focusTraversable
    // add/removeEventFilter/Handler ~ during the capturing/bubbling phase of event delivery see EventDispatcher
    {
        // I want to replace multiple set_action__same calls by only one
        // but fail; how to redirect event??
        top_layer.setFocusTraversable(false); 
        if (vbox__set_action__same){
            top_layer.setMouseTransparent(true);
        } else{
        final EventDispatcher old = top_layer.getEventDispatcher();
        // how to control tail?? it seems tail doesnot include vbox.children...
        // see EventTarget.buildEventDispatchChain
        //     PickResult // When mouse event occurs, the top-most node under cursor is picked and the event is delivered to it through capturing and bubbling phases described at EventDispatcher.
        top_layer.setEventDispatcher((event, tail)->{
            if (event instanceof MouseEvent){
                print(event);
                MouseEvent m = (MouseEvent)event;
                //PickResult(EventTarget target, double sceneX, double sceneY)
                //  getIntersectedNode()
                //m.getPickResult()
                PickResult pr = new PickResult(vbox, m.getSceneX(), m.getSceneY());
                assert vbox == pr.getIntersectedNode(); // not child!
                
            }
            //if (true){vbox.fireEvent(event);}
            if (true){event.fireEvent(vbox, event);}
            //if (true){return vbox.getEventDispatcher().dispatchEvent(event, tail);}
            tail = tail.prepend(vbox.getEventDispatcher());
            return old.dispatchEvent(event, tail);
        });
    }}
    private final StackPane stackpane = new StackPane(vbox, top_layer);
    private final MyScrollPane scrollpane = new MyScrollPane(stackpane);

    private List<Tuple3<Box, Path, Info> > imagebox_path_infos = new ArrayList<>();
    private LaterUpdateTask<Void, Pair<Path, Pair<PathType, Info>>> add_vbox_children__task = null;
    private LaterUpdateTask<Void, Pair<Tuple3<Box, Path, Info>, Image> > turn_images_on__task = null;
    private OneTaskService<Void> add_vbox_children__srvc = new OneTaskService<>();
    private OneTaskService<Void> turn_images_on__srvc = new OneTaskService<>();
    private List<Path> old_paths = new ArrayList<>();
    
    private final Stage stage;
    private final State state;
    private final FontInfo font_info;
    private final CacheLRU<Path, Image> path2image_cache;
    private final CacheLRU<Path, Pair<PathType, Info> > path2type_info_cache;
    
    
    private double x = 0, y = 0;
    
    
    
    // called by App
    public Parent getContent(){
        return scrollpane;
    }
    public View(@NonNull Stage stage, 
                @NonNull CacheLRU<Path, Image> path2image_cache, 
                @NonNull CacheLRU<Path, Pair<PathType, Info> > path2type_info_cache, 
                @NonNull State state, 
                @NonNull FontInfo font_info){
        this.stage = stage;
        this.path2image_cache = path2image_cache;
        this.path2type_info_cache = path2type_info_cache;
        this.state = state;
        this.font_info = font_info;
        


        vbox.setFillWidth(true);
        this.scrollpane.setFitToWidth(true);
        
        set_global_bindings();
        set_global_actions();
        repaint();
    }
    

    

    
    
    
    
    


    private void set_global_bindings(){
        scrollpane.hvalueProperty().addListener(
            (property, oldValue, newValue) -> on_visibles_change()
        );
        scrollpane.vvalueProperty().addListener(
            (property, oldValue, newValue) -> on_visibles_change()
        );

        scrollpane.myViewportBoundsProperty()/*viewportBoundsProperty()*/.addListener(
            (property, oldValue, newValue) -> on_visibles_change()
        );
    }


    private static <V> void cancelLaterUpdateSrvc(OneTaskService<V> srvc){
        LaterUpdateTask<V, ?> task = (LaterUpdateTask<V, ?>)srvc.get_task();
        if (task != null){
            task.laterUpdateCancel();
            srvc.set_task(null);
        }
        srvc.cancel();
    }
    private void cleand_before_on_visibles_change(){
        print("cleand_before_on_visibles_change -> cancelLaterUpdateSrvc(turn_images_on__srvc)");
        cancelLaterUpdateSrvc(turn_images_on__srvc);
    }
    private void on_visibles_change(){
        cleand_before_on_visibles_change();
        print("on_visibles_change");
        print("path2image_cache.getCachedSize()="+path2image_cache.getCachedSize());
        print("path2image_cache.getUsingSize()="+path2image_cache.getUsingSize());
        //path2image_cache.printKeys("path2image_cache ");
        //pause();
        
        vbox.layout(); // layout here success! // layout in repaint seems dont work
        
        Bounds b = scrollpane.getMyViewportBounds()/*fixedViewportBounds()*/;
        //Bounds b = MyScrollPane.calc_viewportBounds(scrollpane);
        //print("MyViewportBounds", b);
        
        final List<Tuple3<Box, Path, Info> > imageon = new ArrayList<>();
        for (Tuple3<Box, Path, Info> box_path_info: imagebox_path_infos){
            Bounds c = box_path_info._0.getBoundsInParent();
            //print("   box bounds", c);
            
            // bugs: once 
            //    if ... # forgot {}!!!
            //       if ...
            //    else ...
            if (b.intersects(c)){
                if (! (box_path_info._0.getChild() instanceof ImageView)) {
                    imageon.add(box_path_info);
                }
                else {
                    assert !(null instanceof ImageView);
                    assert box_path_info._0.getChild() != null;
                    //print("error: not turn on assertion");
                    //System.exit(-1);
                }
            } else
                hide_image(box_path_info);
        }
        
        //print(imageon);
        
        //LaterUpdateTask<Void, Pair<Path, Pair<PathType, Info>>> add_vbox_children__task;
        //LaterUpdateTask<Void, Pair<Tuple3<Box, Path, Info>, Image> > turn_images_on__task;
        turn_images_on__task = new LaterUpdateTask<Void, Pair<Tuple3<Box, Path, Info>, Image> >(
            self -> {
                print("   running @", self);
                for (Tuple3<Box, Path, Info> box_path_info : imageon){
                    //if (self.isLaterUpdateCancelled()) break;
                    //print("   handle box_path_info @", self);
                    Path path = box_path_info._1;
                    //Box box = box_path_info._0;
                    Image image = null;
                    while (image == null && !self.isLaterUpdateCancelled()) {
                        //print("   null ==>> handle box_path_info @", self);
                        try {
                            image = path2image_cache.get(path); // maybe null
                        } catch(Throwable e){
                            e.printStackTrace();
                            throw e;
                        }
                        //print("   after path2image_cache.get <<== handle box_path_info @", self);
                    }
                    //print("   after while <<== handle box_path_info @", self);
                    if (self.isLaterUpdateCancelled()) {
                        break;
                    }
                    else if (self.isLaterUpdateCancelled()) {
                        print("turn_images_on__task.isLaterUpdateCancelled()");
                        print("    LaterUpdateTask @", self);
                        print(imageon);
                        print(box_path_info);
                        Thread me = Thread.currentThread();
                        print("thread id:", me.getId(), me.getName(), me.getState());
                        break;
                    }
                    assert image != null;
                    
                    //print("   got image <<== handle box_path_info @", self);
                    
                    //if (image != null)
                    try {self.report(makePair(box_path_info, image));
                    } catch(InterruptedByCancelException ex){
                        if (self.isLaterUpdateCancelled()) break;
                        print("turn_images_on__task");
                        ex.printStackTrace();
                        throw new RuntimeException(ex);
                    }
                }
                return null;
            },
            (self, box_path_info_image) -> {
                try{
                    show_image(box_path_info_image.fst, box_path_info_image.snd);
                } catch(Throwable e){
                    print("show_image -> Exception");
                    e.printStackTrace();
                    throw e;
                }
            },
            null
        );
        if (false) { // too many threads
            Thread th = new Thread(turn_images_on__task);
            th.setDaemon(false);
            th.start();
        }
        
        if (true) {
            turn_images_on__srvc.restart(turn_images_on__task);
        }
        else if (true){
            turn_images_on__srvc = new OneTaskService<>(turn_images_on__task);
            print("turn_images_on__srvc.start()");
            turn_images_on__srvc.start();
            print("    LaterUpdateTask @", turn_images_on__task);
            //
        }
        else
                for (Tuple3<Box, Path, Info> box_path_info : imageon){
                    Path path = box_path_info._1;
                    //Box box = box_path_info._0;
                    Image image = path2image_cache.get(path); // maybe null
                    show_image(box_path_info, image);
                }
        

        print(" -------- end of on_visibles_change ------- \n\n\n");
    }

    private DoubleBinding view_width = Bindings.createDoubleBinding(
        ()->scrollpane.getViewportBounds().getWidth(), scrollpane.viewportBoundsProperty()
    );
    
    private DoubleBinding viewWidthBinding(){
        return view_width;
    }
    private void show_image(Tuple3<Box, Path, Info> box_path_info, Image image){
        //print("show", box_path_info._1);
        if (image == null){
            print("image == null");
            return;
        }
        Box box = box_path_info._0;
        if (box.getChild() instanceof ImageView) return;
        
        print("show", box_path_info._1);
        print("       loading");
        Path path = box_path_info._1;
        Info info = box_path_info._2;
        Node node = make_image_node(image, path, viewWidthBinding(), info);
        if (box.getChild() instanceof Rectangle) unbind_box_rect(box);
        else if (box.getChild() instanceof Label) unbind_box_imagemisslabel(box);
        box.setChild(node);
    }
    private void hide_image(Tuple3<Box, Path, Info> box_path_info){
        //print("hide", box_path_info._1);
        Box box = box_path_info._0;
        if (! (box.getChild() instanceof ImageView)) return;
        
        print("hide", box_path_info._1);
        print("       discarding");
        Node node = info2empty_image_box_content(viewWidthBinding(), box_path_info._2);
        unbind_box_imageview(box);
        box.setChild(node);
        path2image_cache.discard(box_path_info._1);
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    private void clean_before_repaint(){
        cleand_before_on_visibles_change(); // bug: forgot cancel this task
        cancelLaterUpdateSrvc(add_vbox_children__srvc);
        
        List<Path> image_paths_to_clean = list(map(e->e._1, imagebox_path_infos));
        for (Path path : image_paths_to_clean)
            path2image_cache.discard(path);
        for (Path path : old_paths)
            path2type_info_cache.discard(path);
        List<Box> boxes_to_clean = list(map(e->e._0, imagebox_path_infos));
        for (Box box : boxes_to_clean){
            Node node = box.getChild();
            if (node instanceof ImageView)
                unbind_box_imageview(box);
            else if (node instanceof Rectangle)
                unbind_box_rect(box);
        }
        assert path2image_cache.getUsingSize() < 2; // assume add_vbox_children__task run last loop
        assert path2type_info_cache.getUsingSize() < 2;
        assert path2image_cache.getCachedSize() <= path2image_cache.getMaxCacheSize(); // assume add_vbox_children__task run last loop
        assert path2type_info_cache.getCachedSize() <= path2type_info_cache.getMaxCacheSize();
        
        vbox.getChildren().clear();
        imagebox_path_infos.clear();
        old_paths = null;
    }
    private void repaint(){
        clean_before_repaint();
        
        final List<Path> paths = state.get_paths(); // new paths
        old_paths = paths;
        // LaterUpdateTask<Void, Pair<Path, Pair<PathType, Info>>> add_vbox_children__task;
        add_vbox_children__task = new LaterUpdateTask<Void, Pair<Path, Pair<PathType, Info>> >(
            self -> {
                for (Path path : paths){
                    if (self.isLaterUpdateCancelled()) break;
                    Pair<PathType, Info> pathtype_info = path2type_info_cache.get(path);
                    //path2type_info_cache.discard(path); // pure cache
                    //Node node = make_place_holder(path, pathtype_info);
                    
                    try {self.report(makePair(path, pathtype_info));
                    } catch(InterruptedByCancelException ex){
                        if (self.isLaterUpdateCancelled()) break;
                        throw new RuntimeException(ex);
                    }
                    
                }
                return null;
            },
            (self, path_pathtype_info) -> {
                Path path = path_pathtype_info.fst;
                Pair<PathType, Info> pathtype_info = path_pathtype_info.snd;
                
                Node node = make_place_holder(path, pathtype_info, viewWidthBinding(), font_info);
                if (node instanceof Box){
                    Info info = pathtype_info.snd;
                    Box box = (Box) node;
                    imagebox_path_infos.add(makeTuple(box, path, info));
                }
                vbox.getChildren().add(node);
                set_action(path, node);
            },
            null
        );
        if (false) {
            Thread th = new Thread(add_vbox_children__task);
            th.setDaemon(false);
            th.start();
        }
        add_vbox_children__srvc.restart(add_vbox_children__task);
        

        //scrollpane.layout(); // donot work
        //vbox.layout(); // work, but since on_width_change is another source, so, move this line to on_visibles_change
        //set_actions();
        print("------- end of repaint -----------");
        
    }







    private static Node make_place_holder(
        Path path, 
        Pair<PathType, Info> type_info,
        DoubleBinding view_with, 
        FontInfo font_info
    ){
        PathType type = type_info.fst;
        Info info = type_info.snd;
        Node node;
        switch(type){
            case Image:
                node = make_empty_image_box(path, view_with, info);
                break;
            case Directory:
                node = make_dirpath_node(path, font_info);
                break;
            case BrokenImage:
                node = makeColoredLabel("broken: " + path.toString(), Color.RED);
                break;
            case Other:
                node = make_filepath_node(path, font_info);
                break;
            default:
                assert false;
                node = null; // WTF
        }
        
        return node;
    }
    



    private double getWidth(){
        // base_width
        return scrollpane.getViewportBounds().getWidth();
    }
    private static Node make_filepath_node(Path path, FontInfo font_info){
        return new Label("non-image file: " + path);
    }
    private static Node make_dirpath_node(Path path, FontInfo font_info){
        return new Label("folder: " + path);
    }
    
    public static Node makeLabeledRectangle(String text, double width, double height, Paint fill){
        if(false) return new Label(text, new Rectangle(width, height, fill));
        //print(width, height);
        return new StackPane(new Rectangle(width, height, fill)); // new Label(text), 
    }
    public static Label makeColoredLabel(String text, Color c){
        Label label = new Label(text);
        setBackgroundColor(label, c);
        return label;
    }
    

    private static void unbind_box_rect(Box box){
        Rectangle rect = (Rectangle) box.getChild();
        rect.widthProperty().unbind();//.dispose();
        rect.heightProperty().unbind();//.dispose();
    }
    private static Node info2empty_image_box_content(
            DoubleBinding view_with, Info info) {
        double w = info.scale * view_with.get(); // target width
        double h = w * info.height/info.width;
        Rectangle rect = new Rectangle(//info.width, info.height, 
            w, h, Color.GREY);

        rect.widthProperty().bind(Bindings.multiply(info.scale, view_with));
        rect.heightProperty().bind(Bindings.multiply(info.scale * info.height/info.width, view_with));
        return rect;
    }

    private static Box make_empty_image_box(
            Path path, 
            DoubleBinding view_with,
            Info info
    ){
        // image.width == box.width * box.child_scale
        //           w == base_width * info.scale
        Node rect = info2empty_image_box_content(view_with, info);
        Box box = new Box(rect, info.scale);
        return box;
    
    }
    
    private static Node make_image_node(
            Image image,
            Path path, 
            DoubleBinding view_with,
            Info info){
        Node node;
        if (image == null) {
            //box = new Box(makeLabeledRectangle(path.toString(), w, h, Color.YELLOW), 1.0); // empty box
            Label label = makeColoredLabel("missing: " + path, Color.YELLOW);
            double radio = info.height / info.width;
            label.prefWidthProperty().bind(view_with);
            label.prefHeightProperty().bind(Bindings.multiply(view_with, radio));
            node = label;
        }
        else {
            // image.width == box.width * box.child_scale
            //           w == base_width * info.scale
            ImageView view = new ImageView(image);
            view.setPreserveRatio(true);
            view.fitWidthProperty().bind(view_with);
            node = view;
        }
        return node;
    }
    private static void unbind_box_imageview(Box box){
        ImageView view = (ImageView) box.getChild();
        view.fitWidthProperty().unbind();//.dispose();
        view.fitHeightProperty().unbind();//.dispose();
        view.imageProperty().setValue(null);
    }
    private static void unbind_box_imagemisslabel(Box box){
        Label label = (Label) box.getChild();
        label.prefWidthProperty().unbind();//.dispose();
        label.prefHeightProperty().unbind();//.dispose();
    }



















    private void set_global_actions(){
        
        
        scrollpane.setOnKeyPressed(event->{
            print("----- OnKeyPressed ----");
            assert event.getEventType() == KeyEvent.KEY_PRESSED;
            assert event.getCharacter() == KeyEvent.CHAR_UNDEFINED;
            assert event.getCharacter().length() == 1;
            
            KeyCode s = event.getCode();
            print("KeyPressed:", quote(s));
            switch(s){
            case DOWN: on_page_down(0.5);break;
            case PAGE_DOWN: on_page_down(0.9);break;
            case UP: on_page_down(-0.5);break;
            case PAGE_UP: on_page_down(-0.9);break;
            case LEFT: on_page_right(-0.5);break;
            case KP_LEFT: on_page_right(-0.9);break;
            case RIGHT: on_page_right(0.5);break;
            case KP_RIGHT: on_page_right(0.9);break;
            }
        });
        scrollpane.setOnKeyTyped(event->{
            print("----- OnKeyTyped ----");
            assert event.getEventType() == KeyEvent.KEY_TYPED;
            assert event.getCode() == KeyCode.UNDEFINED;
            assert event.getCharacter().length() == 1;
            String s = event.getCharacter();
            print("KeyTyped:", quote(s));
            for (int i = 0; i < s.length(); ++i){
                char c = s.charAt(i);
                switch(c){
                case ' ':
                    on_page_down(0.9);
                    break;
                }
            }
        });
        
        /* * /
        scrollpane.setOnDragDetected(event->{
            print("----- OnDragDetected ----");
            __print_event(event);
            //event.consume();
            //event.setDragDetect(true);
            scrollpane.startFullDrag();
        });

        scrollpane.setOnMouseDragEntered(event->{
            print("----- OnMouseDragEntered ----");
            __print_event(event);
            //event.consume();
        });
        scrollpane.setOnMouseDragExited(event->{
            print("----- OnMouseDragExited ----");
            __print_event(event);
            //event.consume();
        }); 
        scrollpane.setOnMouseDragReleased(event->{
            print("----- OnMouseDragReleased ----");
            __print_event(event);
            //event.consume();
        }); 
        
        
        /* */
        
        print("scrollpane.setOnMouseDragged");
        scrollpane.setOnMouseDragged(event->{
            print("----- OnMouseDragged ----");
            //__print_event(event);
            event.consume();
            
            double new_x = event.getScreenX();
            double new_y = event.getScreenY();
            double dx = new_x - x;
            double dy = new_y - y;
            x = new_x;
            y = new_y;
            
            
            //double dV = scrollpane.dY2dVvalue(dy);
            //double dH = scrollpane.dX2dHvalue(dx);
            double ylen = scrollpane.getViewportBounds().getHeight();
            double xlen = scrollpane.getViewportBounds().getWidth();
            Node node = scrollpane.getContent();
            if (node == null) return;// 0.0;
            double Ylen = node.getLayoutBounds().getHeight();
            double Xlen = node.getLayoutBounds().getWidth();
            
            print("dx, dy =", dx, dy);
            print("xlen, ylen =", xlen, ylen);
            
            if (Ylen > ylen) on_page_down(-dy/ylen);
            if (Xlen > xlen) on_page_right(-dx/xlen);
        });
        print("scrollpane.setOnMousePressed");
        scrollpane.setOnMousePressed(event->{
            print("----- OnMousePressed ----");
            //__print_event(event);
            //event.consume();
            x = event.getScreenX();
            y = event.getScreenY();
        });
        
        set_action__same(top_layer);
        if (vbox__set_action__same) {
            set_action__same(vbox);
            assert scrollpane.getOnMouseDragged() == vbox.getOnMouseDragged();
        }
    }
    
    private static void __print_event(javafx.scene.input.MouseEvent event){
        
            print(event, event.getClass());
            print(event.getX(), event.getY());
            print(event.getScreenX(), event.getScreenY());
            print(event.getSceneX(), event.getSceneY());
            print(event.getPickResult().getIntersectedPoint());
    }
    
    private void on_page_down(double num_pages){
        double delta = scrollpane.calcVdelta() * num_pages;
        if (Double.isNaN(delta)) return;
        scrollpane.setVvalue(scrollpane.getVvalue() + delta);
    }
    private void on_page_right(double num_pages){
        double delta = scrollpane.calcHdelta() * num_pages;
        if (Double.isNaN(delta)) return;
        print("delta = scrollpane.calcHdelta() * num_pages --", 
              delta, scrollpane.calcHdelta(), num_pages);
        scrollpane.setHvalue(scrollpane.getHvalue() + delta);
    }
    
    private void __set_action__except_Directory(Node node){
        node.setOnMouseClicked(event -> {
            //print("----- OnMouseClicked ----");
            if (event.getEventType() != MouseEvent.MOUSE_CLICKED) return;
            //print("here");
            //ERROR: if (! event.isPrimaryButtonDown()) return;
            if (! event.isStillSincePress()) return;
            if (event.getButton() == MouseButton.PRIMARY) {
                print("----- on_left_click_nondir ----");
                on_left_click_nondir();
            } else if (event.getButton() == MouseButton.SECONDARY) {
                print("----- on_right_click_nondir ----");
                on_right_click_nondir();
            } else if (event.getButton() == MouseButton.MIDDLE) {
                print("----- on_middle_click_nondir ----");
                on_middle_click_nondir();
            }
            event.consume();
            
        });
    }
    private void __set_action__Directory(Path path, Node node){
        node.setOnMouseClicked(event -> {
            print("----- OnMouseClicked ----");
            if (event.getEventType() != MouseEvent.MOUSE_CLICKED) return;
            //print("here");
            //ERROR: if (! event.isPrimaryButtonDown()) return;
            if (event.getButton() != MouseButton.PRIMARY) return;
            print("----- on_click_dir ----", path);
            on_click_dir(path);
        });
    }
    private void set_action(final Path path, Node node){
        set_action__kinds(path, node);
        if (vbox__set_action__same) set_action__same(node);
    }
    private void set_action__kinds(final Path path, Node node){
        Pair<PathType, Info> type_info = path2type_info_cache.get(path);
        PathType type = type_info.fst;
        Info info = type_info.snd;
        switch(type){
            case Image:
                break;
            case Directory:
                __set_action__Directory(path, node);
                return;
                //break;
            case BrokenImage:
                break;
            case Other:
                break;
            default:
                assert false;
        }
        __set_action__except_Directory(node);
    }
    private void set_action__same(Node node){
        __bind_drag_action_to_pane(node);
        //__bind_pressdown_action_to_pane(node);
    }
    private void set_actions(){
        if (true) return;
        print("------- start of set actions ----------");
        // TODO
        // imagebox_path_infos, vbox, state.get_path_infos(), widthProperty(), font_info
        List<Path> paths = state.get_paths();
        
        assert paths.size() == vbox.getChildren().size();
        for (int i = 0; i < paths.size(); i++){
            Path path = paths.get(i);
            Node node = vbox.getChildren().get(i);
            set_action(path, node);
        }
        
        print("------- middle of set actions ----------");
        try {
        for (Node node : vbox.getChildren()){
            __bind_drag_action_to_pane(node);
        }
        __bind_drag_action_to_pane(vbox);
        assert scrollpane.getOnMouseDragged() == vbox.getOnMouseDragged();
        } catch(Exception e){
            e.printStackTrace();
            throw e;
        }
        print("------- end of set actions ----------");
    }
    private void __bind_pressdown_action_to_pane(Node node){
        node.onMousePressedProperty().bind(scrollpane.onMousePressedProperty());
    }
    private void __bind_drag_action_to_pane(Node node){
        node.onMouseDraggedProperty().bind(scrollpane.onMouseDraggedProperty());
    }
    
    public void on_left_click_nondir(){
        on_page_down(0.9);
    }
    public void on_middle_click_nondir(){
        on_click_dir(state.getCurrDir());
    }
    public void on_right_click_nondir(){
        on_page_down(-0.9);
    }
    public void on_click_dir(Path dir){
        if (dir.equals(state.getCurrDir()))
            on_click_opened_dir(dir);
        else
            on_click_closed_dir(dir);
    }
    public void on_click_closed_dir(Path dir){
        open_dir(dir);
    }
    private void open_dir(Path dir){
        // double old_top = get_top(scrollpane);
        state.open(dir);
        repaint();
        // set_top(scrollpane, old_top);
        //on_visibles_change();
    }
    public void on_click_opened_root(Path root){
        // TODO
    }
    public void on_click_opened_dir(Path dir){
        if (dir.equals(state.root))
            on_click_opened_root(dir);
        else
            open_dir(Funcs.get_parent(dir));
    }
}

/*
@FunctionalInterface
interface IAction{
    public void run();
}
class MyActionEvent extends Event{
    IAction action;
    MyActionEvent(
        EventType<? extends MyActionEvent> eventType, 
        IAction f
    ){
        super(eventType);
        this.action = f;
        assert f != null;
    }
    
    void run(){
        action.run();
    }
    
    public static EventType<MyActionEvent> AfterGUILayout = new EventType("AfterGUILayout");
}
/*
EventType<T extends Event>
EventHandler<T extends Event> (T) -> {}
addEventHandler(EventType<T> eventType, EventHandler<? super T> eventHandler)
fireEvent(Event event)
*/
