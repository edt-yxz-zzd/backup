/*
open to many files ==>> OutOfMemoryError??



if not append to ls, it seems OK;

when 186th load_image{new Image(stream(file2bytes))} append to ls:
when 194th load_image{new Image(string)} append to ls:
    Caused by: java.lang.OutOfMemoryError: Java heap space
        at com.sun.javafx.iio.jpeg.JPEGImageLoader.load(Unknown Source)


aImageView.imageProperty().setValue(null); // it works!!

*/


package seed;
import seed.Funcs;


import static seed.io.Prints.*;
import java.nio.file.Path;
import java.nio.file.Paths;


import java.util.List;
import java.util.ArrayList;
import javafx.scene.image.Image;
import java.net.MalformedURLException;
import java.io.IOException;


import javafx.application.Application;
import javafx.stage.Stage;


public class TestImage extends Application {
    public void start(final Stage stage){
        main_(null);
        System.exit(0);
    }
    
    public static void main_(String[] args){
        String im = "E:/multimedia/picture/funny/10sentences.jpg";
        Path path;
        path = Paths.get(im);
        /*
        try{
            path = Paths.get(im);
        } catch(IOException ex){
            print(ex);
            return;
        }*/
        List<Image> ls = new ArrayList<>();
        
        for (int i = 0; i < 10000; i++){
            print(i);
            Image x = Funcs.load_image(path);
            // ls.add(x);
        }
        System.out.println("");
    }
}