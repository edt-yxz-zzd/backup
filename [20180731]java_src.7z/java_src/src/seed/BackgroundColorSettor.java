package seed;

import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.paint.Color;
import javafx.scene.layout.Region;

public class BackgroundColorSettor{
    public static void setBackgroundColor(Region control, Color c){
        BackgroundFill fill = new BackgroundFill(c, null, null);
        control.setBackground(new Background(fill));
    }
}


