
package seed.io;

import seed.io.__ImageWidthHeightGettor__private.ImageWidthHeightGettor.Pair;
// import seed.io.__ImageWidthHeightGettor__private.ImageWidthHeightGettor as __p;

import java.net.URL;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;



/**
<pre>
why?
    BufferedImage im = ImageIO.read(f); 
        // throw IOException if image broken
        // read all pixels??
        // at least verify actual number of pixels
    so I have to implement 
        ImageWidthHeightGettor.getImageWidthHeight(URL|File) -&gt; WidthHeightPair&lt;Integer, Integer&gt;
        which simply get property without read pixels
</pre>
*/
public class ImageWidthHeightGettor{
    /**
        @param url              url to image
        @return                 null if not image else (width, height) of image
        @throws IOException     io fail or image broken
    */
    public static WidthHeightPair<Integer, Integer> getImageWidthHeight(final URL url) throws IOException{
        return makeWidthHeightPair(__p.getImageWidthHeight(url));
    }
    /**
        @param path             path to image
        @return                 null if not image else (width, height) of image
        @throws IOException     io fail or image broken
    */
    public static WidthHeightPair<Integer, Integer> getImageWidthHeight(final File path) throws IOException{
        return makeWidthHeightPair(__p.getImageWidthHeight(path));
    }
    /**
        @param path             path to image
        @return                 null if not image else (width, height) of image
        @throws IOException     io fail or image broken
    */
    public static WidthHeightPair<Integer, Integer> getImageWidthHeight(final Path path) throws IOException{
        return getImageWidthHeight(path.toFile());
    }
    
    


    
    public static class WidthHeightPair<W, H> {
        public final W width;
        public final H height;
        public WidthHeightPair(W w, H h){ 
            assert w != null;
            assert h != null;
            width = w; height = h;}
        public WidthHeightPair(Pair<W, H> pair){this(pair.fst, pair.snd);}

        public String toString(){
            return //this.getClass().getName() + 
                    "(" + width.toString() + ", " 
                        + height.toString() + ")";
        } 
    }

        
    public static <W, H> WidthHeightPair<W, H> makeWidthHeightPair(W w, H h){
        return new WidthHeightPair<W, H>(w, h);
    }
    private static <W, H> WidthHeightPair<W, H> makeWidthHeightPair(Pair<W, H> pair){
        if (pair == null){
            return null;
        }
        return new WidthHeightPair<W, H>(pair);
    }


    private static final 
        seed.io.__ImageWidthHeightGettor__private.ImageWidthHeightGettor
            __p = null;
}


