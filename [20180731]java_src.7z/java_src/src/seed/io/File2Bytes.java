
package seed.io;

import java.io.File;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.ByteArrayInputStream;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import java.io.IOException;


public class File2Bytes {
    public static long file2size(Path file) throws IOException {
        return Files.size(file);
    }
    public static long file2size(String file) throws IOException {
        Path path = Paths.get(file);
        return file2size(path);
    }
    //public static long file2size(File file) {
    //    return file.length();
    //}

    public static byte[] file2bytes(Path path) throws IOException {
        return Files.readAllBytes(path);
    }
    
    public static ByteArrayInputStream file2byte_stream(Path path) throws IOException {
        return new ByteArrayInputStream(file2bytes(path));
    }
}


