

/*
    BufferedImage im = ImageIO.read(f); // throw IOException if image broken
        // read all pixels??
        // at least verify actual number of pixels
    so I have to implement 
        ImageWidthHeightGettor.getImageWidthHeight(URL|File) -> Pair<Integer, Integer>
        which simply get property without read pixels
*/

/*
javax.imageio.ImageReader
    getInput()
    getMinIndex()
    getHeight(int imageIndex)
    getWidth(int imageIndex)
    setInput(Object input)

javax.imageio.ImageIO
    getImageReaders(Object input)
    getImageReadersBySuffix(String fileSuffix)
    getImageReadersByFormatName(String formatName)
    getReaderFileSuffixes()
    getReaderFormatNames()
    read(ImageInputStream stream)
javax.imageio.stream.FileImageInputStream
    FileImageInputStream(File f)
javax.imageio.stream.MemoryCacheImageInputStream
    MemoryCacheImageInputStream(InputStream stream)
java.net.URL
    openStream()
*/

/*
    javac ImageWidthHeightGettor.java
    java -ea -cp . ImageWidthHeightGettor
*/

package seed.io.__ImageWidthHeightGettor__private;

import java.net.URL;
import javax.imageio.stream.ImageInputStream;
import javax.imageio.stream.MemoryCacheImageInputStream;
import javax.imageio.stream.FileImageInputStream;
import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import java.util.Iterator;
import java.io.IOException;
import java.io.InputStream;
import java.io.File;
import java.awt.image.BufferedImage;
//import java.awt.Image;


public class ImageWidthHeightGettor{
    public static class Pair<K, V> {
        public final K fst;
        public final V snd;
        public Pair(K k, V v){ fst = k; snd = v;}
        public static <A, B> Pair<A, B> makePair(A a, B b){
            return new Pair<A, B>(a, b);
        }
        public String toString(){
            return this.getClass().getName() + "(" + fst.toString() + ", " + snd.toString() + ")";
        }
    };
    public static ImageInputStream url2ImageInputStream(URL url)throws IOException{
        InputStream in;
        try {
            in = url.openStream();
        } catch(IOException e){
            throw new IOException("cannot open URL: " + url, e);
        }
        
        // System.err.println(in.getClass()); 
        // java.io.BufferedInputStream
        
        ImageInputStream im_in = new MemoryCacheImageInputStream(in);
        return im_in;
    }
    public static ImageInputStream path2ImageInputStream(File path)throws IOException{
        ImageInputStream im_in;
        try {
            im_in = new FileImageInputStream(path);
        } catch(IOException e){
            throw new IOException("cannot open File: " + path, e);
        }
        
        return im_in;
    }
    public static Pair<Integer, Integer> getImageWidthHeight(URL url)throws IOException{
        try (ImageInputStream im_in = url2ImageInputStream(url)){
            return getImageWidthHeight(im_in, url);
        }
    }
    public static Pair<Integer, Integer> getImageWidthHeight(File path)throws IOException{
        try (ImageInputStream im_in = path2ImageInputStream(path)){
            return getImageWidthHeight(im_in, path);
        }
    }
    @FunctionalInterface
    public static interface Rst1Arg1<R, A> {
        R rst1arg1(A a)throws Exception;
    };
    public static <R> R handle(ImageInputStream im_in, Rst1Arg1<R, ? super ImageReader> f)throws Exception{
        Iterator<ImageReader> it = ImageIO.getImageReaders(im_in);
        return handleIter(it, f);
    }
    public static <R,A> R handleIter(Iterator<A> it, Rst1Arg1<R, ? super A> f)throws Exception{
        if (it.hasNext()) {
            Exception ex = null;
            while (it.hasNext()) {
                A a = it.next();
                try {
                    return f.rst1arg1(a);
                } catch (Exception e) {
                    ex = e;
                }
            }
            if (ex != null)
            throw ex;
        }
        return null; // no args at all
    }



    public static Pair<Integer, Integer> getImageWidthHeight(final ImageInputStream im_in, final Object path) throws IOException{
        try{
        return handle(im_in, im -> {
                assert im.getInput() == null;
                im.setInput(im_in);
                try {
                    int h = im.getHeight(im.getMinIndex());
                    int w = im.getWidth(im.getMinIndex());
                    return new Pair<Integer, Integer>(w, h);
                } catch (IOException e) {
                    throw new IOException("broken input stream?? cannot recognize image from: " + path, e);
                }
            });
        } catch (IOException e) {
            throw e;
        }
        catch(Throwable e){
            assert false;
            e.printStackTrace();
            System.exit(-1);
            return null;
        }
    }

    public static Pair<Integer, Integer> ver1_getImageWidthHeight(final ImageInputStream im_in, Object path) throws IOException{
        Iterator<ImageReader> it = ImageIO.getImageReaders(im_in);
        // for (ImageReader im: it){
        if (it.hasNext()) {
            IOException ex = null;
            while (it.hasNext()) {
                ImageReader im = it.next();
                assert im.getInput() == null;
                im.setInput(im_in);
                try {
                    int h = im.getHeight(im.getMinIndex());
                    int w = im.getWidth(im.getMinIndex());
                    return new Pair<Integer, Integer>(w, h);
                } catch (IOException e) {
                    ex = e;
                }
            }
            
            throw new IOException("broken input stream?? cannot recognize image from: " + path, ex);
        }
        return null;
    }
    
    public static void main(String[] args){
        {
            String path = "E:/my_data/program_source/java_src/se8/src/chapter4/broken.bmp";
            File f = new File(path);
            try{
                System.out.println(f);
                System.out.println(getImageWidthHeight(f)); // donot read all pixels
            } catch(Exception e) {
                e.printStackTrace();
                assert false;
            }
        }
        System.out.println();

        {
            String path = "E:/my_data/program_source/java_src/se8/src/chapter4/broken.bmp";
            File f = new File(path);
            try{
                System.out.println(f);
                BufferedImage im = ImageIO.read(f); // read all pixels
                assert false;
            } catch(IOException e) {
                // e.printStackTrace();
            }
            
        }
        System.out.println();
        
        {
            String path = "E:/multimedia/picture/funny/10sentences.jpg";
            File f = new File(path);
            try{
                System.out.println(f);
                System.out.println(getImageWidthHeight(f));
            } catch(Exception e) {
                e.printStackTrace();
            }
        }
        
        {
            String path = "file:///E:/multimedia/picture/funny/10sentences.jpg";
            System.err.println(path);
            try{
                URL url = new URL(path);
                System.out.println(url);
                System.out.println(getImageWidthHeight(url));
            } catch(Exception e) {
                e.printStackTrace();
            }
        }

    }
}


