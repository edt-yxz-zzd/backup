
package seed.io;
import java.util.Scanner;
import java.util.StringJoiner;
import java.io.IOException;

public class Prints{
    public static synchronized void println(Object... ss){
        for (Object s : ss)
            System.out.println(s);
    }
    public static synchronized void print(Object... ss){
        print_(ss);
        System.out.println();
    }
    public static synchronized void print_(Object... ss){
        print_sep_("  ", ss);
    }
    public static synchronized void print_sep_(Object sep, Object... ss){
        for (Object s : ss){
            System.out.print(s);
            System.out.print(sep);
        }
    }
    public static synchronized void print_sep(Object sep, Object... ss){
        print_sep_(ss);
        System.out.println();
    }

    public static String quote(Object obj){
        return "\"" + obj + "\"";
    }
    
    public static String comma(Object... objs){
        StringJoiner sj = new StringJoiner(", ");
        for (int i = 0; i < objs.length; ++i)
            sj.add(objs[i].toString());
        return sj.toString();
    }
    public static String str_tuple(Object... objs){
        return "(" + comma(objs) + ")";
    }


    public static Scanner scanner = new Scanner(System.in);
    public static void pause(){
        System.err.print("pause:");
        try {System.in.read();
        } catch(IOException ex){
            ex.printStackTrace();
        }
    }
}

