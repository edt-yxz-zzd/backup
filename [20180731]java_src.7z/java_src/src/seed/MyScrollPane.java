package seed;

import javafx.geometry.BoundingBox;
import javafx.geometry.Bounds;
import javafx.scene.control.ScrollPane; 
import javafx.scene.Node;
import javafx.beans.property.ObjectProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.property.ReadOnlyObjectPropertyBase;
import javafx.beans.property.ReadOnlyObjectProperty;

/**
    1) ScrollPane.viewportBounds is weird,
        use fixScrollPaneViewportBounds(this.getViewportBounds()) instead of this.getViewportBounds();
    2) there are bugs in ScrollPane::viewportBounds update method;
        when 
        use getMyViewportBounds() instead of fixScrollPaneViewportBounds(this.getViewportBounds()),
            since viewportBounds may not update yet (assume viewport.width and .height are corret);
    3) scrollpane.layout() dont work; 
        use scrollpane.getContent().layout() instead;

    @see #getMyViewportBounds
*/
public class MyScrollPane extends ScrollPane{
    private final MyViewportBounds myViewportBounds = new MyViewportBounds();
    private 
        class MyViewportBounds extends ReadOnlyObjectPropertyBase<Bounds>{
            //private Bounds b = MyScrollPane.this.getViewportBounds();
            //public void set(Bounds b){this.b = b;}
            @Override
            public Bounds get(){return calc_realViewportBounds(MyScrollPane.this);}
            @Override 
            public Object getBean(){return MyScrollPane.this;}
            @Override 
            public String getName(){return "myViewportBounds";}
            @Override
            public void fireValueChangedEvent(){super.fireValueChangedEvent();}
            
        };
    
    private ChangeListener<Bounds> content_layoutBounds_listener = 
        (p, old, n) -> updateMyViewportBounds();
    
    public MyScrollPane(){
        super();
        addListenersToUpdateMyViewportBounds();
    }
    
    private void addListenersToUpdateMyViewportBounds(){
        hminProperty().addListener(
            (p, oldx, newx) -> updateMyViewportBounds()
        );
        hmaxProperty().addListener(
            (p, oldx, newx) -> updateMyViewportBounds()
        );
        hvalueProperty().addListener(
            (p, oldx, newx) -> updateMyViewportBounds()
        );
        
        vminProperty().addListener(
            (p, oldx, newx) -> updateMyViewportBounds()
        );
        vmaxProperty().addListener(
            (p, oldx, newx) -> updateMyViewportBounds()
        );
        vvalueProperty().addListener(
            (p, oldx, newx) -> updateMyViewportBounds()
        );
        
        viewportBoundsProperty().addListener(
            (p, oldx, newx) -> {
                if (oldx.getHeight() != newx.getHeight() || 
                    oldx.getWidth() != newx.getWidth()
                    ) updateMyViewportBounds();
            }
        );
        
        // scrollpane.content.layoutBounds
        contentProperty().addListener(
            (p, old, n) -> {
                if (old != null)
                    old.layoutBoundsProperty().removeListener(content_layoutBounds_listener);
                if (n != null)
                    n.layoutBoundsProperty().addListener(content_layoutBounds_listener);
            }
        );
        
        // scrollpane.width/height
        widthProperty().addListener(
            (p, oldx, newx) -> updateMyViewportBounds()
        );
        heightProperty().addListener(
            (p, oldx, newx) -> updateMyViewportBounds()
        );
    }
    public MyScrollPane(Node content){
        this();
        super.setContent(content);
        //super.getChildren().add(node); getContent().addListener??
    }
    
    
    
    private void updateMyViewportBounds(){
        myViewportBounds.fireValueChangedEvent();
    }
        
    /**
        viewportBounds may not update yet, let's compute it if width and height are correct.
        
        call getMyViewportBounds() instead of fixScrollPaneViewportBounds(this.getViewportBounds()),
            since viewportBounds may not update yet
        
        @see
            #calc_viewportMinAInContentLayoutA
            #calc_viewportMinAInContentLayoutA
            #calc_realViewportBounds
    */
    public final Bounds getMyViewportBounds(){
        return myViewportBounds.get();//calc_realViewportBounds(this);
    }

    public final ReadOnlyObjectProperty<Bounds> myViewportBoundsProperty(){
        return myViewportBounds;
    }

    public final Bounds fixedViewportBounds(){
        return fixScrollPaneViewportBounds(getViewportBounds());
    }


















    
    
    /**
    viewportBounds is weird, let's map it into content.layoutBounds.

<pre>
    // relative to content.layoutBounds
    let miny = viewportBounds.minY, etc
    let f_miny = fixedViewportBounds.minY , etc
    let h = viewportBounds.height = fixedViewportBounds.height
    let H = content.layoutBounds.height
    
    miny + h == maxy
    when thumb at top most
        miny == 0 ==>> maxy == h
        should have : f_miny = 0, f_maxy = h
        // miny = 0 ~~ f_maxy = h
    when thumb at buttom
        miny = -(H-h) = h-H
        ==>> maxy == 2h - H # meanlingless !!!
        should have : f_miny = H-h, f_maxy = H
        // miny = h-H ~~  f_miny = H-h
    when scrolling till finish
        do not trigger viewportBoundsProperty!
        but if focus other program, viewportBoundsProperty varies!!
    
    [miny = 0 ~~ f_maxy = h][miny = h-H ~~ f_maxy = H]
        ==>> f_maxy = h - miny = maxy - 2*miny
        ==>> f_y = h - y
</pre>    
        
    */
    public static Bounds fixScrollPaneViewportBounds(Bounds b){
        // f_maxy = h - miny
        
        double width = b.getWidth();
        double height = b.getHeight();
        double depth = b.getDepth();
        
        double minX = width - b.getMaxX();
        
        double minY = height - b.getMaxY();
        
        double minZ = depth - b.getMaxZ();
        return new BoundingBox(minX, minY, minZ, width, height, depth);
    }











    
    /**
        viewportBounds may not update yet, let's compute it if width and height are correct.

<pre>
    since there are bugs in ScrollPane::viewportBounds update method
        e.g. 
            scrolling (i.e. vvalue change) ==>> not update viewportbounds 
                (since viewport size does not change, 
                 width and height is correct 
                 minX, minY are old values);
            scrolling then switch to other program ==>> update viewportbounds;
            adjust pane's size (now hvalue/vvalue does not change) ==>> 
                not update viewportbounds yet when width/height changes
                viewportbounds update event happens after size update event
            
    we have to calc by ourselves. 
    (assume width and height are correct.
        e.g. hvalue/vvalue/viewportbounds change;
        what about content.layoutbounds change??)
</pre>
        @param viewportALength          e.g. aScrollPane.getViewportBounds().getHeight()
        @param contentLayoutALength     e.g. aScrollPane.getContent().getLayoutBounds().getHeight()
        @param contentLayoutMinA        e.g. aScrollPane.getContent().getLayoutBounds().getMinY()
        @param radioMinA                e.g. aScrollPane.getVmin()
        @param radioA                   e.g. aScrollPane.getVvalue()
        @param radioMaxA                e.g. aScrollPane.getVmax()
        @return                         e.g. top of viewport in content layoutBounds
    */
    public static double calc_viewportMinAInContentLayoutA(
        double viewportALength, 
        double contentLayoutALength, 
        double contentLayoutMinA,
        double radioMinA,
        double radioA,
        double radioMaxA){
        // (radioA - radioMinA)/(radioMaxA - radioMinA) == viewportMinAInContentLayoutA/(contentLayoutALength - viewportALength)
        return (contentLayoutALength - viewportALength)*(radioA - radioMinA)/(radioMaxA - radioMinA);
    }
    public static double calc_viewportMinYInContentLayoutY(ScrollPane pane){
        double viewportALength = pane.getViewportBounds().getHeight();
        double contentLayoutALength = pane.getContent().getLayoutBounds().getHeight();
        double contentLayoutMinA = pane.getContent().getLayoutBounds().getMinY();
        double radioMinA = pane.getVmin();
        double radioA = pane.getVvalue();
        double radioMaxA = pane.getVmax();
        return calc_viewportMinAInContentLayoutA(
            viewportALength,
            contentLayoutALength, 
            contentLayoutMinA,
            radioMinA,
            radioA,
            radioMaxA
        );
    }
    public static double calc_viewportMinXInContentLayoutX(ScrollPane pane){
        double viewportALength = pane.getViewportBounds().getWidth();
        double contentLayoutALength = pane.getContent().getLayoutBounds().getWidth();
        double contentLayoutMinA = pane.getContent().getLayoutBounds().getMinX();
        double radioMinA = pane.getHmin();
        double radioA = pane.getHvalue();
        double radioMaxA = pane.getHmax();
        return calc_viewportMinAInContentLayoutA(
            viewportALength,
            contentLayoutALength, 
            contentLayoutMinA,
            radioMinA,
            radioA,
            radioMaxA
        );
    }
    
    /**
        use 
            viewportBounds.width/height, 
            scrollpane.h/v[min/value/max], 
            scrollpane.content.layoutBounds
        to calc realViewportBounds
    */
    public static Bounds calc_realViewportBounds(ScrollPane scrollpane){
        if (scrollpane.getContent() == null) 
            return scrollpane.getViewportBounds();
        //Bounds b = fixScrollPaneViewportBounds(scrollpane.getViewportBounds());
        Bounds b = scrollpane.getViewportBounds();
        double width = b.getWidth();
        double height = b.getHeight();
        double minX = calc_viewportMinXInContentLayoutX(scrollpane);
        double minY = calc_viewportMinYInContentLayoutY(scrollpane);
        
        return new BoundingBox(minX, minY, width, height);
    }
    
    
    
    
    
    
    public double dY2dVvalue(double dY){
        return dY2dVvalue(this, dY);
    }
    public double dX2dHvalue(double dX){
        return dX2dHvalue(this, dX);
    }
    public static double dY2dVvalue(ScrollPane scrollpane, double dY){
        double delta_per_page = calc_deltaVvalue_per_page(scrollpane);
        double ylen = scrollpane.getViewportBounds().getHeight();
        return delta_per_page / ylen * dY;
    }
    public static double dX2dHvalue(ScrollPane scrollpane, double dX){
        double delta_per_page = calc_deltaHvalue_per_page(scrollpane);
        double xlen = scrollpane.getViewportBounds().getWidth();
        return delta_per_page / xlen * dX;
    }
    
    private static double normalize_delta(double delta, double len){
        return 0;
    }
    public static double calc_deltaVvalue_per_page(ScrollPane scrollpane){
        // vmin, vvalue, vmax ~ Ymin, ymin, Ymax-ylen(=Ymin+Ylen-ylen)
        // vvalue - vmin : vmax - vmin == ymin - Ymin : Ylen - ylen
        //        what if Ylen == ylen??
        // ? : vmax - vmin == ylen : Ylen - ylen
        // delta_vvalue = ? = (vmax - vmin) * ylen / (Ylen - ylen) 
        //                  = vlen * ylen / (Ylen - ylen)
        Node node = scrollpane.getContent();
        if (node == null) return 0.0;
        double Ylen = node.getLayoutBounds().getHeight();
        
        double vlen = scrollpane.getVmax() - scrollpane.getVmin();
        double ylen = scrollpane.getViewportBounds().getHeight();
        double delta = vlen * ylen / (Ylen - ylen);
        return delta;
    }
    
    public static double calc_deltaHvalue_per_page(ScrollPane scrollpane){
        Node node = scrollpane.getContent();
        if (node == null) return 0.0;
        double Xlen = node.getLayoutBounds().getWidth();
        
        double hlen = scrollpane.getHmax() - scrollpane.getHmin();
        double xlen = scrollpane.getViewportBounds().getWidth();
        double delta = hlen * xlen / (Xlen - xlen);
        return delta;
    }
    
    public double calcVdelta(){
        return calc_deltaVvalue_per_page(this);
    }
    public double calcHdelta(){
        return calc_deltaHvalue_per_page(this);
    }
}