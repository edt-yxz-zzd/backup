package seed.util;
//import static seed.util.DropFirstArg.*;


import java.lang.Runnable; // ()->()
import java.util.function.Supplier; // ()->R
import java.util.function.Function; // V->R
import java.util.function.Consumer; // V->()
import java.util.function.BiConsumer; // A->B->()

/** 
    dropFirstArg :: (a->b) -> c -> (a->b);
    dropFirstArg f a = f
    dropFirstArg(f) = (a, b...) -> f(b...)
*/
public class DropFirstArg {
    public static <T, R> Function<T, R> dropFirstArg(Supplier<R> f){
        if (f == null) return null;
        return a -> f.get();
    }
    public static <V> Consumer<V> dropFirstArg(Runnable f){
        if (f == null) return null;
        return a -> f.run();
    }
    public static <A, B> BiConsumer<A, B> dropFirstArg(Consumer<B> f){
        if (f == null) return null;
        return (a, b) -> f.accept(b);
    }
}
