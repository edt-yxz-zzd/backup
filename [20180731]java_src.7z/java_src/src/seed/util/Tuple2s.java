
package seed.util;

public class Tuple2s {
    public static class Tuple2<E0, E1> {
        public final E0 _0; public final E1 _1; 
        public Tuple2(E0 e0, E1 e1){
            _0 = e0; _1 = e1; 
        }
        
        final int size(){
            return 2;
        }
        
        final Object[] toArray(){
            return new Object[]{_0, _1};
        }
        
        public String toString(){
            return String.format("(%s, %s)"
                , _0.toString(), _1.toString()
                );
        }

    }
    
    

    public static <E0, E1> Tuple2<E0, E1> 
        makeTuple(E0 e0, E1 e1){
            return new Tuple2<E0, E1>(e0, e1);
        }



    
}

