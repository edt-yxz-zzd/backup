
package seed.util;

import java.util.Iterator;
import java.util.LinkedHashMap;
//import java.util.HashMap;
import java.util.Map;
//import java.util.function.Function;

//import seed.annotations.NonNull;
import seed.annotations.NonNegative;



/**
    class invariants:
        0 <= size() <= maxSize
        
    accessOrder - the ordering mode - true for access-order, false for insertion-order
    it seems default accessOrder = true
*/
public class LimitedLinkedHashMap<K,V> extends LinkedHashMap<K,V>{
    private int maxSize;
    public LimitedLinkedHashMap(
                    @NonNegative int maxSize){
        super();
        setMaxSize(maxSize);
    }
    public LimitedLinkedHashMap(
                    @NonNegative int maxSize,
                    int initialCapacity){
        super(initialCapacity);
        setMaxSize(maxSize);
    }
    public LimitedLinkedHashMap(
                    @NonNegative int maxSize,
                    int initialCapacity,
                    float loadFactor){
        super(initialCapacity, loadFactor);
        setMaxSize(maxSize);
    }
    public LimitedLinkedHashMap(
                    @NonNegative int maxSize,
                    int initialCapacity,
                    float loadFactor,
                    boolean accessOrder){
        super(initialCapacity, loadFactor, accessOrder);
        setMaxSize(maxSize);
    }
    @Override
    protected boolean removeEldestEntry(Map.Entry eldest) {
        return size() > maxSize;
    }
    
    public final int getMaxSize(){
        return maxSize;
    }
    
    public final void setMaxSize(int maxSize){
        if (maxSize < 0)
            throw new IllegalArgumentException("maxSize < 0: " + maxSize);
        Iterator<K> it = keySet().iterator();
        while (size() > maxSize) {
            // remove eldest entry
            it.next();
            it.remove();
        }
        this.maxSize = maxSize;
    }
}

