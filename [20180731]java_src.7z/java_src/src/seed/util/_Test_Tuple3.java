
package seed.util;

import static seed.util.Tuple3s.*;

class _Test_Tuple3{
    public static void main(String[] args){
        Tuple3 t = makeTuple("abc", 123, 'd');
        System.out.println(t);
        System.out.println(t.toArray());
        System.out.println(fromArray3(t.toArray()));
    }
}