
package seed.util;

import java.util.LinkedHashMap;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import seed.annotations.NonNull;
import seed.annotations.NonNegative;
import seed.util.LimitedLinkedHashMap;



/**
    a LRU cache, cache the result of compute(key).

<pre>
    three set of results are maintained:
        results allocated - result of get(key) before discard(key)
        results cached - allocated result after discard(key)
        results missing - cached result after cache full and be eldest
</pre>

<pre>
    class invariants
        not set(key2using) & set(key2discarded)
        len(key2discarded) <= cache_size
        not null in key2using.values()
        not null in key2discarded.values()

</pre>
*/
public class CacheLRU<K, V> {

    // final private int cache_size;
    final private Function<? super K,? extends V> compute;
    final private ConcurrentHashMap<K, V> key2using;
    final private LimitedLinkedHashMap<K, V> key2discarded;

    /**
        @param cache_size 
            max size of cached deleted values
        @param compute
            called if cache miss
    */
    public CacheLRU(@NonNegative int cache_size, 
                    @NonNull Function<? super K,? extends V> compute){
        //assert cache_size != null;
        assert compute != null;
        assert cache_size >= 0;
        
        // this.cache_size = cache_size;
        this.compute = compute;
        key2using = new ConcurrentHashMap<K, V>();
        key2discarded = new LimitedLinkedHashMap<K, V>(cache_size);
    }
    
    /**
        get cached value or calc new value if miss
        @parem key
            arg of compute
        @return
            result of compute(key); may be null
    */
    public V get(K key){
        V v = key2discarded.remove(key);
        if (v != null)
            key2using.put(key, v);
        else {
            v = key2using.computeIfAbsent(key, compute);
            //if (v == null)
            //    throw new NullPointerException("CacheLRU.compute return null");
            
        }
        // v may be null
        return v;
    }
    
    /**
        mark result (from get(key)) as disarded,
        so that the result can be remove from the cache if required.
        
        @param key
            key 
    */
    public void discard(K key){
        V v = key2using.remove(key);
        if (v == null) return;
        
        assert !key2discarded.containsKey(key);
        key2discarded.put(key, v);
        
        assert key2discarded.size() <= key2discarded.getMaxSize();
    }


    public static void main(String[] args){
        final int[] array = new int[]{0};
        CacheLRU<String, Integer> c = new CacheLRU<String, Integer>(3,
            s -> {
                ++array[0];
                return array[0];
            });
        assert 1 == c.get("a");
        assert 2 == c.get("b");
        c.discard("a");
        assert 3 == c.get("c");
        assert 1 == c.get("a");
        c.discard("a");
        c.discard("b");
        c.discard("c");
        assert 4 == c.get("d");
        assert 1 == c.get("a");
        assert 2 == c.get("b");
        assert 3 == c.get("c");
        c.discard("b");
        c.discard("c");
        c.discard("a"); // now b is eldest
        c.discard("d"); // now remove "b" from cache
        assert 5 == c.get("b");
        assert 1 == c.get("a");
        assert 3 == c.get("c");
        assert 4 == c.get("d");
        // assert 3 == c.get("d");
        
    }
}