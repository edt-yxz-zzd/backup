

ClassName_tpl = 'Tuple{N}s'
TupleName_tpl = 'Tuple{N}'
java_tpl = '''
{PackageStatement}

public class {ClassName} {{
    public static class {TupleName}<{T0_N}> {{
        {public_final_Ti__i_0_N}
        public {TupleName}({Ti_ti_0_N}){{
            {_i_eq_ti_0_N}
        }}
        
        final int size(){{
            return {N};
        }}
        
        final Object[] toArray(){{
            return new Object[]{{{_i_0_N}}};
        }}
        
        public String toString(){{
            return String.format("({fmt})"
                {_i_toString_0_N}
                );
        }}

    }}
    
    

    public static <{T0_N}> {TupleName}<{T0_N}> 
        makeTuple({Ti_ti_0_N}){{
            return new {TupleName}<{T0_N}>({t0_N});
        }}
/*
    public static <{T0_N}> {TupleName}<{T0_N}> 
        fromArray{N}(Object[] objs){{
            if (objs.length != {N}){{
                throw new IllegalArgumentException("not array of length [{N}]");
            }}
            return makeTuple({Ti_objs_get_i_0_N});
        }}
*/
    
}}

'''

'''
{concat_partition_N}

choose(N-1, k) # k+1 args
sum choose(N-1, k) {k=0..N-1} = 2**(N-1)
    public static Tuple3<T0, T1, T2> concat(Tuple1<T0> a, Tuple1<T2> b, Tuple1<T3> c){
        return makeTuple(a._0, b._0, c._0);
    }
    public static Tuple3<T0, T1, T2> concat(Tuple2<T0, T1> a, Tuple1<T3> b){
        return makeTuple(a._0, a._1, b._0);
    }
'''



def gen_TupleNs_java(package, N,
                     ClassName_tpl = ClassName_tpl,
                     TupleName_tpl = TupleName_tpl):
    PackageStatement = 'package {};'.format(package) if package else ''
    def join(sep, fmt):
        return sep.join(map(fmt.format, range(N)))
    def repeat(fmt):
        return ''.join(map(fmt.format, range(N)))
    T0_N = join(', ', 'E{}')
    t0_N = join(', ', 'e{}')
    public_final_Ti__i_0_N = repeat('public final E{0} _{0}; ')
    Ti_ti_0_N = join(', ', 'E{0} e{0}')
    _i_0_N = join(', ', '_{}')
    _i_eq_ti_0_N = repeat('_{0} = e{0}; ')
    _i_toString_0_N = repeat(', _{}.toString()')
    fmt = join(', ', '%s')
    Ti_objs_get_i_0_N = join(', ', '(E{0})objs[{0}]')

    
    file_basename = ClassName = ClassName_tpl.format(N=N)
    TupleName = TupleName_tpl.format(N=N)
    src = java_tpl.format(
        N = N,
        PackageStatement = PackageStatement,
        ClassName = ClassName,
        TupleName = TupleName,
        T0_N = T0_N,
        t0_N = t0_N,
        public_final_Ti__i_0_N = public_final_Ti__i_0_N,
        Ti_ti_0_N = Ti_ti_0_N,
        _i_0_N = _i_0_N,
        _i_eq_ti_0_N = _i_eq_ti_0_N,
        _i_toString_0_N = _i_toString_0_N,
        fmt = fmt,
        Ti_objs_get_i_0_N = Ti_objs_get_i_0_N
        )

    return file_basename, src
    
    


'''
{PackageStatement}
    package seed.util;
{N}
    3
{T0_N}
    T0, T1, T2
{t0_N}
    t0, t1, t2
{public_final_Ti__i_0_N}
    public final T0 _0;
    public final T1 _1;
    public final T2 _2;
{Ti_ti_0_N}
    T0 t0, T1 t1, T2 t2
{_i_0_N}
    _0, _1, _2
{_i_eq_ti_0_N}
    _0 = t0;
    _1 = t1;
    _2 = t2;

{_i_toString_0_N}
    ,
    _0.toString(),
    _1.toString(),
    _2.toString()

{fmt}
    %s, %s, %s
{Ti_objs_get_i_0_N}
    (T0) objs[0], (T1) objs[1], (T2) objs[2]


    public static void main(String[] args){
        Tuple3 t = makeTuple("abc", 123, new double[]{100.0, 10.0});
        System.out.println(t);
        System.out.println(t.toArray());
        System.out.println(fromArray3(t.toArray()));
    }

'''

def main(args=None):
    import argparse
    import os.path
    parser = argparse.ArgumentParser(description='''generate "TupleNs.java".
                                     
if input == (3, "seed.util", -p "xxx/src"):
    then output "xxx/src/seed/util/Tuple3s.java"
                                     
if input == (3, "seed.util"):
    then output to <stdout>
    ''')
    parser.add_argument('N', type=int, help='length of tuple; N-tuple')
    parser.add_argument('package', type=str,
                        help='package where TupleNs belongs to. e.g. "seed.util"')
    parser.add_argument('-cp', '--CLASSPATH', type=str, default=None,
                        help='output root. e.g. "xxx/src"')
    
    args = parser.parse_args(args)
    file_basename, src = gen_TupleNs_java(args.package, args.N)

    if args.CLASSPATH is None:
        print(src)
        return 0
    
    fname = os.path.join(args.CLASSPATH,
                         args.package.replace('.', '/'),
                         '{}.java'.format(file_basename))
    
    with open(fname, 'x') as fout:
        fout.write(src)
    
    return 0


if '__main__' == __name__:
    #print(gen_TupleNs_java('seed.util', 3))
    main()


    




