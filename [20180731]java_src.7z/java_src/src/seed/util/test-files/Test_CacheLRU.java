
import seed.util.CacheLRU;

public class Test_CacheLRU{
    public static void main(String[] args){
        CacheLRU.main(args);
        System.out.println("here");
    }
}