
package seed.util;
import static seed.io.Prints.*;

import java.util.function.Supplier; // ()->R
import java.util.function.Function; // V->R
import java.util.function.Consumer; // V->()
import java.util.function.BiConsumer; // A->B->()
import javafx.concurrent.Task;
import javafx.application.Platform;
import java.util.concurrent.atomic.AtomicBoolean;


import seed.excepts.InterruptedByCancelException;
import static seed.util.DropFirstArg.*;



/** background compute and fx GUI update;
    non-reusable.
    
<pre>
    LaterUpdateTask<Void, Node> task = makeLaterUpdateTask<Void, Node>(
        self -> {
            for (int i = 0; i < 10; ++i){
                Node node = ...;
                try{self.report(node);}
                catch(InterruptedByCancelException e){
                    if (self.isLaterUpdateCancelled())
                        break;
                    else 
                        throw e;
                }
            }
            return null;
        },
        (self, node) -> {
            // run on javafx GUI thread
            xxx.getChildren().add(node);
        },
        null // need not update result, since Void
    );
    
</pre>
*/
public class LaterUpdateTask<V, X> extends Task<V>{
    /** background compute and fx GUI update.
        
        @param compute  
            run on background thread
        @param report  
            report midstate; 
            called this.report which called by compute;
            run on javafx GUI thread, using Platform.runLater by default
        @param update_result   
            update final result;
            run on javafx GUI thread, using Platform.runLater by default
    */
    public LaterUpdateTask(
        Function<? super LaterUpdateTask<? extends V, ? super X>, ? extends V> compute,
        BiConsumer<? super LaterUpdateTask<? extends V, ? super X>, ? super X> report,
        Consumer<? super LaterUpdateTask<? extends V, ? super X> > update_result
    ){
        super();
        this.compute = compute;
        this.update_result = update_result;
        this._report = report;
    }
    public LaterUpdateTask(
        Supplier<? extends V> compute,
        Consumer<? super LaterUpdateTask<? extends V, ? super X> > update_result
    ){
        this(dropFirstArg(compute), null, update_result);
    }
    
    public static <V, X> LaterUpdateTask<V, X> makeLaterUpdateTask(
        Function<LaterUpdateTask<? extends V, ? super X>, ? extends V> compute,
        BiConsumer<LaterUpdateTask<? extends V, ? super X>, X> report,
        Consumer<LaterUpdateTask<? extends V, ? super X> > update_result
    ){
        return new LaterUpdateTask<V, X>(compute, report, update_result);
    }
    
    
    public final void report(final X x) throws InterruptedByCancelException{
        // called in compute
        if (isLaterUpdateCancelled()) 
            throw new InterruptedByCancelException("cancelled");
        // if (_report == null) return; // if null, user should not call _report
        if (_report == null)
            throw new NullPointerException("LaterUpdateTask::report == null");
        runLater(self -> _report.accept(self, x));
    }
    
    


    public synchronized boolean isLaterUpdateCancelled(){
        return isCancelled() || __isLaterUpdateCancelled.get();
    }
    /**
        call laterUpdateCancel instead of cancel
        @return result of cancel()
    */
    public synchronized final boolean laterUpdateCancel(){
        // why??
        // if normal complete, super cancel will be nop
        // now, we set isLaterUpdateCancelled, so, anyhow
        //      isLaterUpdateCancelled() respond to cancel()
        print("LaterUpdateTask.laterUpdateCancel() @", this);
        __isLaterUpdateCancelled.set(true);
        return cancel();
    }
    
    @Override
    protected V call() throws Exception {
        final V result = compute.apply(this);
        if (update_result != null) {
            updateValue(result);
            runLater(update_result);
        }
        return result;
    }
    protected final void runLater(final Consumer<? super LaterUpdateTask<? extends V, ? super X> > update){
        Platform.runLater(() -> {synchronized(this) {
            if (isLaterUpdateCancelled()) return; // ==>> non-reusable
            update.accept(this);
        }});
    }
    
    private final Function<? super LaterUpdateTask<? extends V, ? super X>, ? extends V> compute;
    private final Consumer<? super LaterUpdateTask<? extends V, ? super X> > update_result;
    private final BiConsumer<? super LaterUpdateTask<? extends V, ? super X>, ? super X> _report;
    private final AtomicBoolean __isLaterUpdateCancelled = new AtomicBoolean(false);
}
