
/**
java std lib bugs:
    lock in context that can throw Exception anywhere:
        // case 1
        lock.lock();
        // what if interrupted here??
        //    donot call finally!!
        try{
        ...
        }finally{
            lock.unlock();
        }
        
        // case 2
        try{
            // what if interrupted here??
            //    unlock other thread's lock!!
            lock.lock();
            ...
        }finally{
            lock.unlock();
        }
        
        
        // case 3
        int c = reentrantLock.getHoldCount();
        try{
            reentrantLock.lock();
            ...
        }finally{
            if (reentrantLock.getHoldCount() != c) reentrantLock.unlock();
        }
        
*/

package seed.util;

import static seed.util.Maybe.*;
import static seed.util.Tuple3s.*;
import static seed.io.Prints.*;

import java.util.HashSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.Collections;

import java.util.WeakHashMap;
import java.lang.ref.WeakReference;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicBoolean;
//import java.util.concurrent.Future;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.CancellationException;


import java.util.concurrent.CompletableFuture;
/*
import java.util.concurrent.locks.Lock;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.function.Supplier;
import java.util.concurrent.locks.ReentrantLock;
//import static seed.util.KeyIndepentMap.ReentrantReadWriteLockR2IReentrantLock.makeR2IReentrantLock;
//import static seed.util.KeyIndepentMap.ReentrantReadWriteLockW2IReentrantLock.makeW2IReentrantLock;
*/



/*
    block any update!! compute at most once per key
    ConcurrentHashMap::computeIfAbsent
        The entire method invocation is performed atomically, so the function is applied at most once per key. 
        Some attempted update operations on this map by other threads may be blocked while computation is in progress, 
        so the computation should be short and simple, and must not attempt to update any other mappings of this map.
*/

/**
    lock on per key, i.e. each key is associated with a lock;
    concurrent hash map
<pre>
    get :: key -> (key->value) -> value
        get if exist // even computing
        wait on future otherwise
            may start computing
    put :: (key, value) -> ()
        set future & cancel computing
    discard :: key
        del future


    m :: Map key future<value>
    get(key, f){
        atomic{
            future = m.computeIfAbset(key, key->new Future(()->f(key)));
        }
        return future.get();
    }
    put(key, value){
        atomic{
            future = m.put(key, new ValueFuture(value));
        }
        if future:
            future.setAndCancel(value);
    }
    del(key){
        atomic{
            m.remove(key); // we dont care future's computing
        }
    }
    
    
    cache :: Map key value
    m :: Map key (refcount, future<value>) // almost empty
    get(key, f)
        atomic(cache):
            if key in cache:
                return cache[key]
            atomic(m):
                if key not in m:
                    m[key] = 0, new Future(()->f(key))
            m[key][0].incrementAndGet()
        try:
            value = future.get()
            if not future.isCancelled():
                atomic(cache, m):
                    if not future.isCancelled():
                        put(key, value)
            return value
        finally:
            atomic(m):
                c = m[key][0].decrementAndGet()
                if c == 0:
                    del m[key]

    put(key, value)
        atomic(cache, m):
            if key in m:
                m[key][-1].setAndCancel(value)
            cache[key] = value
            
    discard(key)
        atomic(cache):
            cache.discard(key)
            atomic(m):
                if key in m:
                    m[key][-1].cancel() // ?? so, not to update cache when done
        
</pre>

*/


















































interface Future<V> {
    V get()throws Exception;
    Maybe<V> get_maybe();
}
class ValueFuture<V> implements Future<V> {
    final AtomicReference<V> a_v = new AtomicReference<>();
    public ValueFuture(V v){
        a_v.set(v);
    }
    public V get()throws Exception{
        return a_v.get();
    }
    public Maybe<V> get_maybe(){
        return Just(a_v.get());
    }
}

class FakeFuture<V> implements Future<V>{
    private final Supplier<? extends V> f;
    private Maybe<V> v = null;
    private Exception e = null;
    private final AtomicReference<Maybe<V> > a_maybe_v = new AtomicReference<>(getNothing());
    // private final 
    
    // constructor without "synchronized"
    public FakeFuture(Supplier<? extends V> f){
        this.f = f;
    }
    public synchronized V get() throws Exception{
        if (v != null)
            return v.unjust();
        if (e != null)
            throw e;
        try {
            v = Just(f.get());
        } catch(Exception ex){
            assert ex != null;
            this.e = ex;
            
            print("xxxxxxxxxxxxxxxxxxxxxxxxxx", ex);
            throw e;
        }
        
        a_maybe_v.set(v);
        return v.unjust();
    }
    
    
    public Maybe<V> get_maybe(){
        return a_maybe_v.get(); // to avoid blocking by get()
    }
}


public 
class KeyIndependentMap<K, V> {
    private final Map<K, Future<V>> cache = new HashMap<>();
    public KeyIndependentMap(){}

    public int size(){
        synchronized(cache){
            return cache.size();
        }
    }


    public void put_future(K key, Future<V> future){
        synchronized(cache){
            if (future != null) {
                cache.put(key, future);
            }
        }
        
    }
    public Future<V> get_future(K key, final Function<? super K, ? extends V> f) {//throws Exception { //throws InterruptedException, ExecutionException{
        Future<V> future = null;
        synchronized(cache){
            future = cache.get(key);
            if (future == null) {
                future = new FakeFuture<V>(() -> f.apply(key));
                cache.put(key, future);
            }
        }
        
        return future;
    }   
    public V computeIfAbsent(K key, final Function<? super K, ? extends V> f) throws Exception { //throws InterruptedException, ExecutionException{
        Future<V> future = get_future(key, f);
        return future.get();
    }
    
        
    public boolean containsKey(K key){
        synchronized(cache){
            return cache.containsKey(key);
        }
        
    }
    public Maybe<V> get_maybe(K key){
        Future<V> future;
        synchronized(cache){
            future = cache.get(key);
        }
        if (future != null){
            return future.get_maybe();
        }
        return getNothing();
    }

    public Future<V> discard_future(K key){
        synchronized(cache){
            return cache.remove(key);
        }
    }
    
    public Maybe<V> discard(K key){
        Future<V> future;
        synchronized(cache){
            future = cache.remove(key);
        }
        if (future != null){
            return future.get_maybe();
        }
        return getNothing();
    }

    
    boolean printKeys(String prefix){
        synchronized(cache){{
            Set<K> s = new HashSet<>();
            for (K key : cache.keySet())
                if (cache.get(key).get_maybe() == getNothing())
                    // computing
                    s.add(key);
            print(prefix + "KeyIndependentMap::almost_empty_futuremap::keys=" + s);
            print(prefix + "KeyIndependentMap::cache::keys=" + cache.keySet());
        }}
        return true;
    }

}































///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
public 
class KeyIndependentMap<K, V> {
    private final Map<K, V> cache = new HashMap<>();
    private final Map<K, WeakReference<Future<V> > > key2wfuture = new HashMap<>();
    private final Map<Future<V>, Boolean> future2first_gotter = 
        // ?? really?? ver1 bug: WeakHashMap is not synchronized: new WeakHashMap<>(); 
        // Collections.synchronizedMap(new WeakHashMap<>());
        new WeakHashMap<>();

    public KeyIndependentMap(){}

    public static <T> WeakReference<T> makeWeakReference(T obj){
        return new WeakReference<T>(obj);
    }

    public int size(){
        synchronized(cache){
            return cache.size();
        }
    }

    public V computeIfAbsent(K key, final Function<? super K, ? extends V> f) throws Exception { //throws InterruptedException, ExecutionException{
        Future<V> future = null;
        synchronized(cache){
            if (cache.containsKey(key))
                return cache.get(key);
            synchronized(key2wfuture){
                if (key2wfuture.containsKey(key))
                    future = key2wfuture.get(key).get();
                if (future == null) {
                    future = new FakeFuture<V>(() -> f.apply(key)); // CompletableFuture.supplyAsync(() -> f.apply(key));
                    key2wfuture.put(key, makeWeakReference(future));
                    synchronized(future2first_gotter) {
                        future2first_gotter.put(future, true);
                    }
                }
            }
            
            // key not in cache; future != null
        }
        
        // key may in cache; 
        // key in cache ==>> future completed
        V v = future.get();
        boolean b;
        synchronized(future2first_gotter){
            b = future2first_gotter.get(future);
            if (b)
                future2first_gotter.put(future, false);
        }
        if (b) synchronized(cache){
            assert !cache.containsKey(key);
            cache.put(key, v);
        }
        
        future = null;
        synchronized(key2wfuture){
            if (key2wfuture.containsKey(key))
                future = key2wfuture.get(key).get();
            if (future == null){
                key2wfuture.remove(key);
                //assert !future2first_gotter.contains();
            }
        }
        return v;
    }

    public Maybe<V> get_maybe(K key){
        V v;
        synchronized(cache){
            v = cache.get(key);
            if (v == null)
                if (! cache.containsKey(key))
                    return getNothing();
        }
        return Just(v);
    }

    public Maybe<V> discard(K key){
        boolean exist;
        V v;
        synchronized(cache) {
            exist = cache.containsKey(key);
            v = cache.remove(key);
        }
        if (exist)
            return Just(v);
        else
            return getNothing();
    }
    
    boolean printKeys(String prefix){
        synchronized(cache){
        synchronized(key2wfuture){
            print(prefix + "KeyIndependentMap::almost_empty_futuremap::keys=" + key2wfuture.keySet());
            print(prefix + "KeyIndependentMap::cache::keys=" + cache.keySet());
        }}
        return true;
    }

}
*/
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////




























///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
public 
class KeyIndependentMap<K, V> {
    // LockPerKey, ComputeOncePerKey, UnlockForOtherKeyWhileComputing
    // null is treated as normal value
    
    // front map for fast fetch
    private final Map<K, V> cache = new HashMap<>();
    
    // Maybe<V> be null or Just(v) never Nothing
    // this map is almost empty
    private final Map<K, Tuple3<AtomicInteger, AtomicReference<Maybe<V> >, Future<? extends V> > > m = new HashMap<>();
    public int size(){
        synchronized(cache){
            return cache.size();
        }
    }

    public KeyIndependentMap(){}
    
    public V computeIfAbsent(K key, final Function<? super K, ? extends V> f) throws InterruptedException, ExecutionException{
        return get_from_supply(key, f);
    }
    
    
    
    public Maybe<V> get_maybe(K key){
        V v;
        synchronized(cache){
            v = cache.get(key);
            if (v == null)
                if (! cache.containsKey(key))
                    return getNothing();
        }
        return Just(v);
    }
    public V get_from_supply(K key, final Function<? super K, ? extends V> f) throws InterruptedException, ExecutionException {
        return get_from_future(key, k->CompletableFuture.supplyAsync(() -> f.apply(k)));
    }
    public V get_from_future(K key, Function<? super K, ? extends Future<? extends V> > f) throws InterruptedException, ExecutionException {
        {
            Maybe<V> maybe = get_maybe(key);
            if (maybe != Nothing)
                return maybe.unjust();
        }
        
        Future<? extends V> future = null;
        Tuple3<AtomicInteger, AtomicReference<Maybe<V> >, Future<? extends V> > e = null;
        
        
        synchronized(m){
            Maybe<V> maybe = get_maybe(key);
            if (maybe != Nothing)
                return maybe.unjust();
                
            e = m.get(key);
            if (e == null){
                future = f.apply(key);
                if (future == null)
                    throw new NullPointerException("null future");
                e = makeTuple(new AtomicInteger(1), 
                              new AtomicReference<>(null), 
                              future);
                m.put(key, e);
                assert future != null;
            }
            else{
                assert future == null;
                e._0.incrementAndGet();
                future = e._2;
            }
            assert e != null;
            assert future != null;
        }

        
        try{
            if (e._1.get() != null)
                return e._1.get().unjust();
            V value = null;
            try{
                //??value = future.get();
                synchronized(future){
                    if (e._1.get() != null)
                        return e._1.get().unjust();
                    value = future.get();
                    e._1.set(Just(value));
                    if (cache.containsKey(key))
                        throw new RuntimeException("key in cache");
                    cache.put(key, value);
                }
            } catch(CancellationException | InterruptedException | ExecutionException ex){
                synchronized(m){
                    // e = m.get(key); ??key may be removed??
                    if (e._1.get() != null){
                        // if put() call cancel
                        // then we come here
                        return e._1.get().unjust();
                    }
                }
                throw ex;
            }
            
            if (e._1.compareAndSet(null, Just(value))) {
                // the first future.get() return
                // the only update action
                synchronized(cache) {
                    cache.put(key, value);
                }
            }
            
            {
                // debug: assume no one call put()
                if (value != e._1.get().unjust())
                    throw new RuntimeException("future.get() != future.get()");
                synchronized(cache) {
                    if (cache.containsKey(key))
                        if (value != cache.get(key))
                            throw new RuntimeException("future.get() != cache.get()");
                }
            }
            return value;
        }
        finally{
            int c = e._0.decrementAndGet();
            if (c == 0)
                synchronized(m){
                    if (e._0.get() == 0)
                        m.remove(key);
                }
            
            // here may rethrow Exception
            
        }
        
    }
    
    public Maybe<V> put(K key, V value){
        synchronized(m){
            Tuple3<AtomicInteger, AtomicReference<Maybe<V> >, Future<? extends V> > e = m.get(key);
            if (e != null){
                if (! e._2.isDone())
                    if (e._1.compareAndSet(null, Just(value)))
                        e._2.cancel(true);
            }
        }
        synchronized(cache) {
            cache.put(key, value);
        }
        
        boolean exist;
        V v;
        synchronized(cache) {
            exist = cache.containsKey(key);
            v = cache.put(key, value);
        }
        if (exist)
            return Just(v);
        else
            return getNothing();
    }
    
    public Maybe<V> discard(K key){
        boolean exist;
        V v;
        synchronized(cache) {
            exist = cache.containsKey(key);
            v = cache.remove(key);
        }
        if (exist)
            return Just(v);
        else
            return getNothing();
    }
    
    void printKeys(String prefix){
        synchronized(m){
        synchronized(cache){
            print(prefix + "KeyIndependentMap::almost_empty_futuremap::keys=" + m.keySet());
            print(prefix + "KeyIndependentMap::cache::keys=" + cache.keySet());
        }}
    }
}
*/



















































/***********************************************************************
//makeW2IReentrantLock makeR2IReentrantLock public 
class __KeyIndependentMap<K, V> {
    // LockPerKey, ComputeOncePerKey, UnlockForOtherKeyWhileComputing
    // null is treated as normal value
    private final Map<K, V> cache = new HashMap<>();
    private final Map<K, Tuple3<AtomicInteger, V, Future<? extends V> > > m = new HashMap<>();
    private final ReentrantReadWriteLock cache_lock = new ReentrantReadWriteLock();
    private final ReentrantReadWriteLock m_lock = new ReentrantReadWriteLock();
    
    Maybe<V> get_maybe(K key){
        return makeR2IReentrantLock(cache_lock).run(()->{
            // hope HashMap donot have mutable field 
            // and get/containsKey are both const method
            if (cache.containsKey(key)){
                return Just(cache.get(key));
            }
            return getNothing();
        });
        
    }
    V get_from_supply(K key, final Function<K, V> f) throws InterruptedException, ExecutionException {
        return get_from_future(key, k->CompletableFuture.supplyAsync(() -> f.apply(k)));
    }
    V get_from_future(K key, Function<K, Future<? extends V> > f) throws InterruptedException, ExecutionException {
        Future<? extends V> future = null;
        Tuple3<AtomicInteger, V, Future<? extends V> > e = null;
        synchronized(cache){
            if (cache.containsKey(key))
                return cache.get(key);
            synchronized(m){
                e = m.get(key);
                if (e == null){
                    future = f.apply(key);
                    if (future == null)
                        throw new NullPointerException("null future");
                    m.put(key, makeTuple(new AtomicInteger(1), null, future));
                }
                else{
                    e._0.incrementAndGet();
                    future = e._2;
                }
                assert future != null;
            // exit to free cache
            }
        }
        
        try{
        try{
            V value = future.get();
            if (! future.isCancelled())
                synchronized(cache) {
                synchronized(m){
                    if (! future.isCancelled())
                        put(key, value);
                }}
                
            return value;
        } catch(CancellationException | InterruptedException | ExecutionException ex){
            synchronized(m){
                e = m.get(key);
                if (e._1 != null){
                    // if put() call cancel or compute complete, 
                    // then we come here
                    return e._1;
                }
            }
            throw ex;
        }}
        finally{
            synchronized(m){
                int c = e._0.decrementAndGet();
                if (c == 0)
                    m.remove(key);
                
                // here may rethrow Exception
            }
        }
        
    }
    
    void put(K key, V value){
        synchronized(cache) {
            synchronized(m){
                Tuple3<AtomicInteger, V, Future<? extends V> > e = m.get(key);
                if (e != null){
                    Future<? extends V> future = e._2;
                    assert e._1 == null;
                    m.put(key, makeTuple(e._0, value, future));
                    future.cancel(true);
                }
            }
            
            cache.put(key, value);
        }
    }
    
    void discard(K key){
        synchronized(cache) {
            cache.remove(key);
        }
    }
    

}


***********************************************************************/

