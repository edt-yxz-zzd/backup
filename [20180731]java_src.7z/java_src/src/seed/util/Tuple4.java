
package seed.util;

public class Tuple4s {
    public static class Tuple4<E0, E1, E2, E3> {
        public final E0 _0; public final E1 _1; public final E2 _2; public final E3 _3; 
        public Tuple4(E0 e0, E1 e1, E2 e2, E3 e3){
            _0 = e0; _1 = e1; _2 = e2; _3 = e3; 
        }
        
        final int size(){
            return 4;
        }
        
        final Object[] toArray(){
            return new Object[]{_0, _1, _2, _3};
        }
        
        public String toString(){
            return String.format("(%s, %s, %s, %s)"
                , _0.toString(), _1.toString(), _2.toString(), _3.toString()
                );
        }

    }
    
    

    public static <E0, E1, E2, E3> Tuple4<E0, E1, E2, E3> 
        makeTuple(E0 e0, E1 e1, E2 e2, E3 e3){
            return new Tuple4<E0, E1, E2, E3>(e0, e1, e2, e3);
        }


}

