
/*
bug: ?? OneTaskService/LaterUpdateTask without synchronized
    public AtomicReference<Task<V> > task_ref; // ?? public
    
    // However, once the Service has been initialized and started, it may only thereafter be used from the FX thread.
*/


package seed.util;
import static seed.io.Prints.*;


import javafx.concurrent.Service;
import javafx.concurrent.Task;
import javafx.application.Platform;
import java.util.concurrent.atomic.AtomicReference;



public class Tasks {
    public static class OneTaskService<V> extends Service<V>{
        private final AtomicReference<Task<V> > task_ref = new AtomicReference<>();
        public OneTaskService(){}
        public OneTaskService(Task<V> task){
            task_ref.set(task);
        }
        @Override
        protected synchronized Task<V> createTask(){
            print("Tasks.OneTaskService.createTask");
            return get_task();
        }
        
        public synchronized Task<V> get_task(){
            return task_ref.get();
        }
        public synchronized void set_task(Task<V> task){
            task_ref.set(task);
        }
        public synchronized void restart(Task<V> task){
            print("OneTaskService.restart");
            cancel();
            set_task(task);
            restart();
            print("OneTaskService.getState() == " + getState());
        }
        
        @Override
        public synchronized boolean cancel(){
            print("OneTaskService.cancel");
            return super.cancel();
        }
    }
    public static <V> Service<V> makeService(final Task<V> task){
        return new OneTaskService<V>(task);
    }
}