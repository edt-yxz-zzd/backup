package seed.util;

public class Tuple3s {
    public static class Tuple3<T0, T1, T2> {
        public final T0 _0;
        public final T1 _1;
        public final T2 _2;
        public Tuple3(T0 t0, T1 t1, T2 t2){
            _0 = t0;
            _1 = t1;
            _2 = t2;
        }
        
        final int size(){
            return 3;
        }
        
        final Object[] toArray(){
            return new Object[]{_0, _1, _2};
        }
        
        public String toString(){
            return String.format("(%s, %s, %s)", 
                _0.toString(),
                _1.toString(),
                _2.toString());
        }
        // public int hashCode(){}
        // public int equals(){}
    }
    
    

    public static <T0, T1, T2> Tuple3<T0, T1, T2> 
        makeTuple(T0 t0, T1 t1, T2 t2){
            return new Tuple3<T0, T1, T2>(t0, t1, t2);
        }

    public static void main(String[] args){
        Tuple3 t = makeTuple("abc", 123, new double[]{100.0, 10.0});
        System.out.println(t);
        System.out.println(t.toArray());
    }
}

