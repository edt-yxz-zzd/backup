// see java.util.Optional<T>

package seed.util;
public final class Maybe<T> {
    private final T v;
    private final boolean just;
    private Maybe(T value){
        this.v = value;
        this.just = true;
    }
    private Maybe(){
        this.v = null;
        this.just = false;
    }
    
    public static final <T> Maybe<T> getNothing(){
        return Nothing;
    }
    public static final Maybe Nothing = new Maybe();
    public static final <T> Maybe<T> Just(T value){
        return new Maybe<T>(value);
    }
    
    public final T unjust(){
        if (just)
            return v;
        throw new RuntimeException("unjust Nothing");
    }
    
    @Override
    public final String toString(){
        if (this == Nothing) return "Nothing";
        return "Just(" + this.unjust() + ")";
    }
    
    @Override
    public final int hashCode(){
        if (this == Nothing) return 3453;
        return this.unjust().hashCode();
    }
    
    @Override
    public final boolean equals(Object obj){
        if (obj == null) return this == null;
        if (obj == Nothing)
            return this == Nothing;
        if (! (obj instanceof Maybe)) return false;
        Maybe other = (Maybe)obj;
        return this.unjust().equals(other.unjust());
    }
}






