
package seed.util;

public class Pairs {
    public static class Pair<K, V> {
        public final K fst;
        public final V snd;
        public Pair(K k, V v){ fst = k; snd = v;}
        public String toString(){
            assert this != null;
            if (true){
                if (this == null)
                    return "null";
                String f = fst == null? "null" : fst.toString();
                String s = snd == null? "null" : snd.toString();
                return //this.getClass().getName() + 
                            "(" + f + ", " + s + ")";
            }
            return this.getClass().getName() + 
                    "(" + fst.toString() + ", " 
                        + snd.toString() + ")";
        }
    }


    public static <A, B> Pair<A, B> makePair(A a, B b){
        return new Pair<A, B>(a, b);
    }
}
