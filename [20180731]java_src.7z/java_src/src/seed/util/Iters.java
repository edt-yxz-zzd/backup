

package seed.util;

import java.util.Iterator;
import java.util.function.Function;
import java.lang.Runnable; // run :: ()->()
import java.util.function.Supplier; // get :: ()->R
import java.util.function.Function; // apply :: V->R 
// UnaryOperator :: apply :: V->V
import java.util.function.BiFunction; // apply :: U->V->R


import java.util.function.Consumer; // accept :: V->()
import java.util.function.BiConsumer; // U->V->()

import java.util.function.Predicate; // test :: V->Bool
import java.util.function.BiPredicate; // test :: U->V->Bool


import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.Collection;

import static seed.util.Pairs.*;
import static seed.util.Tuple2s.*;
import static seed.util.Tuple3s.*;

public class Iters {
    
    //public static interface Iterable<T> {
    //    Iterator<T> iter();
    //}
    
    public static class Iterator2IIterator<T> implements IIterator<T>{
        private final Iterator<T> it;
        public Iterator2IIterator(Iterable<T> it){
            this(it.iterator());
        }
        public Iterator2IIterator(Iterator<T> it){
            this.it = it;
        }
        public Iterator2IIterator(IIterator<T> it){
            this.it = it;
        }
        @Override public
        T next(){
            return it.next();
        }
        @Override public
        boolean hasNext(){
            return it.hasNext();
        }
    }
    public static <T> IIterator<T> makeIIterator(Iterable<T> it){
        return new Iterator2IIterator<T>(it);
    }
    public static <T> IIterator<T> makeIIterator(Iterator<T> it){
        return new Iterator2IIterator<T>(it);
    }
    
    // java.util.stream.Stream<T>??
    

    public static <T, R> IIterator<R> map(Function<? super T, ? extends R> f, Iterable<T> it){
        return map(f, it.iterator());
    }
    public static <T, R> IIterator<R> map(Function<? super T, ? extends R> f, Iterator<T> it){
        return new IIterator<R>(){
            @Override public
            R next(){
                return f.apply(it.next());
            }
            @Override public
            boolean hasNext(){
                return it.hasNext();
            }
            
        };
    }

    public static <T> IIterator<T> filter(Predicate<? super T> f, Iterable<T> it){
        return filter(f, it.iterator());
    }
    public static <T> IIterator<T> filter(Predicate<? super T> f, Iterator<T> it){
        return new IIterator<T>(){
            private T temp;
            {
                if (it.hasNext()) temp = it.next();
                else temp = null;
            }
            @Override public
            T next(){
                if (hasNext()) return temp;
                return it.next();
            }
            @Override public
            boolean hasNext(){
                while(it.hasNext()){
                    temp = it.next();
                    if (f.test(temp)) return true;
                }
                return false;
            }
            
        };
    }


    public static <T, U> IIterator<Pair<T, U> > zipPair(Iterator<T> it0, Iterator<U> it1){
        return new IIterator<Pair<T, U> >(){
            @Override public
            Pair<T, U> next(){
                return makePair(it0.next(), it1.next());
            }
            @Override public
            boolean hasNext(){
                return it0.hasNext() && it1.hasNext();
            }
            
        };
    }
    public static <T, U> IIterator<Tuple2<T, U> > zip(Iterator<T> it0, Iterator<U> it1){
        return new IIterator<Tuple2<T, U> >(){
            @Override public
            Tuple2<T, U> next(){
                return makeTuple(it0.next(), it1.next());
            }
            @Override public
            boolean hasNext(){
                return it0.hasNext() && it1.hasNext();
            }
            
        };
    }
    public static <T, U, V> IIterator<Tuple3<T, U, V> > zip(Iterator<T> it0, Iterator<U> it1, Iterator<V> it2){
        return new IIterator<Tuple3<T, U, V> >(){
            @Override public
            Tuple3<T, U, V> next(){
                return makeTuple(it0.next(), it1.next(), it2.next());
            }
            @Override public
            boolean hasNext(){
                return it0.hasNext() && it1.hasNext() && it2.hasNext();
            }
            
        };
    }
    
    public static <T> void addAll(Collection<? super T> c, Iterator<T> it){
        it.forEachRemaining(t -> c.add(t));
    }
    public static <T> List<T> list(Iterator<T> it){
        ArrayList<T> ls = new ArrayList<>();
        addAll(ls, it);
        return ls;
    }
    public static <T> Set<T> set(Iterator<T> it){
        HashSet<T> s = new HashSet<>();
        addAll(s, it);
        return s;
    }
}












