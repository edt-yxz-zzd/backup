// see seed.util.Iters

package seed.util;
//import static seed.util.GenericFuncs.*;


import java.lang.Runnable; // ()->()
import java.util.function.Supplier; // ()->R
import java.util.function.Function; // V->R
import java.util.function.Consumer; // V->()
import java.util.function.BiConsumer; // A->B->()
import java.util.function.Predicate; // V->boolean



/**
    FunctionalInterface -> Generic FunctionalInterface
    e.g. 
        Function<? super V, ? extends R> -> Function<V, R>
        Function<V, R> -> Function<? extends V, ? super R>
*/
public class GenericFuncs {
    public static <V, R, OV extends V, OR super R> Function<OV, OR> generalized(final Function<V, R> f){
        return new Function<OV, OR>{
            OR apply(OV t){return f.apply(t);}
            <T> Function<OV, T> andThen(Function<? super OR,? extends T> after){
                return generalized(f.andThen(after));
            }
            <T> Function<T, R> compose(Function<? super T, ? extends V> before){
                return generalized(f.compose(before));
            }
        };
    }
}