
package seed.util;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.function.Supplier;
import java.util.concurrent.locks.ReentrantLock;


public interface IReentrantLock {
    int getHoldCount();
    <T> T run(Supplier<T> f);
    void run(Runnable f);
}

abstract class AbstractReentrantLock implements IReentrantLock {
    protected abstract void lock();
    protected abstract void unlock();
    
    public final <T> T run(Supplier<T> f){
        int c = getHoldCount();
        try{
            lock();
            return f.get();
        }finally{
            if (getHoldCount() != c) unlock();
        }
    }
    
    public final void run(Runnable f){
        run(()->{f.run();});
    }

}

final class ReentrantReadWriteLockR2IReentrantLock extends AbstractReentrantLock {
    private final ReentrantReadWriteLock rw;
    public ReentrantReadWriteLockR2IReentrantLock(ReentrantReadWriteLock rw){
        this.rw = rw;
    }
    public final int getHoldCount(){
        return rw.getReadHoldCount();
    }
    protected final void lock(){
        rw.readLock().lock();
    }
    protected final void unlock(){
        rw.readLock().unlock();
    }
    
    public static ReentrantReadWriteLockR2IReentrantLock makeR2IReentrantLock(ReentrantReadWriteLock rw){
        return new ReentrantReadWriteLockR2IReentrantLock(rw);
    }

}
final class ReentrantReadWriteLockW2IReentrantLock{
    private final ReentrantReadWriteLock rw;
    public ReentrantReadWriteLockW2IReentrantLock(ReentrantReadWriteLock rw){
        this.rw = rw;
    }
    public final int getHoldCount(){
        return rw.getWriteHoldCount();
    }
    protected final void lock(){
        rw.writeLock().lock();
    }
    protected final void unlock(){
        rw.writeLock().unlock();
    }
    public static ReentrantReadWriteLockW2IReentrantLock makeW2IReentrantLock(ReentrantReadWriteLock rw){
        return new ReentrantReadWriteLockW2IReentrantLock(rw);
    }
}
