
package seed.util;

import java.util.Iterator;

public interface IIterator<T> extends Iterable<T>, Iterator<T> {
    default IIterator<T> iterator(){
        return this;
    }
    
    //T next();
    //boolean hasNext();
}



