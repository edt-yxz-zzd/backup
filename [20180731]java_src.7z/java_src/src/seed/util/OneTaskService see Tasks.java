

package seed.util;
import static seed.io.Prints.*;

import javafx.concurrent.Service;
import javafx.concurrent.Task;

class OneTaskService<V> extends Service<V> {
    public OneTaskService(Task<V> task){
        super();
        this.task = task;
    }
    // why not return Task<? extends V>??
    protected Task<V> createTask(){
        print("OneTaskService.createTask");
        return task;
    }
    
    private final Task<V> task;
}