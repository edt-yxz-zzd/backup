
package seed.util;

import seed.util.LaterUpdateTask;
import static seed.util.LaterUpdateTask.*;
import seed.excepts.InterruptedByCancelException;

class A{}
class C extends A{}

public class _Test_LaterUpdateTask {
    static void println(Object... ss){
        for (Object s : ss)
            System.out.println(s);
    }
    static void print(Object... ss){
        for (Object s : ss){
            System.out.print(s);
            System.out.print("  ");
        }
        System.out.println();
    }
    public static void main(String[] args){
        System.out.println("");
    
        LaterUpdateTask<Void, A> task = makeLaterUpdateTask(
            self -> {
                for (int i = 0; i < 10; ++i){
                    //Byte c = 'a';
                    //class A extends String{}
                    A c = null;
                    try{self.report(c);}
                    catch(InterruptedByCancelException e){
                        if (self.isCancelled())
                            break;
                        else 
                            throw new RuntimeException("InterruptedByCancelException but not isCancelled", e);
                    }
                }
                return null;
            },
            (self, c) -> {
                // run on javafx GUI thread
                //xxx.getChildren().add(c);
            },
            null // need not update result, since Void
        );
    }
}