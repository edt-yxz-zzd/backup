
package seed.util;

import static seed.util.Maybe.*;
import static seed.io.Prints.*;
import java.util.LinkedHashMap;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.function.Predicate;

import seed.annotations.NonNull;
import seed.annotations.NonNegative;
import seed.util.LimitedLinkedHashMap;
import seed.util.KeyIndependentMap;
import seed.util.KeyIndependentMap.*; // ValueFuture
import java.util.concurrent.ExecutionException;
import java.util.concurrent.CancellationException;


/**
    a LRU cache, cache the result of compute(key).

    cache_size = recycle_size = total_size - using_size
<pre>
    three set of results are maintained:
        results allocated - result of get(key) before discard(key)
        results cached - allocated result after discard(key)
        results missing - cached result after cache full and be eldest
</pre>

<pre>
    class invariants
        not set(key2using) & set(key2discarded)
        len(key2discarded) <= cache_size
        not null in key2using.values()
        not null in key2discarded.values()

    key state/action table:
                get     discard         overflow
        using   using   cached          --
                        (?->overflow)
        cached  using   cached          (eldest->)missing
        missing using   missing         --
</pre>
*/
public class CacheLRU<K, V> {
    /* really??ver2 bug??: 
        get -> key2using -> compute -> key2discarded
        discard -> key2discarded -> key2using -> discard
        
        this->lock(key2discarded):
            other->get(key):
                if key not in key2using:
                    set key2using[key] = future(compute)
                    future.get:
                        other->lock(key2discarded) after this->unlock(key2discarded)
                        1) now this may start to remove key2using[key]!!
                        2) has removed from key2using to key2discarded
                        3) no key at all
                else:
                    remove not begin yet
                    future.get
    */


    // final private int cache_size;
    final private Function<? super K, ? extends V> compute;
    final private Predicate<? super V> recompute;
    final private KeyIndependentMap<K, V> key2using = new KeyIndependentMap<>();
    final private LimitedLinkedHashMap<K, Future<V> > key2discarded;

    /**
        @param cache_size 
            max size of cached deleted values
        @param compute
            called if cache miss
    */
    public CacheLRU(@NonNegative int cache_size, 
                    @NonNull Function<? super K,? extends V> compute){
        this(cache_size, compute, value->false);
    }
    
    public CacheLRU(@NonNegative int cache_size, 
                    @NonNull Function<? super K,? extends V> compute,
                    @NonNull Predicate<? super V> recompute){
        //assert cache_size != null;
        assert compute != null;
        assert cache_size >= 0;
        
        // this.cache_size = cache_size;
        this.key2discarded = new LimitedLinkedHashMap<>(cache_size);
        this.compute = key->{
            assert debugk(key, "compute.apply");
            return compute.apply(key);
        };
        
        this.recompute = recompute;
    }
    
    /**
        get cached value or calc new value if miss
        @parem key
            arg of compute
        @return
            result of compute(key); may be null
    */
    public V get(K key) {
        assert debugk(key, "get");
        clear_if_need_recompute(key);
        
        Future<V> future;
        synchronized(key2discarded){
            if (key2discarded.containsKey(key)) {
                assert !key2using.containsKey(key);
                future = key2discarded.remove(key);
                // future = new ValueFuture(v);
                key2using.put_future(key, future);
            }
            else
                future = key2using.get_future(key, compute);
            assert future != null;
        }
        try{
            return future.get();
        } catch(Exception ex){
            
            throw new RuntimeException("CacheLRU::get", ex);
        }
        finally{
            assert debug("return");
        }
    }
    
    /**
        mark result (from get(key)) as disarded,
        so that the result can be remove from the cache if required.
        
        @param key
            key 
    */
    public Maybe<V> discard(K key){
        assert debugk(key, "discard");
        Future<V> future;
        synchronized(key2discarded){
            future = key2using.discard_future(key);
            if (future == null) return getNothing();
            
            assert !key2discarded.containsKey(key);
            key2discarded.put(key, future);
            assert key2discarded.size() <= key2discarded.getMaxSize();
        }
        
        Maybe<V> maybe = future.get_maybe(); //Just(future.get());
        assert debug("return Just...");
        return maybe;
    }
    public Maybe<V> get_maybe(K key){
        Maybe<V> maybe;
        Future<V> future;
        synchronized(key2discarded){
            maybe = key2using.get_maybe(key);
            if (maybe != Nothing) return maybe;
            
            future = key2discarded.get(key);
        }
        
        assert maybe == Nothing;
        if (future == null) return maybe;
        maybe = future.get_maybe();
        return maybe;
    }
    private void clear_if_need_recompute(K key){
        Maybe<V> maybe = get_maybe(key);
        while (maybe != Nothing) {
            V v = maybe.unjust();
            if (!recompute.test(v)) return;
            synchronized(key2discarded){
                maybe = get_maybe(key);
                // bug: if (v == maybe.unjust()){ // maybe == Nothing
                if (maybe != Nothing && v == maybe.unjust()){
                    key2using.discard_future(key);
                    key2discarded.remove(key);
                }
            }
        }
    }


    public void setMaxCacheSize(int size){
        synchronized(key2discarded){
            key2discarded.setMaxSize(size);
        }
    }
    public int getMaxCacheSize(){
        synchronized(key2discarded){
            return key2discarded.getMaxSize();
        }
    }
    
    public int getUsingSize(){
        return key2using.size();
    }
    public int getCachedSize(){
        synchronized(key2discarded){
            return key2discarded.size();
        }
    }
    
    private boolean debugk(K key, Object... ls){
    if (true) return true;
        debug(ls);
        print("key: " + quote(key));
        return true;
    }
    private boolean debug(Object... ls){
    if (true) return true;
        print_("CacheLRU debug:"); print(ls);
        print("   getCachedSize: " + getCachedSize(), ";", "getUsingSize: " + getUsingSize());
        return true;
    }
    
    public boolean printKeys(String prefix){
    if (true) return true;
        synchronized(key2discarded){
            print(prefix + "CacheLRU::key2using::{");
            key2using.printKeys("     ");
            print("}");
            print(prefix + "CacheLRU::key2discarded::keys=" + key2discarded.keySet());
        }
        return true;
    }
    
    public static void main(String[] args){
        final int[] array = new int[]{0};
        CacheLRU<String, Integer> c = new CacheLRU<String, Integer>(3,
            s -> {
                ++array[0];
                return array[0];
            });
        assert 1 == c.get("a");
        assert 2 == c.get("b");
        c.discard("a");
        assert 3 == c.get("c");
        assert 1 == c.get("a");
        c.discard("a");
        c.discard("b");
        c.discard("c");
        assert 4 == c.get("d");
        assert 1 == c.get("a");
        assert 2 == c.get("b");
        assert 3 == c.get("c");
        c.discard("b");
        c.discard("c");
        c.discard("a"); // now b is eldest
        c.discard("d"); // now remove "b" from cache
        assert 5 == c.get("b");
        assert 1 == c.get("a");
        assert 3 == c.get("c");
        assert 4 == c.get("d");
        // assert 3 == c.get("d");
        
    }
}