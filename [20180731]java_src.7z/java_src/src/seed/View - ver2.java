
/*
mistake
    stage.setOnShown(...) instead of stage.onShownProperty().addListener(...)
    // ERROR:  assert stage.isShowing() == stage is shown;

keypoint .layout();
    1) scrollpane.layout() dont work; 
        use scrollpane.getContent().layout() instead
    2) on_width_change/repaint -> on_visibles_change
        so, call vbox.layout() in on_visibles_change instead of just repaint

scrollpane.viewportBounds was wrong, need to transform


repaint - ver1
    // has read all images info
    // but to read all images info at once is too slow
    
    draw_place_holders 
    set_actions
    
repaint
    // only know paths to draw
    task.laterUpdateCancel()
    vbox.getChildren().clear()
    task = new LaterUpdateTask(
        self -> {
            for path in paths:
                if isLaterUpdateCancelled(): break
                info = path2info(path)
                // image = load path if (isImage info) else None
                node = make_place_holder(path, info)
                report((node, path, info))
        },
        (self, (node, path, info)) -> {
            if node is Box: box_path_infos.add((node, path, info))
            vbox.getChildren().add(node);
        },
        null
    );
    

*/


package seed;
import javafx.event.Event;
import javafx.event.EventType;
import javafx.concurrent.Service;
import javafx.concurrent.Task;

import seed.Box;
import seed.MyScrollPane;
import static seed.io.Prints.*;
import javafx.scene.paint.Paint;
import javafx.geometry.Orientation;
import javafx.scene.shape.Rectangle;
import javafx.geometry.BoundingBox;
import javafx.stage.Stage;
import javafx.beans.binding.Bindings;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.MouseButton;



import seed.annotations.NonNull;
import java.nio.file.Path;

import javafx.beans.property.DoubleProperty;
import javafx.geometry.Bounds;
import javafx.scene.control.ScrollPane; 
import javafx.scene.layout.VBox;
import javafx.scene.control.Label;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.paint.Color;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.util.function.Function;
import seed.util.CacheLRU;
import seed.util.LaterUpdateTask;
import seed.State;
import seed.Funcs;
import static seed.Funcs.PathType;
import static seed.Funcs.Info;

import static seed.util.Pairs.*;
import static seed.util.Tuple3s.*;
import java.util.List;
import java.util.Set;
import java.util.ArrayList;
import java.util.HashSet;
import static seed.BackgroundColorSettor.*;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.beans.property.ReadOnlyDoubleProperty;

// Node::public boolean isResizable()
// javafx.scene.layout.Region::backgroundProperty


class PathCache extends CacheLRU<Path, Image> {
    public PathCache(
        int cacheSize,
        Function<? super Path,? extends Image> compute
        )
    {super(cacheSize, compute);}
}




class FontInfo{}


class View{
    private final Stage stage;
    private final MyScrollPane scrollpane;
    private final VBox vbox;
    private final PathCache cache;
    private boolean shown;
    private int end_of_repaint = 0;
    
    private State state;
    private FontInfo font_info;
    // assert box_path_infos.size() == boxes.size();
    //private List<Box> boxes = new ArrayList<>();
    private List<Tuple3<Box, Path, Info> > box_path_infos = new ArrayList<>();
    

    
    // [(Path, PathInfo, Box)] # image paths
    //private List<Tuple3<Path, Pair<PathType, Info>, Box> > visibles;

    
    
    Parent getNode(){
        return scrollpane;
    }
    public View(@NonNull Stage stage, 
                @NonNull PathCache cache, 
                @NonNull State state, 
                @NonNull FontInfo font_info){
        this.stage = stage;
        this.cache = cache;
        this.state = state;
        this.font_info = font_info;
        

        this.vbox = new VBox();
        this.scrollpane = new MyScrollPane(vbox);
        vbox.setFillWidth(true);
        this.scrollpane.setFitToWidth(true);
        
        this.shown = false;
    /*
        assert !stage.isShowing(); 
        stage.setOnShown(event -> {
            print("------------ shown ------------");
            this.shown = true;
            scrollpane.layout();
        });
        stage.setOnShowing(event -> {
            print("------------ Showing ------------");
        });
        //scrollpane.getChildren().add(vbox);
        //this.visibles = new ArrayList<Tuple3<Path, Pair<PathType, Info>, Box> >();
        stage.addEventHandler(MyActionEvent.AfterGUILayout, event->{event.run();});
    */
        init();
        repaint();
    }
    

    

    
    
    
    
    
    
    
    
    private static Set<Path> get_paths(
        List<Tuple3<Path, Pair<PathType, Info>, Box> > visibles){
        Set<Path> s = new HashSet<Path>();
        for (Tuple3<Path, Pair<PathType, Info>, Box> t : visibles){
            Path path = t._0;
            s.add(path);
        }
        return s;
    }


    private void init(){
        scrollpane.widthProperty()
            .addListener((property) -> // , oldValue, newValue
                            {
                                //double vvalue = scrollpane.getVvalue();
                                on_width_change();
                                //set_vvalue(scrollpane, vvalue);
                            }
            );
        
        scrollpane.vvalueProperty()
            .addListener(property -> //(property, oldValue, newValue)
                            {
                                on_visibles_change();
                            }
            );
        /* since the viewportBounds event follows height event
            donot do this:
        scrollpane.heightProperty()
            .addListener(property -> // (property, oldValue, newValue)
                            {
                                //on_visibles_change();
                                double v = scrollpane.getVvalue();
                                scrollpane.setVvalue(v+0.1);
                                scrollpane.setVvalue(v);
                            }
            );*/
        scrollpane.viewportBoundsProperty()
            .addListener(property -> // (property, oldValue, newValue)
                            {
                                on_visibles_change();
                            }
            );
    }

    private boolean ignore(){
        double width = getWidth();
        //if (true) return width < 1e-4;;
        if (true) return false;
        boolean r;
        
        if (end_of_repaint > 0){
            --end_of_repaint;
            r = true;
        }
        else {
            //double width = getWidth();
            //if (true) return !stage.isShowing() || width < 1e-4;
            
            r = !this.shown || !stage.isShowing() || width < 1e-4;
        }
        print("IGNORE : " + r);
        return r;
    }
    private void on_width_change(){
        print("on_width_change");
        if (ignore()) return;
        double width = getWidth();
        //if (false)for (Box box: boxes){
            //box.setBoxWidth(width);
        //}
        print("vbox.getWidth()  ", vbox.getWidth());
        print("width -> " + width);
        for (Tuple3<Box, Path, Info> box_path_info : box_path_infos){
            Box box = box_path_info._0;
            box.setWidthKeepingRadio(width);
        }
    }
    
    private void on_visibles_change(){
        print("on_visibles_change");
/*
        stage.fireEvent(new MyActionEvent(MyActionEvent.AfterGUILayout, ()->{
            __on_visibles_change();
        }));
    }
    private void __on_visibles_change(){
        print("__on_visibles_change");
        if (ignore()) return;
*/
        vbox.layout(); // layout here success! // layout in repaint seems dont work
        
        //Bounds b = trasformBounds(scrollpane.getViewportBounds());
        //print("vbox.getBoundsInLocal()   ", vbox.getBoundsInLocal());
        //print("vbox.getLayoutBounds()   ", vbox.getLayoutBounds());
        //print("scrollpane.getViewportBounds()   ", scrollpane.getViewportBounds());
        //print("trasformBounds(scrollpane.getViewportBounds())   ", b);
        //print("vbox.parentToLocal(scrollpane.getViewportBounds())   ", vbox.parentToLocal(scrollpane.getViewportBounds()));
        //print("vbox.parentToLocal(trasformBounds(scrollpane.getViewportBounds()))   ", vbox.parentToLocal(b));
        //double minY = calc_viewportMinYInContentLayoutY(scrollpane);
        //double maxY = minY + b.getHeight();
        //print("minY  maxY   ", minY, maxY);
        //print("calc_viewportBounds()", calc_viewportBounds(scrollpane));
        Bounds b = MyScrollPane.calc_viewportBounds(scrollpane);
        
        for (Tuple3<Box, Path, Info> box_path_info: box_path_infos){
            //if (!(node instanceof Box)) continue;
            Bounds c = box_path_info._0.getBoundsInParent();
            
            //print(b.intersects(c));
            //print("   ", c);
            if (b.intersects(c))
                show_image(box_path_info);
            else
                hide_image(box_path_info);
        }

        print("\n\n\n");
    }
    private ReadOnlyDoubleProperty widthProperty(){
        return scrollpane.widthProperty();
    }
    private void show_image(Tuple3<Box, Path, Info> box_path_info){
        print("show", box_path_info._1);
        Box box = box_path_info._0;
        if (box.getChild() instanceof ImageView) return;
        
        print("       loading");
        Path path = box_path_info._1;
        Info info = box_path_info._2;
        Node node = make_image_node(cache, path, widthProperty(), info);
        box.setChild(node);
    }
    private void hide_image(Tuple3<Box, Path, Info> box_path_info){
        print("hide", box_path_info._1);
        Box box = box_path_info._0;
        if (! (box.getChild() instanceof ImageView)) return;
        
        print("       discarding");
        Node node = info2empty_image_box_content(widthProperty(), box_path_info._2);
        box.setChild(node);
        cache.discard(box_path_info._1);
    }
    
    private void repaint(){
        vbox.getChildren().clear();
        //boxes.clear();
        box_path_infos.clear();
        draw_place_holder(box_path_infos, vbox, state.get_path_infos(), 
                          widthProperty(), font_info);
        //scrollpane.layout(); // donot work
        //vbox.layout(); // work, but since on_width_change is another source, so, move this line to on_visibles_change
        set_actions();
        print("------- end of repaint -----------");
        end_of_repaint = 0;
        
    }
    

    private double getWidth(){
        // base_width
        return scrollpane.getViewportBounds().getWidth();
    }
    private static void draw_string(VBox vbox, Path path, FontInfo font_info){
        // TODO
        vbox.getChildren().add(new Label("non-image file: "+path.toString()));
    }
    private static void draw_dirpath(VBox vbox, Path path, FontInfo font_info){
        // TODO
        vbox.getChildren().add(new Label("folder: " + path.toString()));
        
    }
    
    
    
    
    public static Node makeLabeledRectangle(String text, double width, double height, Paint fill){
        if(false) return new Label(text, new Rectangle(width, height, fill));
        //print(width, height);
        return new StackPane(new Rectangle(width, height, fill)); // new Label(text), 
    }
    public static Label makeColoredLabel(String text, Color c){
        Label label = new Label(text);
        setBackgroundColor(label, c);
        return label;
    }
    private static Node info2empty_image_box_content(
            ReadOnlyDoubleProperty base_width, Info info) {
        double w = info.scale * base_width.get(); // target width
        double h = w * info.height/info.width;
        Rectangle rect = new Rectangle(//info.width, info.height, 
            w, h, Color.GREY);

        rect.widthProperty().bind(Bindings.multiply(info.scale, base_width));
        rect.heightProperty().bind(Bindings.multiply(info.scale * info.height/info.width, base_width));
        return rect;
    }

    private static void draw_empty_image_box(
            final List<Tuple3<Box, Path, Info> > box_path_infos,
            VBox vbox, 
            Path path, 
            ReadOnlyDoubleProperty base_width, 
            Info info){
        //assert base_width > 0.0;
        //double w = info.scale * base_width; // target width
        //double h = w * info.height/info.width;
        
        Node node;
        {
            // image.width == box.width * box.child_scale
            //           w == base_width * info.scale
            Node rect = info2empty_image_box_content(base_width, info);
            Box box = new Box(rect, info.scale);
            box_path_infos.add(makeTuple(box, path, info));
            node = box;
            //node.relocate(200, 200);
        }
        vbox.getChildren().add(node);
    
    }
    private static Node make_image_node(
            final PathCache cache,
            Path path, 
            ReadOnlyDoubleProperty base_width, 
            Info info){
        Image image = cache.get(path);
        
        Node node;
        if (image == null) {
            //box = new Box(makeLabeledRectangle(path.toString(), w, h, Color.YELLOW), 1.0); // empty box
            Label label = makeColoredLabel("missing: " + path.toString(), Color.YELLOW);
            node = label;
        }
        else {
            // image.width == box.width * box.child_scale
            //           w == base_width * info.scale
            ImageView view = new ImageView(image);
            view.setPreserveRatio(true);
            view.fitWidthProperty().bind(base_width);
            node = view;
        }
        return node;
    }
    private static void ____________draw_image(
            final PathCache cache,
            //final List<Box> boxes,
            final List<Tuple3<Box, Path, Info> > box_path_infos,
            VBox vbox, 
            Path path, 
            ReadOnlyDoubleProperty base_width, 
            Info info){
        //assert base_width > 0.0;
        //double w = info.scale * base_width; // target width
        //double h = w * info.height/info.width;
        Node node = make_image_node(cache, path, base_width, info);
        Box box = new Box(node, info.scale);
        box_path_infos.add(makeTuple(box, path, info));
        vbox.getChildren().add(box);
    }
    private static void draw_place_holder(
            //final PathCache cache,
            //final List<Box> boxes,
            final List<Tuple3<Box, Path, Info> > box_path_infos,
            VBox vbox, 
            List<Pair<Path, Pair<PathType, Info> > > path_info_ls, 
            ReadOnlyDoubleProperty base_width, 
            FontInfo font_info){
        //if (base_width < 100.0){
        //    base_width = 100.0;
        //}
        for (Pair<Path, Pair<PathType, Info> > path_info : path_info_ls){
            final Path path = path_info.fst;
            Pair<PathType, Info> type_info = path_info.snd;
            PathType type = type_info.fst;
            Info info = type_info.snd;
            switch(type){
                case Image:
                    //print(base_width, info.scale, info.width, info.height);
                    //draw_image(cache, box_path_infos, vbox, path, base_width, info);
                    draw_empty_image_box(box_path_infos, vbox, path, base_width, info);
                    break;
                case Directory:
                    draw_dirpath(vbox, path, font_info);
                    break;
                case BrokenImage:
                    //Label rect = new Label("broken: " + path.toString());
                    //setBackgroundColor(rect, Color.RED);
                    Label rect = makeColoredLabel("broken: " + path.toString(), Color.RED);
                    vbox.getChildren().add(rect);
                    break;
                case Other:
                    draw_string(vbox, path, font_info);
                    break;
                default:
                    assert false;
            }
        }
    }

    

    
    private void set_actions(){
        // TODO
        // box_path_infos, vbox, state.get_path_infos(), widthProperty(), font_info
        List<Pair<Path, Pair<PathType, Info> > > path_info_ls = state.get_path_infos();
        
        assert path_info_ls.size() == vbox.getChildren().size();
        for (int i = 0; i < path_info_ls.size(); i++){
            Pair<Path, Pair<PathType, Info> > path_info = path_info_ls.get(i);
            Node node = vbox.getChildren().get(i);
            
            final Path path = path_info.fst;
            Pair<PathType, Info> type_info = path_info.snd;
            PathType type = type_info.fst;
            Info info = type_info.snd;
            switch(type){
                case Image:
                    break;
                case Directory:
                    node.setOnMouseClicked(event -> {
                        print("----- OnMouseClicked ----");
                        //ERROR: 
                        if (event.getEventType() != MouseEvent.MOUSE_CLICKED) return;
                        print("here");
                        //ERROR: if (! event.isPrimaryButtonDown()) return;
                        if (event.getButton() != MouseButton.PRIMARY) return;
                        print("----- on_click_dir ----", path);
                        on_click_dir(path);
                    });
                    break;
                case BrokenImage:
                    break;
                case Other:
                    break;
                default:
                    assert false;
            }
        }

    }
    
    
    public void on_click_dir(Path dir){
        if (dir.equals(state.getCurrDir()))
            on_click_opened_dir(dir);
        else
            on_click_closed_dir(dir);
    }
    public void on_click_closed_dir(Path dir){
        open_dir(dir);
    }
    private void open_dir(Path dir){
        // double old_top = get_top(scrollpane);
        state.open(dir);
        repaint();
        // set_top(scrollpane, old_top);
        //on_visibles_change();
    }
    public void on_click_opened_root(Path root){
        // TODO
    }
    public void on_click_opened_dir(Path dir){
        if (dir.equals(state.root))
            on_click_opened_root(dir);
        else
            open_dir(Funcs.get_parent(dir));
    }
}

/*
@FunctionalInterface
interface IAction{
    public void run();
}
class MyActionEvent extends Event{
    IAction action;
    MyActionEvent(
        EventType<? extends MyActionEvent> eventType, 
        IAction f
    ){
        super(eventType);
        this.action = f;
        assert f != null;
    }
    
    void run(){
        action.run();
    }
    
    public static EventType<MyActionEvent> AfterGUILayout = new EventType("AfterGUILayout");
}
/*
EventType<T extends Event>
EventHandler<T extends Event> (T) -> {}
addEventHandler(EventType<T> eventType, EventHandler<? super T> eventHandler)
fireEvent(Event event)
*/
