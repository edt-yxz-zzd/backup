
package seed.annotations;

public @interface Positive{}

