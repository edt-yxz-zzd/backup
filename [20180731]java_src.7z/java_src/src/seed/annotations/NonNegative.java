
package seed.annotations;

public @interface NonNegative{}

