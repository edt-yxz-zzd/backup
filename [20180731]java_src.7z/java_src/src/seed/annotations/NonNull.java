
package seed.annotations;

public @interface NonNull{}

