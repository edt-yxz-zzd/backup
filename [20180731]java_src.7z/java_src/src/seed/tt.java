


/*
    why compute more than once in old class??
    why the code do work after coming this file??
        javafx.concurrent.Task requires main javafx.application.Application
        straige:
            main exit, but the program does not
            main is not main, or there is a non-daemon thread??
            
    
    why consume all memory when Task.compute is deadloop??
    
*/



package seed;
import javafx.concurrent.Service;
import javafx.concurrent.Task;

import static seed.util.Iters.*;
import seed.excepts.InterruptedByCancelException;
import static seed.io.Prints.*;



import java.nio.file.Path;
import java.nio.file.Paths;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.util.function.Function;
import seed.util.CacheLRU;
import seed.util.LaterUpdateTask;
import seed.State;
import seed.Funcs;
import static seed.Funcs.PathType;
import static seed.Funcs.Info;

import static seed.util.Pairs.*;
import static seed.util.Tuple3s.*;
import java.util.List;
import java.util.Set;
import java.util.ArrayList;
import java.util.HashSet;
import javafx.application.Application;
import java.io.IOException;
import javafx.stage.Stage;


public class tt extends Application{
    public tt(){}
    static final CacheLRU<Path, Image> path2image_cache = new CacheLRU<>(10, Funcs::load_image);
    
    static LaterUpdateTask<Void, Void> make_task(String[] paths){
        print("make_task");
        return new LaterUpdateTask<Void, Void>(
            self -> {
            print("LaterUpdateTask::start");
            //if (true)while(true);/*if (true)throw null; 
                for (String spath: paths){
                    if (self.isLaterUpdateCancelled()) break;
                    Path path = Paths.get(spath);
                    Image image = path2image_cache.get(path); // maybe null
                    path2image_cache.printKeys("task path2image_cache ");
                    try{self.report(null);
                    }catch(InterruptedByCancelException ex){
                        throw null;
                    }
                }//*/
                return null;
            },
            (self, x) -> {return;},
            null
        );
    }
    static Thread make_thread(String[] paths){
        Thread th = new Thread(make_task(paths));
        th.setDaemon(false);
        return th;
    }

    static final String dir = "E:/multimedia/picture/extreme_name_group/";
    static final String[] paths = {
        dir + "��_���ں�.png",
        dir + "ʳ��.png",
        dir + "СϪ.png"
    };
    
    static final Thread[] threads = {
        make_thread(paths),
        make_thread(paths),
        make_thread(paths),
        make_thread(paths),
        make_thread(paths),
        make_thread(paths),
        make_thread(paths),
        make_thread(paths),
        make_thread(paths),
        make_thread(paths),
        make_thread(paths),
        make_thread(paths),
        make_thread(paths),
        make_thread(paths),
        make_thread(paths),
        make_thread(paths),
    };
    {
        for (Thread th : threads){
            print("start thread");
            th.start();
        }
    }

    @Override
    public void start(Stage s){
    }
    public static void main(String[] args){
        print("main");
        new tt();
        path2image_cache.printKeys("path2image_cache ");
        for (Thread th : threads){
            assert th.getState() != Thread.State.NEW;
            try{th.join();
            } catch(Throwable ex){
                //
            }
            assert th.getState() == Thread.State.TERMINATED;
            assert !th.isInterrupted();
        }
        path2image_cache.printKeys("path2image_cache ");
    }
    
}