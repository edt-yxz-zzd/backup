package seed;

import seed.util.IIterator;
import static seed.util.IIterator.*;
import static seed.util.Iters.*;
import static seed.io.Prints.*;
/*
//data PathType = Directory | BrokenImage | Image | Other
//data Info = Info {width, height, scale}
//PathInfo = (PathType, Info)
data PathInfo = Directory | BrokenImage | Image width height scale | Other

class Funcs:
    static List<Path> list_entries(Path root, Path me, dir_cmp, file_cmp):...
    get_infos :: [Path] -> [(Path, PathInfo)]
    load_image :: Path -> Image
    get_parent :: Path -> Path
*/


import seed.annotations.NonNull;
import seed.annotations.Positive;

import java.nio.file.Path; // prefer Path than File
import java.nio.file.Paths;
import java.nio.file.Files;
import java.nio.file.DirectoryStream;
import java.nio.file.DirectoryIteratorException;
import java.io.ByteArrayInputStream;
import java.nio.channels.AsynchronousCloseException;
import java.nio.channels.ClosedByInterruptException;

import static seed.io.ImageWidthHeightGettor.*;
import javafx.scene.image.Image;
import java.net.MalformedURLException;
import java.io.IOException;

import static seed.util.Pairs.*;
import static seed.util.Tuple3s.*;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.util.Collection;

import java.util.Comparator;
import java.util.function.Predicate;

import java.util.logging.Level; // FINEST
import static java.util.logging.Logger.getGlobal; // finest(...)

class Funcs{
    
    // PathInfo = Pair<PathType, Info>
    
    public static enum PathType{
        Directory, BrokenImage, Image, Other;
    }

    public static class Info {
        public final double width, height, scale;
        public Info(@NonNull WidthHeightPair<Integer, Integer> wh,
                    @NonNull @Positive double scale){
            this(wh.width, wh.height, scale);
            assert wh != null;
            //assert scale != null;
            assert scale > 0;
            
        }
        public Info(@NonNull double width, 
                    @NonNull double height, 
                    @NonNull double scale) {
            //assert width != null;
            //assert height != null;
            //assert scale != null;
    
            this.width = width;
            this.height = height;
            this.scale = scale;
        }
    }
    



    
    /**
        list all files/directories that will be showed.
<pre>
    def list_entries(root, me, dir_order, file_order):
        yield root
        dirs = iter(list_directories(root, dir_order))
        
        if root == me:
            files = list_files(root, file_order)
            yield from dirs
            yield from files
            return
        for dir in dirs:
            if me.startswith(dir):
                break
            yield dir
        else:
            raise ...
        
        yield from list_entries(dir, me, dir_order, file_order)
        yield from dirs
</pre>
        @param root         the directory opened via virtaul root or directory chooser
        @param me           the directory whose contents will be showed
        @param dir_order    to sort subdirectories; nullable
        @param file_order   to sort subfiles; nullable
        @return             all files/directories that will be showed
    */
    public static List<Path> list_entries(
                Path root, 
                Path me, 
                Comparator<Path> dir_order,
                Comparator<Path> file_order){
        assert Files.isDirectory(me);
        assert root.isAbsolute();
        assert me.startsWith(root);
        assert me.isAbsolute();
        
        ArrayList<Path> output = new ArrayList<Path>();
        list_entries(output, root, me, dir_order, file_order);
        return output;
    }

    // public streamToList(){}
    public static List<Path> list(Path parent_dir, Predicate<? super Path> predicate) {
        assert Files.isDirectory(parent_dir);
        // Stream<Path> s = Files.list(parent_dir).sorted(dir_order);
        List<Path> result = new ArrayList<>();
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(parent_dir)) {
            for (Path entry: stream) {
                //try {
                    if (predicate.test(entry)) result.add(entry);
                //}finally{}
            }
        } catch (DirectoryIteratorException | IOException ex) {
           // I/O error encounted during the iteration, the cause is an IOException
           // throw ex.getCause();
        }
        return result;
    }
    public static <T> Iterator<T> sortedListInplace(List<T> ls, Comparator<T> order) {
        ls.sort(order);
        return ls.iterator();
    }
    public static Iterator<Path> list_directories(Path parent_dir, Comparator<Path> dir_order){
        List<Path> result = list(parent_dir, path -> Files.isDirectory(path));
        return sortedListInplace(result, dir_order);
    }
    public static Iterator<Path> list_files(Path parent_dir, Comparator<Path> file_order){
        List<Path> result = list(parent_dir, path -> Files.isRegularFile(path));
        return sortedListInplace(result, file_order);
    }
    private static void list_entries(
                List<Path> output,
                Path root, 
                Path me, 
                Comparator<Path> dir_order,
                Comparator<Path> file_order){
        output.add(root);
        
        Iterator<Path> dirs = list_directories(root, dir_order);
        
        if (root.equals(me)){
            Iterator<Path> files = list_files(root, file_order);
            addAll(output, dirs);
            addAll(output, files);
            return;
        }

        Path dir = null;
        while (dirs.hasNext()){
            dir = dirs.next();
            if (me.startsWith(dir)) {
                break;
            }
            output.add(dir);
        }

        assert dir != null;
        assert me.startsWith(dir);
        
        list_entries(output, dir, me, dir_order, file_order);
        addAll(output, dirs);
        return;
    }
    
    
    
    
    public static Pair<PathType, Info> path2info(Path path){
        if (Files.isRegularFile(path))
            try {
                WidthHeightPair<Integer, Integer> wh = getImageWidthHeight(path);
                if (wh != null)
                    // sub image file
                    return makePair(PathType.Image, new Info(wh, 1.0));
                else
                    // non-image file
                    return makePair(PathType.Other, null);
            }
            catch(IOException e){
                print("path2info -> IOException");
                e.printStackTrace();
                // broken image
                return makePair(PathType.BrokenImage, null);
            }
        else{
            // subdirectory
            return makePair(PathType.Directory, null);
        }
    }
    /**
        query image width and height over paths
        @param paths ::[Path]; directories/images/other_files
        @return ::[(PathType, Info)]; 
                [(directory|broken_image|other, null)|(image, (width, height, scale))]
    */
    public static List<Pair<Path, Pair<PathType, Info> > > 
        get_infos(Iterable<? extends Path> paths){
        List<Pair<Path, Pair<PathType, Info> > >
            ls = new ArrayList<Pair<Path, Pair<PathType, Info> > >();
        for (Path path : paths){
            ls.add(makePair(path, path2info(path)));
        }
        return ls;
    }
    public static IIterator<Pair<Path, Pair<PathType, Info> > > 
        iter_get_infos(Iterable<? extends Path> paths
    ){
        return map(path->makePair(path, path2info(path)), paths);
    }
    
    
    static class MyImage extends Image{
        public MyImage(String s){
            super(s);
            try{this.finalize();
            } catch(Throwable t){
                print("MyImage::finalize", t);
            }
        }
        
        public void finalize() throws Throwable {
            super.finalize();
        }
    }
    /*
    java.io.InputStream
    java.io.ByteArrayInputStream(byte[] buf)
    java.io.FileInputStream
    java.nio.file.Files.readAllBytes(Path path)
    */
    public static byte[] read_file(Path path) throws IOException {
        return Files.readAllBytes(path);
    }
    public static ByteArrayInputStream path2stream(Path path) throws IOException {
        return new ByteArrayInputStream(read_file(path));
    }
    public static Image load_image2(Path path) throws Exception {
        try{
            return new Image(path2stream(path));
        } catch(AsynchronousCloseException e){
            e.printStackTrace();
            throw e;
        } catch(Exception e){
            e.printStackTrace();
            return null;
        }
    }
    
    
    public static Image load_image(Path path) {
        // null - retry
        // .isError() - error
        // otherwise - normal
        
        //getGlobal().finest("try to load image: " + path);
        ByteArrayInputStream s;
        try{
            s = path2stream(path);
        } catch(ClosedByInterruptException e){
            print("load_image -> ClosedByInterruptException");
            print(e);
            return null;
        } catch(Exception e){
            print("load_image -> Exception");
            print(e);
            e.printStackTrace();
            s = new ByteArrayInputStream(new byte[0]);
        }
        
        // 
        // image.isError();
        return new Image(s);
    }
    public static Image load_image0(Path path){
        return load_image1(path, false);
    }
    public static Image load_image1(Path path, boolean background){
        getGlobal().finest("try to load image: " + path);
        print("------------------ load image : " + path + " --------------------");
        try{
            String s = path.toUri().toURL().toString();
            return new Image(s, false);
        } catch (MalformedURLException e) {
            assert false;
            return null;
        }
    }
    public static Path get_parent(Path path){
        return path.getParent();
    }
}


