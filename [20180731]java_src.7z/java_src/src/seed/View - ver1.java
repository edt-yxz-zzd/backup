package seed;

import seed.Box;

import seed.annotations.NonNull;
import java.nio.file.Path;

import javafx.beans.property.DoubleProperty;
import javafx.geometry.Bounds;
import javafx.scene.control.ScrollPane; 
import javafx.scene.layout.VBox;
import javafx.scene.control.Label;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.paint.Color;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.util.function.Function;
import seed.util.CacheLRU;
import seed.State;
import seed.Funcs;
import static seed.Funcs.PathType;
import static seed.Funcs.Info;

import static seed.util.Pairs.*;
import static seed.util.Tuple3s.*;
import java.util.List;
import java.util.Set;
import java.util.ArrayList;
import java.util.HashSet;
import static seed.BackgroundColorSettor.*;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.beans.property.ReadOnlyDoubleProperty;

// Node::public boolean isResizable()
// javafx.scene.layout.Region::backgroundProperty


class PathCache extends CacheLRU<Path, Image> {
    public PathCache(
        int cacheSize,
        Function<? super Path,? extends Image> compute
        )
    {super(cacheSize, compute);}
}



class Rect extends Box{
    public Rect(Color c, double width, double height, Node... nodes){
        super(c, width, height, nodes);
    }
    
    void set(Node node){getChildren().add(node);}
}
class FontInfo{}


class View{
    //private final Stage stage;
    private final MyScrollPane scrollpane;
    private final VBox vbox;
    private final PathCache cache;
    
    private State state;
    private FontInfo font_info;

    
    // [(Path, PathInfo, Box)] # image paths
    private List<Tuple3<Path, Pair<PathType, Info>, Box> > visibles;
    static class MyScrollPane extends ScrollPane{
        public MyScrollPane(Node node){
            super(node);
            super.getChildren().add(node);
        }/*
        public ObservableList<Node> getChildren(){
            return super.getChildren();
        }*/
    }
    
    
    Parent getNode(){
        return scrollpane;
    }
    public View(//@NonNull Stage stage, 
                @NonNull PathCache cache, 
                @NonNull State state, 
                @NonNull FontInfo font_info){
        //this.stage = stage;
        this.cache = cache;
        this.state = state;
        this.font_info = font_info;
        

        this.vbox = new VBox();
        this.scrollpane = new MyScrollPane(vbox);
        //scrollpane.getChildren().add(vbox);
        this.visibles = new ArrayList<Tuple3<Path, Pair<PathType, Info>, Box> >();
        init();
    }
    
    public final ReadOnlyDoubleProperty widthProperty(){
        // TODO
        return scrollpane.widthProperty();
    }
    public final ReadOnlyDoubleProperty heightProperty(){
        // TODO
        return scrollpane.heightProperty();
    }
    protected final void setWidth(double value){
        throw new UnsupportedOperationException("setWidth");
        // scrollpane.setWidth(value);
    }
    public final double getWidth(){
        return scrollpane.getWidth();
    }
    
    
    public void on_click_closed_dir(Path dir){
        open_dir(dir);
    }
    private void open_dir(Path dir){
        // double old_top = get_top(scrollpane);
        state.open(dir);
        repaint();
        // set_top(scrollpane, old_top);
        on_visibles_change();
    }
    public void on_click_opened_root(Path root){
        // TODO
    }
    public void on_click_opened_dir(Path dir){
        if (dir.equals(state.root))
            on_click_opened_root(dir);
        else
            open_dir(Funcs.get_parent(dir));
    }
    private static Set<Path> get_paths(
        List<Tuple3<Path, Pair<PathType, Info>, Box> > visibles){
        Set<Path> s = new HashSet<Path>();
        for (Tuple3<Path, Pair<PathType, Info>, Box> t : visibles){
            Path path = t._0;
            s.add(path);
        }
        return s;
    }
    
    //(top, height)
    /*
    public static Pair<Double, Double> get_pos(MyScrollPane scrollpane){
        double pane_height = scrollpane.getHeight();
        return makePair(top, pane_height);
    }*/
    public static double get_top(MyScrollPane scrollpane){
        // .layoutY???
        // The ScrollPane allows the application to set the current, minimum, and maximum values for positioning the contents in the horizontal and vertical directions. 
        // These values are mapped proportionally onto the layoutBounds of the contained node.
        // layoutBounds of contained!!
        Bounds b = scrollpane.getViewportBounds();
        double view_height = b.getHeight();
        double pane_height = scrollpane.getContent().getLayoutY();// scrollpane.getHeight();
        
        double vvalue = scrollpane.getVvalue();
        double vmin = scrollpane.getVmin();
        double vmax = scrollpane.getVmax();
        
        double top_min = 0; 
        double top_max = pane_height - view_height;
        double top = top_min + (top_max - top_min) * (vvalue - vmin) / (vmax - vmin);
        return top;
    }
    public static double calc_vvalue(MyScrollPane scrollpane, double top){
        Bounds b = scrollpane.getViewportBounds();
        double view_height = b.getHeight();
        double pane_height = scrollpane.getContent().getLayoutY();// scrollpane.getHeight();
        
        //double vvalue = scrollpane.getVvalue();
        double vmin = scrollpane.getVmin();
        double vmax = scrollpane.getVmax();
        
        double top_min = 0; 
        double top_max = pane_height - view_height;
        double vvalue = vmin + (vmax - vmin) * (top - top_min) / (top_max - top_min);
        return vvalue;
    }

    private void init(){
        scrollpane.widthProperty()
            .addListener((property) -> // , oldValue, newValue
                            {
                                double vvalue = scrollpane.getVvalue();
                                this.repaint();
                                set_vvalue(scrollpane, vvalue);
                            }
            );
        
        scrollpane.vvalueProperty()
            .addListener(property -> //(property, oldValue, newValue)
                            {
                                on_visibles_change();
                            }
            );
        scrollpane.heightProperty()
            .addListener(property -> // (property, oldValue, newValue)
                            {
                                on_visibles_change();
                            }
            );
    }

    
    
    private void set_vvalue(MyScrollPane scrollpane, double vvalue){
        scrollpane.setVvalue(vvalue);
        on_visibles_change();
    }
    private void set_top(MyScrollPane scrollpane, double top){
        // relocate(x, y)??
        double vvalue = calc_vvalue(scrollpane, top);
        set_vvalue(scrollpane, vvalue);
    }
    
    
    /*
    private void clean(Box box){
        
    }
    private void clean(List<Tuple3<Path, Pair<PathType, Info>, Box> > visibles){
        for (Tuple3<Path, Pair<PathType, Info>, Box> e : visibles){
            clean(e._2);
        }
    }*/
    
    private Pair<Integer, Integer> find_visible_range(MyScrollPane scrollpane, VBox vbox){
        List<Node> nodes = find_visible_entries(scrollpane, vbox);
        int begin = nodes.isEmpty()? 0 : vbox.getChildren().indexOf(nodes.get(0));
        int end = begin + nodes.size();
        return makePair(begin, end);
    }
    
    static void print(String s, Region node){
        System.out.println(s + "width, height == " + node.getWidth() + ", " + node.getHeight());
        throw new RuntimeException("afafasfsf");
    }
    
    private static boolean isVisible(MyScrollPane scrollpane, VBox vbox, Node node){
        return false;
    }
    private List<Node> find_visible_entries(MyScrollPane scrollpane, VBox vbox){
        // return null;// TODO
        Bounds b = scrollpane.getViewportBounds();
        b = vbox.sceneToLocal(b);
        System.out.println("scrollpane width height: " + scrollpane.getWidth() + " " + scrollpane.getHeight());
        System.out.println("scrollpane bounds to vbox: " + b);
        
        List<Node> ls = new ArrayList<Node>();
        int state = 0;
        for (Node node : vbox.getChildren()){
            //Bounds x = node.getBoundsInParent();
            
            //if (isVisible(scrollpane, vbox, node)) ls.add(node);
            // if (1==1)continue;
            // if (node.isVisible()) // always true
            
            //print("  ", (Region)node);
            
            Bounds x = node.getBoundsInParent();
            if (!x.isEmpty()) System.out.println("    child BoundsInParent: " + x);
            //else System.out.println("    child BoundsInParent: (empty)");
            //System.out.println("        child BoundsInLocal: " + node.getBoundsInLocal());
            //System.out.println("             child LayoutBounds: " + node.getLayoutBounds());
            //if (1==1)continue;
            //if (x.intersects(b)) ls.add(node);
            if (x.intersects(b))
                ;
            if (state == 0){
                if (x.intersects(b)){
                    state = 1;
                    ls.add(node);
                }
            }
            else if (state == 1){
                if (x.isEmpty() || x.intersects(b))
                    ls.add(node);
                else
                    state = 2;
            }
            else if (state == 2 && !x.intersects(b)){
                ;
            }
            else {
                assert state == 2 && x.intersects(b);
                throw new RuntimeException("logic error");
            }
        }
        return ls;
    }
    private void on_visibles_change(){
        if (true) return;
        Pair<Integer, Integer> rng = find_visible_range(scrollpane, vbox);
        int begin = rng.fst;
        int end = rng.snd;

        List<Tuple3<Path, Pair<PathType, Info>, Box> > new_visibles = 
            new ArrayList<Tuple3<Path, Pair<PathType, Info>, Box> >();
        for (int i = begin; i != end; ++i){
            Pair<Path, Pair<PathType, Info> > info = state.get_path_infos().get(i);
            if (info.snd.fst == PathType.Image)
                new_visibles.add(makeTuple(
                    info.fst, info.snd, (Box)vbox.getChildren().get(i)));
        }
        
        Set<Path> to_remove = get_paths(visibles);
        Set<Path> to_draw = get_paths(new_visibles);
        to_remove.removeAll(to_draw);
        
        System.out.println("to_remove: " + to_remove);
        System.out.println("to_draw: " + to_draw);
        clean_image_boxes(cache, visibles, to_remove);
        draw_image_boxs(cache, new_visibles);
        this.visibles = new_visibles;
    }
    private void repaint(){
        vbox.getChildren().clear();
        draw_place_holder(cache, vbox, state.get_path_infos(), 
                          getWidth(), font_info);
        // scrollpane.requestLayout();
        scrollpane.layout();
        vbox.layout();
        find_visible_range(scrollpane, vbox);
        // move(scrollpane, pos)
        // self.move_update()
        set_actions();
        scrollpane.setMinWidth(scrollpane.USE_COMPUTED_SIZE);
    }
    
    private static void draw_string(VBox vbox, Path path, FontInfo font_info){
        // TODO
        vbox.getChildren().add(new Label("non-image file: "+path.toString()));
    }
    private static void draw_dirpath(VBox vbox, Path path, FontInfo font_info){
        // TODO
        vbox.getChildren().add(new Label("folder: " + path.toString()));
    }
    private static void draw_place_holder(
            final PathCache cache,
            VBox vbox, 
            List<Pair<Path, Pair<PathType, Info> > > path_info_ls, 
            double base_width, 
            FontInfo font_info){
        for (Pair<Path, Pair<PathType, Info> > path_info : path_info_ls){
            final Path path = path_info.fst;
            Pair<PathType, Info> type_info = path_info.snd;
            PathType type = type_info.fst;
            Info info = type_info.snd;
            switch(type){
                case Image:
                    double w = info.scale * base_width;
                    double h = w * info.height/info.width;
                    final Box box = new Box(w, h, new Label()); // empty box
                    box.visibleProperty().addListener(
                        (observable, oldValue, newValue) -> {
                            if (newValue) draw_image_box(cache, path, box);
                            else clean_image_box(cache, path, box);;
                        }
                    );
                    vbox.getChildren().add(box);
                    
                    break;
                case Directory:
                    draw_dirpath(vbox, path, font_info);
                    break;
                case BrokenImage:
                    Rect rect = new Rect(Color.GREY, base_width, base_width/4);
                    rect.set(new Label(path.toString()));
                    vbox.getChildren().add(rect);
                    break;
                case Other:
                    draw_string(vbox, path, font_info);
                    break;
                default:
                    assert false;
            }
        }
    }
    private static void draw_image_boxs(
            PathCache cache, 
            List<Tuple3<Path, Pair<PathType, Info>, Box> > visibles){
        for (Tuple3<Path, Pair<PathType, Info>, Box> e : visibles){
            draw_image_box(cache, e._0, e._2);
        }
    }
    
    private static void draw_image_box(PathCache cache, Path path, Box box){
        Image image = cache.get(path);
        box.set(image);
    }
    private static void clean_image_box(PathCache cache, Path path, Box box){
        cache.discard(path);
        box.clr();
    }

    private static void clean_image_boxes(
            PathCache cache, 
                List<
                    Tuple3<Path, Pair<PathType, Info>, Box>
                > visibles, 
            Set<Path> to_remove){
        for (Tuple3<Path, Pair<PathType, Info>, Box> e : visibles){
            if (to_remove.contains(e._0)){
                e._2.clr();
            }
        }
    }
    
    private void set_actions(){
        // TODO
        
    }
}






