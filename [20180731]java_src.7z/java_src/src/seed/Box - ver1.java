package seed;

import javafx.scene.Node;
import javafx.scene.layout.Region;

public class Box extends Region {
    private double width, height, child_scale;
    private Node child;
    public final void setBoxWidth(double width){
        if (this.width == width) return;
        this.width = width;
        
        setMinWidth(width);
        setMaxWidth(width);
        setPrefWidth(width);
        
        requestParentLayout();
    }
    public final void setBoxHeight(double height){
        if (this.height == height) return;
        this.height = height;
        
        setMinHeight(height);
        setMaxHeight(height);
        setPrefHeight(height);
        requestParentLayout();
    }
    public final void setBoxSize(double width, double height){
        setBoxWidth(width);
        setBoxHeight(height);
    }
    public final void setBoxChildScale(double scale){
        this.child_scale = scale;
        requestLayout();
    }
    protected void layoutChildren(){
        child.resize(width * child_scale, height * child_scale);
    }
    
    public boolean isResizable(){
        return false;
    }
    public Box(double width, double height, double scale, Node node){
        super();
        assert node != null;
        
        setBoxSize(width, height);
        setBoxChildScale(scale);
        this.child = node;
        getChildren().add(node);
    }
    
    
    @Override
    protected double computeMinHeight(double width){
        return height;
    }
    @Override
    protected double computeMaxHeight(double width){
        return height;
    }
    @Override
    protected double computePrefHeight(double width){
        return height;
    }
    @Override
    protected double computeMinWidth(double height){
        return width;
    }
    @Override
    protected double computeMaxWidth(double height){
        return width;
    }
    @Override
    protected double computePrefWidth(double height){
        return width;
    }
    
    

}











