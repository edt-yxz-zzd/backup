package ;

import seed.io.Prints.*;

public class {
    public static void main(String[] args){
        System.out.println("");
    }
}