package seed;

import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Group;
import javafx.scene.layout.Region;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;
import javafx.geometry.Orientation;
import static seed.io.Prints.*;


// child.size = box.size * scale
public class Box extends Parent {
    private double child_scale;
    private Node child;
    public Node getChild(){return child;}
    public void setChild(Node child) {
        if (child == null){
            throw new NullPointerException("Box::setChild");
        }
        this.child = child;
        getChildren().add(child);
        onUpdate();
    }
    public double getChildScale(){
        return child_scale;
    }
    public void setChildScale(double child_scale){
        if (child_scale <= 0.0){
            throw new IllegalArgumentException("Box::setChildScale");
        }
        this.child_scale = child_scale;
        onUpdate();
    }

    private void onUpdate(){
        requestParentLayout();
    }
    
    public void setWidthKeepingRadio(double width){
        double height = width * child.getLayoutBounds().getHeight() / child.getLayoutBounds().getWidth();
        resize(width, height);
    }

    public Box(Node node, double child_scale){
        super();
        this.child_scale = 1.0;
        setChild(node);
        setChildScale(child_scale);
        
        resize(child.getLayoutBounds().getWidth(), child.getLayoutBounds().getHeight());
    }
    
    // isResizable(), getContentBias(), resize(double, double), getLayoutBounds()
    // minWidth(double), minHeight(double), prefWidth(double), prefHeight(double), maxWidth(double), maxHeight(double), 
    public boolean isResizable(){return true;}
    public Orientation getContentBias(){return child.getContentBias();}
    public void resize(double width, double height){
        super.resize(width, height);
        //print("width * child_scale, height * child_scale   ", width * child_scale, height * child_scale);
        //print("width, height, child_scale   ", width, height, child_scale);
        //print("maxwidth, maxheight   ", maxWidth(height), maxHeight(width));
        child.resize(width * child_scale, height * child_scale);
    }
    public double minWidth(double height){
        double child_height = height * child_scale;
        double child_minWidth = child.minWidth(child_height);
        return child_minWidth / child_scale;
    }
    public double maxWidth(double height){
        double child_height = height * child_scale;
        double child_maxWidth = child.maxWidth(child_height);
        return child_maxWidth / child_scale;
    }
    public double prefWidth(double height){
        double child_height = height * child_scale;
        double child_prefWidth = child.prefWidth(child_height);
        return child_prefWidth / child_scale;
    }
    public double minHeight(double width){
        double child_width = width * child_scale;
        double child_minHeight = child.minHeight(child_width);
        return child_minHeight / child_scale;
    }
    public double maxHeight(double width){
        double child_width = width * child_scale;
        double child_maxHeight = child.maxHeight(child_width);
        return child_maxHeight / child_scale;
    }
    public double prefHeight(double width){
        double child_width = width * child_scale;
        double child_prefHeight = child.prefHeight(child_width);
        return child_prefHeight / child_scale;
    }



}











