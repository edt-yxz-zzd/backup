
package seed;

import static seed.util.Pairs.*;
import static seed.io.Prints.*;
import static seed.io.ImageWidthHeightGettor.*;
import javafx.stage.Screen;
import javafx.geometry.Rectangle2D;
import javafx.geometry.Bounds;


import javafx.beans.binding.Bindings;
import javafx.stage.DirectoryChooser;
import javafx.scene.control.ScrollPane; 
    // hvalue, vvalue, setFitToWidth, setPrefViewportWidth, getViewportBounds
//import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.layout.Pane;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.util.Stack;
import java.util.Comparator;
import java.util.*;
import java.util.Collection;
import java.nio.file.DirectoryStream;
import java.nio.file.DirectoryIteratorException;
import java.util.function.Predicate;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import java.net.MalformedURLException;

/*
 javafx.scene.control.ListView<T>
 javafx.scene.web.WebView 
        .getEngine()
 javafx.scene.web.WebEngine 
        .loadContent(html_content)
        .reload()
        .executeScript(script)
 static String format(String format, Object... args)
 
*/
import javafx.scene.web.WebView;
import javafx.scene.web.WebEngine;

import java.nio.file.Path; // prefer Path than File
import java.nio.file.Paths;
import java.nio.file.Files;

import javax.swing.text.html.parser.DTD;
import javax.swing.text.html.parser.DocumentParser;
import java.nio.charset.StandardCharsets;



import java.io.File;
import java.net.URL;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import java.io.IOException;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.Parent;
import javafx.scene.Node;


import javafx.beans.binding.Bindings;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.text.Font;
import javafx.scene.shape.Rectangle;


// class Rect extends ; // Rect = EmptyBox<W,H> | Image<W,H>


/*
java.util.HashMap
java.util.LinkedHashMap !!!! 
*/

import seed.util.CacheLRU;
import static seed.Funcs.PathType;
import static seed.Funcs.Info;



import static seed.util.Tuple3s.*;
import seed.annotations.NonNull;
import seed.annotations.Positive;
import seed.View.*;
import seed.Funcs;
import static java.util.logging.Logger.getGlobal;
import java.util.logging.ConsoleHandler;
import java.util.logging.Level;
import java.util.logging.Handler;





public class T extends Application {
    public void start(final Stage stage){
    
        getGlobal().setLevel(Level.ALL);
        Handler h = new ConsoleHandler();
        h.setLevel(Level.ALL);
        getGlobal().addHandler(h);
        // E:\my_data\program_source\java_src\src>java -cp . seed.T e:\ e:\multimedia\picture\beauty\wallpaper\1
        Path root = Paths.get("e:/");
        Path curr_dir = Paths.get("E:/multimedia/picture/extreme_name_group");
        Path me = Paths.get("e:/multimedia/picture/beauty/wallpaper/1");
        
        
        
        Rectangle2D primaryScreenBounds = Screen.getPrimary().getVisualBounds();
        //set Stage boundaries to visible bounds of the main screen
        stage.setX(primaryScreenBounds.getMinX());
        stage.setY(primaryScreenBounds.getMinY());
        stage.setWidth(primaryScreenBounds.getWidth());
        stage.setHeight(primaryScreenBounds.getHeight());
        
        CacheLRU<Path, Image> path2image_cache = new CacheLRU<>(10, Funcs::load_image, v->v==null);
        CacheLRU<Path, Pair<PathType, Info> > path2type_info_cache = new CacheLRU<>(300, Funcs::path2info, v->v.fst==PathType.BrokenImage);
        FontInfo font = new FontInfo();
        Comparator<Path> cmp = Path::compareTo; //(p1, p2) -> p1.compareTo(p2);
        State state = new State(root, curr_dir, cmp, cmp);
        View v = new View(stage, path2image_cache, path2type_info_cache, state, font);
        
        print("------------- before stage.show ---------------");
        stage.setScene(new Scene(v.getContent()));
        stage.show();

    }
 
    
}



