1     package chap21.BasicApplet;
1     import java.applet.*;
2     import java.awt.*;
3     import javax.swing.*;
4
5     public class BasicApplet extends JApplet {
6
7       private static JTextArea textarea = null;
8       private static JScrollPane scrollpane = null;
9
10      public void init(){
11        textarea = new JTextArea(10, 30);
12        scrollpane = new JScrollPane(textarea);
13        getContentPane().add(scrollpane);
14        textarea.append("BasicApplet init() method called.\n");
15        System.out.println("BasicApplet init() method called.");
16      }
17
18      public void start(){
19        System.out.println("BasicApplet start() method called.");
20        textarea.append("BasicApplet start() method called.\n");
21      }
22
23      public void stop(){
24        System.out.println("BasicApplet stop() method called.");
25        textarea.append("BasicApplet stop() method called.\n");
26      }
27
28      public void destroy(){
29        System.out.println("BasicApplet destroy() method called.");
30        textarea.append("BasicApplet destroy() method called.\n");
31      }
32    } // end BasicApplet class definition