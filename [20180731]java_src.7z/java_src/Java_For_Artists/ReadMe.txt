
modify set_main.bat

m.bat - get %main%

copy src to s.java

s.bat to gen %main%.java // remove line number

c.bat to compile
d.bat to gen doc
r.bat to run

cr.bat to c & r

