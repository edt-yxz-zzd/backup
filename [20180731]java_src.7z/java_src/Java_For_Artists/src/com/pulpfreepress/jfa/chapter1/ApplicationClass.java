package com.pulpfreepress.jfa.chapter1;

public class ApplicationClass {

  public static void main(String args[]){
    SampleClass sc = new SampleClass();
    System.out.println(SampleClass.CONST_VAL);
    System.out.println(SampleClass.getClassVariable());
    System.out.println(sc.getInstanceVariable());
    SampleClass.setClassVariable(3);
    sc.setInstanceVariable(4);
    System.out.println(SampleClass.getClassVariable());
    System.out.println(sc.getInstanceVariable());

    System.out.println(sc.getClassVariable());
  }
}