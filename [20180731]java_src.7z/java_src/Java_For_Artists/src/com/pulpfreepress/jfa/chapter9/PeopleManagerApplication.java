package com.pulpfreepress.jfa.chapter9;

public class PeopleManagerApplication {
  public static void main(String[] args){
    Person p1 = new Person("Steve", "Jason", "Brown", 1980, 3, 4, "Male");

    System.out.println(p1.getFirstName() + " " + p1.getMiddleName()
                       + " " + p1.getLastName() + " - " + p1.getGender());
    System.out.println(p1.getFirstName() + " is " + p1.getAge() + " years old!");

   }  // end main
 }// end PeopleManagerApplication class