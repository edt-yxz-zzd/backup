package com.pulpfreepress.jfa.chapter6;

public class TestClassOne7 {

  public static void main(String[] args){
    int int_variable_1 = Integer.parseInt(args[0]);
    int int_variable_2 = Integer.parseInt(args[1]);
    int int_variable_3 = Integer.parseInt(args[2]);

    int total = int_variable_1 + int_variable_2 + int_variable_3;

    System.out.println(total);

  }
}