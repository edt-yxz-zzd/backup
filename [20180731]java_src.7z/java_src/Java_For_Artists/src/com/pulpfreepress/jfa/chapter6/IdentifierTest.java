 package com.pulpfreepress.jfa.chapter6;

 public class IdentifierTest {
  public static void main(String[] args){
       String  \u03B63_3 = "Hello - \u03B63_3 is a valid identifier!";
       System.out.println(\u03b63_3);
       System.out.println(Character.isJavaIdentifierStart('\u03B6'));
       System.out.println(Character.isJavaIdentifierStart('?'));
       System.out.println(Character.isJavaIdentifierStart('��'));
       System.out.println(Character.isJavaIdentifierStart('$'));
       System.out.println(Character.isJavaIdentifierStart('a'));
       System.out.println(Character.isJavaIdentifierStart('?'));
       System.out.println(Character.isJavaIdentifierStart('��'));
   }
}