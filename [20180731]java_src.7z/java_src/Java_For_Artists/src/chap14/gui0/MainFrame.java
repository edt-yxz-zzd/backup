  package chap14.gui0;

  import java.awt.BorderLayout;
  import java.awt.Container;

  import javax.swing.JFrame;

  public class MainFrame extends JFrame {

    private DressingBoard dressingBoard;

    public MainFrame() {
      setTitle(getClass().getName());
      setSize(600, 400);
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

      Container contentPane = getContentPane();
      contentPane.setLayout(new BorderLayout());
      dressingBoard = new DressingBoard();
      contentPane.add("Center", dressingBoard);
    }
    public static void main(String[] arg) {
      new MainFrame().setVisible(true);
    }
   }