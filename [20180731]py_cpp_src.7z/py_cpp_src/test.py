import py_inter as t

print(dir(t))
p = t.print_bytes
pp = lambda bs: bs
p(b'affss')
