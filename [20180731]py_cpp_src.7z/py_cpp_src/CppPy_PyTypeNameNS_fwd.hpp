
namespace PyTypeNameNS{
    extern char const PyObject[];
    extern char const PyBytes[];
}
