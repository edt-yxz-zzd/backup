

#include "CppPy.hpp"

namespace PyTypeNameNS{
    extern char const PyObject[] = "PyObject";
}
