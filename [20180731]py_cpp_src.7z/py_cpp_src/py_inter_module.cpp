
#include "limit_py.h"

#include <vector>
#include <string>
#include <iostream>
#include <stdexcept>
//#include "py_inter.h"
#include "CppPy.hpp"
#include "CppPy_PyTypeNameNS_fwd.hpp"
#include "gil_lock.hpp"





typedef std::vector<unsigned char> T;

static PyObject *print_bytes(PyObject *self, PyObject *args)
{
    PyObject *py_obj = NULL;
    if (! PyArg_ParseTuple(args, "S", &py_obj)) //only bytes
    {
        return NULL;
    }
    
    // Note that any Python object references which are provided to the caller are borrowed references; do not decrement their reference count!
    Py_INCREF(py_obj);

    try{
        T bytes = CppPy<T, PyTypeNameNS::PyBytes>::as(py_obj);
        
        //threads_allow _;
        //std::cout << "here" << std::endl;
        //std::cout << std::string(bytes.begin(), bytes.end()) << std::endl;
        std::string s(bytes.begin(), bytes.end());
        PySys_FormatStdout("%s", s.c_str());
    }
    catch(std::exception& e){
        threads_allow _;
        try {
            std::cerr << e.what() << std::endl;
        }catch(...){}
    }
    
    Py_DECREF(py_obj);
    Py_RETURN_NONE;
}







//////////////////////////////////////////////


static PyMethodDef py_inter_methods[] = {

    {"print_bytes",  print_bytes, METH_VARARGS,
     "print bytes."},
    {NULL, NULL, 0, NULL}        /* Sentinel */
};

static struct PyModuleDef py_inter_module = {
   PyModuleDef_HEAD_INIT,
   "py_inter",   /* name of module */
   NULL, /* module documentation, may be NULL */
   -1,       /* size of per-interpreter state of the module,
                or -1 if the module keeps state in global variables. */
   py_inter_methods
};

PyMODINIT_FUNC
PyInit_py_inter(void)
{
    return PyModule_Create(&py_inter_module);
}



