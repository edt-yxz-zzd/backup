
#include "limit_py.h"

#include <vector>

std::vector<unsigned char> py_bytes_as_cpp_bytes(PyObject *py_bytes);


PyObject *py_bytes_from_cpp_bytes(std::vector<unsigned char> const& cpp_bytes);
