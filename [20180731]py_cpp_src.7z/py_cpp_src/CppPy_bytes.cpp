

#include "CppPy.hpp"
#include "bytes_n_vec.hpp"

typedef std::vector<unsigned char> T;
#define P PyTypeNameNS::PyBytes
namespace PyTypeNameNS{
    extern char const PyBytes[] = "PyBytes";
}

template <>
struct CppPy<T>:CppPy<T, P>{};

template <>
T CppPy<T,P>::as(PyObject *py_obj)
{
    return py_bytes_as_cpp_bytes(py_obj);
}

template <>
PyObject* CppPy<T,P>::from(CppType const& cpp_obj)
{
    return py_bytes_from_cpp_bytes(cpp_obj);
}



