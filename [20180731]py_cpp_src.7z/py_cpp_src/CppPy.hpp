
#include "limit_py.h"

namespace PyTypeNameNS{
    extern char const PyObject[];
}

template <typename T, char const *P = PyTypeNameNS::PyObject>
struct CppPy{
    typedef T CppType;
    static char const PyTypeName[];   
    static CppType as(PyObject *py_obj);
    static PyObject *from(CppType const& cpp_obj);
};


template <typename T, char const *P>
char const CppPy<T, P>::PyTypeName[] = P;

/*
template <typename T, char const P[] = "PyObject">
struct CppPy: CppPyBase<T, P>{
    typedef CppPyBase<T, P> Base;
    typedef typename Base::CppType CppType;
    
};*/
