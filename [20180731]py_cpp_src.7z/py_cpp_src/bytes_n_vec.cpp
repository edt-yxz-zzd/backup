
#include "limit_py.h"

#include <stdexcept>
#include "bytes_n_vec.hpp"

std::vector<unsigned char> py_bytes_as_cpp_bytes(PyObject *py_bytes){
    if (! PyBytes_CheckExact(py_bytes)){
        throw std::invalid_argument(
            "should be \'bytes\' exactly @py_bytes_as_cpp_bytes"); 
    }
    
    Py_ssize_t len = PyBytes_Size(py_bytes);
    unsigned char *begin = (unsigned char*) PyBytes_AsString(py_bytes);
    if (nullptr == begin){
        throw std::logic_error(
            "PyBytes_AsString failed @py_bytes_as_cpp_bytes");
    }

    return std::vector<unsigned char>(begin, begin + len);
}


PyObject *py_bytes_from_cpp_bytes(std::vector<unsigned char> const& cpp_bytes){
    PyObject *r = PyByteArray_FromStringAndSize(
                    (char const*) cpp_bytes.data(), 
                    cpp_bytes.size());
    if (nullptr == r){
        throw std::runtime_error(
            "PyByteArray_FromStringAndSize failed @py_bytes_from_cpp_bytes");
    }
    return r;
}
